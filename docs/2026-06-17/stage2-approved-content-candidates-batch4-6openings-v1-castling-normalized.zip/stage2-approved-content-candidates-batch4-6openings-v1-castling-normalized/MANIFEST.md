# Manifest — Castling Normalized Repair

## Package identity

- Original package name: `stage2-approved-content-candidates-batch4-6openings-v1`
- Repaired package name: `stage2-approved-content-candidates-batch4-6openings-v1-castling-normalized`
- Input zip: `/workspaces/opening-lab/docs/2026-06-11/stage2-approved-content-candidates-batch4-6openings-v1.zip`
- Output zip: `/workspaces/opening-lab/docs/2026-06-11/stage2-approved-content-candidates-batch4-6openings-v1-castling-normalized.zip`

## Counts

- Total lines: 150
- Total packets: 625
- Packets normalized: 86
- Packet IDs changed: 86
- Openings affected by castling normalization: italian-black, kings-indian-black, nimzo-indian-black, queens-indian-black, ruy-lopez-white, scotch-white

## Normalization count by opening

- `italian-black`: 11
- `kings-indian-black`: 25
- `nimzo-indian-black`: 21
- `queens-indian-black`: 9
- `ruy-lopez-white`: 15
- `scotch-white`: 5

## Integrity confirmations

- Opening coverage unchanged: YES
- Packet counts unchanged: YES
- Line counts unchanged: YES
- No app code modified: YES
- No `approvedContentAvailable` flag flipped: YES
- Candidate status preserved: YES

## Next step

Run the app-validation/activation layer using `sourceRuntimeMoveUci` for runtime lookup and normalized `moveUci` / `visualRecipe.targetMoveUci` for app move authority.
