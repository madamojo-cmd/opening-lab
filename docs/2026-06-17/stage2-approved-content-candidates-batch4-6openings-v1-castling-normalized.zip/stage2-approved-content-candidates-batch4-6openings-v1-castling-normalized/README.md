# Stage 2 Approved-Content Candidates Batch 4: 6 Openings v1 — Castling Normalized Repair

This is a repaired Batch 4 candidate package. It normalizes castling UCI from runtime rook-square notation to standard king-destination UCI:

- `e1h1` → `e1g1`
- `e8h8` → `e8g8`
- queenside equivalents are also scanned and normalized if present

The package remains **candidate-only**. It is **not app-activated** and is **not final approved content**. App-side validation must still run before promotion.

Runtime traceability is preserved on every packet:

- `sourceRuntimeMoveUci` = original runtime/source move
- `moveUci` = normalized app-authority target
- `normalizedMoveUci` = normalized app-authority target
- `uciNormalizationApplied` marks whether a packet was changed

No app code was modified and no `approvedContentAvailable` flag was flipped.
