# King’s Indian Defense approved-content candidates — Batch 4

Opening ID: `kings-indian-black`  
Status: approved candidates only; not app-activated.


## kings-indian-black-line-001: 1. d4 Nf6 2. c4 g6 3. Nc3 Bg7 4. e4 d6 5. Nf3 O-O 6. Be2 e5

Runtime playKey: `d2d4,g8f6,c2c4,g7g6,b1c3,f8g7,e2e4,d7d6,g1f3,e8h8,f1e2,e7e5`  
Runtime totalGames field at line node: `1612131`

### Packet kings-indian-black.line-001.ply-04.g7g6

- Move: `g6` / `g7g6` at ply 4

- CoachCard: **Prepare the King’s Indian fianchetto** — g6 prepares the bishop’s long-diagonal role. This is a core King’s Indian idea: pressure White’s center from distance instead of matching every pawn immediately.

- Plain hint: Build the kingside fianchetto that will pressure the long diagonal.

- Opening themes: ...g6 fianchetto, long diagonal, hypermodern center

### Packet kings-indian-black.line-001.ply-06.f8g7

- Move: `Bg7` / `f8g7` at ply 6

- CoachCard: **Complete the King’s Indian bishop** — Bg7 completes the King’s Indian fianchetto. The bishop now works against White’s central and queenside dark squares from a safe distance.

- Plain hint: Place the bishop on the long diagonal so it aims at White’s center.

- Opening themes: ...Bg7 long diagonal, dark-square pressure, KID bishop

### Packet kings-indian-black.line-001.ply-08.d7d6

- Move: `d6` / `d7d6` at ply 8

- CoachCard: **Anchor the King’s Indian center** — d6 gives Black the typical King’s Indian pawn base. It restrains the center and prepares later counterplay such as a supported central break when the pieces are ready.

- Plain hint: Support the compact center before choosing a break.

- Opening themes: ...d6 base, central restraint, KID structure

### Packet kings-indian-black.line-001.ply-10.e8g8

- Move: `O-O` / `e8g8` at ply 10
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle behind the King’s Indian shell** — O-O puts Black’s king behind the fianchetto structure. In the King’s Indian, castling is a prerequisite for confident central or kingside counterplay.

- Plain hint: Secure the king before beginning central counterplay.

- Opening themes: king safety, fianchetto shelter, KID counterplay

### Packet kings-indian-black.line-001.ply-12.e7e5

- Move: `e5` / `e7e5` at ply 12

- CoachCard: **Strike at White’s center with the e-pawn** — e5 challenges White’s broad center after Black has built the King’s Indian setup. The move is a central counterstrike, not a random pawn push.

- Plain hint: Use the prepared central break once the fianchetto and king safety support it.

- Opening themes: ...e5 break, central counterattack, prepared KID strike


## kings-indian-black-line-002: 1. d4 Nf6 2. c4 g6 3. Nc3 Bg7 4. e4 d6 5. Nf3 O-O 6. Be2 Nbd7

Runtime playKey: `d2d4,g8f6,c2c4,g7g6,b1c3,f8g7,e2e4,d7d6,g1f3,e8h8,f1e2,b8d7`  
Runtime totalGames field at line node: `950240`

### Packet kings-indian-black.line-002.ply-04.g7g6

- Move: `g6` / `g7g6` at ply 4

- CoachCard: **Prepare the King’s Indian fianchetto** — g6 prepares the bishop’s long-diagonal role. This is a core King’s Indian idea: pressure White’s center from distance instead of matching every pawn immediately.

- Plain hint: Build the kingside fianchetto that will pressure the long diagonal.

- Opening themes: ...g6 fianchetto, long diagonal, hypermodern center

### Packet kings-indian-black.line-002.ply-06.f8g7

- Move: `Bg7` / `f8g7` at ply 6

- CoachCard: **Complete the King’s Indian bishop** — Bg7 completes the King’s Indian fianchetto. The bishop now works against White’s central and queenside dark squares from a safe distance.

- Plain hint: Place the bishop on the long diagonal so it aims at White’s center.

- Opening themes: ...Bg7 long diagonal, dark-square pressure, KID bishop

### Packet kings-indian-black.line-002.ply-08.d7d6

- Move: `d6` / `d7d6` at ply 8

- CoachCard: **Anchor the King’s Indian center** — d6 gives Black the typical King’s Indian pawn base. It restrains the center and prepares later counterplay such as a supported central break when the pieces are ready.

- Plain hint: Support the compact center before choosing a break.

- Opening themes: ...d6 base, central restraint, KID structure

### Packet kings-indian-black.line-002.ply-10.e8g8

- Move: `O-O` / `e8g8` at ply 10
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle behind the King’s Indian shell** — O-O puts Black’s king behind the fianchetto structure. In the King’s Indian, castling is a prerequisite for confident central or kingside counterplay.

- Plain hint: Secure the king before beginning central counterplay.

- Opening themes: king safety, fianchetto shelter, KID counterplay

### Packet kings-indian-black.line-002.ply-12.b8d7

- Move: `Nbd7` / `b8d7` at ply 12

- CoachCard: **Add support behind the King’s Indian break** — Nbd7 develops the knight toward central support squares. In the King’s Indian, this often backs up ...e5 or helps Black coordinate around White’s center.

- Plain hint: Use the queenside knight to reinforce central pressure before the break.

- Opening themes: knight support, central break preparation, KID coordination


## kings-indian-black-line-003: 1. d4 Nf6 2. c4 g6 3. Nf3 Bg7 4. g3 d6 5. Bg2 O-O 6. O-O Nbd7

Runtime playKey: `d2d4,g8f6,c2c4,g7g6,g1f3,f8g7,g2g3,d7d6,f1g2,e8h8,e1h1,b8d7`  
Runtime totalGames field at line node: `705080`

### Packet kings-indian-black.line-003.ply-04.g7g6

- Move: `g6` / `g7g6` at ply 4

- CoachCard: **Prepare the King’s Indian fianchetto** — g6 prepares the bishop’s long-diagonal role. This is a core King’s Indian idea: pressure White’s center from distance instead of matching every pawn immediately.

- Plain hint: Build the kingside fianchetto that will pressure the long diagonal.

- Opening themes: ...g6 fianchetto, long diagonal, hypermodern center

### Packet kings-indian-black.line-003.ply-06.f8g7

- Move: `Bg7` / `f8g7` at ply 6

- CoachCard: **Complete the King’s Indian bishop** — Bg7 completes the King’s Indian fianchetto. The bishop now works against White’s central and queenside dark squares from a safe distance.

- Plain hint: Place the bishop on the long diagonal so it aims at White’s center.

- Opening themes: ...Bg7 long diagonal, dark-square pressure, KID bishop

### Packet kings-indian-black.line-003.ply-08.d7d6

- Move: `d6` / `d7d6` at ply 8

- CoachCard: **Anchor the King’s Indian center** — d6 gives Black the typical King’s Indian pawn base. It restrains the center and prepares later counterplay such as a supported central break when the pieces are ready.

- Plain hint: Support the compact center before choosing a break.

- Opening themes: ...d6 base, central restraint, KID structure

### Packet kings-indian-black.line-003.ply-10.e8g8

- Move: `O-O` / `e8g8` at ply 10
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle behind the King’s Indian shell** — O-O puts Black’s king behind the fianchetto structure. In the King’s Indian, castling is a prerequisite for confident central or kingside counterplay.

- Plain hint: Secure the king before beginning central counterplay.

- Opening themes: king safety, fianchetto shelter, KID counterplay

### Packet kings-indian-black.line-003.ply-12.b8d7

- Move: `Nbd7` / `b8d7` at ply 12

- CoachCard: **Add support behind the King’s Indian break** — Nbd7 develops the knight toward central support squares. In the King’s Indian, this often backs up ...e5 or helps Black coordinate around White’s center.

- Plain hint: Use the queenside knight to reinforce central pressure before the break.

- Opening themes: knight support, central break preparation, KID coordination


## kings-indian-black-line-004: 1. d4 Nf6 2. c4 g6 3. Nf3 Bg7 4. g3 d6 5. Bg2 O-O 6. O-O Nc6

Runtime playKey: `d2d4,g8f6,c2c4,g7g6,g1f3,f8g7,g2g3,d7d6,f1g2,e8h8,e1h1,b8c6`  
Runtime totalGames field at line node: `605426`

### Packet kings-indian-black.line-004.ply-04.g7g6

- Move: `g6` / `g7g6` at ply 4

- CoachCard: **Prepare the King’s Indian fianchetto** — g6 prepares the bishop’s long-diagonal role. This is a core King’s Indian idea: pressure White’s center from distance instead of matching every pawn immediately.

- Plain hint: Build the kingside fianchetto that will pressure the long diagonal.

- Opening themes: ...g6 fianchetto, long diagonal, hypermodern center

### Packet kings-indian-black.line-004.ply-06.f8g7

- Move: `Bg7` / `f8g7` at ply 6

- CoachCard: **Complete the King’s Indian bishop** — Bg7 completes the King’s Indian fianchetto. The bishop now works against White’s central and queenside dark squares from a safe distance.

- Plain hint: Place the bishop on the long diagonal so it aims at White’s center.

- Opening themes: ...Bg7 long diagonal, dark-square pressure, KID bishop

### Packet kings-indian-black.line-004.ply-08.d7d6

- Move: `d6` / `d7d6` at ply 8

- CoachCard: **Anchor the King’s Indian center** — d6 gives Black the typical King’s Indian pawn base. It restrains the center and prepares later counterplay such as a supported central break when the pieces are ready.

- Plain hint: Support the compact center before choosing a break.

- Opening themes: ...d6 base, central restraint, KID structure

### Packet kings-indian-black.line-004.ply-10.e8g8

- Move: `O-O` / `e8g8` at ply 10
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle behind the King’s Indian shell** — O-O puts Black’s king behind the fianchetto structure. In the King’s Indian, castling is a prerequisite for confident central or kingside counterplay.

- Plain hint: Secure the king before beginning central counterplay.

- Opening themes: king safety, fianchetto shelter, KID counterplay

### Packet kings-indian-black.line-004.ply-12.b8c6

- Move: `Nc6` / `b8c6` at ply 12

- CoachCard: **Add support behind the King’s Indian break** — Nc6 develops the knight toward central support squares. In the King’s Indian, this often backs up ...e5 or helps Black coordinate around White’s center.

- Plain hint: Use the queenside knight to reinforce central pressure before the break.

- Opening themes: knight support, central break preparation, KID coordination


## kings-indian-black-line-005: 1. d4 Nf6 2. c4 g6 3. Nc3 Bg7 4. e4 d6 5. f4 O-O 6. Nf3 c5

Runtime playKey: `d2d4,g8f6,c2c4,g7g6,b1c3,f8g7,e2e4,d7d6,f2f4,e8h8,g1f3,c7c5`  
Runtime totalGames field at line node: `527837`

### Packet kings-indian-black.line-005.ply-04.g7g6

- Move: `g6` / `g7g6` at ply 4

- CoachCard: **Prepare the King’s Indian fianchetto** — g6 prepares the bishop’s long-diagonal role. This is a core King’s Indian idea: pressure White’s center from distance instead of matching every pawn immediately.

- Plain hint: Build the kingside fianchetto that will pressure the long diagonal.

- Opening themes: ...g6 fianchetto, long diagonal, hypermodern center

### Packet kings-indian-black.line-005.ply-06.f8g7

- Move: `Bg7` / `f8g7` at ply 6

- CoachCard: **Complete the King’s Indian bishop** — Bg7 completes the King’s Indian fianchetto. The bishop now works against White’s central and queenside dark squares from a safe distance.

- Plain hint: Place the bishop on the long diagonal so it aims at White’s center.

- Opening themes: ...Bg7 long diagonal, dark-square pressure, KID bishop

### Packet kings-indian-black.line-005.ply-08.d7d6

- Move: `d6` / `d7d6` at ply 8

- CoachCard: **Anchor the King’s Indian center** — d6 gives Black the typical King’s Indian pawn base. It restrains the center and prepares later counterplay such as a supported central break when the pieces are ready.

- Plain hint: Support the compact center before choosing a break.

- Opening themes: ...d6 base, central restraint, KID structure

### Packet kings-indian-black.line-005.ply-10.e8g8

- Move: `O-O` / `e8g8` at ply 10
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle behind the King’s Indian shell** — O-O puts Black’s king behind the fianchetto structure. In the King’s Indian, castling is a prerequisite for confident central or kingside counterplay.

- Plain hint: Secure the king before beginning central counterplay.

- Opening themes: king safety, fianchetto shelter, KID counterplay

### Packet kings-indian-black.line-005.ply-12.c7c5

- Move: `c5` / `c7c5` at ply 12

- CoachCard: **Counter from the queenside against the center** — c5 attacks White’s center from the flank. In King’s Indian structures, ...c5 is a thematic counterbreak when the position supports queenside pressure.

- Plain hint: Challenge White’s central pawns from the side after the KID setup is ready.

- Opening themes: ...c5 break, queenside counterplay, central challenge


## kings-indian-black-line-006: 1. d4 Nf6 2. c4 g6 3. Nf3 Bg7 4. g3 d6 5. Bg2 O-O 6. Nc3 Nbd7

Runtime playKey: `d2d4,g8f6,c2c4,g7g6,g1f3,f8g7,g2g3,d7d6,f1g2,e8h8,b1c3,b8d7`  
Runtime totalGames field at line node: `478588`

### Packet kings-indian-black.line-006.ply-04.g7g6

- Move: `g6` / `g7g6` at ply 4

- CoachCard: **Prepare the King’s Indian fianchetto** — g6 prepares the bishop’s long-diagonal role. This is a core King’s Indian idea: pressure White’s center from distance instead of matching every pawn immediately.

- Plain hint: Build the kingside fianchetto that will pressure the long diagonal.

- Opening themes: ...g6 fianchetto, long diagonal, hypermodern center

### Packet kings-indian-black.line-006.ply-06.f8g7

- Move: `Bg7` / `f8g7` at ply 6

- CoachCard: **Complete the King’s Indian bishop** — Bg7 completes the King’s Indian fianchetto. The bishop now works against White’s central and queenside dark squares from a safe distance.

- Plain hint: Place the bishop on the long diagonal so it aims at White’s center.

- Opening themes: ...Bg7 long diagonal, dark-square pressure, KID bishop

### Packet kings-indian-black.line-006.ply-08.d7d6

- Move: `d6` / `d7d6` at ply 8

- CoachCard: **Anchor the King’s Indian center** — d6 gives Black the typical King’s Indian pawn base. It restrains the center and prepares later counterplay such as a supported central break when the pieces are ready.

- Plain hint: Support the compact center before choosing a break.

- Opening themes: ...d6 base, central restraint, KID structure

### Packet kings-indian-black.line-006.ply-10.e8g8

- Move: `O-O` / `e8g8` at ply 10
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle behind the King’s Indian shell** — O-O puts Black’s king behind the fianchetto structure. In the King’s Indian, castling is a prerequisite for confident central or kingside counterplay.

- Plain hint: Secure the king before beginning central counterplay.

- Opening themes: king safety, fianchetto shelter, KID counterplay

### Packet kings-indian-black.line-006.ply-12.b8d7

- Move: `Nbd7` / `b8d7` at ply 12

- CoachCard: **Add support behind the King’s Indian break** — Nbd7 develops the knight toward central support squares. In the King’s Indian, this often backs up ...e5 or helps Black coordinate around White’s center.

- Plain hint: Use the queenside knight to reinforce central pressure before the break.

- Opening themes: knight support, central break preparation, KID coordination


## kings-indian-black-line-007: 1. d4 Nf6 2. c4 g6 3. Nc3 Bg7 4. e4 d6 5. Nf3 O-O 6. Bd3 Nbd7

Runtime playKey: `d2d4,g8f6,c2c4,g7g6,b1c3,f8g7,e2e4,d7d6,g1f3,e8h8,f1d3,b8d7`  
Runtime totalGames field at line node: `443763`

### Packet kings-indian-black.line-007.ply-04.g7g6

- Move: `g6` / `g7g6` at ply 4

- CoachCard: **Prepare the King’s Indian fianchetto** — g6 prepares the bishop’s long-diagonal role. This is a core King’s Indian idea: pressure White’s center from distance instead of matching every pawn immediately.

- Plain hint: Build the kingside fianchetto that will pressure the long diagonal.

- Opening themes: ...g6 fianchetto, long diagonal, hypermodern center

### Packet kings-indian-black.line-007.ply-06.f8g7

- Move: `Bg7` / `f8g7` at ply 6

- CoachCard: **Complete the King’s Indian bishop** — Bg7 completes the King’s Indian fianchetto. The bishop now works against White’s central and queenside dark squares from a safe distance.

- Plain hint: Place the bishop on the long diagonal so it aims at White’s center.

- Opening themes: ...Bg7 long diagonal, dark-square pressure, KID bishop

### Packet kings-indian-black.line-007.ply-08.d7d6

- Move: `d6` / `d7d6` at ply 8

- CoachCard: **Anchor the King’s Indian center** — d6 gives Black the typical King’s Indian pawn base. It restrains the center and prepares later counterplay such as a supported central break when the pieces are ready.

- Plain hint: Support the compact center before choosing a break.

- Opening themes: ...d6 base, central restraint, KID structure

### Packet kings-indian-black.line-007.ply-10.e8g8

- Move: `O-O` / `e8g8` at ply 10
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle behind the King’s Indian shell** — O-O puts Black’s king behind the fianchetto structure. In the King’s Indian, castling is a prerequisite for confident central or kingside counterplay.

- Plain hint: Secure the king before beginning central counterplay.

- Opening themes: king safety, fianchetto shelter, KID counterplay

### Packet kings-indian-black.line-007.ply-12.b8d7

- Move: `Nbd7` / `b8d7` at ply 12

- CoachCard: **Add support behind the King’s Indian break** — Nbd7 develops the knight toward central support squares. In the King’s Indian, this often backs up ...e5 or helps Black coordinate around White’s center.

- Plain hint: Use the queenside knight to reinforce central pressure before the break.

- Opening themes: knight support, central break preparation, KID coordination


## kings-indian-black-line-008: 1. d4 Nf6 2. c4 g6 3. Nc3 Bg7 4. Nf3 d6 5. Bg5 O-O 6. e3 Nbd7

Runtime playKey: `d2d4,g8f6,c2c4,g7g6,b1c3,f8g7,g1f3,d7d6,c1g5,e8h8,e2e3,b8d7`  
Runtime totalGames field at line node: `438048`

### Packet kings-indian-black.line-008.ply-04.g7g6

- Move: `g6` / `g7g6` at ply 4

- CoachCard: **Prepare the King’s Indian fianchetto** — g6 prepares the bishop’s long-diagonal role. This is a core King’s Indian idea: pressure White’s center from distance instead of matching every pawn immediately.

- Plain hint: Build the kingside fianchetto that will pressure the long diagonal.

- Opening themes: ...g6 fianchetto, long diagonal, hypermodern center

### Packet kings-indian-black.line-008.ply-06.f8g7

- Move: `Bg7` / `f8g7` at ply 6

- CoachCard: **Complete the King’s Indian bishop** — Bg7 completes the King’s Indian fianchetto. The bishop now works against White’s central and queenside dark squares from a safe distance.

- Plain hint: Place the bishop on the long diagonal so it aims at White’s center.

- Opening themes: ...Bg7 long diagonal, dark-square pressure, KID bishop

### Packet kings-indian-black.line-008.ply-08.d7d6

- Move: `d6` / `d7d6` at ply 8

- CoachCard: **Anchor the King’s Indian center** — d6 gives Black the typical King’s Indian pawn base. It restrains the center and prepares later counterplay such as a supported central break when the pieces are ready.

- Plain hint: Support the compact center before choosing a break.

- Opening themes: ...d6 base, central restraint, KID structure

### Packet kings-indian-black.line-008.ply-10.e8g8

- Move: `O-O` / `e8g8` at ply 10
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle behind the King’s Indian shell** — O-O puts Black’s king behind the fianchetto structure. In the King’s Indian, castling is a prerequisite for confident central or kingside counterplay.

- Plain hint: Secure the king before beginning central counterplay.

- Opening themes: king safety, fianchetto shelter, KID counterplay

### Packet kings-indian-black.line-008.ply-12.b8d7

- Move: `Nbd7` / `b8d7` at ply 12

- CoachCard: **Add support behind the King’s Indian break** — Nbd7 develops the knight toward central support squares. In the King’s Indian, this often backs up ...e5 or helps Black coordinate around White’s center.

- Plain hint: Use the queenside knight to reinforce central pressure before the break.

- Opening themes: knight support, central break preparation, KID coordination


## kings-indian-black-line-009: 1. d4 Nf6 2. c4 g6 3. Nf3 Bg7 4. g3 d6 5. Bg2 O-O 6. Nc3 Nc6

Runtime playKey: `d2d4,g8f6,c2c4,g7g6,g1f3,f8g7,g2g3,d7d6,f1g2,e8h8,b1c3,b8c6`  
Runtime totalGames field at line node: `430981`

### Packet kings-indian-black.line-009.ply-04.g7g6

- Move: `g6` / `g7g6` at ply 4

- CoachCard: **Prepare the King’s Indian fianchetto** — g6 prepares the bishop’s long-diagonal role. This is a core King’s Indian idea: pressure White’s center from distance instead of matching every pawn immediately.

- Plain hint: Build the kingside fianchetto that will pressure the long diagonal.

- Opening themes: ...g6 fianchetto, long diagonal, hypermodern center

### Packet kings-indian-black.line-009.ply-06.f8g7

- Move: `Bg7` / `f8g7` at ply 6

- CoachCard: **Complete the King’s Indian bishop** — Bg7 completes the King’s Indian fianchetto. The bishop now works against White’s central and queenside dark squares from a safe distance.

- Plain hint: Place the bishop on the long diagonal so it aims at White’s center.

- Opening themes: ...Bg7 long diagonal, dark-square pressure, KID bishop

### Packet kings-indian-black.line-009.ply-08.d7d6

- Move: `d6` / `d7d6` at ply 8

- CoachCard: **Anchor the King’s Indian center** — d6 gives Black the typical King’s Indian pawn base. It restrains the center and prepares later counterplay such as a supported central break when the pieces are ready.

- Plain hint: Support the compact center before choosing a break.

- Opening themes: ...d6 base, central restraint, KID structure

### Packet kings-indian-black.line-009.ply-10.e8g8

- Move: `O-O` / `e8g8` at ply 10
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle behind the King’s Indian shell** — O-O puts Black’s king behind the fianchetto structure. In the King’s Indian, castling is a prerequisite for confident central or kingside counterplay.

- Plain hint: Secure the king before beginning central counterplay.

- Opening themes: king safety, fianchetto shelter, KID counterplay

### Packet kings-indian-black.line-009.ply-12.b8c6

- Move: `Nc6` / `b8c6` at ply 12

- CoachCard: **Add support behind the King’s Indian break** — Nc6 develops the knight toward central support squares. In the King’s Indian, this often backs up ...e5 or helps Black coordinate around White’s center.

- Plain hint: Use the queenside knight to reinforce central pressure before the break.

- Opening themes: knight support, central break preparation, KID coordination


## kings-indian-black-line-010: 1. d4 Nf6 2. c4 g6 3. Nc3 Bg7 4. Nf3 d6 5. Bg5 O-O 6. e4 Nbd7

Runtime playKey: `d2d4,g8f6,c2c4,g7g6,b1c3,f8g7,g1f3,d7d6,c1g5,e8h8,e2e4,b8d7`  
Runtime totalGames field at line node: `352405`

### Packet kings-indian-black.line-010.ply-04.g7g6

- Move: `g6` / `g7g6` at ply 4

- CoachCard: **Prepare the King’s Indian fianchetto** — g6 prepares the bishop’s long-diagonal role. This is a core King’s Indian idea: pressure White’s center from distance instead of matching every pawn immediately.

- Plain hint: Build the kingside fianchetto that will pressure the long diagonal.

- Opening themes: ...g6 fianchetto, long diagonal, hypermodern center

### Packet kings-indian-black.line-010.ply-06.f8g7

- Move: `Bg7` / `f8g7` at ply 6

- CoachCard: **Complete the King’s Indian bishop** — Bg7 completes the King’s Indian fianchetto. The bishop now works against White’s central and queenside dark squares from a safe distance.

- Plain hint: Place the bishop on the long diagonal so it aims at White’s center.

- Opening themes: ...Bg7 long diagonal, dark-square pressure, KID bishop

### Packet kings-indian-black.line-010.ply-08.d7d6

- Move: `d6` / `d7d6` at ply 8

- CoachCard: **Anchor the King’s Indian center** — d6 gives Black the typical King’s Indian pawn base. It restrains the center and prepares later counterplay such as a supported central break when the pieces are ready.

- Plain hint: Support the compact center before choosing a break.

- Opening themes: ...d6 base, central restraint, KID structure

### Packet kings-indian-black.line-010.ply-10.e8g8

- Move: `O-O` / `e8g8` at ply 10
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle behind the King’s Indian shell** — O-O puts Black’s king behind the fianchetto structure. In the King’s Indian, castling is a prerequisite for confident central or kingside counterplay.

- Plain hint: Secure the king before beginning central counterplay.

- Opening themes: king safety, fianchetto shelter, KID counterplay

### Packet kings-indian-black.line-010.ply-12.b8d7

- Move: `Nbd7` / `b8d7` at ply 12

- CoachCard: **Add support behind the King’s Indian break** — Nbd7 develops the knight toward central support squares. In the King’s Indian, this often backs up ...e5 or helps Black coordinate around White’s center.

- Plain hint: Use the queenside knight to reinforce central pressure before the break.

- Opening themes: knight support, central break preparation, KID coordination


## kings-indian-black-line-011: 1. d4 Nf6 2. c4 g6 3. Nc3 Bg7 4. e4 d6 5. Nf3 O-O 6. Bd3 Bg4

Runtime playKey: `d2d4,g8f6,c2c4,g7g6,b1c3,f8g7,e2e4,d7d6,g1f3,e8h8,f1d3,c8g4`  
Runtime totalGames field at line node: `326551`

### Packet kings-indian-black.line-011.ply-04.g7g6

- Move: `g6` / `g7g6` at ply 4

- CoachCard: **Prepare the King’s Indian fianchetto** — g6 prepares the bishop’s long-diagonal role. This is a core King’s Indian idea: pressure White’s center from distance instead of matching every pawn immediately.

- Plain hint: Build the kingside fianchetto that will pressure the long diagonal.

- Opening themes: ...g6 fianchetto, long diagonal, hypermodern center

### Packet kings-indian-black.line-011.ply-06.f8g7

- Move: `Bg7` / `f8g7` at ply 6

- CoachCard: **Complete the King’s Indian bishop** — Bg7 completes the King’s Indian fianchetto. The bishop now works against White’s central and queenside dark squares from a safe distance.

- Plain hint: Place the bishop on the long diagonal so it aims at White’s center.

- Opening themes: ...Bg7 long diagonal, dark-square pressure, KID bishop

### Packet kings-indian-black.line-011.ply-08.d7d6

- Move: `d6` / `d7d6` at ply 8

- CoachCard: **Anchor the King’s Indian center** — d6 gives Black the typical King’s Indian pawn base. It restrains the center and prepares later counterplay such as a supported central break when the pieces are ready.

- Plain hint: Support the compact center before choosing a break.

- Opening themes: ...d6 base, central restraint, KID structure

### Packet kings-indian-black.line-011.ply-10.e8g8

- Move: `O-O` / `e8g8` at ply 10
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle behind the King’s Indian shell** — O-O puts Black’s king behind the fianchetto structure. In the King’s Indian, castling is a prerequisite for confident central or kingside counterplay.

- Plain hint: Secure the king before beginning central counterplay.

- Opening themes: king safety, fianchetto shelter, KID counterplay

### Packet kings-indian-black.line-011.ply-12.c8g4

- Move: `Bg4` / `c8g4` at ply 12

- CoachCard: **Keep the King’s Indian counterattack coherent** — Bg4 supports Black’s King’s Indian plan of fianchetto pressure, central restraint, and timed counterplay against White’s space.

- Plain hint: Tie the move to the fianchetto, king safety, or a prepared strike at White’s center.

- Opening themes: KID coordination, hypermodern pressure, central counterplay


## kings-indian-black-line-012: 1. d4 Nf6 2. c4 g6 3. Nc3 Bg7 4. e4 d6 5. f4 O-O 6. Nf3 Bg4

Runtime playKey: `d2d4,g8f6,c2c4,g7g6,b1c3,f8g7,e2e4,d7d6,f2f4,e8h8,g1f3,c8g4`  
Runtime totalGames field at line node: `247481`

### Packet kings-indian-black.line-012.ply-04.g7g6

- Move: `g6` / `g7g6` at ply 4

- CoachCard: **Prepare the King’s Indian fianchetto** — g6 prepares the bishop’s long-diagonal role. This is a core King’s Indian idea: pressure White’s center from distance instead of matching every pawn immediately.

- Plain hint: Build the kingside fianchetto that will pressure the long diagonal.

- Opening themes: ...g6 fianchetto, long diagonal, hypermodern center

### Packet kings-indian-black.line-012.ply-06.f8g7

- Move: `Bg7` / `f8g7` at ply 6

- CoachCard: **Complete the King’s Indian bishop** — Bg7 completes the King’s Indian fianchetto. The bishop now works against White’s central and queenside dark squares from a safe distance.

- Plain hint: Place the bishop on the long diagonal so it aims at White’s center.

- Opening themes: ...Bg7 long diagonal, dark-square pressure, KID bishop

### Packet kings-indian-black.line-012.ply-08.d7d6

- Move: `d6` / `d7d6` at ply 8

- CoachCard: **Anchor the King’s Indian center** — d6 gives Black the typical King’s Indian pawn base. It restrains the center and prepares later counterplay such as a supported central break when the pieces are ready.

- Plain hint: Support the compact center before choosing a break.

- Opening themes: ...d6 base, central restraint, KID structure

### Packet kings-indian-black.line-012.ply-10.e8g8

- Move: `O-O` / `e8g8` at ply 10
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle behind the King’s Indian shell** — O-O puts Black’s king behind the fianchetto structure. In the King’s Indian, castling is a prerequisite for confident central or kingside counterplay.

- Plain hint: Secure the king before beginning central counterplay.

- Opening themes: king safety, fianchetto shelter, KID counterplay

### Packet kings-indian-black.line-012.ply-12.c8g4

- Move: `Bg4` / `c8g4` at ply 12

- CoachCard: **Keep the King’s Indian counterattack coherent** — Bg4 supports Black’s King’s Indian plan of fianchetto pressure, central restraint, and timed counterplay against White’s space.

- Plain hint: Tie the move to the fianchetto, king safety, or a prepared strike at White’s center.

- Opening themes: KID coordination, hypermodern pressure, central counterplay


## kings-indian-black-line-013: 1. d4 Nf6 2. c4 g6 3. Nc3 Bg7 4. Nf3 d6 5. Bg5 O-O 6. e4 h6

Runtime playKey: `d2d4,g8f6,c2c4,g7g6,b1c3,f8g7,g1f3,d7d6,c1g5,e8h8,e2e4,h7h6`  
Runtime totalGames field at line node: `220875`

### Packet kings-indian-black.line-013.ply-04.g7g6

- Move: `g6` / `g7g6` at ply 4

- CoachCard: **Prepare the King’s Indian fianchetto** — g6 prepares the bishop’s long-diagonal role. This is a core King’s Indian idea: pressure White’s center from distance instead of matching every pawn immediately.

- Plain hint: Build the kingside fianchetto that will pressure the long diagonal.

- Opening themes: ...g6 fianchetto, long diagonal, hypermodern center

### Packet kings-indian-black.line-013.ply-06.f8g7

- Move: `Bg7` / `f8g7` at ply 6

- CoachCard: **Complete the King’s Indian bishop** — Bg7 completes the King’s Indian fianchetto. The bishop now works against White’s central and queenside dark squares from a safe distance.

- Plain hint: Place the bishop on the long diagonal so it aims at White’s center.

- Opening themes: ...Bg7 long diagonal, dark-square pressure, KID bishop

### Packet kings-indian-black.line-013.ply-08.d7d6

- Move: `d6` / `d7d6` at ply 8

- CoachCard: **Anchor the King’s Indian center** — d6 gives Black the typical King’s Indian pawn base. It restrains the center and prepares later counterplay such as a supported central break when the pieces are ready.

- Plain hint: Support the compact center before choosing a break.

- Opening themes: ...d6 base, central restraint, KID structure

### Packet kings-indian-black.line-013.ply-10.e8g8

- Move: `O-O` / `e8g8` at ply 10
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle behind the King’s Indian shell** — O-O puts Black’s king behind the fianchetto structure. In the King’s Indian, castling is a prerequisite for confident central or kingside counterplay.

- Plain hint: Secure the king before beginning central counterplay.

- Opening themes: king safety, fianchetto shelter, KID counterplay

### Packet kings-indian-black.line-013.ply-12.h7h6

- Move: `h6` / `h7h6` at ply 12

- CoachCard: **Control the bishop’s pin in the KID setup** — h6 questions a bishop that can bother Black’s knight or kingside structure. In King’s Indian lines, this is relevant only when the center is otherwise supported.

- Plain hint: Ask White’s bishop to clarify before central play begins.

- Opening themes: bishop question, KID shelter, central stability


## kings-indian-black-line-014: 1. d4 Nf6 2. c4 g6 3. Nc3 Bg7 4. e4 d6 5. f4 O-O 6. e5 dxe5

Runtime playKey: `d2d4,g8f6,c2c4,g7g6,b1c3,f8g7,e2e4,d7d6,f2f4,e8h8,e4e5,d6e5`  
Runtime totalGames field at line node: `186102`

### Packet kings-indian-black.line-014.ply-04.g7g6

- Move: `g6` / `g7g6` at ply 4

- CoachCard: **Prepare the King’s Indian fianchetto** — g6 prepares the bishop’s long-diagonal role. This is a core King’s Indian idea: pressure White’s center from distance instead of matching every pawn immediately.

- Plain hint: Build the kingside fianchetto that will pressure the long diagonal.

- Opening themes: ...g6 fianchetto, long diagonal, hypermodern center

### Packet kings-indian-black.line-014.ply-06.f8g7

- Move: `Bg7` / `f8g7` at ply 6

- CoachCard: **Complete the King’s Indian bishop** — Bg7 completes the King’s Indian fianchetto. The bishop now works against White’s central and queenside dark squares from a safe distance.

- Plain hint: Place the bishop on the long diagonal so it aims at White’s center.

- Opening themes: ...Bg7 long diagonal, dark-square pressure, KID bishop

### Packet kings-indian-black.line-014.ply-08.d7d6

- Move: `d6` / `d7d6` at ply 8

- CoachCard: **Anchor the King’s Indian center** — d6 gives Black the typical King’s Indian pawn base. It restrains the center and prepares later counterplay such as a supported central break when the pieces are ready.

- Plain hint: Support the compact center before choosing a break.

- Opening themes: ...d6 base, central restraint, KID structure

### Packet kings-indian-black.line-014.ply-10.e8g8

- Move: `O-O` / `e8g8` at ply 10
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle behind the King’s Indian shell** — O-O puts Black’s king behind the fianchetto structure. In the King’s Indian, castling is a prerequisite for confident central or kingside counterplay.

- Plain hint: Secure the king before beginning central counterplay.

- Opening themes: king safety, fianchetto shelter, KID counterplay

### Packet kings-indian-black.line-014.ply-12.d6e5

- Move: `dxe5` / `d6e5` at ply 12

- CoachCard: **Keep the King’s Indian counterattack coherent** — dxe5 supports Black’s King’s Indian plan of fianchetto pressure, central restraint, and timed counterplay against White’s space.

- Plain hint: Tie the move to the fianchetto, king safety, or a prepared strike at White’s center.

- Opening themes: KID coordination, hypermodern pressure, central counterplay


## kings-indian-black-line-015: 1. d4 Nf6 2. c4 g6 3. Nc3 Bg7 4. Nf3 d6 5. Bg5 O-O 6. e3 h6

Runtime playKey: `d2d4,g8f6,c2c4,g7g6,b1c3,f8g7,g1f3,d7d6,c1g5,e8h8,e2e3,h7h6`  
Runtime totalGames field at line node: `168226`

### Packet kings-indian-black.line-015.ply-04.g7g6

- Move: `g6` / `g7g6` at ply 4

- CoachCard: **Prepare the King’s Indian fianchetto** — g6 prepares the bishop’s long-diagonal role. This is a core King’s Indian idea: pressure White’s center from distance instead of matching every pawn immediately.

- Plain hint: Build the kingside fianchetto that will pressure the long diagonal.

- Opening themes: ...g6 fianchetto, long diagonal, hypermodern center

### Packet kings-indian-black.line-015.ply-06.f8g7

- Move: `Bg7` / `f8g7` at ply 6

- CoachCard: **Complete the King’s Indian bishop** — Bg7 completes the King’s Indian fianchetto. The bishop now works against White’s central and queenside dark squares from a safe distance.

- Plain hint: Place the bishop on the long diagonal so it aims at White’s center.

- Opening themes: ...Bg7 long diagonal, dark-square pressure, KID bishop

### Packet kings-indian-black.line-015.ply-08.d7d6

- Move: `d6` / `d7d6` at ply 8

- CoachCard: **Anchor the King’s Indian center** — d6 gives Black the typical King’s Indian pawn base. It restrains the center and prepares later counterplay such as a supported central break when the pieces are ready.

- Plain hint: Support the compact center before choosing a break.

- Opening themes: ...d6 base, central restraint, KID structure

### Packet kings-indian-black.line-015.ply-10.e8g8

- Move: `O-O` / `e8g8` at ply 10
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle behind the King’s Indian shell** — O-O puts Black’s king behind the fianchetto structure. In the King’s Indian, castling is a prerequisite for confident central or kingside counterplay.

- Plain hint: Secure the king before beginning central counterplay.

- Opening themes: king safety, fianchetto shelter, KID counterplay

### Packet kings-indian-black.line-015.ply-12.h7h6

- Move: `h6` / `h7h6` at ply 12

- CoachCard: **Control the bishop’s pin in the KID setup** — h6 questions a bishop that can bother Black’s knight or kingside structure. In King’s Indian lines, this is relevant only when the center is otherwise supported.

- Plain hint: Ask White’s bishop to clarify before central play begins.

- Opening themes: bishop question, KID shelter, central stability


## kings-indian-black-line-016: 1. d4 Nf6 2. c4 g6 3. Nc3 Bg7 4. e4 d6 5. f4 O-O 6. e5 Nfd7

Runtime playKey: `d2d4,g8f6,c2c4,g7g6,b1c3,f8g7,e2e4,d7d6,f2f4,e8h8,e4e5,f6d7`  
Runtime totalGames field at line node: `32359`

### Packet kings-indian-black.line-016.ply-04.g7g6

- Move: `g6` / `g7g6` at ply 4

- CoachCard: **Prepare the King’s Indian fianchetto** — g6 prepares the bishop’s long-diagonal role. This is a core King’s Indian idea: pressure White’s center from distance instead of matching every pawn immediately.

- Plain hint: Build the kingside fianchetto that will pressure the long diagonal.

- Opening themes: ...g6 fianchetto, long diagonal, hypermodern center

### Packet kings-indian-black.line-016.ply-06.f8g7

- Move: `Bg7` / `f8g7` at ply 6

- CoachCard: **Complete the King’s Indian bishop** — Bg7 completes the King’s Indian fianchetto. The bishop now works against White’s central and queenside dark squares from a safe distance.

- Plain hint: Place the bishop on the long diagonal so it aims at White’s center.

- Opening themes: ...Bg7 long diagonal, dark-square pressure, KID bishop

### Packet kings-indian-black.line-016.ply-08.d7d6

- Move: `d6` / `d7d6` at ply 8

- CoachCard: **Anchor the King’s Indian center** — d6 gives Black the typical King’s Indian pawn base. It restrains the center and prepares later counterplay such as a supported central break when the pieces are ready.

- Plain hint: Support the compact center before choosing a break.

- Opening themes: ...d6 base, central restraint, KID structure

### Packet kings-indian-black.line-016.ply-10.e8g8

- Move: `O-O` / `e8g8` at ply 10
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle behind the King’s Indian shell** — O-O puts Black’s king behind the fianchetto structure. In the King’s Indian, castling is a prerequisite for confident central or kingside counterplay.

- Plain hint: Secure the king before beginning central counterplay.

- Opening themes: king safety, fianchetto shelter, KID counterplay

### Packet kings-indian-black.line-016.ply-12.f6d7

- Move: `Nfd7` / `f6d7` at ply 12

- CoachCard: **Keep the King’s Indian counterattack coherent** — Nfd7 supports Black’s King’s Indian plan of fianchetto pressure, central restraint, and timed counterplay against White’s space.

- Plain hint: Tie the move to the fianchetto, king safety, or a prepared strike at White’s center.

- Opening themes: KID coordination, hypermodern pressure, central counterplay


## kings-indian-black-line-017: 1. d4 Nf6 2. c4 g6 3. Nc3 Bg7 4. Nf3 d6 5. e4 O-O 6. Be2 e5

Runtime playKey: `d2d4,g8f6,c2c4,g7g6,b1c3,f8g7,g1f3,d7d6,e2e4,e8h8,f1e2,e7e5`  
Runtime totalGames field at line node: `1612131`

### Packet kings-indian-black.line-017.ply-04.g7g6

- Move: `g6` / `g7g6` at ply 4

- CoachCard: **Prepare the King’s Indian fianchetto** — g6 prepares the bishop’s long-diagonal role. This is a core King’s Indian idea: pressure White’s center from distance instead of matching every pawn immediately.

- Plain hint: Build the kingside fianchetto that will pressure the long diagonal.

- Opening themes: ...g6 fianchetto, long diagonal, hypermodern center

### Packet kings-indian-black.line-017.ply-06.f8g7

- Move: `Bg7` / `f8g7` at ply 6

- CoachCard: **Complete the King’s Indian bishop** — Bg7 completes the King’s Indian fianchetto. The bishop now works against White’s central and queenside dark squares from a safe distance.

- Plain hint: Place the bishop on the long diagonal so it aims at White’s center.

- Opening themes: ...Bg7 long diagonal, dark-square pressure, KID bishop

### Packet kings-indian-black.line-017.ply-08.d7d6

- Move: `d6` / `d7d6` at ply 8

- CoachCard: **Anchor the King’s Indian center** — d6 gives Black the typical King’s Indian pawn base. It restrains the center and prepares later counterplay such as a supported central break when the pieces are ready.

- Plain hint: Support the compact center before choosing a break.

- Opening themes: ...d6 base, central restraint, KID structure

### Packet kings-indian-black.line-017.ply-10.e8g8

- Move: `O-O` / `e8g8` at ply 10
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle behind the King’s Indian shell** — O-O puts Black’s king behind the fianchetto structure. In the King’s Indian, castling is a prerequisite for confident central or kingside counterplay.

- Plain hint: Secure the king before beginning central counterplay.

- Opening themes: king safety, fianchetto shelter, KID counterplay

### Packet kings-indian-black.line-017.ply-12.e7e5

- Move: `e5` / `e7e5` at ply 12

- CoachCard: **Strike at White’s center with the e-pawn** — e5 challenges White’s broad center after Black has built the King’s Indian setup. The move is a central counterstrike, not a random pawn push.

- Plain hint: Use the prepared central break once the fianchetto and king safety support it.

- Opening themes: ...e5 break, central counterattack, prepared KID strike


## kings-indian-black-line-018: 1. d4 Nf6 2. c4 g6 3. Nf3 Bg7 4. Nc3 d6 5. e4 O-O 6. Be2 e5

Runtime playKey: `d2d4,g8f6,c2c4,g7g6,g1f3,f8g7,b1c3,d7d6,e2e4,e8h8,f1e2,e7e5`  
Runtime totalGames field at line node: `1612131`

### Packet kings-indian-black.line-018.ply-04.g7g6

- Move: `g6` / `g7g6` at ply 4

- CoachCard: **Prepare the King’s Indian fianchetto** — g6 prepares the bishop’s long-diagonal role. This is a core King’s Indian idea: pressure White’s center from distance instead of matching every pawn immediately.

- Plain hint: Build the kingside fianchetto that will pressure the long diagonal.

- Opening themes: ...g6 fianchetto, long diagonal, hypermodern center

### Packet kings-indian-black.line-018.ply-06.f8g7

- Move: `Bg7` / `f8g7` at ply 6

- CoachCard: **Complete the King’s Indian bishop** — Bg7 completes the King’s Indian fianchetto. The bishop now works against White’s central and queenside dark squares from a safe distance.

- Plain hint: Place the bishop on the long diagonal so it aims at White’s center.

- Opening themes: ...Bg7 long diagonal, dark-square pressure, KID bishop

### Packet kings-indian-black.line-018.ply-08.d7d6

- Move: `d6` / `d7d6` at ply 8

- CoachCard: **Anchor the King’s Indian center** — d6 gives Black the typical King’s Indian pawn base. It restrains the center and prepares later counterplay such as a supported central break when the pieces are ready.

- Plain hint: Support the compact center before choosing a break.

- Opening themes: ...d6 base, central restraint, KID structure

### Packet kings-indian-black.line-018.ply-10.e8g8

- Move: `O-O` / `e8g8` at ply 10
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle behind the King’s Indian shell** — O-O puts Black’s king behind the fianchetto structure. In the King’s Indian, castling is a prerequisite for confident central or kingside counterplay.

- Plain hint: Secure the king before beginning central counterplay.

- Opening themes: king safety, fianchetto shelter, KID counterplay

### Packet kings-indian-black.line-018.ply-12.e7e5

- Move: `e5` / `e7e5` at ply 12

- CoachCard: **Strike at White’s center with the e-pawn** — e5 challenges White’s broad center after Black has built the King’s Indian setup. The move is a central counterstrike, not a random pawn push.

- Plain hint: Use the prepared central break once the fianchetto and king safety support it.

- Opening themes: ...e5 break, central counterattack, prepared KID strike


## kings-indian-black-line-019: 1. d4 Nf6 2. c4 g6 3. Nc3 Bg7 4. Nf3 d6 5. e4 O-O 6. Be2 Nbd7

Runtime playKey: `d2d4,g8f6,c2c4,g7g6,b1c3,f8g7,g1f3,d7d6,e2e4,e8h8,f1e2,b8d7`  
Runtime totalGames field at line node: `950240`

### Packet kings-indian-black.line-019.ply-04.g7g6

- Move: `g6` / `g7g6` at ply 4

- CoachCard: **Prepare the King’s Indian fianchetto** — g6 prepares the bishop’s long-diagonal role. This is a core King’s Indian idea: pressure White’s center from distance instead of matching every pawn immediately.

- Plain hint: Build the kingside fianchetto that will pressure the long diagonal.

- Opening themes: ...g6 fianchetto, long diagonal, hypermodern center

### Packet kings-indian-black.line-019.ply-06.f8g7

- Move: `Bg7` / `f8g7` at ply 6

- CoachCard: **Complete the King’s Indian bishop** — Bg7 completes the King’s Indian fianchetto. The bishop now works against White’s central and queenside dark squares from a safe distance.

- Plain hint: Place the bishop on the long diagonal so it aims at White’s center.

- Opening themes: ...Bg7 long diagonal, dark-square pressure, KID bishop

### Packet kings-indian-black.line-019.ply-08.d7d6

- Move: `d6` / `d7d6` at ply 8

- CoachCard: **Anchor the King’s Indian center** — d6 gives Black the typical King’s Indian pawn base. It restrains the center and prepares later counterplay such as a supported central break when the pieces are ready.

- Plain hint: Support the compact center before choosing a break.

- Opening themes: ...d6 base, central restraint, KID structure

### Packet kings-indian-black.line-019.ply-10.e8g8

- Move: `O-O` / `e8g8` at ply 10
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle behind the King’s Indian shell** — O-O puts Black’s king behind the fianchetto structure. In the King’s Indian, castling is a prerequisite for confident central or kingside counterplay.

- Plain hint: Secure the king before beginning central counterplay.

- Opening themes: king safety, fianchetto shelter, KID counterplay

### Packet kings-indian-black.line-019.ply-12.b8d7

- Move: `Nbd7` / `b8d7` at ply 12

- CoachCard: **Add support behind the King’s Indian break** — Nbd7 develops the knight toward central support squares. In the King’s Indian, this often backs up ...e5 or helps Black coordinate around White’s center.

- Plain hint: Use the queenside knight to reinforce central pressure before the break.

- Opening themes: knight support, central break preparation, KID coordination


## kings-indian-black-line-020: 1. d4 Nf6 2. c4 g6 3. Nf3 Bg7 4. Nc3 d6 5. e4 O-O 6. Be2 Nbd7

Runtime playKey: `d2d4,g8f6,c2c4,g7g6,g1f3,f8g7,b1c3,d7d6,e2e4,e8h8,f1e2,b8d7`  
Runtime totalGames field at line node: `950240`

### Packet kings-indian-black.line-020.ply-04.g7g6

- Move: `g6` / `g7g6` at ply 4

- CoachCard: **Prepare the King’s Indian fianchetto** — g6 prepares the bishop’s long-diagonal role. This is a core King’s Indian idea: pressure White’s center from distance instead of matching every pawn immediately.

- Plain hint: Build the kingside fianchetto that will pressure the long diagonal.

- Opening themes: ...g6 fianchetto, long diagonal, hypermodern center

### Packet kings-indian-black.line-020.ply-06.f8g7

- Move: `Bg7` / `f8g7` at ply 6

- CoachCard: **Complete the King’s Indian bishop** — Bg7 completes the King’s Indian fianchetto. The bishop now works against White’s central and queenside dark squares from a safe distance.

- Plain hint: Place the bishop on the long diagonal so it aims at White’s center.

- Opening themes: ...Bg7 long diagonal, dark-square pressure, KID bishop

### Packet kings-indian-black.line-020.ply-08.d7d6

- Move: `d6` / `d7d6` at ply 8

- CoachCard: **Anchor the King’s Indian center** — d6 gives Black the typical King’s Indian pawn base. It restrains the center and prepares later counterplay such as a supported central break when the pieces are ready.

- Plain hint: Support the compact center before choosing a break.

- Opening themes: ...d6 base, central restraint, KID structure

### Packet kings-indian-black.line-020.ply-10.e8g8

- Move: `O-O` / `e8g8` at ply 10
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle behind the King’s Indian shell** — O-O puts Black’s king behind the fianchetto structure. In the King’s Indian, castling is a prerequisite for confident central or kingside counterplay.

- Plain hint: Secure the king before beginning central counterplay.

- Opening themes: king safety, fianchetto shelter, KID counterplay

### Packet kings-indian-black.line-020.ply-12.b8d7

- Move: `Nbd7` / `b8d7` at ply 12

- CoachCard: **Add support behind the King’s Indian break** — Nbd7 develops the knight toward central support squares. In the King’s Indian, this often backs up ...e5 or helps Black coordinate around White’s center.

- Plain hint: Use the queenside knight to reinforce central pressure before the break.

- Opening themes: knight support, central break preparation, KID coordination


## kings-indian-black-line-021: 1. d4 Nf6 2. c4 g6 3. Nc3 Bg7 4. Nf3 d6 5. e4 O-O 6. Bd3 Nbd7

Runtime playKey: `d2d4,g8f6,c2c4,g7g6,b1c3,f8g7,g1f3,d7d6,e2e4,e8h8,f1d3,b8d7`  
Runtime totalGames field at line node: `443763`

### Packet kings-indian-black.line-021.ply-04.g7g6

- Move: `g6` / `g7g6` at ply 4

- CoachCard: **Prepare the King’s Indian fianchetto** — g6 prepares the bishop’s long-diagonal role. This is a core King’s Indian idea: pressure White’s center from distance instead of matching every pawn immediately.

- Plain hint: Build the kingside fianchetto that will pressure the long diagonal.

- Opening themes: ...g6 fianchetto, long diagonal, hypermodern center

### Packet kings-indian-black.line-021.ply-06.f8g7

- Move: `Bg7` / `f8g7` at ply 6

- CoachCard: **Complete the King’s Indian bishop** — Bg7 completes the King’s Indian fianchetto. The bishop now works against White’s central and queenside dark squares from a safe distance.

- Plain hint: Place the bishop on the long diagonal so it aims at White’s center.

- Opening themes: ...Bg7 long diagonal, dark-square pressure, KID bishop

### Packet kings-indian-black.line-021.ply-08.d7d6

- Move: `d6` / `d7d6` at ply 8

- CoachCard: **Anchor the King’s Indian center** — d6 gives Black the typical King’s Indian pawn base. It restrains the center and prepares later counterplay such as a supported central break when the pieces are ready.

- Plain hint: Support the compact center before choosing a break.

- Opening themes: ...d6 base, central restraint, KID structure

### Packet kings-indian-black.line-021.ply-10.e8g8

- Move: `O-O` / `e8g8` at ply 10
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle behind the King’s Indian shell** — O-O puts Black’s king behind the fianchetto structure. In the King’s Indian, castling is a prerequisite for confident central or kingside counterplay.

- Plain hint: Secure the king before beginning central counterplay.

- Opening themes: king safety, fianchetto shelter, KID counterplay

### Packet kings-indian-black.line-021.ply-12.b8d7

- Move: `Nbd7` / `b8d7` at ply 12

- CoachCard: **Add support behind the King’s Indian break** — Nbd7 develops the knight toward central support squares. In the King’s Indian, this often backs up ...e5 or helps Black coordinate around White’s center.

- Plain hint: Use the queenside knight to reinforce central pressure before the break.

- Opening themes: knight support, central break preparation, KID coordination


## kings-indian-black-line-022: 1. d4 Nf6 2. c4 g6 3. Nf3 Bg7 4. Nc3 d6 5. e4 O-O 6. Bd3 Nbd7

Runtime playKey: `d2d4,g8f6,c2c4,g7g6,g1f3,f8g7,b1c3,d7d6,e2e4,e8h8,f1d3,b8d7`  
Runtime totalGames field at line node: `443763`

### Packet kings-indian-black.line-022.ply-04.g7g6

- Move: `g6` / `g7g6` at ply 4

- CoachCard: **Prepare the King’s Indian fianchetto** — g6 prepares the bishop’s long-diagonal role. This is a core King’s Indian idea: pressure White’s center from distance instead of matching every pawn immediately.

- Plain hint: Build the kingside fianchetto that will pressure the long diagonal.

- Opening themes: ...g6 fianchetto, long diagonal, hypermodern center

### Packet kings-indian-black.line-022.ply-06.f8g7

- Move: `Bg7` / `f8g7` at ply 6

- CoachCard: **Complete the King’s Indian bishop** — Bg7 completes the King’s Indian fianchetto. The bishop now works against White’s central and queenside dark squares from a safe distance.

- Plain hint: Place the bishop on the long diagonal so it aims at White’s center.

- Opening themes: ...Bg7 long diagonal, dark-square pressure, KID bishop

### Packet kings-indian-black.line-022.ply-08.d7d6

- Move: `d6` / `d7d6` at ply 8

- CoachCard: **Anchor the King’s Indian center** — d6 gives Black the typical King’s Indian pawn base. It restrains the center and prepares later counterplay such as a supported central break when the pieces are ready.

- Plain hint: Support the compact center before choosing a break.

- Opening themes: ...d6 base, central restraint, KID structure

### Packet kings-indian-black.line-022.ply-10.e8g8

- Move: `O-O` / `e8g8` at ply 10
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle behind the King’s Indian shell** — O-O puts Black’s king behind the fianchetto structure. In the King’s Indian, castling is a prerequisite for confident central or kingside counterplay.

- Plain hint: Secure the king before beginning central counterplay.

- Opening themes: king safety, fianchetto shelter, KID counterplay

### Packet kings-indian-black.line-022.ply-12.b8d7

- Move: `Nbd7` / `b8d7` at ply 12

- CoachCard: **Add support behind the King’s Indian break** — Nbd7 develops the knight toward central support squares. In the King’s Indian, this often backs up ...e5 or helps Black coordinate around White’s center.

- Plain hint: Use the queenside knight to reinforce central pressure before the break.

- Opening themes: knight support, central break preparation, KID coordination


## kings-indian-black-line-023: 1. d4 Nf6 2. c4 g6 3. Nf3 Bg7 4. Nc3 d6 5. Bg5 O-O 6. e3 Nbd7

Runtime playKey: `d2d4,g8f6,c2c4,g7g6,g1f3,f8g7,b1c3,d7d6,c1g5,e8h8,e2e3,b8d7`  
Runtime totalGames field at line node: `438048`

### Packet kings-indian-black.line-023.ply-04.g7g6

- Move: `g6` / `g7g6` at ply 4

- CoachCard: **Prepare the King’s Indian fianchetto** — g6 prepares the bishop’s long-diagonal role. This is a core King’s Indian idea: pressure White’s center from distance instead of matching every pawn immediately.

- Plain hint: Build the kingside fianchetto that will pressure the long diagonal.

- Opening themes: ...g6 fianchetto, long diagonal, hypermodern center

### Packet kings-indian-black.line-023.ply-06.f8g7

- Move: `Bg7` / `f8g7` at ply 6

- CoachCard: **Complete the King’s Indian bishop** — Bg7 completes the King’s Indian fianchetto. The bishop now works against White’s central and queenside dark squares from a safe distance.

- Plain hint: Place the bishop on the long diagonal so it aims at White’s center.

- Opening themes: ...Bg7 long diagonal, dark-square pressure, KID bishop

### Packet kings-indian-black.line-023.ply-08.d7d6

- Move: `d6` / `d7d6` at ply 8

- CoachCard: **Anchor the King’s Indian center** — d6 gives Black the typical King’s Indian pawn base. It restrains the center and prepares later counterplay such as a supported central break when the pieces are ready.

- Plain hint: Support the compact center before choosing a break.

- Opening themes: ...d6 base, central restraint, KID structure

### Packet kings-indian-black.line-023.ply-10.e8g8

- Move: `O-O` / `e8g8` at ply 10
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle behind the King’s Indian shell** — O-O puts Black’s king behind the fianchetto structure. In the King’s Indian, castling is a prerequisite for confident central or kingside counterplay.

- Plain hint: Secure the king before beginning central counterplay.

- Opening themes: king safety, fianchetto shelter, KID counterplay

### Packet kings-indian-black.line-023.ply-12.b8d7

- Move: `Nbd7` / `b8d7` at ply 12

- CoachCard: **Add support behind the King’s Indian break** — Nbd7 develops the knight toward central support squares. In the King’s Indian, this often backs up ...e5 or helps Black coordinate around White’s center.

- Plain hint: Use the queenside knight to reinforce central pressure before the break.

- Opening themes: knight support, central break preparation, KID coordination


## kings-indian-black-line-024: 1. d4 Nf6 2. c4 g6 3. Nf3 Bg7 4. Nc3 d6 5. Bg5 O-O 6. e4 Nbd7

Runtime playKey: `d2d4,g8f6,c2c4,g7g6,g1f3,f8g7,b1c3,d7d6,c1g5,e8h8,e2e4,b8d7`  
Runtime totalGames field at line node: `352405`

### Packet kings-indian-black.line-024.ply-04.g7g6

- Move: `g6` / `g7g6` at ply 4

- CoachCard: **Prepare the King’s Indian fianchetto** — g6 prepares the bishop’s long-diagonal role. This is a core King’s Indian idea: pressure White’s center from distance instead of matching every pawn immediately.

- Plain hint: Build the kingside fianchetto that will pressure the long diagonal.

- Opening themes: ...g6 fianchetto, long diagonal, hypermodern center

### Packet kings-indian-black.line-024.ply-06.f8g7

- Move: `Bg7` / `f8g7` at ply 6

- CoachCard: **Complete the King’s Indian bishop** — Bg7 completes the King’s Indian fianchetto. The bishop now works against White’s central and queenside dark squares from a safe distance.

- Plain hint: Place the bishop on the long diagonal so it aims at White’s center.

- Opening themes: ...Bg7 long diagonal, dark-square pressure, KID bishop

### Packet kings-indian-black.line-024.ply-08.d7d6

- Move: `d6` / `d7d6` at ply 8

- CoachCard: **Anchor the King’s Indian center** — d6 gives Black the typical King’s Indian pawn base. It restrains the center and prepares later counterplay such as a supported central break when the pieces are ready.

- Plain hint: Support the compact center before choosing a break.

- Opening themes: ...d6 base, central restraint, KID structure

### Packet kings-indian-black.line-024.ply-10.e8g8

- Move: `O-O` / `e8g8` at ply 10
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle behind the King’s Indian shell** — O-O puts Black’s king behind the fianchetto structure. In the King’s Indian, castling is a prerequisite for confident central or kingside counterplay.

- Plain hint: Secure the king before beginning central counterplay.

- Opening themes: king safety, fianchetto shelter, KID counterplay

### Packet kings-indian-black.line-024.ply-12.b8d7

- Move: `Nbd7` / `b8d7` at ply 12

- CoachCard: **Add support behind the King’s Indian break** — Nbd7 develops the knight toward central support squares. In the King’s Indian, this often backs up ...e5 or helps Black coordinate around White’s center.

- Plain hint: Use the queenside knight to reinforce central pressure before the break.

- Opening themes: knight support, central break preparation, KID coordination


## kings-indian-black-line-025: 1. d4 Nf6 2. c4 g6 3. Nc3 Bg7 4. Nf3 d6 5. e4 O-O 6. Bd3 Bg4

Runtime playKey: `d2d4,g8f6,c2c4,g7g6,b1c3,f8g7,g1f3,d7d6,e2e4,e8h8,f1d3,c8g4`  
Runtime totalGames field at line node: `326551`

### Packet kings-indian-black.line-025.ply-04.g7g6

- Move: `g6` / `g7g6` at ply 4

- CoachCard: **Prepare the King’s Indian fianchetto** — g6 prepares the bishop’s long-diagonal role. This is a core King’s Indian idea: pressure White’s center from distance instead of matching every pawn immediately.

- Plain hint: Build the kingside fianchetto that will pressure the long diagonal.

- Opening themes: ...g6 fianchetto, long diagonal, hypermodern center

### Packet kings-indian-black.line-025.ply-06.f8g7

- Move: `Bg7` / `f8g7` at ply 6

- CoachCard: **Complete the King’s Indian bishop** — Bg7 completes the King’s Indian fianchetto. The bishop now works against White’s central and queenside dark squares from a safe distance.

- Plain hint: Place the bishop on the long diagonal so it aims at White’s center.

- Opening themes: ...Bg7 long diagonal, dark-square pressure, KID bishop

### Packet kings-indian-black.line-025.ply-08.d7d6

- Move: `d6` / `d7d6` at ply 8

- CoachCard: **Anchor the King’s Indian center** — d6 gives Black the typical King’s Indian pawn base. It restrains the center and prepares later counterplay such as a supported central break when the pieces are ready.

- Plain hint: Support the compact center before choosing a break.

- Opening themes: ...d6 base, central restraint, KID structure

### Packet kings-indian-black.line-025.ply-10.e8g8

- Move: `O-O` / `e8g8` at ply 10
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle behind the King’s Indian shell** — O-O puts Black’s king behind the fianchetto structure. In the King’s Indian, castling is a prerequisite for confident central or kingside counterplay.

- Plain hint: Secure the king before beginning central counterplay.

- Opening themes: king safety, fianchetto shelter, KID counterplay

### Packet kings-indian-black.line-025.ply-12.c8g4

- Move: `Bg4` / `c8g4` at ply 12

- CoachCard: **Keep the King’s Indian counterattack coherent** — Bg4 supports Black’s King’s Indian plan of fianchetto pressure, central restraint, and timed counterplay against White’s space.

- Plain hint: Tie the move to the fianchetto, king safety, or a prepared strike at White’s center.

- Opening themes: KID coordination, hypermodern pressure, central counterplay
