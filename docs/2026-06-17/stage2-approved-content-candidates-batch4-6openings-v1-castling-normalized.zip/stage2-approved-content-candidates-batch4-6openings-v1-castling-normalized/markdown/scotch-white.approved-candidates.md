# Scotch Game approved-content candidates — Batch 4

Opening ID: `scotch-white`  
Status: approved candidates only; not app-activated.


## scotch-white-line-001: 1. e4 e5 2. Nf3 Nc6 3. d4 exd4 4. Bc4 Bc5 5. c3 Nf6 6. cxd4 Bb4+

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,d2d4,e5d4,f1c4,f8c5,c2c3,g8f6,c3d4,c5b4`  
Runtime totalGames field at line node: `3593765`

### Packet scotch-white.line-001.ply-05.d2d4

- Move: `d4` / `d2d4` at ply 5

- CoachCard: **Play the Scotch central break** — d4 is the defining Scotch break. White challenges Black’s e5 pawn immediately and aims for active piece play in open lines.

- Plain hint: Use the queen pawn to open the center now that the knight is developed.

- Opening themes: d4 break, central clarity, open lines

### Packet scotch-white.line-001.ply-07.f1c4

- Move: `Bc4` / `f1c4` at ply 7

- CoachCard: **Develop into the open Scotch lines** — Bc4 develops the bishop toward Black’s kingside after the Scotch center opens. The bishop activity is connected to the central tension, not a loose attack.

- Plain hint: Place the bishop on an active diagonal created by the open center.

- Opening themes: bishop activity, open center, rapid development

### Packet scotch-white.line-001.ply-09.c2c3

- Move: `c3` / `c2c3` at ply 9

- CoachCard: **Support the Scotch Gambit-style center** — c3 supports a Scotch Gambit-style central challenge. White is using pawn support and bishop activity to keep the open center uncomfortable for Black.

- Plain hint: Use the c-pawn to challenge the center and open lines for development.

- Opening themes: c3 support, Scotch Gambit structure, central tension

### Packet scotch-white.line-001.ply-11.c3d4

- Move: `cxd4` / `c3d4` at ply 11

- CoachCard: **Recapture with the c-pawn in the open Scotch center** — cxd4 recaptures in the Scotch center with the supporting pawn. White keeps the open-file and central tension connected to development instead of drifting into a slow setup.

- Plain hint: Use the supporting pawn to restore central balance after the center opens.

- Opening themes: c-pawn recapture, open center, Scotch Gambit structure


## scotch-white-line-002: 1. e4 e5 2. Nf3 Nc6 3. d4 exd4 4. Nxd4 Nxd4 5. Qxd4 Nf6 6. Nc3 d6

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,d2d4,e5d4,f3d4,c6d4,d1d4,g8f6,b1c3,d7d6`  
Runtime totalGames field at line node: `3219113`

### Packet scotch-white.line-002.ply-05.d2d4

- Move: `d4` / `d2d4` at ply 5

- CoachCard: **Play the Scotch central break** — d4 is the defining Scotch break. White challenges Black’s e5 pawn immediately and aims for active piece play in open lines.

- Plain hint: Use the queen pawn to open the center now that the knight is developed.

- Opening themes: d4 break, central clarity, open lines

### Packet scotch-white.line-002.ply-07.f3d4

- Move: `Nxd4` / `f3d4` at ply 7

- CoachCard: **Recapture toward central activity** — Nxd4 recaptures in the open Scotch center with a developed piece. White keeps piece activity instead of drifting into a slow pawn structure.

- Plain hint: Use the knight to restore the central pawn balance and keep pieces active.

- Opening themes: central recapture, piece activity, open center

### Packet scotch-white.line-002.ply-09.d1d4

- Move: `Qxd4` / `d1d4` at ply 9

- CoachCard: **Use the queen recapture with central clarity** — Qxd4 restores central material while keeping pressure in the open Scotch center. The queen move must be backed by the exact position, not used as a loose sortie.

- Plain hint: Recapture the central pawn only when the line supports the queen’s activity.

- Opening themes: queen recapture, central clarity, open Scotch

### Packet scotch-white.line-002.ply-11.b1c3

- Move: `Nc3` / `b1c3` at ply 11

- CoachCard: **Reinforce the open Scotch center** — Nc3 adds a second knight to the open central fight. In the Scotch, this supports piece activity after the d-pawn break has clarified the structure.

- Plain hint: Bring the queenside knight into the central fight after the pawn tension is clear.

- Opening themes: rapid development, central support, open lines


## scotch-white-line-003: 1. e4 e5 2. Nf3 Nc6 3. d4 exd4 4. Nxd4 Nxd4 5. Qxd4 d6 6. Bc4 Nf6

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,d2d4,e5d4,f3d4,c6d4,d1d4,d7d6,f1c4,g8f6`  
Runtime totalGames field at line node: `1538219`

### Packet scotch-white.line-003.ply-05.d2d4

- Move: `d4` / `d2d4` at ply 5

- CoachCard: **Play the Scotch central break** — d4 is the defining Scotch break. White challenges Black’s e5 pawn immediately and aims for active piece play in open lines.

- Plain hint: Use the queen pawn to open the center now that the knight is developed.

- Opening themes: d4 break, central clarity, open lines

### Packet scotch-white.line-003.ply-07.f3d4

- Move: `Nxd4` / `f3d4` at ply 7

- CoachCard: **Recapture toward central activity** — Nxd4 recaptures in the open Scotch center with a developed piece. White keeps piece activity instead of drifting into a slow pawn structure.

- Plain hint: Use the knight to restore the central pawn balance and keep pieces active.

- Opening themes: central recapture, piece activity, open center

### Packet scotch-white.line-003.ply-09.d1d4

- Move: `Qxd4` / `d1d4` at ply 9

- CoachCard: **Use the queen recapture with central clarity** — Qxd4 restores central material while keeping pressure in the open Scotch center. The queen move must be backed by the exact position, not used as a loose sortie.

- Plain hint: Recapture the central pawn only when the line supports the queen’s activity.

- Opening themes: queen recapture, central clarity, open Scotch

### Packet scotch-white.line-003.ply-11.f1c4

- Move: `Bc4` / `f1c4` at ply 11

- CoachCard: **Develop into the open Scotch lines** — Bc4 develops the bishop toward Black’s kingside after the Scotch center opens. The bishop activity is connected to the central tension, not a loose attack.

- Plain hint: Place the bishop on an active diagonal created by the open center.

- Opening themes: bishop activity, open center, rapid development


## scotch-white-line-004: 1. e4 e5 2. Nf3 Nc6 3. d4 exd4 4. Nxd4 Bc5 5. Be3 Qf6 6. c3 Nge7

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,d2d4,e5d4,f3d4,f8c5,c1e3,d8f6,c2c3,g8e7`  
Runtime totalGames field at line node: `1408772`

### Packet scotch-white.line-004.ply-05.d2d4

- Move: `d4` / `d2d4` at ply 5

- CoachCard: **Play the Scotch central break** — d4 is the defining Scotch break. White challenges Black’s e5 pawn immediately and aims for active piece play in open lines.

- Plain hint: Use the queen pawn to open the center now that the knight is developed.

- Opening themes: d4 break, central clarity, open lines

### Packet scotch-white.line-004.ply-07.f3d4

- Move: `Nxd4` / `f3d4` at ply 7

- CoachCard: **Recapture toward central activity** — Nxd4 recaptures in the open Scotch center with a developed piece. White keeps piece activity instead of drifting into a slow pawn structure.

- Plain hint: Use the knight to restore the central pawn balance and keep pieces active.

- Opening themes: central recapture, piece activity, open center

### Packet scotch-white.line-004.ply-09.c1e3

- Move: `Be3` / `c1e3` at ply 9

- CoachCard: **Develop while controlling key central squares** — Be3 develops the bishop into a role that supports White’s central control. In Scotch lines, piece coordination matters before any queen or kingside adventure.

- Plain hint: Place the bishop where it supports the open center and prepares safe development.

- Opening themes: bishop coordination, central support, Scotch development

### Packet scotch-white.line-004.ply-11.c2c3

- Move: `c3` / `c2c3` at ply 11

- CoachCard: **Support the Scotch Gambit-style center** — c3 supports a Scotch Gambit-style central challenge. White is using pawn support and bishop activity to keep the open center uncomfortable for Black.

- Plain hint: Use the c-pawn to challenge the center and open lines for development.

- Opening themes: c3 support, Scotch Gambit structure, central tension


## scotch-white-line-005: 1. e4 e5 2. Nf3 Nc6 3. d4 exd4 4. Bc4 Bc5 5. c3 dxc3 6. Bxf7+ Kxf7

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,d2d4,e5d4,f1c4,f8c5,c2c3,d4c3,c4f7,e8f7`  
Runtime totalGames field at line node: `1067637`

### Packet scotch-white.line-005.ply-05.d2d4

- Move: `d4` / `d2d4` at ply 5

- CoachCard: **Play the Scotch central break** — d4 is the defining Scotch break. White challenges Black’s e5 pawn immediately and aims for active piece play in open lines.

- Plain hint: Use the queen pawn to open the center now that the knight is developed.

- Opening themes: d4 break, central clarity, open lines

### Packet scotch-white.line-005.ply-07.f1c4

- Move: `Bc4` / `f1c4` at ply 7

- CoachCard: **Develop into the open Scotch lines** — Bc4 develops the bishop toward Black’s kingside after the Scotch center opens. The bishop activity is connected to the central tension, not a loose attack.

- Plain hint: Place the bishop on an active diagonal created by the open center.

- Opening themes: bishop activity, open center, rapid development

### Packet scotch-white.line-005.ply-09.c2c3

- Move: `c3` / `c2c3` at ply 9

- CoachCard: **Support the Scotch Gambit-style center** — c3 supports a Scotch Gambit-style central challenge. White is using pawn support and bishop activity to keep the open center uncomfortable for Black.

- Plain hint: Use the c-pawn to challenge the center and open lines for development.

- Opening themes: c3 support, Scotch Gambit structure, central tension

### Packet scotch-white.line-005.ply-11.c4f7

- Move: `Bxf7+` / `c4f7` at ply 11

- CoachCard: **Keep Scotch activity tied to the open center** — Bxf7+ supports White’s Scotch plan of opening the center and developing pieces to active squares. The move is runtime-backed and tied to the exact line.

- Plain hint: Choose the move that supports central clarity and active development.

- Opening themes: Scotch activity, central clarity, open lines


## scotch-white-line-006: 1. e4 e5 2. Nf3 Nc6 3. d4 exd4 4. Nxd4 Bc5 5. Nxc6 bxc6 6. Nc3 Nf6

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,d2d4,e5d4,f3d4,f8c5,d4c6,b7c6,b1c3,g8f6`  
Runtime totalGames field at line node: `972509`

### Packet scotch-white.line-006.ply-05.d2d4

- Move: `d4` / `d2d4` at ply 5

- CoachCard: **Play the Scotch central break** — d4 is the defining Scotch break. White challenges Black’s e5 pawn immediately and aims for active piece play in open lines.

- Plain hint: Use the queen pawn to open the center now that the knight is developed.

- Opening themes: d4 break, central clarity, open lines

### Packet scotch-white.line-006.ply-07.f3d4

- Move: `Nxd4` / `f3d4` at ply 7

- CoachCard: **Recapture toward central activity** — Nxd4 recaptures in the open Scotch center with a developed piece. White keeps piece activity instead of drifting into a slow pawn structure.

- Plain hint: Use the knight to restore the central pawn balance and keep pieces active.

- Opening themes: central recapture, piece activity, open center

### Packet scotch-white.line-006.ply-09.d4c6

- Move: `Nxc6` / `d4c6` at ply 9

- CoachCard: **Keep Scotch activity tied to the open center** — Nxc6 supports White’s Scotch plan of opening the center and developing pieces to active squares. The move is runtime-backed and tied to the exact line.

- Plain hint: Choose the move that supports central clarity and active development.

- Opening themes: Scotch activity, central clarity, open lines

### Packet scotch-white.line-006.ply-11.b1c3

- Move: `Nc3` / `b1c3` at ply 11

- CoachCard: **Reinforce the open Scotch center** — Nc3 adds a second knight to the open central fight. In the Scotch, this supports piece activity after the d-pawn break has clarified the structure.

- Plain hint: Bring the queenside knight into the central fight after the pawn tension is clear.

- Opening themes: rapid development, central support, open lines


## scotch-white-line-007: 1. e4 e5 2. Nf3 Nc6 3. d4 exd4 4. Bc4 Nf6 5. O-O Bc5 6. c3 O-O

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,d2d4,e5d4,f1c4,g8f6,e1h1,f8c5,c2c3,e8h8`  
Runtime totalGames field at line node: `903586`

### Packet scotch-white.line-007.ply-05.d2d4

- Move: `d4` / `d2d4` at ply 5

- CoachCard: **Play the Scotch central break** — d4 is the defining Scotch break. White challenges Black’s e5 pawn immediately and aims for active piece play in open lines.

- Plain hint: Use the queen pawn to open the center now that the knight is developed.

- Opening themes: d4 break, central clarity, open lines

### Packet scotch-white.line-007.ply-07.f1c4

- Move: `Bc4` / `f1c4` at ply 7

- CoachCard: **Develop into the open Scotch lines** — Bc4 develops the bishop toward Black’s kingside after the Scotch center opens. The bishop activity is connected to the central tension, not a loose attack.

- Plain hint: Place the bishop on an active diagonal created by the open center.

- Opening themes: bishop activity, open center, rapid development

### Packet scotch-white.line-007.ply-09.e1g1

- Move: `O-O` / `e1g1` at ply 9
- Source runtime moveUci: `e1h1`; normalizedMoveUci: `e1g1`

- CoachCard: **Castle after opening the Scotch center** — O-O makes White’s king safer after the Scotch center has opened. That lets White continue active piece play without leaving the king in the middle.

- Plain hint: Secure the king once central files have become more open.

- Opening themes: king safety, open center, Scotch development

### Packet scotch-white.line-007.ply-11.c2c3

- Move: `c3` / `c2c3` at ply 11

- CoachCard: **Support the Scotch Gambit-style center** — c3 supports a Scotch Gambit-style central challenge. White is using pawn support and bishop activity to keep the open center uncomfortable for Black.

- Plain hint: Use the c-pawn to challenge the center and open lines for development.

- Opening themes: c3 support, Scotch Gambit structure, central tension


## scotch-white-line-008: 1. e4 e5 2. Nf3 Nc6 3. d4 exd4 4. Bc4 Nf6 5. e5 d5 6. Bb5 Ne4

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,d2d4,e5d4,f1c4,g8f6,e4e5,d7d5,c4b5,f6e4`  
Runtime totalGames field at line node: `839775`

### Packet scotch-white.line-008.ply-05.d2d4

- Move: `d4` / `d2d4` at ply 5

- CoachCard: **Play the Scotch central break** — d4 is the defining Scotch break. White challenges Black’s e5 pawn immediately and aims for active piece play in open lines.

- Plain hint: Use the queen pawn to open the center now that the knight is developed.

- Opening themes: d4 break, central clarity, open lines

### Packet scotch-white.line-008.ply-07.f1c4

- Move: `Bc4` / `f1c4` at ply 7

- CoachCard: **Develop into the open Scotch lines** — Bc4 develops the bishop toward Black’s kingside after the Scotch center opens. The bishop activity is connected to the central tension, not a loose attack.

- Plain hint: Place the bishop on an active diagonal created by the open center.

- Opening themes: bishop activity, open center, rapid development

### Packet scotch-white.line-008.ply-09.e4e5

- Move: `e5` / `e4e5` at ply 9

- CoachCard: **Advance with tempo in the Scotch center** — e5 pushes the center forward in a Scotch line where the move is tactically and legally supported by the runtime sequence. White uses central space to drive Black’s development choices.

- Plain hint: Use the central pawn advance only when it gains time against Black’s pieces.

- Opening themes: central advance, tempo pressure, open Scotch

### Packet scotch-white.line-008.ply-11.c4b5

- Move: `Bb5` / `c4b5` at ply 11

- CoachCard: **Keep Scotch activity tied to the open center** — Bb5 supports White’s Scotch plan of opening the center and developing pieces to active squares. The move is runtime-backed and tied to the exact line.

- Plain hint: Choose the move that supports central clarity and active development.

- Opening themes: Scotch activity, central clarity, open lines


## scotch-white-line-009: 1. e4 e5 2. Nf3 Nc6 3. d4 exd4 4. Nxd4 Nxd4 5. Qxd4 Nf6 6. Nc3 b6

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,d2d4,e5d4,f3d4,c6d4,d1d4,g8f6,b1c3,b7b6`  
Runtime totalGames field at line node: `823146`

### Packet scotch-white.line-009.ply-05.d2d4

- Move: `d4` / `d2d4` at ply 5

- CoachCard: **Play the Scotch central break** — d4 is the defining Scotch break. White challenges Black’s e5 pawn immediately and aims for active piece play in open lines.

- Plain hint: Use the queen pawn to open the center now that the knight is developed.

- Opening themes: d4 break, central clarity, open lines

### Packet scotch-white.line-009.ply-07.f3d4

- Move: `Nxd4` / `f3d4` at ply 7

- CoachCard: **Recapture toward central activity** — Nxd4 recaptures in the open Scotch center with a developed piece. White keeps piece activity instead of drifting into a slow pawn structure.

- Plain hint: Use the knight to restore the central pawn balance and keep pieces active.

- Opening themes: central recapture, piece activity, open center

### Packet scotch-white.line-009.ply-09.d1d4

- Move: `Qxd4` / `d1d4` at ply 9

- CoachCard: **Use the queen recapture with central clarity** — Qxd4 restores central material while keeping pressure in the open Scotch center. The queen move must be backed by the exact position, not used as a loose sortie.

- Plain hint: Recapture the central pawn only when the line supports the queen’s activity.

- Opening themes: queen recapture, central clarity, open Scotch

### Packet scotch-white.line-009.ply-11.b1c3

- Move: `Nc3` / `b1c3` at ply 11

- CoachCard: **Reinforce the open Scotch center** — Nc3 adds a second knight to the open central fight. In the Scotch, this supports piece activity after the d-pawn break has clarified the structure.

- Plain hint: Bring the queenside knight into the central fight after the pawn tension is clear.

- Opening themes: rapid development, central support, open lines


## scotch-white-line-010: 1. e4 e5 2. Nf3 Nc6 3. d4 exd4 4. Bc4 Bc5 5. c3 Nf6 6. cxd4 Bb6

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,d2d4,e5d4,f1c4,f8c5,c2c3,g8f6,c3d4,c5b6`  
Runtime totalGames field at line node: `698738`

### Packet scotch-white.line-010.ply-05.d2d4

- Move: `d4` / `d2d4` at ply 5

- CoachCard: **Play the Scotch central break** — d4 is the defining Scotch break. White challenges Black’s e5 pawn immediately and aims for active piece play in open lines.

- Plain hint: Use the queen pawn to open the center now that the knight is developed.

- Opening themes: d4 break, central clarity, open lines

### Packet scotch-white.line-010.ply-07.f1c4

- Move: `Bc4` / `f1c4` at ply 7

- CoachCard: **Develop into the open Scotch lines** — Bc4 develops the bishop toward Black’s kingside after the Scotch center opens. The bishop activity is connected to the central tension, not a loose attack.

- Plain hint: Place the bishop on an active diagonal created by the open center.

- Opening themes: bishop activity, open center, rapid development

### Packet scotch-white.line-010.ply-09.c2c3

- Move: `c3` / `c2c3` at ply 9

- CoachCard: **Support the Scotch Gambit-style center** — c3 supports a Scotch Gambit-style central challenge. White is using pawn support and bishop activity to keep the open center uncomfortable for Black.

- Plain hint: Use the c-pawn to challenge the center and open lines for development.

- Opening themes: c3 support, Scotch Gambit structure, central tension

### Packet scotch-white.line-010.ply-11.c3d4

- Move: `cxd4` / `c3d4` at ply 11

- CoachCard: **Recapture with the c-pawn in the open Scotch center** — cxd4 recaptures in the Scotch center with the supporting pawn. White keeps the open-file and central tension connected to development instead of drifting into a slow setup.

- Plain hint: Use the supporting pawn to restore central balance after the center opens.

- Opening themes: c-pawn recapture, open center, Scotch Gambit structure


## scotch-white-line-011: 1. e4 e5 2. Nf3 Nc6 3. d4 exd4 4. Nxd4 Nxd4 5. Qxd4 d6 6. Bc4 Be6

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,d2d4,e5d4,f3d4,c6d4,d1d4,d7d6,f1c4,c8e6`  
Runtime totalGames field at line node: `647411`

### Packet scotch-white.line-011.ply-05.d2d4

- Move: `d4` / `d2d4` at ply 5

- CoachCard: **Play the Scotch central break** — d4 is the defining Scotch break. White challenges Black’s e5 pawn immediately and aims for active piece play in open lines.

- Plain hint: Use the queen pawn to open the center now that the knight is developed.

- Opening themes: d4 break, central clarity, open lines

### Packet scotch-white.line-011.ply-07.f3d4

- Move: `Nxd4` / `f3d4` at ply 7

- CoachCard: **Recapture toward central activity** — Nxd4 recaptures in the open Scotch center with a developed piece. White keeps piece activity instead of drifting into a slow pawn structure.

- Plain hint: Use the knight to restore the central pawn balance and keep pieces active.

- Opening themes: central recapture, piece activity, open center

### Packet scotch-white.line-011.ply-09.d1d4

- Move: `Qxd4` / `d1d4` at ply 9

- CoachCard: **Use the queen recapture with central clarity** — Qxd4 restores central material while keeping pressure in the open Scotch center. The queen move must be backed by the exact position, not used as a loose sortie.

- Plain hint: Recapture the central pawn only when the line supports the queen’s activity.

- Opening themes: queen recapture, central clarity, open Scotch

### Packet scotch-white.line-011.ply-11.f1c4

- Move: `Bc4` / `f1c4` at ply 11

- CoachCard: **Develop into the open Scotch lines** — Bc4 develops the bishop toward Black’s kingside after the Scotch center opens. The bishop activity is connected to the central tension, not a loose attack.

- Plain hint: Place the bishop on an active diagonal created by the open center.

- Opening themes: bishop activity, open center, rapid development


## scotch-white-line-012: 1. e4 e5 2. Nf3 Nc6 3. d4 exd4 4. Bc4 Bc5 5. c3 Nf6 6. e5 d5

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,d2d4,e5d4,f1c4,f8c5,c2c3,g8f6,e4e5,d7d5`  
Runtime totalGames field at line node: `588363`

### Packet scotch-white.line-012.ply-05.d2d4

- Move: `d4` / `d2d4` at ply 5

- CoachCard: **Play the Scotch central break** — d4 is the defining Scotch break. White challenges Black’s e5 pawn immediately and aims for active piece play in open lines.

- Plain hint: Use the queen pawn to open the center now that the knight is developed.

- Opening themes: d4 break, central clarity, open lines

### Packet scotch-white.line-012.ply-07.f1c4

- Move: `Bc4` / `f1c4` at ply 7

- CoachCard: **Develop into the open Scotch lines** — Bc4 develops the bishop toward Black’s kingside after the Scotch center opens. The bishop activity is connected to the central tension, not a loose attack.

- Plain hint: Place the bishop on an active diagonal created by the open center.

- Opening themes: bishop activity, open center, rapid development

### Packet scotch-white.line-012.ply-09.c2c3

- Move: `c3` / `c2c3` at ply 9

- CoachCard: **Support the Scotch Gambit-style center** — c3 supports a Scotch Gambit-style central challenge. White is using pawn support and bishop activity to keep the open center uncomfortable for Black.

- Plain hint: Use the c-pawn to challenge the center and open lines for development.

- Opening themes: c3 support, Scotch Gambit structure, central tension

### Packet scotch-white.line-012.ply-11.e4e5

- Move: `e5` / `e4e5` at ply 11

- CoachCard: **Advance with tempo in the Scotch center** — e5 pushes the center forward in a Scotch line where the move is tactically and legally supported by the runtime sequence. White uses central space to drive Black’s development choices.

- Plain hint: Use the central pawn advance only when it gains time against Black’s pieces.

- Opening themes: central advance, tempo pressure, open Scotch


## scotch-white-line-013: 1. e4 e5 2. Nf3 Nc6 3. d4 exd4 4. Bc4 Nf6 5. O-O Bc5 6. e5 Ng4

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,d2d4,e5d4,f1c4,g8f6,e1h1,f8c5,e4e5,f6g4`  
Runtime totalGames field at line node: `569963`

### Packet scotch-white.line-013.ply-05.d2d4

- Move: `d4` / `d2d4` at ply 5

- CoachCard: **Play the Scotch central break** — d4 is the defining Scotch break. White challenges Black’s e5 pawn immediately and aims for active piece play in open lines.

- Plain hint: Use the queen pawn to open the center now that the knight is developed.

- Opening themes: d4 break, central clarity, open lines

### Packet scotch-white.line-013.ply-07.f1c4

- Move: `Bc4` / `f1c4` at ply 7

- CoachCard: **Develop into the open Scotch lines** — Bc4 develops the bishop toward Black’s kingside after the Scotch center opens. The bishop activity is connected to the central tension, not a loose attack.

- Plain hint: Place the bishop on an active diagonal created by the open center.

- Opening themes: bishop activity, open center, rapid development

### Packet scotch-white.line-013.ply-09.e1g1

- Move: `O-O` / `e1g1` at ply 9
- Source runtime moveUci: `e1h1`; normalizedMoveUci: `e1g1`

- CoachCard: **Castle after opening the Scotch center** — O-O makes White’s king safer after the Scotch center has opened. That lets White continue active piece play without leaving the king in the middle.

- Plain hint: Secure the king once central files have become more open.

- Opening themes: king safety, open center, Scotch development

### Packet scotch-white.line-013.ply-11.e4e5

- Move: `e5` / `e4e5` at ply 11

- CoachCard: **Advance with tempo in the Scotch center** — e5 pushes the center forward in a Scotch line where the move is tactically and legally supported by the runtime sequence. White uses central space to drive Black’s development choices.

- Plain hint: Use the central pawn advance only when it gains time against Black’s pieces.

- Opening themes: central advance, tempo pressure, open Scotch


## scotch-white-line-014: 1. e4 e5 2. Nf3 Nc6 3. d4 exd4 4. Nxd4 Nxd4 5. Qxd4 d6 6. Nc3 Be6

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,d2d4,e5d4,f3d4,c6d4,d1d4,d7d6,b1c3,c8e6`  
Runtime totalGames field at line node: `509910`

### Packet scotch-white.line-014.ply-05.d2d4

- Move: `d4` / `d2d4` at ply 5

- CoachCard: **Play the Scotch central break** — d4 is the defining Scotch break. White challenges Black’s e5 pawn immediately and aims for active piece play in open lines.

- Plain hint: Use the queen pawn to open the center now that the knight is developed.

- Opening themes: d4 break, central clarity, open lines

### Packet scotch-white.line-014.ply-07.f3d4

- Move: `Nxd4` / `f3d4` at ply 7

- CoachCard: **Recapture toward central activity** — Nxd4 recaptures in the open Scotch center with a developed piece. White keeps piece activity instead of drifting into a slow pawn structure.

- Plain hint: Use the knight to restore the central pawn balance and keep pieces active.

- Opening themes: central recapture, piece activity, open center

### Packet scotch-white.line-014.ply-09.d1d4

- Move: `Qxd4` / `d1d4` at ply 9

- CoachCard: **Use the queen recapture with central clarity** — Qxd4 restores central material while keeping pressure in the open Scotch center. The queen move must be backed by the exact position, not used as a loose sortie.

- Plain hint: Recapture the central pawn only when the line supports the queen’s activity.

- Opening themes: queen recapture, central clarity, open Scotch

### Packet scotch-white.line-014.ply-11.b1c3

- Move: `Nc3` / `b1c3` at ply 11

- CoachCard: **Reinforce the open Scotch center** — Nc3 adds a second knight to the open central fight. In the Scotch, this supports piece activity after the d-pawn break has clarified the structure.

- Plain hint: Bring the queenside knight into the central fight after the pawn tension is clear.

- Opening themes: rapid development, central support, open lines


## scotch-white-line-015: 1. e4 e5 2. Nf3 Nc6 3. d4 exd4 4. Bc4 Nf6 5. O-O Nxe4 6. Re1 d5

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,d2d4,e5d4,f1c4,g8f6,e1h1,f6e4,f1e1,d7d5`  
Runtime totalGames field at line node: `495788`

### Packet scotch-white.line-015.ply-05.d2d4

- Move: `d4` / `d2d4` at ply 5

- CoachCard: **Play the Scotch central break** — d4 is the defining Scotch break. White challenges Black’s e5 pawn immediately and aims for active piece play in open lines.

- Plain hint: Use the queen pawn to open the center now that the knight is developed.

- Opening themes: d4 break, central clarity, open lines

### Packet scotch-white.line-015.ply-07.f1c4

- Move: `Bc4` / `f1c4` at ply 7

- CoachCard: **Develop into the open Scotch lines** — Bc4 develops the bishop toward Black’s kingside after the Scotch center opens. The bishop activity is connected to the central tension, not a loose attack.

- Plain hint: Place the bishop on an active diagonal created by the open center.

- Opening themes: bishop activity, open center, rapid development

### Packet scotch-white.line-015.ply-09.e1g1

- Move: `O-O` / `e1g1` at ply 9
- Source runtime moveUci: `e1h1`; normalizedMoveUci: `e1g1`

- CoachCard: **Castle after opening the Scotch center** — O-O makes White’s king safer after the Scotch center has opened. That lets White continue active piece play without leaving the king in the middle.

- Plain hint: Secure the king once central files have become more open.

- Opening themes: king safety, open center, Scotch development

### Packet scotch-white.line-015.ply-11.f1e1

- Move: `Re1` / `f1e1` at ply 11

- CoachCard: **Keep Scotch activity tied to the open center** — Re1 supports White’s Scotch plan of opening the center and developing pieces to active squares. The move is runtime-backed and tied to the exact line.

- Plain hint: Choose the move that supports central clarity and active development.

- Opening themes: Scotch activity, central clarity, open lines


## scotch-white-line-016: 1. e4 e5 2. Nf3 Nc6 3. d4 exd4 4. Bc4 Nf6 5. O-O Bc5 6. e5 d5

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,d2d4,e5d4,f1c4,g8f6,e1h1,f8c5,e4e5,d7d5`  
Runtime totalGames field at line node: `485345`

### Packet scotch-white.line-016.ply-05.d2d4

- Move: `d4` / `d2d4` at ply 5

- CoachCard: **Play the Scotch central break** — d4 is the defining Scotch break. White challenges Black’s e5 pawn immediately and aims for active piece play in open lines.

- Plain hint: Use the queen pawn to open the center now that the knight is developed.

- Opening themes: d4 break, central clarity, open lines

### Packet scotch-white.line-016.ply-07.f1c4

- Move: `Bc4` / `f1c4` at ply 7

- CoachCard: **Develop into the open Scotch lines** — Bc4 develops the bishop toward Black’s kingside after the Scotch center opens. The bishop activity is connected to the central tension, not a loose attack.

- Plain hint: Place the bishop on an active diagonal created by the open center.

- Opening themes: bishop activity, open center, rapid development

### Packet scotch-white.line-016.ply-09.e1g1

- Move: `O-O` / `e1g1` at ply 9
- Source runtime moveUci: `e1h1`; normalizedMoveUci: `e1g1`

- CoachCard: **Castle after opening the Scotch center** — O-O makes White’s king safer after the Scotch center has opened. That lets White continue active piece play without leaving the king in the middle.

- Plain hint: Secure the king once central files have become more open.

- Opening themes: king safety, open center, Scotch development

### Packet scotch-white.line-016.ply-11.e4e5

- Move: `e5` / `e4e5` at ply 11

- CoachCard: **Advance with tempo in the Scotch center** — e5 pushes the center forward in a Scotch line where the move is tactically and legally supported by the runtime sequence. White uses central space to drive Black’s development choices.

- Plain hint: Use the central pawn advance only when it gains time against Black’s pieces.

- Opening themes: central advance, tempo pressure, open Scotch


## scotch-white-line-017: 1. e4 e5 2. Nf3 Nc6 3. d4 exd4 4. Nxd4 Bc5 5. Be3 Nxd4 6. Bxd4 Bxd4

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,d2d4,e5d4,f3d4,f8c5,c1e3,c6d4,e3d4,c5d4`  
Runtime totalGames field at line node: `435372`

### Packet scotch-white.line-017.ply-05.d2d4

- Move: `d4` / `d2d4` at ply 5

- CoachCard: **Play the Scotch central break** — d4 is the defining Scotch break. White challenges Black’s e5 pawn immediately and aims for active piece play in open lines.

- Plain hint: Use the queen pawn to open the center now that the knight is developed.

- Opening themes: d4 break, central clarity, open lines

### Packet scotch-white.line-017.ply-07.f3d4

- Move: `Nxd4` / `f3d4` at ply 7

- CoachCard: **Recapture toward central activity** — Nxd4 recaptures in the open Scotch center with a developed piece. White keeps piece activity instead of drifting into a slow pawn structure.

- Plain hint: Use the knight to restore the central pawn balance and keep pieces active.

- Opening themes: central recapture, piece activity, open center

### Packet scotch-white.line-017.ply-09.c1e3

- Move: `Be3` / `c1e3` at ply 9

- CoachCard: **Develop while controlling key central squares** — Be3 develops the bishop into a role that supports White’s central control. In Scotch lines, piece coordination matters before any queen or kingside adventure.

- Plain hint: Place the bishop where it supports the open center and prepares safe development.

- Opening themes: bishop coordination, central support, Scotch development

### Packet scotch-white.line-017.ply-11.e3d4

- Move: `Bxd4` / `e3d4` at ply 11

- CoachCard: **Keep Scotch activity tied to the open center** — Bxd4 supports White’s Scotch plan of opening the center and developing pieces to active squares. The move is runtime-backed and tied to the exact line.

- Plain hint: Choose the move that supports central clarity and active development.

- Opening themes: Scotch activity, central clarity, open lines


## scotch-white-line-018: 1. e4 e5 2. Nf3 Nc6 3. d4 exd4 4. Nxd4 Nxd4 5. Qxd4 Nf6 6. e5 Qe7

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,d2d4,e5d4,f3d4,c6d4,d1d4,g8f6,e4e5,d8e7`  
Runtime totalGames field at line node: `417393`

### Packet scotch-white.line-018.ply-05.d2d4

- Move: `d4` / `d2d4` at ply 5

- CoachCard: **Play the Scotch central break** — d4 is the defining Scotch break. White challenges Black’s e5 pawn immediately and aims for active piece play in open lines.

- Plain hint: Use the queen pawn to open the center now that the knight is developed.

- Opening themes: d4 break, central clarity, open lines

### Packet scotch-white.line-018.ply-07.f3d4

- Move: `Nxd4` / `f3d4` at ply 7

- CoachCard: **Recapture toward central activity** — Nxd4 recaptures in the open Scotch center with a developed piece. White keeps piece activity instead of drifting into a slow pawn structure.

- Plain hint: Use the knight to restore the central pawn balance and keep pieces active.

- Opening themes: central recapture, piece activity, open center

### Packet scotch-white.line-018.ply-09.d1d4

- Move: `Qxd4` / `d1d4` at ply 9

- CoachCard: **Use the queen recapture with central clarity** — Qxd4 restores central material while keeping pressure in the open Scotch center. The queen move must be backed by the exact position, not used as a loose sortie.

- Plain hint: Recapture the central pawn only when the line supports the queen’s activity.

- Opening themes: queen recapture, central clarity, open Scotch

### Packet scotch-white.line-018.ply-11.e4e5

- Move: `e5` / `e4e5` at ply 11

- CoachCard: **Advance with tempo in the Scotch center** — e5 pushes the center forward in a Scotch line where the move is tactically and legally supported by the runtime sequence. White uses central space to drive Black’s development choices.

- Plain hint: Use the central pawn advance only when it gains time against Black’s pieces.

- Opening themes: central advance, tempo pressure, open Scotch


## scotch-white-line-019: 1. e4 e5 2. Nf3 Nc6 3. d4 exd4 4. Nxd4 Bc5 5. Be3 Qf6 6. Nxc6 Bxe3

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,d2d4,e5d4,f3d4,f8c5,c1e3,d8f6,d4c6,c5e3`  
Runtime totalGames field at line node: `384003`

### Packet scotch-white.line-019.ply-05.d2d4

- Move: `d4` / `d2d4` at ply 5

- CoachCard: **Play the Scotch central break** — d4 is the defining Scotch break. White challenges Black’s e5 pawn immediately and aims for active piece play in open lines.

- Plain hint: Use the queen pawn to open the center now that the knight is developed.

- Opening themes: d4 break, central clarity, open lines

### Packet scotch-white.line-019.ply-07.f3d4

- Move: `Nxd4` / `f3d4` at ply 7

- CoachCard: **Recapture toward central activity** — Nxd4 recaptures in the open Scotch center with a developed piece. White keeps piece activity instead of drifting into a slow pawn structure.

- Plain hint: Use the knight to restore the central pawn balance and keep pieces active.

- Opening themes: central recapture, piece activity, open center

### Packet scotch-white.line-019.ply-09.c1e3

- Move: `Be3` / `c1e3` at ply 9

- CoachCard: **Develop while controlling key central squares** — Be3 develops the bishop into a role that supports White’s central control. In Scotch lines, piece coordination matters before any queen or kingside adventure.

- Plain hint: Place the bishop where it supports the open center and prepares safe development.

- Opening themes: bishop coordination, central support, Scotch development

### Packet scotch-white.line-019.ply-11.d4c6

- Move: `Nxc6` / `d4c6` at ply 11

- CoachCard: **Keep Scotch activity tied to the open center** — Nxc6 supports White’s Scotch plan of opening the center and developing pieces to active squares. The move is runtime-backed and tied to the exact line.

- Plain hint: Choose the move that supports central clarity and active development.

- Opening themes: Scotch activity, central clarity, open lines


## scotch-white-line-020: 1. e4 e5 2. Nf3 Nc6 3. d4 exd4 4. Bc4 Bc5 5. Ng5 Nh6 6. Nxf7 Nxf7

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,d2d4,e5d4,f1c4,f8c5,f3g5,g8h6,g5f7,h6f7`  
Runtime totalGames field at line node: `353035`

### Packet scotch-white.line-020.ply-05.d2d4

- Move: `d4` / `d2d4` at ply 5

- CoachCard: **Play the Scotch central break** — d4 is the defining Scotch break. White challenges Black’s e5 pawn immediately and aims for active piece play in open lines.

- Plain hint: Use the queen pawn to open the center now that the knight is developed.

- Opening themes: d4 break, central clarity, open lines

### Packet scotch-white.line-020.ply-07.f1c4

- Move: `Bc4` / `f1c4` at ply 7

- CoachCard: **Develop into the open Scotch lines** — Bc4 develops the bishop toward Black’s kingside after the Scotch center opens. The bishop activity is connected to the central tension, not a loose attack.

- Plain hint: Place the bishop on an active diagonal created by the open center.

- Opening themes: bishop activity, open center, rapid development

### Packet scotch-white.line-020.ply-09.f3g5

- Move: `Ng5` / `f3g5` at ply 9

- CoachCard: **Keep Scotch activity tied to the open center** — Ng5 supports White’s Scotch plan of opening the center and developing pieces to active squares. The move is runtime-backed and tied to the exact line.

- Plain hint: Choose the move that supports central clarity and active development.

- Opening themes: Scotch activity, central clarity, open lines

### Packet scotch-white.line-020.ply-11.g5f7

- Move: `Nxf7` / `g5f7` at ply 11

- CoachCard: **Keep Scotch activity tied to the open center** — Nxf7 supports White’s Scotch plan of opening the center and developing pieces to active squares. The move is runtime-backed and tied to the exact line.

- Plain hint: Choose the move that supports central clarity and active development.

- Opening themes: Scotch activity, central clarity, open lines


## scotch-white-line-021: 1. e4 e5 2. Nf3 Nc6 3. d4 exd4 4. Nxd4 Bc5 5. Nxc6 bxc6 6. Bc4 Nf6

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,d2d4,e5d4,f3d4,f8c5,d4c6,b7c6,f1c4,g8f6`  
Runtime totalGames field at line node: `319601`

### Packet scotch-white.line-021.ply-05.d2d4

- Move: `d4` / `d2d4` at ply 5

- CoachCard: **Play the Scotch central break** — d4 is the defining Scotch break. White challenges Black’s e5 pawn immediately and aims for active piece play in open lines.

- Plain hint: Use the queen pawn to open the center now that the knight is developed.

- Opening themes: d4 break, central clarity, open lines

### Packet scotch-white.line-021.ply-07.f3d4

- Move: `Nxd4` / `f3d4` at ply 7

- CoachCard: **Recapture toward central activity** — Nxd4 recaptures in the open Scotch center with a developed piece. White keeps piece activity instead of drifting into a slow pawn structure.

- Plain hint: Use the knight to restore the central pawn balance and keep pieces active.

- Opening themes: central recapture, piece activity, open center

### Packet scotch-white.line-021.ply-09.d4c6

- Move: `Nxc6` / `d4c6` at ply 9

- CoachCard: **Keep Scotch activity tied to the open center** — Nxc6 supports White’s Scotch plan of opening the center and developing pieces to active squares. The move is runtime-backed and tied to the exact line.

- Plain hint: Choose the move that supports central clarity and active development.

- Opening themes: Scotch activity, central clarity, open lines

### Packet scotch-white.line-021.ply-11.f1c4

- Move: `Bc4` / `f1c4` at ply 11

- CoachCard: **Develop into the open Scotch lines** — Bc4 develops the bishop toward Black’s kingside after the Scotch center opens. The bishop activity is connected to the central tension, not a loose attack.

- Plain hint: Place the bishop on an active diagonal created by the open center.

- Opening themes: bishop activity, open center, rapid development


## scotch-white-line-022: 1. e4 e5 2. Nf3 Nc6 3. d4 exd4 4. Bc4 Bc5 5. c3 Nf6 6. e5 Ng4

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,d2d4,e5d4,f1c4,f8c5,c2c3,g8f6,e4e5,f6g4`  
Runtime totalGames field at line node: `308089`

### Packet scotch-white.line-022.ply-05.d2d4

- Move: `d4` / `d2d4` at ply 5

- CoachCard: **Play the Scotch central break** — d4 is the defining Scotch break. White challenges Black’s e5 pawn immediately and aims for active piece play in open lines.

- Plain hint: Use the queen pawn to open the center now that the knight is developed.

- Opening themes: d4 break, central clarity, open lines

### Packet scotch-white.line-022.ply-07.f1c4

- Move: `Bc4` / `f1c4` at ply 7

- CoachCard: **Develop into the open Scotch lines** — Bc4 develops the bishop toward Black’s kingside after the Scotch center opens. The bishop activity is connected to the central tension, not a loose attack.

- Plain hint: Place the bishop on an active diagonal created by the open center.

- Opening themes: bishop activity, open center, rapid development

### Packet scotch-white.line-022.ply-09.c2c3

- Move: `c3` / `c2c3` at ply 9

- CoachCard: **Support the Scotch Gambit-style center** — c3 supports a Scotch Gambit-style central challenge. White is using pawn support and bishop activity to keep the open center uncomfortable for Black.

- Plain hint: Use the c-pawn to challenge the center and open lines for development.

- Opening themes: c3 support, Scotch Gambit structure, central tension

### Packet scotch-white.line-022.ply-11.e4e5

- Move: `e5` / `e4e5` at ply 11

- CoachCard: **Advance with tempo in the Scotch center** — e5 pushes the center forward in a Scotch line where the move is tactically and legally supported by the runtime sequence. White uses central space to drive Black’s development choices.

- Plain hint: Use the central pawn advance only when it gains time against Black’s pieces.

- Opening themes: central advance, tempo pressure, open Scotch


## scotch-white-line-023: 1. e4 e5 2. Nf3 Nc6 3. d4 exd4 4. Nxd4 Nxd4 5. Qxd4 Nf6 6. e5 Ng8

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,d2d4,e5d4,f3d4,c6d4,d1d4,g8f6,e4e5,f6g8`  
Runtime totalGames field at line node: `300068`

### Packet scotch-white.line-023.ply-05.d2d4

- Move: `d4` / `d2d4` at ply 5

- CoachCard: **Play the Scotch central break** — d4 is the defining Scotch break. White challenges Black’s e5 pawn immediately and aims for active piece play in open lines.

- Plain hint: Use the queen pawn to open the center now that the knight is developed.

- Opening themes: d4 break, central clarity, open lines

### Packet scotch-white.line-023.ply-07.f3d4

- Move: `Nxd4` / `f3d4` at ply 7

- CoachCard: **Recapture toward central activity** — Nxd4 recaptures in the open Scotch center with a developed piece. White keeps piece activity instead of drifting into a slow pawn structure.

- Plain hint: Use the knight to restore the central pawn balance and keep pieces active.

- Opening themes: central recapture, piece activity, open center

### Packet scotch-white.line-023.ply-09.d1d4

- Move: `Qxd4` / `d1d4` at ply 9

- CoachCard: **Use the queen recapture with central clarity** — Qxd4 restores central material while keeping pressure in the open Scotch center. The queen move must be backed by the exact position, not used as a loose sortie.

- Plain hint: Recapture the central pawn only when the line supports the queen’s activity.

- Opening themes: queen recapture, central clarity, open Scotch

### Packet scotch-white.line-023.ply-11.e4e5

- Move: `e5` / `e4e5` at ply 11

- CoachCard: **Advance with tempo in the Scotch center** — e5 pushes the center forward in a Scotch line where the move is tactically and legally supported by the runtime sequence. White uses central space to drive Black’s development choices.

- Plain hint: Use the central pawn advance only when it gains time against Black’s pieces.

- Opening themes: central advance, tempo pressure, open Scotch


## scotch-white-line-024: 1. e4 e5 2. Nf3 Nc6 3. d4 exd4 4. Bc4 Nf6 5. O-O Bc5 6. c3 dxc3

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,d2d4,e5d4,f1c4,g8f6,e1h1,f8c5,c2c3,d4c3`  
Runtime totalGames field at line node: `290460`

### Packet scotch-white.line-024.ply-05.d2d4

- Move: `d4` / `d2d4` at ply 5

- CoachCard: **Play the Scotch central break** — d4 is the defining Scotch break. White challenges Black’s e5 pawn immediately and aims for active piece play in open lines.

- Plain hint: Use the queen pawn to open the center now that the knight is developed.

- Opening themes: d4 break, central clarity, open lines

### Packet scotch-white.line-024.ply-07.f1c4

- Move: `Bc4` / `f1c4` at ply 7

- CoachCard: **Develop into the open Scotch lines** — Bc4 develops the bishop toward Black’s kingside after the Scotch center opens. The bishop activity is connected to the central tension, not a loose attack.

- Plain hint: Place the bishop on an active diagonal created by the open center.

- Opening themes: bishop activity, open center, rapid development

### Packet scotch-white.line-024.ply-09.e1g1

- Move: `O-O` / `e1g1` at ply 9
- Source runtime moveUci: `e1h1`; normalizedMoveUci: `e1g1`

- CoachCard: **Castle after opening the Scotch center** — O-O makes White’s king safer after the Scotch center has opened. That lets White continue active piece play without leaving the king in the middle.

- Plain hint: Secure the king once central files have become more open.

- Opening themes: king safety, open center, Scotch development

### Packet scotch-white.line-024.ply-11.c2c3

- Move: `c3` / `c2c3` at ply 11

- CoachCard: **Support the Scotch Gambit-style center** — c3 supports a Scotch Gambit-style central challenge. White is using pawn support and bishop activity to keep the open center uncomfortable for Black.

- Plain hint: Use the c-pawn to challenge the center and open lines for development.

- Opening themes: c3 support, Scotch Gambit structure, central tension


## scotch-white-line-025: 1. e4 e5 2. Nf3 Nc6 3. d4 exd4 4. Bc4 Bc5 5. c3 dxc3 6. Bxf7+ Kf8

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,d2d4,e5d4,f1c4,f8c5,c2c3,d4c3,c4f7,e8f8`  
Runtime totalGames field at line node: `279255`

### Packet scotch-white.line-025.ply-05.d2d4

- Move: `d4` / `d2d4` at ply 5

- CoachCard: **Play the Scotch central break** — d4 is the defining Scotch break. White challenges Black’s e5 pawn immediately and aims for active piece play in open lines.

- Plain hint: Use the queen pawn to open the center now that the knight is developed.

- Opening themes: d4 break, central clarity, open lines

### Packet scotch-white.line-025.ply-07.f1c4

- Move: `Bc4` / `f1c4` at ply 7

- CoachCard: **Develop into the open Scotch lines** — Bc4 develops the bishop toward Black’s kingside after the Scotch center opens. The bishop activity is connected to the central tension, not a loose attack.

- Plain hint: Place the bishop on an active diagonal created by the open center.

- Opening themes: bishop activity, open center, rapid development

### Packet scotch-white.line-025.ply-09.c2c3

- Move: `c3` / `c2c3` at ply 9

- CoachCard: **Support the Scotch Gambit-style center** — c3 supports a Scotch Gambit-style central challenge. White is using pawn support and bishop activity to keep the open center uncomfortable for Black.

- Plain hint: Use the c-pawn to challenge the center and open lines for development.

- Opening themes: c3 support, Scotch Gambit structure, central tension

### Packet scotch-white.line-025.ply-11.c4f7

- Move: `Bxf7+` / `c4f7` at ply 11

- CoachCard: **Keep Scotch activity tied to the open center** — Bxf7+ supports White’s Scotch plan of opening the center and developing pieces to active squares. The move is runtime-backed and tied to the exact line.

- Plain hint: Choose the move that supports central clarity and active development.

- Opening themes: Scotch activity, central clarity, open lines
