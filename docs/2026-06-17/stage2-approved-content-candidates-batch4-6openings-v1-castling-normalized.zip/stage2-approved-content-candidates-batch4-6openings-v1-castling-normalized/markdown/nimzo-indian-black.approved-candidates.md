# Nimzo-Indian Defense approved-content candidates — Batch 4

Opening ID: `nimzo-indian-black`  
Status: approved candidates only; not app-activated.


## nimzo-indian-black-line-001: 1. d4 Nf6 2. c4 e6 3. Nc3 Bb4 4. Nf3 O-O 5. Bg5 d5 6. e3 Nbd7

Runtime playKey: `d2d4,g8f6,c2c4,e7e6,b1c3,f8b4,g1f3,e8h8,c1g5,d7d5,e2e3,b8d7`  
Runtime totalGames field at line node: `181557`

### Packet nimzo-indian-black.line-001.ply-06.f8b4

- Move: `Bb4` / `f8b4` at ply 6

- CoachCard: **Pin the c3 knight in true Nimzo style** — Bb4 is the Nimzo-Indian’s defining move: Black pressures the c3 knight that helps White control e4 and d5. This creates structural and central tension without overclaiming tactics.

- Plain hint: Put bishop pressure on the knight that supports White’s central pawns.

- Opening themes: ...Bb4 pin, c3 knight pressure, dark-square control

### Packet nimzo-indian-black.line-001.ply-08.e8g8

- Move: `O-O` / `e8g8` at ply 8
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle before resolving the Nimzo tension** — O-O secures Black’s king before deciding whether to keep, trade, or retreat the Nimzo bishop. It keeps central pressure without rushing the structure.

- Plain hint: Make the king safe while keeping the bishop and central pressure intact.

- Opening themes: king safety, Nimzo tension, development

### Packet nimzo-indian-black.line-001.ply-10.d7d5

- Move: `d5` / `d7d5` at ply 10

- CoachCard: **Add direct central pressure** — d5 contests White’s center directly while the Nimzo bishop pressure still shapes White’s choices. It gives Black a solid central foothold.

- Plain hint: Use the queen pawn to contest the center while the bishop pressure remains.

- Opening themes: ...d5 center, Nimzo structure, central pressure

### Packet nimzo-indian-black.line-001.ply-12.b8d7

- Move: `Nbd7` / `b8d7` at ply 12

- CoachCard: **Keep Nimzo pressure tied to the center** — Nbd7 supports the Nimzo-Indian plan of central pressure, dark-square control, and coordinated development around the c3 knight.

- Plain hint: Coordinate around the pinned knight, dark squares, and White’s queen-pawn center.

- Opening themes: Nimzo coordination, dark-square pressure, central control


## nimzo-indian-black-line-002: 1. d4 Nf6 2. c4 e6 3. Nc3 Bb4 4. Nf3 O-O 5. Bg5 d5 6. e3 h6

Runtime playKey: `d2d4,g8f6,c2c4,e7e6,b1c3,f8b4,g1f3,e8h8,c1g5,d7d5,e2e3,h7h6`  
Runtime totalGames field at line node: `172574`

### Packet nimzo-indian-black.line-002.ply-06.f8b4

- Move: `Bb4` / `f8b4` at ply 6

- CoachCard: **Pin the c3 knight in true Nimzo style** — Bb4 is the Nimzo-Indian’s defining move: Black pressures the c3 knight that helps White control e4 and d5. This creates structural and central tension without overclaiming tactics.

- Plain hint: Put bishop pressure on the knight that supports White’s central pawns.

- Opening themes: ...Bb4 pin, c3 knight pressure, dark-square control

### Packet nimzo-indian-black.line-002.ply-08.e8g8

- Move: `O-O` / `e8g8` at ply 8
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle before resolving the Nimzo tension** — O-O secures Black’s king before deciding whether to keep, trade, or retreat the Nimzo bishop. It keeps central pressure without rushing the structure.

- Plain hint: Make the king safe while keeping the bishop and central pressure intact.

- Opening themes: king safety, Nimzo tension, development

### Packet nimzo-indian-black.line-002.ply-10.d7d5

- Move: `d5` / `d7d5` at ply 10

- CoachCard: **Add direct central pressure** — d5 contests White’s center directly while the Nimzo bishop pressure still shapes White’s choices. It gives Black a solid central foothold.

- Plain hint: Use the queen pawn to contest the center while the bishop pressure remains.

- Opening themes: ...d5 center, Nimzo structure, central pressure

### Packet nimzo-indian-black.line-002.ply-12.h7h6

- Move: `h6` / `h7h6` at ply 12

- CoachCard: **Keep Nimzo pressure tied to the center** — h6 supports the Nimzo-Indian plan of central pressure, dark-square control, and coordinated development around the c3 knight.

- Plain hint: Coordinate around the pinned knight, dark squares, and White’s queen-pawn center.

- Opening themes: Nimzo coordination, dark-square pressure, central control


## nimzo-indian-black-line-003: 1. d4 Nf6 2. c4 e6 3. Nc3 Bb4 4. Nf3 c5 5. e3 O-O 6. Bd3 d5

Runtime playKey: `d2d4,g8f6,c2c4,e7e6,b1c3,f8b4,g1f3,c7c5,e2e3,e8h8,f1d3,d7d5`  
Runtime totalGames field at line node: `129754`

### Packet nimzo-indian-black.line-003.ply-06.f8b4

- Move: `Bb4` / `f8b4` at ply 6

- CoachCard: **Pin the c3 knight in true Nimzo style** — Bb4 is the Nimzo-Indian’s defining move: Black pressures the c3 knight that helps White control e4 and d5. This creates structural and central tension without overclaiming tactics.

- Plain hint: Put bishop pressure on the knight that supports White’s central pawns.

- Opening themes: ...Bb4 pin, c3 knight pressure, dark-square control

### Packet nimzo-indian-black.line-003.ply-08.c7c5

- Move: `c5` / `c7c5` at ply 8

- CoachCard: **Hit White’s d-pawn structure** — c5 attacks White’s d4/c4 structure from the side. In the Nimzo, this pairs well with bishop pressure on the c3 knight.

- Plain hint: Use the c-pawn to challenge White’s queen-pawn center.

- Opening themes: ...c5 break, d4 pressure, Nimzo center

### Packet nimzo-indian-black.line-003.ply-10.e8g8

- Move: `O-O` / `e8g8` at ply 10
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle before resolving the Nimzo tension** — O-O secures Black’s king before deciding whether to keep, trade, or retreat the Nimzo bishop. It keeps central pressure without rushing the structure.

- Plain hint: Make the king safe while keeping the bishop and central pressure intact.

- Opening themes: king safety, Nimzo tension, development

### Packet nimzo-indian-black.line-003.ply-12.d7d5

- Move: `d5` / `d7d5` at ply 12

- CoachCard: **Add direct central pressure** — d5 contests White’s center directly while the Nimzo bishop pressure still shapes White’s choices. It gives Black a solid central foothold.

- Plain hint: Use the queen pawn to contest the center while the bishop pressure remains.

- Opening themes: ...d5 center, Nimzo structure, central pressure


## nimzo-indian-black-line-004: 1. d4 Nf6 2. c4 e6 3. Nc3 Bb4 4. Nf3 O-O 5. Bg5 h6 6. Bh4 d5

Runtime playKey: `d2d4,g8f6,c2c4,e7e6,b1c3,f8b4,g1f3,e8h8,c1g5,h7h6,g5h4,d7d5`  
Runtime totalGames field at line node: `93293`

### Packet nimzo-indian-black.line-004.ply-06.f8b4

- Move: `Bb4` / `f8b4` at ply 6

- CoachCard: **Pin the c3 knight in true Nimzo style** — Bb4 is the Nimzo-Indian’s defining move: Black pressures the c3 knight that helps White control e4 and d5. This creates structural and central tension without overclaiming tactics.

- Plain hint: Put bishop pressure on the knight that supports White’s central pawns.

- Opening themes: ...Bb4 pin, c3 knight pressure, dark-square control

### Packet nimzo-indian-black.line-004.ply-08.e8g8

- Move: `O-O` / `e8g8` at ply 8
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle before resolving the Nimzo tension** — O-O secures Black’s king before deciding whether to keep, trade, or retreat the Nimzo bishop. It keeps central pressure without rushing the structure.

- Plain hint: Make the king safe while keeping the bishop and central pressure intact.

- Opening themes: king safety, Nimzo tension, development

### Packet nimzo-indian-black.line-004.ply-10.h7h6

- Move: `h6` / `h7h6` at ply 10

- CoachCard: **Keep Nimzo pressure tied to the center** — h6 supports the Nimzo-Indian plan of central pressure, dark-square control, and coordinated development around the c3 knight.

- Plain hint: Coordinate around the pinned knight, dark squares, and White’s queen-pawn center.

- Opening themes: Nimzo coordination, dark-square pressure, central control

### Packet nimzo-indian-black.line-004.ply-12.d7d5

- Move: `d5` / `d7d5` at ply 12

- CoachCard: **Add direct central pressure** — d5 contests White’s center directly while the Nimzo bishop pressure still shapes White’s choices. It gives Black a solid central foothold.

- Plain hint: Use the queen pawn to contest the center while the bishop pressure remains.

- Opening themes: ...d5 center, Nimzo structure, central pressure


## nimzo-indian-black-line-005: 1. d4 Nf6 2. c4 e6 3. Nc3 Bb4 4. Qc2 O-O 5. a3 Bxc3+ 6. Qxc3 d5

Runtime playKey: `d2d4,g8f6,c2c4,e7e6,b1c3,f8b4,d1c2,e8h8,a2a3,b4c3,c2c3,d7d5`  
Runtime totalGames field at line node: `86508`

### Packet nimzo-indian-black.line-005.ply-06.f8b4

- Move: `Bb4` / `f8b4` at ply 6

- CoachCard: **Pin the c3 knight in true Nimzo style** — Bb4 is the Nimzo-Indian’s defining move: Black pressures the c3 knight that helps White control e4 and d5. This creates structural and central tension without overclaiming tactics.

- Plain hint: Put bishop pressure on the knight that supports White’s central pawns.

- Opening themes: ...Bb4 pin, c3 knight pressure, dark-square control

### Packet nimzo-indian-black.line-005.ply-08.e8g8

- Move: `O-O` / `e8g8` at ply 8
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle before resolving the Nimzo tension** — O-O secures Black’s king before deciding whether to keep, trade, or retreat the Nimzo bishop. It keeps central pressure without rushing the structure.

- Plain hint: Make the king safe while keeping the bishop and central pressure intact.

- Opening themes: king safety, Nimzo tension, development

### Packet nimzo-indian-black.line-005.ply-10.b4c3

- Move: `Bxc3+` / `b4c3` at ply 10

- CoachCard: **Create the Nimzo structural question** — Bxc3+ resolves the Nimzo bishop pressure by damaging or changing White’s queenside pawn structure. The point is structural pressure, not an automatic tactic.

- Plain hint: Trade the bishop only when the resulting structure is part of the plan.

- Opening themes: doubled-pawn threat, structural pressure, bishop trade

### Packet nimzo-indian-black.line-005.ply-12.d7d5

- Move: `d5` / `d7d5` at ply 12

- CoachCard: **Add direct central pressure** — d5 contests White’s center directly while the Nimzo bishop pressure still shapes White’s choices. It gives Black a solid central foothold.

- Plain hint: Use the queen pawn to contest the center while the bishop pressure remains.

- Opening themes: ...d5 center, Nimzo structure, central pressure


## nimzo-indian-black-line-006: 1. d4 Nf6 2. c4 e6 3. Nc3 Bb4 4. Qc2 c5 5. e3 O-O 6. Nf3 d5

Runtime playKey: `d2d4,g8f6,c2c4,e7e6,b1c3,f8b4,d1c2,c7c5,e2e3,e8h8,g1f3,d7d5`  
Runtime totalGames field at line node: `81295`

### Packet nimzo-indian-black.line-006.ply-06.f8b4

- Move: `Bb4` / `f8b4` at ply 6

- CoachCard: **Pin the c3 knight in true Nimzo style** — Bb4 is the Nimzo-Indian’s defining move: Black pressures the c3 knight that helps White control e4 and d5. This creates structural and central tension without overclaiming tactics.

- Plain hint: Put bishop pressure on the knight that supports White’s central pawns.

- Opening themes: ...Bb4 pin, c3 knight pressure, dark-square control

### Packet nimzo-indian-black.line-006.ply-08.c7c5

- Move: `c5` / `c7c5` at ply 8

- CoachCard: **Hit White’s d-pawn structure** — c5 attacks White’s d4/c4 structure from the side. In the Nimzo, this pairs well with bishop pressure on the c3 knight.

- Plain hint: Use the c-pawn to challenge White’s queen-pawn center.

- Opening themes: ...c5 break, d4 pressure, Nimzo center

### Packet nimzo-indian-black.line-006.ply-10.e8g8

- Move: `O-O` / `e8g8` at ply 10
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle before resolving the Nimzo tension** — O-O secures Black’s king before deciding whether to keep, trade, or retreat the Nimzo bishop. It keeps central pressure without rushing the structure.

- Plain hint: Make the king safe while keeping the bishop and central pressure intact.

- Opening themes: king safety, Nimzo tension, development

### Packet nimzo-indian-black.line-006.ply-12.d7d5

- Move: `d5` / `d7d5` at ply 12

- CoachCard: **Add direct central pressure** — d5 contests White’s center directly while the Nimzo bishop pressure still shapes White’s choices. It gives Black a solid central foothold.

- Plain hint: Use the queen pawn to contest the center while the bishop pressure remains.

- Opening themes: ...d5 center, Nimzo structure, central pressure


## nimzo-indian-black-line-007: 1. d4 Nf6 2. c4 e6 3. Nc3 Bb4 4. Nf3 O-O 5. e3 d5 6. a3 Bxc3+

Runtime playKey: `d2d4,g8f6,c2c4,e7e6,b1c3,f8b4,g1f3,e8h8,e2e3,d7d5,a2a3,b4c3`  
Runtime totalGames field at line node: `80208`

### Packet nimzo-indian-black.line-007.ply-06.f8b4

- Move: `Bb4` / `f8b4` at ply 6

- CoachCard: **Pin the c3 knight in true Nimzo style** — Bb4 is the Nimzo-Indian’s defining move: Black pressures the c3 knight that helps White control e4 and d5. This creates structural and central tension without overclaiming tactics.

- Plain hint: Put bishop pressure on the knight that supports White’s central pawns.

- Opening themes: ...Bb4 pin, c3 knight pressure, dark-square control

### Packet nimzo-indian-black.line-007.ply-08.e8g8

- Move: `O-O` / `e8g8` at ply 8
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle before resolving the Nimzo tension** — O-O secures Black’s king before deciding whether to keep, trade, or retreat the Nimzo bishop. It keeps central pressure without rushing the structure.

- Plain hint: Make the king safe while keeping the bishop and central pressure intact.

- Opening themes: king safety, Nimzo tension, development

### Packet nimzo-indian-black.line-007.ply-10.d7d5

- Move: `d5` / `d7d5` at ply 10

- CoachCard: **Add direct central pressure** — d5 contests White’s center directly while the Nimzo bishop pressure still shapes White’s choices. It gives Black a solid central foothold.

- Plain hint: Use the queen pawn to contest the center while the bishop pressure remains.

- Opening themes: ...d5 center, Nimzo structure, central pressure

### Packet nimzo-indian-black.line-007.ply-12.b4c3

- Move: `Bxc3+` / `b4c3` at ply 12

- CoachCard: **Create the Nimzo structural question** — Bxc3+ resolves the Nimzo bishop pressure by damaging or changing White’s queenside pawn structure. The point is structural pressure, not an automatic tactic.

- Plain hint: Trade the bishop only when the resulting structure is part of the plan.

- Opening themes: doubled-pawn threat, structural pressure, bishop trade


## nimzo-indian-black-line-008: 1. d4 Nf6 2. c4 e6 3. Nc3 Bb4 4. Nf3 O-O 5. e3 d5 6. Bd3 dxc4

Runtime playKey: `d2d4,g8f6,c2c4,e7e6,b1c3,f8b4,g1f3,e8h8,e2e3,d7d5,f1d3,d5c4`  
Runtime totalGames field at line node: `74626`

### Packet nimzo-indian-black.line-008.ply-06.f8b4

- Move: `Bb4` / `f8b4` at ply 6

- CoachCard: **Pin the c3 knight in true Nimzo style** — Bb4 is the Nimzo-Indian’s defining move: Black pressures the c3 knight that helps White control e4 and d5. This creates structural and central tension without overclaiming tactics.

- Plain hint: Put bishop pressure on the knight that supports White’s central pawns.

- Opening themes: ...Bb4 pin, c3 knight pressure, dark-square control

### Packet nimzo-indian-black.line-008.ply-08.e8g8

- Move: `O-O` / `e8g8` at ply 8
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle before resolving the Nimzo tension** — O-O secures Black’s king before deciding whether to keep, trade, or retreat the Nimzo bishop. It keeps central pressure without rushing the structure.

- Plain hint: Make the king safe while keeping the bishop and central pressure intact.

- Opening themes: king safety, Nimzo tension, development

### Packet nimzo-indian-black.line-008.ply-10.d7d5

- Move: `d5` / `d7d5` at ply 10

- CoachCard: **Add direct central pressure** — d5 contests White’s center directly while the Nimzo bishop pressure still shapes White’s choices. It gives Black a solid central foothold.

- Plain hint: Use the queen pawn to contest the center while the bishop pressure remains.

- Opening themes: ...d5 center, Nimzo structure, central pressure

### Packet nimzo-indian-black.line-008.ply-12.d5c4

- Move: `dxc4` / `d5c4` at ply 12

- CoachCard: **Keep Nimzo pressure tied to the center** — dxc4 supports the Nimzo-Indian plan of central pressure, dark-square control, and coordinated development around the c3 knight.

- Plain hint: Coordinate around the pinned knight, dark squares, and White’s queen-pawn center.

- Opening themes: Nimzo coordination, dark-square pressure, central control


## nimzo-indian-black-line-009: 1. d4 Nf6 2. c4 e6 3. Nc3 Bb4 4. Qc2 O-O 5. Nf3 d5 6. Bg5 h6

Runtime playKey: `d2d4,g8f6,c2c4,e7e6,b1c3,f8b4,d1c2,e8h8,g1f3,d7d5,c1g5,h7h6`  
Runtime totalGames field at line node: `55572`

### Packet nimzo-indian-black.line-009.ply-06.f8b4

- Move: `Bb4` / `f8b4` at ply 6

- CoachCard: **Pin the c3 knight in true Nimzo style** — Bb4 is the Nimzo-Indian’s defining move: Black pressures the c3 knight that helps White control e4 and d5. This creates structural and central tension without overclaiming tactics.

- Plain hint: Put bishop pressure on the knight that supports White’s central pawns.

- Opening themes: ...Bb4 pin, c3 knight pressure, dark-square control

### Packet nimzo-indian-black.line-009.ply-08.e8g8

- Move: `O-O` / `e8g8` at ply 8
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle before resolving the Nimzo tension** — O-O secures Black’s king before deciding whether to keep, trade, or retreat the Nimzo bishop. It keeps central pressure without rushing the structure.

- Plain hint: Make the king safe while keeping the bishop and central pressure intact.

- Opening themes: king safety, Nimzo tension, development

### Packet nimzo-indian-black.line-009.ply-10.d7d5

- Move: `d5` / `d7d5` at ply 10

- CoachCard: **Add direct central pressure** — d5 contests White’s center directly while the Nimzo bishop pressure still shapes White’s choices. It gives Black a solid central foothold.

- Plain hint: Use the queen pawn to contest the center while the bishop pressure remains.

- Opening themes: ...d5 center, Nimzo structure, central pressure

### Packet nimzo-indian-black.line-009.ply-12.h7h6

- Move: `h6` / `h7h6` at ply 12

- CoachCard: **Keep Nimzo pressure tied to the center** — h6 supports the Nimzo-Indian plan of central pressure, dark-square control, and coordinated development around the c3 knight.

- Plain hint: Coordinate around the pinned knight, dark squares, and White’s queen-pawn center.

- Opening themes: Nimzo coordination, dark-square pressure, central control


## nimzo-indian-black-line-010: 1. d4 Nf6 2. c4 e6 3. Nc3 Bb4 4. Qc2 O-O 5. a3 Bxc3+ 6. Qxc3 b6

Runtime playKey: `d2d4,g8f6,c2c4,e7e6,b1c3,f8b4,d1c2,e8h8,a2a3,b4c3,c2c3,b7b6`  
Runtime totalGames field at line node: `42747`

### Packet nimzo-indian-black.line-010.ply-06.f8b4

- Move: `Bb4` / `f8b4` at ply 6

- CoachCard: **Pin the c3 knight in true Nimzo style** — Bb4 is the Nimzo-Indian’s defining move: Black pressures the c3 knight that helps White control e4 and d5. This creates structural and central tension without overclaiming tactics.

- Plain hint: Put bishop pressure on the knight that supports White’s central pawns.

- Opening themes: ...Bb4 pin, c3 knight pressure, dark-square control

### Packet nimzo-indian-black.line-010.ply-08.e8g8

- Move: `O-O` / `e8g8` at ply 8
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle before resolving the Nimzo tension** — O-O secures Black’s king before deciding whether to keep, trade, or retreat the Nimzo bishop. It keeps central pressure without rushing the structure.

- Plain hint: Make the king safe while keeping the bishop and central pressure intact.

- Opening themes: king safety, Nimzo tension, development

### Packet nimzo-indian-black.line-010.ply-10.b4c3

- Move: `Bxc3+` / `b4c3` at ply 10

- CoachCard: **Create the Nimzo structural question** — Bxc3+ resolves the Nimzo bishop pressure by damaging or changing White’s queenside pawn structure. The point is structural pressure, not an automatic tactic.

- Plain hint: Trade the bishop only when the resulting structure is part of the plan.

- Opening themes: doubled-pawn threat, structural pressure, bishop trade

### Packet nimzo-indian-black.line-010.ply-12.b7b6

- Move: `b6` / `b7b6` at ply 12

- CoachCard: **Add queenside dark-square support** — b6 prepares a queenside fianchetto-style pressure on the long diagonal. In Nimzo structures, this can reinforce control of e4 and d5.

- Plain hint: Prepare a queenside bishop route that increases pressure on the center.

- Opening themes: ...b6 setup, dark-square pressure, Nimzo development


## nimzo-indian-black-line-011: 1. d4 Nf6 2. c4 e6 3. Nc3 Bb4 4. Nf3 O-O 5. Bg5 h6 6. Bxf6 Qxf6

Runtime playKey: `d2d4,g8f6,c2c4,e7e6,b1c3,f8b4,g1f3,e8h8,c1g5,h7h6,g5f6,d8f6`  
Runtime totalGames field at line node: `39882`

### Packet nimzo-indian-black.line-011.ply-06.f8b4

- Move: `Bb4` / `f8b4` at ply 6

- CoachCard: **Pin the c3 knight in true Nimzo style** — Bb4 is the Nimzo-Indian’s defining move: Black pressures the c3 knight that helps White control e4 and d5. This creates structural and central tension without overclaiming tactics.

- Plain hint: Put bishop pressure on the knight that supports White’s central pawns.

- Opening themes: ...Bb4 pin, c3 knight pressure, dark-square control

### Packet nimzo-indian-black.line-011.ply-08.e8g8

- Move: `O-O` / `e8g8` at ply 8
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle before resolving the Nimzo tension** — O-O secures Black’s king before deciding whether to keep, trade, or retreat the Nimzo bishop. It keeps central pressure without rushing the structure.

- Plain hint: Make the king safe while keeping the bishop and central pressure intact.

- Opening themes: king safety, Nimzo tension, development

### Packet nimzo-indian-black.line-011.ply-10.h7h6

- Move: `h6` / `h7h6` at ply 10

- CoachCard: **Keep Nimzo pressure tied to the center** — h6 supports the Nimzo-Indian plan of central pressure, dark-square control, and coordinated development around the c3 knight.

- Plain hint: Coordinate around the pinned knight, dark squares, and White’s queen-pawn center.

- Opening themes: Nimzo coordination, dark-square pressure, central control

### Packet nimzo-indian-black.line-011.ply-12.d8f6

- Move: `Qxf6` / `d8f6` at ply 12

- CoachCard: **Keep Nimzo pressure tied to the center** — Qxf6 supports the Nimzo-Indian plan of central pressure, dark-square control, and coordinated development around the c3 knight.

- Plain hint: Coordinate around the pinned knight, dark squares, and White’s queen-pawn center.

- Opening themes: Nimzo coordination, dark-square pressure, central control


## nimzo-indian-black-line-012: 1. d4 Nf6 2. c4 e6 3. Nc3 Bb4 4. Qc2 O-O 5. Nf3 d5 6. Bg5 Nbd7

Runtime playKey: `d2d4,g8f6,c2c4,e7e6,b1c3,f8b4,d1c2,e8h8,g1f3,d7d5,c1g5,b8d7`  
Runtime totalGames field at line node: `35263`

### Packet nimzo-indian-black.line-012.ply-06.f8b4

- Move: `Bb4` / `f8b4` at ply 6

- CoachCard: **Pin the c3 knight in true Nimzo style** — Bb4 is the Nimzo-Indian’s defining move: Black pressures the c3 knight that helps White control e4 and d5. This creates structural and central tension without overclaiming tactics.

- Plain hint: Put bishop pressure on the knight that supports White’s central pawns.

- Opening themes: ...Bb4 pin, c3 knight pressure, dark-square control

### Packet nimzo-indian-black.line-012.ply-08.e8g8

- Move: `O-O` / `e8g8` at ply 8
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle before resolving the Nimzo tension** — O-O secures Black’s king before deciding whether to keep, trade, or retreat the Nimzo bishop. It keeps central pressure without rushing the structure.

- Plain hint: Make the king safe while keeping the bishop and central pressure intact.

- Opening themes: king safety, Nimzo tension, development

### Packet nimzo-indian-black.line-012.ply-10.d7d5

- Move: `d5` / `d7d5` at ply 10

- CoachCard: **Add direct central pressure** — d5 contests White’s center directly while the Nimzo bishop pressure still shapes White’s choices. It gives Black a solid central foothold.

- Plain hint: Use the queen pawn to contest the center while the bishop pressure remains.

- Opening themes: ...d5 center, Nimzo structure, central pressure

### Packet nimzo-indian-black.line-012.ply-12.b8d7

- Move: `Nbd7` / `b8d7` at ply 12

- CoachCard: **Keep Nimzo pressure tied to the center** — Nbd7 supports the Nimzo-Indian plan of central pressure, dark-square control, and coordinated development around the c3 knight.

- Plain hint: Coordinate around the pinned knight, dark squares, and White’s queen-pawn center.

- Opening themes: Nimzo coordination, dark-square pressure, central control


## nimzo-indian-black-line-013: 1. d4 Nf6 2. c4 e6 3. Nc3 Bb4 4. Qc2 c5 5. e3 Nc6 6. Nf3 O-O

Runtime playKey: `d2d4,g8f6,c2c4,e7e6,b1c3,f8b4,d1c2,c7c5,e2e3,b8c6,g1f3,e8h8`  
Runtime totalGames field at line node: `28931`

### Packet nimzo-indian-black.line-013.ply-06.f8b4

- Move: `Bb4` / `f8b4` at ply 6

- CoachCard: **Pin the c3 knight in true Nimzo style** — Bb4 is the Nimzo-Indian’s defining move: Black pressures the c3 knight that helps White control e4 and d5. This creates structural and central tension without overclaiming tactics.

- Plain hint: Put bishop pressure on the knight that supports White’s central pawns.

- Opening themes: ...Bb4 pin, c3 knight pressure, dark-square control

### Packet nimzo-indian-black.line-013.ply-08.c7c5

- Move: `c5` / `c7c5` at ply 8

- CoachCard: **Hit White’s d-pawn structure** — c5 attacks White’s d4/c4 structure from the side. In the Nimzo, this pairs well with bishop pressure on the c3 knight.

- Plain hint: Use the c-pawn to challenge White’s queen-pawn center.

- Opening themes: ...c5 break, d4 pressure, Nimzo center

### Packet nimzo-indian-black.line-013.ply-10.b8c6

- Move: `Nc6` / `b8c6` at ply 10

- CoachCard: **Keep Nimzo pressure tied to the center** — Nc6 supports the Nimzo-Indian plan of central pressure, dark-square control, and coordinated development around the c3 knight.

- Plain hint: Coordinate around the pinned knight, dark squares, and White’s queen-pawn center.

- Opening themes: Nimzo coordination, dark-square pressure, central control

### Packet nimzo-indian-black.line-013.ply-12.e8g8

- Move: `O-O` / `e8g8` at ply 12
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle before resolving the Nimzo tension** — O-O secures Black’s king before deciding whether to keep, trade, or retreat the Nimzo bishop. It keeps central pressure without rushing the structure.

- Plain hint: Make the king safe while keeping the bishop and central pressure intact.

- Opening themes: king safety, Nimzo tension, development


## nimzo-indian-black-line-014: 1. d4 Nf6 2. c4 e6 3. Nc3 Bb4 4. Nf3 c5 5. e3 O-O 6. Be2 d5

Runtime playKey: `d2d4,g8f6,c2c4,e7e6,b1c3,f8b4,g1f3,c7c5,e2e3,e8h8,f1e2,d7d5`  
Runtime totalGames field at line node: `27994`

### Packet nimzo-indian-black.line-014.ply-06.f8b4

- Move: `Bb4` / `f8b4` at ply 6

- CoachCard: **Pin the c3 knight in true Nimzo style** — Bb4 is the Nimzo-Indian’s defining move: Black pressures the c3 knight that helps White control e4 and d5. This creates structural and central tension without overclaiming tactics.

- Plain hint: Put bishop pressure on the knight that supports White’s central pawns.

- Opening themes: ...Bb4 pin, c3 knight pressure, dark-square control

### Packet nimzo-indian-black.line-014.ply-08.c7c5

- Move: `c5` / `c7c5` at ply 8

- CoachCard: **Hit White’s d-pawn structure** — c5 attacks White’s d4/c4 structure from the side. In the Nimzo, this pairs well with bishop pressure on the c3 knight.

- Plain hint: Use the c-pawn to challenge White’s queen-pawn center.

- Opening themes: ...c5 break, d4 pressure, Nimzo center

### Packet nimzo-indian-black.line-014.ply-10.e8g8

- Move: `O-O` / `e8g8` at ply 10
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle before resolving the Nimzo tension** — O-O secures Black’s king before deciding whether to keep, trade, or retreat the Nimzo bishop. It keeps central pressure without rushing the structure.

- Plain hint: Make the king safe while keeping the bishop and central pressure intact.

- Opening themes: king safety, Nimzo tension, development

### Packet nimzo-indian-black.line-014.ply-12.d7d5

- Move: `d5` / `d7d5` at ply 12

- CoachCard: **Add direct central pressure** — d5 contests White’s center directly while the Nimzo bishop pressure still shapes White’s choices. It gives Black a solid central foothold.

- Plain hint: Use the queen pawn to contest the center while the bishop pressure remains.

- Opening themes: ...d5 center, Nimzo structure, central pressure


## nimzo-indian-black-line-015: 1. d4 Nf6 2. c4 e6 3. Nc3 Bb4 4. Qc2 c5 5. e3 Nc6 6. Nf3 d5

Runtime playKey: `d2d4,g8f6,c2c4,e7e6,b1c3,f8b4,d1c2,c7c5,e2e3,b8c6,g1f3,d7d5`  
Runtime totalGames field at line node: `26286`

### Packet nimzo-indian-black.line-015.ply-06.f8b4

- Move: `Bb4` / `f8b4` at ply 6

- CoachCard: **Pin the c3 knight in true Nimzo style** — Bb4 is the Nimzo-Indian’s defining move: Black pressures the c3 knight that helps White control e4 and d5. This creates structural and central tension without overclaiming tactics.

- Plain hint: Put bishop pressure on the knight that supports White’s central pawns.

- Opening themes: ...Bb4 pin, c3 knight pressure, dark-square control

### Packet nimzo-indian-black.line-015.ply-08.c7c5

- Move: `c5` / `c7c5` at ply 8

- CoachCard: **Hit White’s d-pawn structure** — c5 attacks White’s d4/c4 structure from the side. In the Nimzo, this pairs well with bishop pressure on the c3 knight.

- Plain hint: Use the c-pawn to challenge White’s queen-pawn center.

- Opening themes: ...c5 break, d4 pressure, Nimzo center

### Packet nimzo-indian-black.line-015.ply-10.b8c6

- Move: `Nc6` / `b8c6` at ply 10

- CoachCard: **Keep Nimzo pressure tied to the center** — Nc6 supports the Nimzo-Indian plan of central pressure, dark-square control, and coordinated development around the c3 knight.

- Plain hint: Coordinate around the pinned knight, dark squares, and White’s queen-pawn center.

- Opening themes: Nimzo coordination, dark-square pressure, central control

### Packet nimzo-indian-black.line-015.ply-12.d7d5

- Move: `d5` / `d7d5` at ply 12

- CoachCard: **Add direct central pressure** — d5 contests White’s center directly while the Nimzo bishop pressure still shapes White’s choices. It gives Black a solid central foothold.

- Plain hint: Use the queen pawn to contest the center while the bishop pressure remains.

- Opening themes: ...d5 center, Nimzo structure, central pressure


## nimzo-indian-black-line-016: 1. d4 Nf6 2. c4 e6 3. Nc3 Bb4 4. Nf3 O-O 5. Bg5 h6 6. Bh4 c5

Runtime playKey: `d2d4,g8f6,c2c4,e7e6,b1c3,f8b4,g1f3,e8h8,c1g5,h7h6,g5h4,c7c5`  
Runtime totalGames field at line node: `24828`

### Packet nimzo-indian-black.line-016.ply-06.f8b4

- Move: `Bb4` / `f8b4` at ply 6

- CoachCard: **Pin the c3 knight in true Nimzo style** — Bb4 is the Nimzo-Indian’s defining move: Black pressures the c3 knight that helps White control e4 and d5. This creates structural and central tension without overclaiming tactics.

- Plain hint: Put bishop pressure on the knight that supports White’s central pawns.

- Opening themes: ...Bb4 pin, c3 knight pressure, dark-square control

### Packet nimzo-indian-black.line-016.ply-08.e8g8

- Move: `O-O` / `e8g8` at ply 8
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle before resolving the Nimzo tension** — O-O secures Black’s king before deciding whether to keep, trade, or retreat the Nimzo bishop. It keeps central pressure without rushing the structure.

- Plain hint: Make the king safe while keeping the bishop and central pressure intact.

- Opening themes: king safety, Nimzo tension, development

### Packet nimzo-indian-black.line-016.ply-10.h7h6

- Move: `h6` / `h7h6` at ply 10

- CoachCard: **Keep Nimzo pressure tied to the center** — h6 supports the Nimzo-Indian plan of central pressure, dark-square control, and coordinated development around the c3 knight.

- Plain hint: Coordinate around the pinned knight, dark squares, and White’s queen-pawn center.

- Opening themes: Nimzo coordination, dark-square pressure, central control

### Packet nimzo-indian-black.line-016.ply-12.c7c5

- Move: `c5` / `c7c5` at ply 12

- CoachCard: **Hit White’s d-pawn structure** — c5 attacks White’s d4/c4 structure from the side. In the Nimzo, this pairs well with bishop pressure on the c3 knight.

- Plain hint: Use the c-pawn to challenge White’s queen-pawn center.

- Opening themes: ...c5 break, d4 pressure, Nimzo center


## nimzo-indian-black-line-017: 1. d4 Nf6 2. c4 e6 3. Nc3 Bb4 4. Qc2 c5 5. dxc5 Na6 6. a3 Bxc3+

Runtime playKey: `d2d4,g8f6,c2c4,e7e6,b1c3,f8b4,d1c2,c7c5,d4c5,b8a6,a2a3,b4c3`  
Runtime totalGames field at line node: `24722`

### Packet nimzo-indian-black.line-017.ply-06.f8b4

- Move: `Bb4` / `f8b4` at ply 6

- CoachCard: **Pin the c3 knight in true Nimzo style** — Bb4 is the Nimzo-Indian’s defining move: Black pressures the c3 knight that helps White control e4 and d5. This creates structural and central tension without overclaiming tactics.

- Plain hint: Put bishop pressure on the knight that supports White’s central pawns.

- Opening themes: ...Bb4 pin, c3 knight pressure, dark-square control

### Packet nimzo-indian-black.line-017.ply-08.c7c5

- Move: `c5` / `c7c5` at ply 8

- CoachCard: **Hit White’s d-pawn structure** — c5 attacks White’s d4/c4 structure from the side. In the Nimzo, this pairs well with bishop pressure on the c3 knight.

- Plain hint: Use the c-pawn to challenge White’s queen-pawn center.

- Opening themes: ...c5 break, d4 pressure, Nimzo center

### Packet nimzo-indian-black.line-017.ply-10.b8a6

- Move: `Na6` / `b8a6` at ply 10

- CoachCard: **Keep Nimzo pressure tied to the center** — Na6 supports the Nimzo-Indian plan of central pressure, dark-square control, and coordinated development around the c3 knight.

- Plain hint: Coordinate around the pinned knight, dark squares, and White’s queen-pawn center.

- Opening themes: Nimzo coordination, dark-square pressure, central control

### Packet nimzo-indian-black.line-017.ply-12.b4c3

- Move: `Bxc3+` / `b4c3` at ply 12

- CoachCard: **Create the Nimzo structural question** — Bxc3+ resolves the Nimzo bishop pressure by damaging or changing White’s queenside pawn structure. The point is structural pressure, not an automatic tactic.

- Plain hint: Trade the bishop only when the resulting structure is part of the plan.

- Opening themes: doubled-pawn threat, structural pressure, bishop trade


## nimzo-indian-black-line-018: 1. d4 Nf6 2. c4 e6 3. Nc3 Bb4 4. Qc2 O-O 5. Nf3 d5 6. e3 b6

Runtime playKey: `d2d4,g8f6,c2c4,e7e6,b1c3,f8b4,d1c2,e8h8,g1f3,d7d5,e2e3,b7b6`  
Runtime totalGames field at line node: `22965`

### Packet nimzo-indian-black.line-018.ply-06.f8b4

- Move: `Bb4` / `f8b4` at ply 6

- CoachCard: **Pin the c3 knight in true Nimzo style** — Bb4 is the Nimzo-Indian’s defining move: Black pressures the c3 knight that helps White control e4 and d5. This creates structural and central tension without overclaiming tactics.

- Plain hint: Put bishop pressure on the knight that supports White’s central pawns.

- Opening themes: ...Bb4 pin, c3 knight pressure, dark-square control

### Packet nimzo-indian-black.line-018.ply-08.e8g8

- Move: `O-O` / `e8g8` at ply 8
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle before resolving the Nimzo tension** — O-O secures Black’s king before deciding whether to keep, trade, or retreat the Nimzo bishop. It keeps central pressure without rushing the structure.

- Plain hint: Make the king safe while keeping the bishop and central pressure intact.

- Opening themes: king safety, Nimzo tension, development

### Packet nimzo-indian-black.line-018.ply-10.d7d5

- Move: `d5` / `d7d5` at ply 10

- CoachCard: **Add direct central pressure** — d5 contests White’s center directly while the Nimzo bishop pressure still shapes White’s choices. It gives Black a solid central foothold.

- Plain hint: Use the queen pawn to contest the center while the bishop pressure remains.

- Opening themes: ...d5 center, Nimzo structure, central pressure

### Packet nimzo-indian-black.line-018.ply-12.b7b6

- Move: `b6` / `b7b6` at ply 12

- CoachCard: **Add queenside dark-square support** — b6 prepares a queenside fianchetto-style pressure on the long diagonal. In Nimzo structures, this can reinforce control of e4 and d5.

- Plain hint: Prepare a queenside bishop route that increases pressure on the center.

- Opening themes: ...b6 setup, dark-square pressure, Nimzo development


## nimzo-indian-black-line-019: 1. d4 Nf6 2. c4 e6 3. Nc3 Bb4 4. Nf3 O-O 5. e3 d5 6. a3 Be7

Runtime playKey: `d2d4,g8f6,c2c4,e7e6,b1c3,f8b4,g1f3,e8h8,e2e3,d7d5,a2a3,b4e7`  
Runtime totalGames field at line node: `22787`

### Packet nimzo-indian-black.line-019.ply-06.f8b4

- Move: `Bb4` / `f8b4` at ply 6

- CoachCard: **Pin the c3 knight in true Nimzo style** — Bb4 is the Nimzo-Indian’s defining move: Black pressures the c3 knight that helps White control e4 and d5. This creates structural and central tension without overclaiming tactics.

- Plain hint: Put bishop pressure on the knight that supports White’s central pawns.

- Opening themes: ...Bb4 pin, c3 knight pressure, dark-square control

### Packet nimzo-indian-black.line-019.ply-08.e8g8

- Move: `O-O` / `e8g8` at ply 8
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle before resolving the Nimzo tension** — O-O secures Black’s king before deciding whether to keep, trade, or retreat the Nimzo bishop. It keeps central pressure without rushing the structure.

- Plain hint: Make the king safe while keeping the bishop and central pressure intact.

- Opening themes: king safety, Nimzo tension, development

### Packet nimzo-indian-black.line-019.ply-10.d7d5

- Move: `d5` / `d7d5` at ply 10

- CoachCard: **Add direct central pressure** — d5 contests White’s center directly while the Nimzo bishop pressure still shapes White’s choices. It gives Black a solid central foothold.

- Plain hint: Use the queen pawn to contest the center while the bishop pressure remains.

- Opening themes: ...d5 center, Nimzo structure, central pressure

### Packet nimzo-indian-black.line-019.ply-12.b4e7

- Move: `Be7` / `b4e7` at ply 12

- CoachCard: **Keep Nimzo pressure tied to the center** — Be7 supports the Nimzo-Indian plan of central pressure, dark-square control, and coordinated development around the c3 knight.

- Plain hint: Coordinate around the pinned knight, dark squares, and White’s queen-pawn center.

- Opening themes: Nimzo coordination, dark-square pressure, central control


## nimzo-indian-black-line-020: 1. d4 Nf6 2. c4 e6 3. Nc3 Bb4 4. Qc2 c5 5. dxc5 Bxc5 6. Nf3 O-O

Runtime playKey: `d2d4,g8f6,c2c4,e7e6,b1c3,f8b4,d1c2,c7c5,d4c5,b4c5,g1f3,e8h8`  
Runtime totalGames field at line node: `22337`

### Packet nimzo-indian-black.line-020.ply-06.f8b4

- Move: `Bb4` / `f8b4` at ply 6

- CoachCard: **Pin the c3 knight in true Nimzo style** — Bb4 is the Nimzo-Indian’s defining move: Black pressures the c3 knight that helps White control e4 and d5. This creates structural and central tension without overclaiming tactics.

- Plain hint: Put bishop pressure on the knight that supports White’s central pawns.

- Opening themes: ...Bb4 pin, c3 knight pressure, dark-square control

### Packet nimzo-indian-black.line-020.ply-08.c7c5

- Move: `c5` / `c7c5` at ply 8

- CoachCard: **Hit White’s d-pawn structure** — c5 attacks White’s d4/c4 structure from the side. In the Nimzo, this pairs well with bishop pressure on the c3 knight.

- Plain hint: Use the c-pawn to challenge White’s queen-pawn center.

- Opening themes: ...c5 break, d4 pressure, Nimzo center

### Packet nimzo-indian-black.line-020.ply-10.b4c5

- Move: `Bxc5` / `b4c5` at ply 10

- CoachCard: **Keep Nimzo pressure tied to the center** — Bxc5 supports the Nimzo-Indian plan of central pressure, dark-square control, and coordinated development around the c3 knight.

- Plain hint: Coordinate around the pinned knight, dark squares, and White’s queen-pawn center.

- Opening themes: Nimzo coordination, dark-square pressure, central control

### Packet nimzo-indian-black.line-020.ply-12.e8g8

- Move: `O-O` / `e8g8` at ply 12
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle before resolving the Nimzo tension** — O-O secures Black’s king before deciding whether to keep, trade, or retreat the Nimzo bishop. It keeps central pressure without rushing the structure.

- Plain hint: Make the king safe while keeping the bishop and central pressure intact.

- Opening themes: king safety, Nimzo tension, development


## nimzo-indian-black-line-021: 1. d4 Nf6 2. c4 e6 3. Nc3 Bb4 4. Nf3 c5 5. e3 Nc6 6. Bd3 O-O

Runtime playKey: `d2d4,g8f6,c2c4,e7e6,b1c3,f8b4,g1f3,c7c5,e2e3,b8c6,f1d3,e8h8`  
Runtime totalGames field at line node: `20650`

### Packet nimzo-indian-black.line-021.ply-06.f8b4

- Move: `Bb4` / `f8b4` at ply 6

- CoachCard: **Pin the c3 knight in true Nimzo style** — Bb4 is the Nimzo-Indian’s defining move: Black pressures the c3 knight that helps White control e4 and d5. This creates structural and central tension without overclaiming tactics.

- Plain hint: Put bishop pressure on the knight that supports White’s central pawns.

- Opening themes: ...Bb4 pin, c3 knight pressure, dark-square control

### Packet nimzo-indian-black.line-021.ply-08.c7c5

- Move: `c5` / `c7c5` at ply 8

- CoachCard: **Hit White’s d-pawn structure** — c5 attacks White’s d4/c4 structure from the side. In the Nimzo, this pairs well with bishop pressure on the c3 knight.

- Plain hint: Use the c-pawn to challenge White’s queen-pawn center.

- Opening themes: ...c5 break, d4 pressure, Nimzo center

### Packet nimzo-indian-black.line-021.ply-10.b8c6

- Move: `Nc6` / `b8c6` at ply 10

- CoachCard: **Keep Nimzo pressure tied to the center** — Nc6 supports the Nimzo-Indian plan of central pressure, dark-square control, and coordinated development around the c3 knight.

- Plain hint: Coordinate around the pinned knight, dark squares, and White’s queen-pawn center.

- Opening themes: Nimzo coordination, dark-square pressure, central control

### Packet nimzo-indian-black.line-021.ply-12.e8g8

- Move: `O-O` / `e8g8` at ply 12
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle before resolving the Nimzo tension** — O-O secures Black’s king before deciding whether to keep, trade, or retreat the Nimzo bishop. It keeps central pressure without rushing the structure.

- Plain hint: Make the king safe while keeping the bishop and central pressure intact.

- Opening themes: king safety, Nimzo tension, development


## nimzo-indian-black-line-022: 1. d4 Nf6 2. c4 e6 3. Nc3 Bb4 4. Qc2 c5 5. dxc5 Na6 6. Nf3 O-O

Runtime playKey: `d2d4,g8f6,c2c4,e7e6,b1c3,f8b4,d1c2,c7c5,d4c5,b8a6,g1f3,e8h8`  
Runtime totalGames field at line node: `20086`

### Packet nimzo-indian-black.line-022.ply-06.f8b4

- Move: `Bb4` / `f8b4` at ply 6

- CoachCard: **Pin the c3 knight in true Nimzo style** — Bb4 is the Nimzo-Indian’s defining move: Black pressures the c3 knight that helps White control e4 and d5. This creates structural and central tension without overclaiming tactics.

- Plain hint: Put bishop pressure on the knight that supports White’s central pawns.

- Opening themes: ...Bb4 pin, c3 knight pressure, dark-square control

### Packet nimzo-indian-black.line-022.ply-08.c7c5

- Move: `c5` / `c7c5` at ply 8

- CoachCard: **Hit White’s d-pawn structure** — c5 attacks White’s d4/c4 structure from the side. In the Nimzo, this pairs well with bishop pressure on the c3 knight.

- Plain hint: Use the c-pawn to challenge White’s queen-pawn center.

- Opening themes: ...c5 break, d4 pressure, Nimzo center

### Packet nimzo-indian-black.line-022.ply-10.b8a6

- Move: `Na6` / `b8a6` at ply 10

- CoachCard: **Keep Nimzo pressure tied to the center** — Na6 supports the Nimzo-Indian plan of central pressure, dark-square control, and coordinated development around the c3 knight.

- Plain hint: Coordinate around the pinned knight, dark squares, and White’s queen-pawn center.

- Opening themes: Nimzo coordination, dark-square pressure, central control

### Packet nimzo-indian-black.line-022.ply-12.e8g8

- Move: `O-O` / `e8g8` at ply 12
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle before resolving the Nimzo tension** — O-O secures Black’s king before deciding whether to keep, trade, or retreat the Nimzo bishop. It keeps central pressure without rushing the structure.

- Plain hint: Make the king safe while keeping the bishop and central pressure intact.

- Opening themes: king safety, Nimzo tension, development


## nimzo-indian-black-line-023: 1. d4 Nf6 2. c4 e6 3. Nc3 Bb4 4. Qc2 c5 5. dxc5 Bxc5 6. Nf3 Nc6

Runtime playKey: `d2d4,g8f6,c2c4,e7e6,b1c3,f8b4,d1c2,c7c5,d4c5,b4c5,g1f3,b8c6`  
Runtime totalGames field at line node: `17065`

### Packet nimzo-indian-black.line-023.ply-06.f8b4

- Move: `Bb4` / `f8b4` at ply 6

- CoachCard: **Pin the c3 knight in true Nimzo style** — Bb4 is the Nimzo-Indian’s defining move: Black pressures the c3 knight that helps White control e4 and d5. This creates structural and central tension without overclaiming tactics.

- Plain hint: Put bishop pressure on the knight that supports White’s central pawns.

- Opening themes: ...Bb4 pin, c3 knight pressure, dark-square control

### Packet nimzo-indian-black.line-023.ply-08.c7c5

- Move: `c5` / `c7c5` at ply 8

- CoachCard: **Hit White’s d-pawn structure** — c5 attacks White’s d4/c4 structure from the side. In the Nimzo, this pairs well with bishop pressure on the c3 knight.

- Plain hint: Use the c-pawn to challenge White’s queen-pawn center.

- Opening themes: ...c5 break, d4 pressure, Nimzo center

### Packet nimzo-indian-black.line-023.ply-10.b4c5

- Move: `Bxc5` / `b4c5` at ply 10

- CoachCard: **Keep Nimzo pressure tied to the center** — Bxc5 supports the Nimzo-Indian plan of central pressure, dark-square control, and coordinated development around the c3 knight.

- Plain hint: Coordinate around the pinned knight, dark squares, and White’s queen-pawn center.

- Opening themes: Nimzo coordination, dark-square pressure, central control

### Packet nimzo-indian-black.line-023.ply-12.b8c6

- Move: `Nc6` / `b8c6` at ply 12

- CoachCard: **Keep Nimzo pressure tied to the center** — Nc6 supports the Nimzo-Indian plan of central pressure, dark-square control, and coordinated development around the c3 knight.

- Plain hint: Coordinate around the pinned knight, dark squares, and White’s queen-pawn center.

- Opening themes: Nimzo coordination, dark-square pressure, central control


## nimzo-indian-black-line-024: 1. d4 Nf6 2. c4 e6 3. Nc3 Bb4 4. Nf3 c5 5. d5 exd5 6. cxd5 d6

Runtime playKey: `d2d4,g8f6,c2c4,e7e6,b1c3,f8b4,g1f3,c7c5,d4d5,e6d5,c4d5,d7d6`  
Runtime totalGames field at line node: `14374`

### Packet nimzo-indian-black.line-024.ply-06.f8b4

- Move: `Bb4` / `f8b4` at ply 6

- CoachCard: **Pin the c3 knight in true Nimzo style** — Bb4 is the Nimzo-Indian’s defining move: Black pressures the c3 knight that helps White control e4 and d5. This creates structural and central tension without overclaiming tactics.

- Plain hint: Put bishop pressure on the knight that supports White’s central pawns.

- Opening themes: ...Bb4 pin, c3 knight pressure, dark-square control

### Packet nimzo-indian-black.line-024.ply-08.c7c5

- Move: `c5` / `c7c5` at ply 8

- CoachCard: **Hit White’s d-pawn structure** — c5 attacks White’s d4/c4 structure from the side. In the Nimzo, this pairs well with bishop pressure on the c3 knight.

- Plain hint: Use the c-pawn to challenge White’s queen-pawn center.

- Opening themes: ...c5 break, d4 pressure, Nimzo center

### Packet nimzo-indian-black.line-024.ply-10.e6d5

- Move: `exd5` / `e6d5` at ply 10

- CoachCard: **Keep Nimzo pressure tied to the center** — exd5 supports the Nimzo-Indian plan of central pressure, dark-square control, and coordinated development around the c3 knight.

- Plain hint: Coordinate around the pinned knight, dark squares, and White’s queen-pawn center.

- Opening themes: Nimzo coordination, dark-square pressure, central control

### Packet nimzo-indian-black.line-024.ply-12.d7d6

- Move: `d6` / `d7d6` at ply 12

- CoachCard: **Keep Nimzo pressure tied to the center** — d6 supports the Nimzo-Indian plan of central pressure, dark-square control, and coordinated development around the c3 knight.

- Plain hint: Coordinate around the pinned knight, dark squares, and White’s queen-pawn center.

- Opening themes: Nimzo coordination, dark-square pressure, central control


## nimzo-indian-black-line-025: 1. d4 Nf6 2. c4 e6 3. Nc3 Bb4 4. Qc2 O-O 5. a3 Be7 6. Nf3 d5

Runtime playKey: `d2d4,g8f6,c2c4,e7e6,b1c3,f8b4,d1c2,e8h8,a2a3,b4e7,g1f3,d7d5`  
Runtime totalGames field at line node: `11057`

### Packet nimzo-indian-black.line-025.ply-06.f8b4

- Move: `Bb4` / `f8b4` at ply 6

- CoachCard: **Pin the c3 knight in true Nimzo style** — Bb4 is the Nimzo-Indian’s defining move: Black pressures the c3 knight that helps White control e4 and d5. This creates structural and central tension without overclaiming tactics.

- Plain hint: Put bishop pressure on the knight that supports White’s central pawns.

- Opening themes: ...Bb4 pin, c3 knight pressure, dark-square control

### Packet nimzo-indian-black.line-025.ply-08.e8g8

- Move: `O-O` / `e8g8` at ply 8
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle before resolving the Nimzo tension** — O-O secures Black’s king before deciding whether to keep, trade, or retreat the Nimzo bishop. It keeps central pressure without rushing the structure.

- Plain hint: Make the king safe while keeping the bishop and central pressure intact.

- Opening themes: king safety, Nimzo tension, development

### Packet nimzo-indian-black.line-025.ply-10.b4e7

- Move: `Be7` / `b4e7` at ply 10

- CoachCard: **Keep Nimzo pressure tied to the center** — Be7 supports the Nimzo-Indian plan of central pressure, dark-square control, and coordinated development around the c3 knight.

- Plain hint: Coordinate around the pinned knight, dark squares, and White’s queen-pawn center.

- Opening themes: Nimzo coordination, dark-square pressure, central control

### Packet nimzo-indian-black.line-025.ply-12.d7d5

- Move: `d5` / `d7d5` at ply 12

- CoachCard: **Add direct central pressure** — d5 contests White’s center directly while the Nimzo bishop pressure still shapes White’s choices. It gives Black a solid central foothold.

- Plain hint: Use the queen pawn to contest the center while the bishop pressure remains.

- Opening themes: ...d5 center, Nimzo structure, central pressure
