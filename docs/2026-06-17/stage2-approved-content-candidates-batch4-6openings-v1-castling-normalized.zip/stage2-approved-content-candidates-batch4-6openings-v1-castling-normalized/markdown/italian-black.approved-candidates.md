# Italian Game as Black approved-content candidates — Batch 4

Opening ID: `italian-black`  
Status: approved candidates only; not app-activated.


## italian-black-line-001: 1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. c3 Nf6 5. d4 exd4 6. cxd4 Bb4+

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1c4,f8c5,c2c3,g8f6,d2d4,e5d4,c3d4,c5b4`  
Runtime totalGames field at line node: `3593728`

### Packet italian-black.line-001.ply-06.f8c5

- Move: `Bc5` / `f8c5` at ply 6

- CoachCard: **Develop the Italian bishop actively** — Bc5 develops the bishop to an active Italian square, keeping pressure on White’s kingside and clearing Black to castle. It also keeps an eye on the central light squares.

- Plain hint: Place the king bishop on the active diagonal before castling.

- Opening themes: ...Bc5 Italian setup, kingside pressure, castling preparation

### Packet italian-black.line-001.ply-08.g8f6

- Move: `Nf6` / `g8f6` at ply 8

- CoachCard: **Attack e4 before White expands** — Nf6 develops with a direct question to White’s e-pawn. In Italian structures, this also prepares castling before White’s c3/d4 center arrives.

- Plain hint: Bring the kingside knight out to hit White’s central pawn and prepare king safety.

- Opening themes: e4 pressure, kingside development, castling preparation

### Packet italian-black.line-001.ply-10.e5d4

- Move: `exd4` / `e5d4` at ply 10

- CoachCard: **Clarify White’s Italian central break** — exd4 answers White’s d-pawn break by exchanging in the center. In Italian lines with c3 and d4, Black should meet the break directly rather than drift.

- Plain hint: When White opens the center, use the central pawn to resolve the tension.

- Opening themes: c3/d4 break, central clarification, Italian center

### Packet italian-black.line-001.ply-12.c5b4

- Move: `Bb4+` / `c5b4` at ply 12

- CoachCard: **Preserve the active Italian bishop** — Bb4+ repositions the Italian bishop after central contact. The bishop stays relevant to White’s king and central light squares instead of being trapped by the pawn structure.

- Plain hint: Keep the bishop active after the center changes.

- Opening themes: bishop activity, response to d4, Italian light squares


## italian-black-line-002: 1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. c3 d6 5. d4 exd4 6. cxd4 Bb6

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1c4,f8c5,c2c3,d7d6,d2d4,e5d4,c3d4,c5b6`  
Runtime totalGames field at line node: `1436145`

### Packet italian-black.line-002.ply-06.f8c5

- Move: `Bc5` / `f8c5` at ply 6

- CoachCard: **Develop the Italian bishop actively** — Bc5 develops the bishop to an active Italian square, keeping pressure on White’s kingside and clearing Black to castle. It also keeps an eye on the central light squares.

- Plain hint: Place the king bishop on the active diagonal before castling.

- Opening themes: ...Bc5 Italian setup, kingside pressure, castling preparation

### Packet italian-black.line-002.ply-08.d7d6

- Move: `d6` / `d7d6` at ply 8

- CoachCard: **Brace the Italian center** — d6 reinforces Black’s e5 pawn and gives the c8 bishop a route. Against Italian c3/d4 ideas, this keeps Black’s center from being pulled apart too quickly.

- Plain hint: Support the central pawn so White’s planned pawn break does not come with tempo.

- Opening themes: e5 support, c3/d4 response, solid Italian structure

### Packet italian-black.line-002.ply-10.e5d4

- Move: `exd4` / `e5d4` at ply 10

- CoachCard: **Clarify White’s Italian central break** — exd4 answers White’s d-pawn break by exchanging in the center. In Italian lines with c3 and d4, Black should meet the break directly rather than drift.

- Plain hint: When White opens the center, use the central pawn to resolve the tension.

- Opening themes: c3/d4 break, central clarification, Italian center

### Packet italian-black.line-002.ply-12.c5b6

- Move: `Bb6` / `c5b6` at ply 12

- CoachCard: **Preserve the active Italian bishop** — Bb6 repositions the Italian bishop after central contact. The bishop stays relevant to White’s king and central light squares instead of being trapped by the pawn structure.

- Plain hint: Keep the bishop active after the center changes.

- Opening themes: bishop activity, response to d4, Italian light squares


## italian-black-line-003: 1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. c3 d6 5. d4 exd4 6. cxd4 Bb4+

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1c4,f8c5,c2c3,d7d6,d2d4,e5d4,c3d4,c5b4`  
Runtime totalGames field at line node: `1434702`

### Packet italian-black.line-003.ply-06.f8c5

- Move: `Bc5` / `f8c5` at ply 6

- CoachCard: **Develop the Italian bishop actively** — Bc5 develops the bishop to an active Italian square, keeping pressure on White’s kingside and clearing Black to castle. It also keeps an eye on the central light squares.

- Plain hint: Place the king bishop on the active diagonal before castling.

- Opening themes: ...Bc5 Italian setup, kingside pressure, castling preparation

### Packet italian-black.line-003.ply-08.d7d6

- Move: `d6` / `d7d6` at ply 8

- CoachCard: **Brace the Italian center** — d6 reinforces Black’s e5 pawn and gives the c8 bishop a route. Against Italian c3/d4 ideas, this keeps Black’s center from being pulled apart too quickly.

- Plain hint: Support the central pawn so White’s planned pawn break does not come with tempo.

- Opening themes: e5 support, c3/d4 response, solid Italian structure

### Packet italian-black.line-003.ply-10.e5d4

- Move: `exd4` / `e5d4` at ply 10

- CoachCard: **Clarify White’s Italian central break** — exd4 answers White’s d-pawn break by exchanging in the center. In Italian lines with c3 and d4, Black should meet the break directly rather than drift.

- Plain hint: When White opens the center, use the central pawn to resolve the tension.

- Opening themes: c3/d4 break, central clarification, Italian center

### Packet italian-black.line-003.ply-12.c5b4

- Move: `Bb4+` / `c5b4` at ply 12

- CoachCard: **Preserve the active Italian bishop** — Bb4+ repositions the Italian bishop after central contact. The bishop stays relevant to White’s king and central light squares instead of being trapped by the pawn structure.

- Plain hint: Keep the bishop active after the center changes.

- Opening themes: bishop activity, response to d4, Italian light squares


## italian-black-line-004: 1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. c3 Nf6 5. d3 O-O 6. O-O h6

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1c4,f8c5,c2c3,g8f6,d2d3,e8h8,e1h1,h7h6`  
Runtime totalGames field at line node: `1142935`

### Packet italian-black.line-004.ply-06.f8c5

- Move: `Bc5` / `f8c5` at ply 6

- CoachCard: **Develop the Italian bishop actively** — Bc5 develops the bishop to an active Italian square, keeping pressure on White’s kingside and clearing Black to castle. It also keeps an eye on the central light squares.

- Plain hint: Place the king bishop on the active diagonal before castling.

- Opening themes: ...Bc5 Italian setup, kingside pressure, castling preparation

### Packet italian-black.line-004.ply-08.g8f6

- Move: `Nf6` / `g8f6` at ply 8

- CoachCard: **Attack e4 before White expands** — Nf6 develops with a direct question to White’s e-pawn. In Italian structures, this also prepares castling before White’s c3/d4 center arrives.

- Plain hint: Bring the kingside knight out to hit White’s central pawn and prepare king safety.

- Opening themes: e4 pressure, kingside development, castling preparation

### Packet italian-black.line-004.ply-10.e8g8

- Move: `O-O` / `e8g8` at ply 10
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle before the Italian center opens** — O-O puts Black’s king safe before the Italian center can open. That is important when White is preparing c3, d4, or piece pressure on the kingside.

- Plain hint: Secure the king before White’s central pawn break becomes sharper.

- Opening themes: king safety, Italian center, castling timing

### Packet italian-black.line-004.ply-12.h7h6

- Move: `h6` / `h7h6` at ply 12

- CoachCard: **Question the pin without loosening the center** — h6 gives Black a useful luft-style question in an Italian structure without abandoning central support. It is relevant when White’s bishop pressure affects Black’s development.

- Plain hint: Ask the bishop or knight to clarify while keeping the central structure intact.

- Opening themes: bishop question, king shelter, Italian structure


## italian-black-line-005: 1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. O-O d6 5. h3 Nf6 6. d3 h6

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1c4,f8c5,e1h1,d7d6,h2h3,g8f6,d2d3,h7h6`  
Runtime totalGames field at line node: `996294`

### Packet italian-black.line-005.ply-06.f8c5

- Move: `Bc5` / `f8c5` at ply 6

- CoachCard: **Develop the Italian bishop actively** — Bc5 develops the bishop to an active Italian square, keeping pressure on White’s kingside and clearing Black to castle. It also keeps an eye on the central light squares.

- Plain hint: Place the king bishop on the active diagonal before castling.

- Opening themes: ...Bc5 Italian setup, kingside pressure, castling preparation

### Packet italian-black.line-005.ply-08.d7d6

- Move: `d6` / `d7d6` at ply 8

- CoachCard: **Brace the Italian center** — d6 reinforces Black’s e5 pawn and gives the c8 bishop a route. Against Italian c3/d4 ideas, this keeps Black’s center from being pulled apart too quickly.

- Plain hint: Support the central pawn so White’s planned pawn break does not come with tempo.

- Opening themes: e5 support, c3/d4 response, solid Italian structure

### Packet italian-black.line-005.ply-10.g8f6

- Move: `Nf6` / `g8f6` at ply 10

- CoachCard: **Attack e4 before White expands** — Nf6 develops with a direct question to White’s e-pawn. In Italian structures, this also prepares castling before White’s c3/d4 center arrives.

- Plain hint: Bring the kingside knight out to hit White’s central pawn and prepare king safety.

- Opening themes: e4 pressure, kingside development, castling preparation

### Packet italian-black.line-005.ply-12.h7h6

- Move: `h6` / `h7h6` at ply 12

- CoachCard: **Question the pin without loosening the center** — h6 gives Black a useful luft-style question in an Italian structure without abandoning central support. It is relevant when White’s bishop pressure affects Black’s development.

- Plain hint: Ask the bishop or knight to clarify while keeping the central structure intact.

- Opening themes: bishop question, king shelter, Italian structure


## italian-black-line-006: 1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. c3 d6 5. O-O Nf6 6. d3 O-O

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1c4,f8c5,c2c3,d7d6,e1h1,g8f6,d2d3,e8h8`  
Runtime totalGames field at line node: `904253`

### Packet italian-black.line-006.ply-06.f8c5

- Move: `Bc5` / `f8c5` at ply 6

- CoachCard: **Develop the Italian bishop actively** — Bc5 develops the bishop to an active Italian square, keeping pressure on White’s kingside and clearing Black to castle. It also keeps an eye on the central light squares.

- Plain hint: Place the king bishop on the active diagonal before castling.

- Opening themes: ...Bc5 Italian setup, kingside pressure, castling preparation

### Packet italian-black.line-006.ply-08.d7d6

- Move: `d6` / `d7d6` at ply 8

- CoachCard: **Brace the Italian center** — d6 reinforces Black’s e5 pawn and gives the c8 bishop a route. Against Italian c3/d4 ideas, this keeps Black’s center from being pulled apart too quickly.

- Plain hint: Support the central pawn so White’s planned pawn break does not come with tempo.

- Opening themes: e5 support, c3/d4 response, solid Italian structure

### Packet italian-black.line-006.ply-10.g8f6

- Move: `Nf6` / `g8f6` at ply 10

- CoachCard: **Attack e4 before White expands** — Nf6 develops with a direct question to White’s e-pawn. In Italian structures, this also prepares castling before White’s c3/d4 center arrives.

- Plain hint: Bring the kingside knight out to hit White’s central pawn and prepare king safety.

- Opening themes: e4 pressure, kingside development, castling preparation

### Packet italian-black.line-006.ply-12.e8g8

- Move: `O-O` / `e8g8` at ply 12
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle before the Italian center opens** — O-O puts Black’s king safe before the Italian center can open. That is important when White is preparing c3, d4, or piece pressure on the kingside.

- Plain hint: Secure the king before White’s central pawn break becomes sharper.

- Opening themes: king safety, Italian center, castling timing


## italian-black-line-007: 1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. O-O Nf6 5. c3 O-O 6. d4 exd4

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1c4,f8c5,e1h1,g8f6,c2c3,e8h8,d2d4,e5d4`  
Runtime totalGames field at line node: `903575`

### Packet italian-black.line-007.ply-06.f8c5

- Move: `Bc5` / `f8c5` at ply 6

- CoachCard: **Develop the Italian bishop actively** — Bc5 develops the bishop to an active Italian square, keeping pressure on White’s kingside and clearing Black to castle. It also keeps an eye on the central light squares.

- Plain hint: Place the king bishop on the active diagonal before castling.

- Opening themes: ...Bc5 Italian setup, kingside pressure, castling preparation

### Packet italian-black.line-007.ply-08.g8f6

- Move: `Nf6` / `g8f6` at ply 8

- CoachCard: **Attack e4 before White expands** — Nf6 develops with a direct question to White’s e-pawn. In Italian structures, this also prepares castling before White’s c3/d4 center arrives.

- Plain hint: Bring the kingside knight out to hit White’s central pawn and prepare king safety.

- Opening themes: e4 pressure, kingside development, castling preparation

### Packet italian-black.line-007.ply-10.e8g8

- Move: `O-O` / `e8g8` at ply 10
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle before the Italian center opens** — O-O puts Black’s king safe before the Italian center can open. That is important when White is preparing c3, d4, or piece pressure on the kingside.

- Plain hint: Secure the king before White’s central pawn break becomes sharper.

- Opening themes: king safety, Italian center, castling timing

### Packet italian-black.line-007.ply-12.e5d4

- Move: `exd4` / `e5d4` at ply 12

- CoachCard: **Clarify White’s Italian central break** — exd4 answers White’s d-pawn break by exchanging in the center. In Italian lines with c3 and d4, Black should meet the break directly rather than drift.

- Plain hint: When White opens the center, use the central pawn to resolve the tension.

- Opening themes: c3/d4 break, central clarification, Italian center


## italian-black-line-008: 1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. c3 d6 5. O-O Nf6 6. d4 exd4

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1c4,f8c5,c2c3,d7d6,e1h1,g8f6,d2d4,e5d4`  
Runtime totalGames field at line node: `749048`

### Packet italian-black.line-008.ply-06.f8c5

- Move: `Bc5` / `f8c5` at ply 6

- CoachCard: **Develop the Italian bishop actively** — Bc5 develops the bishop to an active Italian square, keeping pressure on White’s kingside and clearing Black to castle. It also keeps an eye on the central light squares.

- Plain hint: Place the king bishop on the active diagonal before castling.

- Opening themes: ...Bc5 Italian setup, kingside pressure, castling preparation

### Packet italian-black.line-008.ply-08.d7d6

- Move: `d6` / `d7d6` at ply 8

- CoachCard: **Brace the Italian center** — d6 reinforces Black’s e5 pawn and gives the c8 bishop a route. Against Italian c3/d4 ideas, this keeps Black’s center from being pulled apart too quickly.

- Plain hint: Support the central pawn so White’s planned pawn break does not come with tempo.

- Opening themes: e5 support, c3/d4 response, solid Italian structure

### Packet italian-black.line-008.ply-10.g8f6

- Move: `Nf6` / `g8f6` at ply 10

- CoachCard: **Attack e4 before White expands** — Nf6 develops with a direct question to White’s e-pawn. In Italian structures, this also prepares castling before White’s c3/d4 center arrives.

- Plain hint: Bring the kingside knight out to hit White’s central pawn and prepare king safety.

- Opening themes: e4 pressure, kingside development, castling preparation

### Packet italian-black.line-008.ply-12.e5d4

- Move: `exd4` / `e5d4` at ply 12

- CoachCard: **Clarify White’s Italian central break** — exd4 answers White’s d-pawn break by exchanging in the center. In Italian lines with c3 and d4, Black should meet the break directly rather than drift.

- Plain hint: When White opens the center, use the central pawn to resolve the tension.

- Opening themes: c3/d4 break, central clarification, Italian center


## italian-black-line-009: 1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. c3 Nf6 5. d4 exd4 6. cxd4 Bb6

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1c4,f8c5,c2c3,g8f6,d2d4,e5d4,c3d4,c5b6`  
Runtime totalGames field at line node: `698730`

### Packet italian-black.line-009.ply-06.f8c5

- Move: `Bc5` / `f8c5` at ply 6

- CoachCard: **Develop the Italian bishop actively** — Bc5 develops the bishop to an active Italian square, keeping pressure on White’s kingside and clearing Black to castle. It also keeps an eye on the central light squares.

- Plain hint: Place the king bishop on the active diagonal before castling.

- Opening themes: ...Bc5 Italian setup, kingside pressure, castling preparation

### Packet italian-black.line-009.ply-08.g8f6

- Move: `Nf6` / `g8f6` at ply 8

- CoachCard: **Attack e4 before White expands** — Nf6 develops with a direct question to White’s e-pawn. In Italian structures, this also prepares castling before White’s c3/d4 center arrives.

- Plain hint: Bring the kingside knight out to hit White’s central pawn and prepare king safety.

- Opening themes: e4 pressure, kingside development, castling preparation

### Packet italian-black.line-009.ply-10.e5d4

- Move: `exd4` / `e5d4` at ply 10

- CoachCard: **Clarify White’s Italian central break** — exd4 answers White’s d-pawn break by exchanging in the center. In Italian lines with c3 and d4, Black should meet the break directly rather than drift.

- Plain hint: When White opens the center, use the central pawn to resolve the tension.

- Opening themes: c3/d4 break, central clarification, Italian center

### Packet italian-black.line-009.ply-12.c5b6

- Move: `Bb6` / `c5b6` at ply 12

- CoachCard: **Preserve the active Italian bishop** — Bb6 repositions the Italian bishop after central contact. The bishop stays relevant to White’s king and central light squares instead of being trapped by the pawn structure.

- Plain hint: Keep the bishop active after the center changes.

- Opening themes: bishop activity, response to d4, Italian light squares


## italian-black-line-010: 1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. c3 Nf6 5. d4 exd4 6. e5 d5

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1c4,f8c5,c2c3,g8f6,d2d4,e5d4,e4e5,d7d5`  
Runtime totalGames field at line node: `588357`

### Packet italian-black.line-010.ply-06.f8c5

- Move: `Bc5` / `f8c5` at ply 6

- CoachCard: **Develop the Italian bishop actively** — Bc5 develops the bishop to an active Italian square, keeping pressure on White’s kingside and clearing Black to castle. It also keeps an eye on the central light squares.

- Plain hint: Place the king bishop on the active diagonal before castling.

- Opening themes: ...Bc5 Italian setup, kingside pressure, castling preparation

### Packet italian-black.line-010.ply-08.g8f6

- Move: `Nf6` / `g8f6` at ply 8

- CoachCard: **Attack e4 before White expands** — Nf6 develops with a direct question to White’s e-pawn. In Italian structures, this also prepares castling before White’s c3/d4 center arrives.

- Plain hint: Bring the kingside knight out to hit White’s central pawn and prepare king safety.

- Opening themes: e4 pressure, kingside development, castling preparation

### Packet italian-black.line-010.ply-10.e5d4

- Move: `exd4` / `e5d4` at ply 10

- CoachCard: **Clarify White’s Italian central break** — exd4 answers White’s d-pawn break by exchanging in the center. In Italian lines with c3 and d4, Black should meet the break directly rather than drift.

- Plain hint: When White opens the center, use the central pawn to resolve the tension.

- Opening themes: c3/d4 break, central clarification, Italian center

### Packet italian-black.line-010.ply-12.d7d5

- Move: `d5` / `d7d5` at ply 12

- CoachCard: **Keep Black’s Italian setup coordinated** — d5 keeps Black’s Italian response coordinated around e5, active minor pieces, and king safety. The move is runtime-backed and fits the exact line’s central structure.

- Plain hint: Keep the move tied to e-pawn support, bishop activity, or castling readiness.

- Opening themes: Italian coordination, central response, development


## italian-black-line-011: 1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. c3 d6 5. O-O Nf6 6. d3 Bg4

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1c4,f8c5,c2c3,d7d6,e1h1,g8f6,d2d3,c8g4`  
Runtime totalGames field at line node: `554341`

### Packet italian-black.line-011.ply-06.f8c5

- Move: `Bc5` / `f8c5` at ply 6

- CoachCard: **Develop the Italian bishop actively** — Bc5 develops the bishop to an active Italian square, keeping pressure on White’s kingside and clearing Black to castle. It also keeps an eye on the central light squares.

- Plain hint: Place the king bishop on the active diagonal before castling.

- Opening themes: ...Bc5 Italian setup, kingside pressure, castling preparation

### Packet italian-black.line-011.ply-08.d7d6

- Move: `d6` / `d7d6` at ply 8

- CoachCard: **Brace the Italian center** — d6 reinforces Black’s e5 pawn and gives the c8 bishop a route. Against Italian c3/d4 ideas, this keeps Black’s center from being pulled apart too quickly.

- Plain hint: Support the central pawn so White’s planned pawn break does not come with tempo.

- Opening themes: e5 support, c3/d4 response, solid Italian structure

### Packet italian-black.line-011.ply-10.g8f6

- Move: `Nf6` / `g8f6` at ply 10

- CoachCard: **Attack e4 before White expands** — Nf6 develops with a direct question to White’s e-pawn. In Italian structures, this also prepares castling before White’s c3/d4 center arrives.

- Plain hint: Bring the kingside knight out to hit White’s central pawn and prepare king safety.

- Opening themes: e4 pressure, kingside development, castling preparation

### Packet italian-black.line-011.ply-12.c8g4

- Move: `Bg4` / `c8g4` at ply 12

- CoachCard: **Pin a defender in the Italian setup** — Bg4 develops with pressure on a kingside defender. In Italian positions, that can make White’s central break less comfortable.

- Plain hint: Use the bishop to pressure a piece that supports White’s central play.

- Opening themes: bishop pin, central support pressure, Italian development


## italian-black-line-012: 1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. c3 Nf6 5. d3 d6 6. h3 h6

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1c4,f8c5,c2c3,g8f6,d2d3,d7d6,h2h3,h7h6`  
Runtime totalGames field at line node: `513385`

### Packet italian-black.line-012.ply-06.f8c5

- Move: `Bc5` / `f8c5` at ply 6

- CoachCard: **Develop the Italian bishop actively** — Bc5 develops the bishop to an active Italian square, keeping pressure on White’s kingside and clearing Black to castle. It also keeps an eye on the central light squares.

- Plain hint: Place the king bishop on the active diagonal before castling.

- Opening themes: ...Bc5 Italian setup, kingside pressure, castling preparation

### Packet italian-black.line-012.ply-08.g8f6

- Move: `Nf6` / `g8f6` at ply 8

- CoachCard: **Attack e4 before White expands** — Nf6 develops with a direct question to White’s e-pawn. In Italian structures, this also prepares castling before White’s c3/d4 center arrives.

- Plain hint: Bring the kingside knight out to hit White’s central pawn and prepare king safety.

- Opening themes: e4 pressure, kingside development, castling preparation

### Packet italian-black.line-012.ply-10.d7d6

- Move: `d6` / `d7d6` at ply 10

- CoachCard: **Brace the Italian center** — d6 reinforces Black’s e5 pawn and gives the c8 bishop a route. Against Italian c3/d4 ideas, this keeps Black’s center from being pulled apart too quickly.

- Plain hint: Support the central pawn so White’s planned pawn break does not come with tempo.

- Opening themes: e5 support, c3/d4 response, solid Italian structure

### Packet italian-black.line-012.ply-12.h7h6

- Move: `h6` / `h7h6` at ply 12

- CoachCard: **Question the pin without loosening the center** — h6 gives Black a useful luft-style question in an Italian structure without abandoning central support. It is relevant when White’s bishop pressure affects Black’s development.

- Plain hint: Ask the bishop or knight to clarify while keeping the central structure intact.

- Opening themes: bishop question, king shelter, Italian structure


## italian-black-line-013: 1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. O-O d6 5. h3 Nf6 6. d3 O-O

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1c4,f8c5,e1h1,d7d6,h2h3,g8f6,d2d3,e8h8`  
Runtime totalGames field at line node: `504792`

### Packet italian-black.line-013.ply-06.f8c5

- Move: `Bc5` / `f8c5` at ply 6

- CoachCard: **Develop the Italian bishop actively** — Bc5 develops the bishop to an active Italian square, keeping pressure on White’s kingside and clearing Black to castle. It also keeps an eye on the central light squares.

- Plain hint: Place the king bishop on the active diagonal before castling.

- Opening themes: ...Bc5 Italian setup, kingside pressure, castling preparation

### Packet italian-black.line-013.ply-08.d7d6

- Move: `d6` / `d7d6` at ply 8

- CoachCard: **Brace the Italian center** — d6 reinforces Black’s e5 pawn and gives the c8 bishop a route. Against Italian c3/d4 ideas, this keeps Black’s center from being pulled apart too quickly.

- Plain hint: Support the central pawn so White’s planned pawn break does not come with tempo.

- Opening themes: e5 support, c3/d4 response, solid Italian structure

### Packet italian-black.line-013.ply-10.g8f6

- Move: `Nf6` / `g8f6` at ply 10

- CoachCard: **Attack e4 before White expands** — Nf6 develops with a direct question to White’s e-pawn. In Italian structures, this also prepares castling before White’s c3/d4 center arrives.

- Plain hint: Bring the kingside knight out to hit White’s central pawn and prepare king safety.

- Opening themes: e4 pressure, kingside development, castling preparation

### Packet italian-black.line-013.ply-12.e8g8

- Move: `O-O` / `e8g8` at ply 12
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle before the Italian center opens** — O-O puts Black’s king safe before the Italian center can open. That is important when White is preparing c3, d4, or piece pressure on the kingside.

- Plain hint: Secure the king before White’s central pawn break becomes sharper.

- Opening themes: king safety, Italian center, castling timing


## italian-black-line-014: 1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. O-O Nf6 5. d3 O-O 6. Bg5 h6

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1c4,f8c5,e1h1,g8f6,d2d3,e8h8,c1g5,h7h6`  
Runtime totalGames field at line node: `436918`

### Packet italian-black.line-014.ply-06.f8c5

- Move: `Bc5` / `f8c5` at ply 6

- CoachCard: **Develop the Italian bishop actively** — Bc5 develops the bishop to an active Italian square, keeping pressure on White’s kingside and clearing Black to castle. It also keeps an eye on the central light squares.

- Plain hint: Place the king bishop on the active diagonal before castling.

- Opening themes: ...Bc5 Italian setup, kingside pressure, castling preparation

### Packet italian-black.line-014.ply-08.g8f6

- Move: `Nf6` / `g8f6` at ply 8

- CoachCard: **Attack e4 before White expands** — Nf6 develops with a direct question to White’s e-pawn. In Italian structures, this also prepares castling before White’s c3/d4 center arrives.

- Plain hint: Bring the kingside knight out to hit White’s central pawn and prepare king safety.

- Opening themes: e4 pressure, kingside development, castling preparation

### Packet italian-black.line-014.ply-10.e8g8

- Move: `O-O` / `e8g8` at ply 10
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle before the Italian center opens** — O-O puts Black’s king safe before the Italian center can open. That is important when White is preparing c3, d4, or piece pressure on the kingside.

- Plain hint: Secure the king before White’s central pawn break becomes sharper.

- Opening themes: king safety, Italian center, castling timing

### Packet italian-black.line-014.ply-12.h7h6

- Move: `h6` / `h7h6` at ply 12

- CoachCard: **Question the pin without loosening the center** — h6 gives Black a useful luft-style question in an Italian structure without abandoning central support. It is relevant when White’s bishop pressure affects Black’s development.

- Plain hint: Ask the bishop or knight to clarify while keeping the central structure intact.

- Opening themes: bishop question, king shelter, Italian structure


## italian-black-line-015: 1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. O-O Nf6 5. c3 O-O 6. Re1 d6

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1c4,f8c5,e1h1,g8f6,c2c3,e8h8,f1e1,d7d6`  
Runtime totalGames field at line node: `352212`

### Packet italian-black.line-015.ply-06.f8c5

- Move: `Bc5` / `f8c5` at ply 6

- CoachCard: **Develop the Italian bishop actively** — Bc5 develops the bishop to an active Italian square, keeping pressure on White’s kingside and clearing Black to castle. It also keeps an eye on the central light squares.

- Plain hint: Place the king bishop on the active diagonal before castling.

- Opening themes: ...Bc5 Italian setup, kingside pressure, castling preparation

### Packet italian-black.line-015.ply-08.g8f6

- Move: `Nf6` / `g8f6` at ply 8

- CoachCard: **Attack e4 before White expands** — Nf6 develops with a direct question to White’s e-pawn. In Italian structures, this also prepares castling before White’s c3/d4 center arrives.

- Plain hint: Bring the kingside knight out to hit White’s central pawn and prepare king safety.

- Opening themes: e4 pressure, kingside development, castling preparation

### Packet italian-black.line-015.ply-10.e8g8

- Move: `O-O` / `e8g8` at ply 10
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle before the Italian center opens** — O-O puts Black’s king safe before the Italian center can open. That is important when White is preparing c3, d4, or piece pressure on the kingside.

- Plain hint: Secure the king before White’s central pawn break becomes sharper.

- Opening themes: king safety, Italian center, castling timing

### Packet italian-black.line-015.ply-12.d7d6

- Move: `d6` / `d7d6` at ply 12

- CoachCard: **Brace the Italian center** — d6 reinforces Black’s e5 pawn and gives the c8 bishop a route. Against Italian c3/d4 ideas, this keeps Black’s center from being pulled apart too quickly.

- Plain hint: Support the central pawn so White’s planned pawn break does not come with tempo.

- Opening themes: e5 support, c3/d4 response, solid Italian structure


## italian-black-line-016: 1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. c3 Nf6 5. d4 exd4 6. e5 Ng4

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1c4,f8c5,c2c3,g8f6,d2d4,e5d4,e4e5,f6g4`  
Runtime totalGames field at line node: `308086`

### Packet italian-black.line-016.ply-06.f8c5

- Move: `Bc5` / `f8c5` at ply 6

- CoachCard: **Develop the Italian bishop actively** — Bc5 develops the bishop to an active Italian square, keeping pressure on White’s kingside and clearing Black to castle. It also keeps an eye on the central light squares.

- Plain hint: Place the king bishop on the active diagonal before castling.

- Opening themes: ...Bc5 Italian setup, kingside pressure, castling preparation

### Packet italian-black.line-016.ply-08.g8f6

- Move: `Nf6` / `g8f6` at ply 8

- CoachCard: **Attack e4 before White expands** — Nf6 develops with a direct question to White’s e-pawn. In Italian structures, this also prepares castling before White’s c3/d4 center arrives.

- Plain hint: Bring the kingside knight out to hit White’s central pawn and prepare king safety.

- Opening themes: e4 pressure, kingside development, castling preparation

### Packet italian-black.line-016.ply-10.e5d4

- Move: `exd4` / `e5d4` at ply 10

- CoachCard: **Clarify White’s Italian central break** — exd4 answers White’s d-pawn break by exchanging in the center. In Italian lines with c3 and d4, Black should meet the break directly rather than drift.

- Plain hint: When White opens the center, use the central pawn to resolve the tension.

- Opening themes: c3/d4 break, central clarification, Italian center

### Packet italian-black.line-016.ply-12.f6g4

- Move: `Ng4` / `f6g4` at ply 12

- CoachCard: **Keep Black’s Italian setup coordinated** — Ng4 keeps Black’s Italian response coordinated around e5, active minor pieces, and king safety. The move is runtime-backed and fits the exact line’s central structure.

- Plain hint: Keep the move tied to e-pawn support, bishop activity, or castling readiness.

- Opening themes: Italian coordination, central response, development


## italian-black-line-017: 1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. c3 d6 5. O-O Bg4 6. h3 Bh5

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1c4,f8c5,c2c3,d7d6,e1h1,c8g4,h2h3,g4h5`  
Runtime totalGames field at line node: `286410`

### Packet italian-black.line-017.ply-06.f8c5

- Move: `Bc5` / `f8c5` at ply 6

- CoachCard: **Develop the Italian bishop actively** — Bc5 develops the bishop to an active Italian square, keeping pressure on White’s kingside and clearing Black to castle. It also keeps an eye on the central light squares.

- Plain hint: Place the king bishop on the active diagonal before castling.

- Opening themes: ...Bc5 Italian setup, kingside pressure, castling preparation

### Packet italian-black.line-017.ply-08.d7d6

- Move: `d6` / `d7d6` at ply 8

- CoachCard: **Brace the Italian center** — d6 reinforces Black’s e5 pawn and gives the c8 bishop a route. Against Italian c3/d4 ideas, this keeps Black’s center from being pulled apart too quickly.

- Plain hint: Support the central pawn so White’s planned pawn break does not come with tempo.

- Opening themes: e5 support, c3/d4 response, solid Italian structure

### Packet italian-black.line-017.ply-10.c8g4

- Move: `Bg4` / `c8g4` at ply 10

- CoachCard: **Pin a defender in the Italian setup** — Bg4 develops with pressure on a kingside defender. In Italian positions, that can make White’s central break less comfortable.

- Plain hint: Use the bishop to pressure a piece that supports White’s central play.

- Opening themes: bishop pin, central support pressure, Italian development

### Packet italian-black.line-017.ply-12.g4h5

- Move: `Bh5` / `g4h5` at ply 12

- CoachCard: **Keep Black’s Italian setup coordinated** — Bh5 keeps Black’s Italian response coordinated around e5, active minor pieces, and king safety. The move is runtime-backed and fits the exact line’s central structure.

- Plain hint: Keep the move tied to e-pawn support, bishop activity, or castling readiness.

- Opening themes: Italian coordination, central response, development


## italian-black-line-018: 1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. c3 Nf6 5. d3 d6 6. h3 O-O

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1c4,f8c5,c2c3,g8f6,d2d3,d7d6,h2h3,e8h8`  
Runtime totalGames field at line node: `266891`

### Packet italian-black.line-018.ply-06.f8c5

- Move: `Bc5` / `f8c5` at ply 6

- CoachCard: **Develop the Italian bishop actively** — Bc5 develops the bishop to an active Italian square, keeping pressure on White’s kingside and clearing Black to castle. It also keeps an eye on the central light squares.

- Plain hint: Place the king bishop on the active diagonal before castling.

- Opening themes: ...Bc5 Italian setup, kingside pressure, castling preparation

### Packet italian-black.line-018.ply-08.g8f6

- Move: `Nf6` / `g8f6` at ply 8

- CoachCard: **Attack e4 before White expands** — Nf6 develops with a direct question to White’s e-pawn. In Italian structures, this also prepares castling before White’s c3/d4 center arrives.

- Plain hint: Bring the kingside knight out to hit White’s central pawn and prepare king safety.

- Opening themes: e4 pressure, kingside development, castling preparation

### Packet italian-black.line-018.ply-10.d7d6

- Move: `d6` / `d7d6` at ply 10

- CoachCard: **Brace the Italian center** — d6 reinforces Black’s e5 pawn and gives the c8 bishop a route. Against Italian c3/d4 ideas, this keeps Black’s center from being pulled apart too quickly.

- Plain hint: Support the central pawn so White’s planned pawn break does not come with tempo.

- Opening themes: e5 support, c3/d4 response, solid Italian structure

### Packet italian-black.line-018.ply-12.e8g8

- Move: `O-O` / `e8g8` at ply 12
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle before the Italian center opens** — O-O puts Black’s king safe before the Italian center can open. That is important when White is preparing c3, d4, or piece pressure on the kingside.

- Plain hint: Secure the king before White’s central pawn break becomes sharper.

- Opening themes: king safety, Italian center, castling timing


## italian-black-line-019: 1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. O-O Nf6 5. d3 O-O 6. Bg5 d6

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1c4,f8c5,e1h1,g8f6,d2d3,e8h8,c1g5,d7d6`  
Runtime totalGames field at line node: `247761`

### Packet italian-black.line-019.ply-06.f8c5

- Move: `Bc5` / `f8c5` at ply 6

- CoachCard: **Develop the Italian bishop actively** — Bc5 develops the bishop to an active Italian square, keeping pressure on White’s kingside and clearing Black to castle. It also keeps an eye on the central light squares.

- Plain hint: Place the king bishop on the active diagonal before castling.

- Opening themes: ...Bc5 Italian setup, kingside pressure, castling preparation

### Packet italian-black.line-019.ply-08.g8f6

- Move: `Nf6` / `g8f6` at ply 8

- CoachCard: **Attack e4 before White expands** — Nf6 develops with a direct question to White’s e-pawn. In Italian structures, this also prepares castling before White’s c3/d4 center arrives.

- Plain hint: Bring the kingside knight out to hit White’s central pawn and prepare king safety.

- Opening themes: e4 pressure, kingside development, castling preparation

### Packet italian-black.line-019.ply-10.e8g8

- Move: `O-O` / `e8g8` at ply 10
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle before the Italian center opens** — O-O puts Black’s king safe before the Italian center can open. That is important when White is preparing c3, d4, or piece pressure on the kingside.

- Plain hint: Secure the king before White’s central pawn break becomes sharper.

- Opening themes: king safety, Italian center, castling timing

### Packet italian-black.line-019.ply-12.d7d6

- Move: `d6` / `d7d6` at ply 12

- CoachCard: **Brace the Italian center** — d6 reinforces Black’s e5 pawn and gives the c8 bishop a route. Against Italian c3/d4 ideas, this keeps Black’s center from being pulled apart too quickly.

- Plain hint: Support the central pawn so White’s planned pawn break does not come with tempo.

- Opening themes: e5 support, c3/d4 response, solid Italian structure


## italian-black-line-020: 1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. O-O d6 5. h3 Nf6 6. Re1 O-O

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1c4,f8c5,e1h1,d7d6,h2h3,g8f6,f1e1,e8h8`  
Runtime totalGames field at line node: `240666`

### Packet italian-black.line-020.ply-06.f8c5

- Move: `Bc5` / `f8c5` at ply 6

- CoachCard: **Develop the Italian bishop actively** — Bc5 develops the bishop to an active Italian square, keeping pressure on White’s kingside and clearing Black to castle. It also keeps an eye on the central light squares.

- Plain hint: Place the king bishop on the active diagonal before castling.

- Opening themes: ...Bc5 Italian setup, kingside pressure, castling preparation

### Packet italian-black.line-020.ply-08.d7d6

- Move: `d6` / `d7d6` at ply 8

- CoachCard: **Brace the Italian center** — d6 reinforces Black’s e5 pawn and gives the c8 bishop a route. Against Italian c3/d4 ideas, this keeps Black’s center from being pulled apart too quickly.

- Plain hint: Support the central pawn so White’s planned pawn break does not come with tempo.

- Opening themes: e5 support, c3/d4 response, solid Italian structure

### Packet italian-black.line-020.ply-10.g8f6

- Move: `Nf6` / `g8f6` at ply 10

- CoachCard: **Attack e4 before White expands** — Nf6 develops with a direct question to White’s e-pawn. In Italian structures, this also prepares castling before White’s c3/d4 center arrives.

- Plain hint: Bring the kingside knight out to hit White’s central pawn and prepare king safety.

- Opening themes: e4 pressure, kingside development, castling preparation

### Packet italian-black.line-020.ply-12.e8g8

- Move: `O-O` / `e8g8` at ply 12
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle before the Italian center opens** — O-O puts Black’s king safe before the Italian center can open. That is important when White is preparing c3, d4, or piece pressure on the kingside.

- Plain hint: Secure the king before White’s central pawn break becomes sharper.

- Opening themes: king safety, Italian center, castling timing


## italian-black-line-021: 1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. c3 d6 5. O-O Bg4 6. d4 exd4

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1c4,f8c5,c2c3,d7d6,e1h1,c8g4,d2d4,e5d4`  
Runtime totalGames field at line node: `238225`

### Packet italian-black.line-021.ply-06.f8c5

- Move: `Bc5` / `f8c5` at ply 6

- CoachCard: **Develop the Italian bishop actively** — Bc5 develops the bishop to an active Italian square, keeping pressure on White’s kingside and clearing Black to castle. It also keeps an eye on the central light squares.

- Plain hint: Place the king bishop on the active diagonal before castling.

- Opening themes: ...Bc5 Italian setup, kingside pressure, castling preparation

### Packet italian-black.line-021.ply-08.d7d6

- Move: `d6` / `d7d6` at ply 8

- CoachCard: **Brace the Italian center** — d6 reinforces Black’s e5 pawn and gives the c8 bishop a route. Against Italian c3/d4 ideas, this keeps Black’s center from being pulled apart too quickly.

- Plain hint: Support the central pawn so White’s planned pawn break does not come with tempo.

- Opening themes: e5 support, c3/d4 response, solid Italian structure

### Packet italian-black.line-021.ply-10.c8g4

- Move: `Bg4` / `c8g4` at ply 10

- CoachCard: **Pin a defender in the Italian setup** — Bg4 develops with pressure on a kingside defender. In Italian positions, that can make White’s central break less comfortable.

- Plain hint: Use the bishop to pressure a piece that supports White’s central play.

- Opening themes: bishop pin, central support pressure, Italian development

### Packet italian-black.line-021.ply-12.e5d4

- Move: `exd4` / `e5d4` at ply 12

- CoachCard: **Clarify White’s Italian central break** — exd4 answers White’s d-pawn break by exchanging in the center. In Italian lines with c3 and d4, Black should meet the break directly rather than drift.

- Plain hint: When White opens the center, use the central pawn to resolve the tension.

- Opening themes: c3/d4 break, central clarification, Italian center


## italian-black-line-022: 1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. c3 d6 5. O-O Nf6 6. d4 Bb6

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1c4,f8c5,c2c3,d7d6,e1h1,g8f6,d2d4,c5b6`  
Runtime totalGames field at line node: `190098`

### Packet italian-black.line-022.ply-06.f8c5

- Move: `Bc5` / `f8c5` at ply 6

- CoachCard: **Develop the Italian bishop actively** — Bc5 develops the bishop to an active Italian square, keeping pressure on White’s kingside and clearing Black to castle. It also keeps an eye on the central light squares.

- Plain hint: Place the king bishop on the active diagonal before castling.

- Opening themes: ...Bc5 Italian setup, kingside pressure, castling preparation

### Packet italian-black.line-022.ply-08.d7d6

- Move: `d6` / `d7d6` at ply 8

- CoachCard: **Brace the Italian center** — d6 reinforces Black’s e5 pawn and gives the c8 bishop a route. Against Italian c3/d4 ideas, this keeps Black’s center from being pulled apart too quickly.

- Plain hint: Support the central pawn so White’s planned pawn break does not come with tempo.

- Opening themes: e5 support, c3/d4 response, solid Italian structure

### Packet italian-black.line-022.ply-10.g8f6

- Move: `Nf6` / `g8f6` at ply 10

- CoachCard: **Attack e4 before White expands** — Nf6 develops with a direct question to White’s e-pawn. In Italian structures, this also prepares castling before White’s c3/d4 center arrives.

- Plain hint: Bring the kingside knight out to hit White’s central pawn and prepare king safety.

- Opening themes: e4 pressure, kingside development, castling preparation

### Packet italian-black.line-022.ply-12.c5b6

- Move: `Bb6` / `c5b6` at ply 12

- CoachCard: **Preserve the active Italian bishop** — Bb6 repositions the Italian bishop after central contact. The bishop stays relevant to White’s king and central light squares instead of being trapped by the pawn structure.

- Plain hint: Keep the bishop active after the center changes.

- Opening themes: bishop activity, response to d4, Italian light squares


## italian-black-line-023: 1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. O-O d6 5. h3 h6 6. c3 Nf6

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1c4,f8c5,e1h1,d7d6,h2h3,h7h6,c2c3,g8f6`  
Runtime totalGames field at line node: `179261`

### Packet italian-black.line-023.ply-06.f8c5

- Move: `Bc5` / `f8c5` at ply 6

- CoachCard: **Develop the Italian bishop actively** — Bc5 develops the bishop to an active Italian square, keeping pressure on White’s kingside and clearing Black to castle. It also keeps an eye on the central light squares.

- Plain hint: Place the king bishop on the active diagonal before castling.

- Opening themes: ...Bc5 Italian setup, kingside pressure, castling preparation

### Packet italian-black.line-023.ply-08.d7d6

- Move: `d6` / `d7d6` at ply 8

- CoachCard: **Brace the Italian center** — d6 reinforces Black’s e5 pawn and gives the c8 bishop a route. Against Italian c3/d4 ideas, this keeps Black’s center from being pulled apart too quickly.

- Plain hint: Support the central pawn so White’s planned pawn break does not come with tempo.

- Opening themes: e5 support, c3/d4 response, solid Italian structure

### Packet italian-black.line-023.ply-10.h7h6

- Move: `h6` / `h7h6` at ply 10

- CoachCard: **Question the pin without loosening the center** — h6 gives Black a useful luft-style question in an Italian structure without abandoning central support. It is relevant when White’s bishop pressure affects Black’s development.

- Plain hint: Ask the bishop or knight to clarify while keeping the central structure intact.

- Opening themes: bishop question, king shelter, Italian structure

### Packet italian-black.line-023.ply-12.g8f6

- Move: `Nf6` / `g8f6` at ply 12

- CoachCard: **Attack e4 before White expands** — Nf6 develops with a direct question to White’s e-pawn. In Italian structures, this also prepares castling before White’s c3/d4 center arrives.

- Plain hint: Bring the kingside knight out to hit White’s central pawn and prepare king safety.

- Opening themes: e4 pressure, kingside development, castling preparation


## italian-black-line-024: 1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. c3 Nf6 5. d3 O-O 6. Bg5 h6

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1c4,f8c5,c2c3,g8f6,d2d3,e8h8,c1g5,h7h6`  
Runtime totalGames field at line node: `175761`

### Packet italian-black.line-024.ply-06.f8c5

- Move: `Bc5` / `f8c5` at ply 6

- CoachCard: **Develop the Italian bishop actively** — Bc5 develops the bishop to an active Italian square, keeping pressure on White’s kingside and clearing Black to castle. It also keeps an eye on the central light squares.

- Plain hint: Place the king bishop on the active diagonal before castling.

- Opening themes: ...Bc5 Italian setup, kingside pressure, castling preparation

### Packet italian-black.line-024.ply-08.g8f6

- Move: `Nf6` / `g8f6` at ply 8

- CoachCard: **Attack e4 before White expands** — Nf6 develops with a direct question to White’s e-pawn. In Italian structures, this also prepares castling before White’s c3/d4 center arrives.

- Plain hint: Bring the kingside knight out to hit White’s central pawn and prepare king safety.

- Opening themes: e4 pressure, kingside development, castling preparation

### Packet italian-black.line-024.ply-10.e8g8

- Move: `O-O` / `e8g8` at ply 10
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle before the Italian center opens** — O-O puts Black’s king safe before the Italian center can open. That is important when White is preparing c3, d4, or piece pressure on the kingside.

- Plain hint: Secure the king before White’s central pawn break becomes sharper.

- Opening themes: king safety, Italian center, castling timing

### Packet italian-black.line-024.ply-12.h7h6

- Move: `h6` / `h7h6` at ply 12

- CoachCard: **Question the pin without loosening the center** — h6 gives Black a useful luft-style question in an Italian structure without abandoning central support. It is relevant when White’s bishop pressure affects Black’s development.

- Plain hint: Ask the bishop or knight to clarify while keeping the central structure intact.

- Opening themes: bishop question, king shelter, Italian structure


## italian-black-line-025: 1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. c3 Nf6 5. d3 O-O 6. Bg5 d6

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1c4,f8c5,c2c3,g8f6,d2d3,e8h8,c1g5,d7d6`  
Runtime totalGames field at line node: `95179`

### Packet italian-black.line-025.ply-06.f8c5

- Move: `Bc5` / `f8c5` at ply 6

- CoachCard: **Develop the Italian bishop actively** — Bc5 develops the bishop to an active Italian square, keeping pressure on White’s kingside and clearing Black to castle. It also keeps an eye on the central light squares.

- Plain hint: Place the king bishop on the active diagonal before castling.

- Opening themes: ...Bc5 Italian setup, kingside pressure, castling preparation

### Packet italian-black.line-025.ply-08.g8f6

- Move: `Nf6` / `g8f6` at ply 8

- CoachCard: **Attack e4 before White expands** — Nf6 develops with a direct question to White’s e-pawn. In Italian structures, this also prepares castling before White’s c3/d4 center arrives.

- Plain hint: Bring the kingside knight out to hit White’s central pawn and prepare king safety.

- Opening themes: e4 pressure, kingside development, castling preparation

### Packet italian-black.line-025.ply-10.e8g8

- Move: `O-O` / `e8g8` at ply 10
- Source runtime moveUci: `e8h8`; normalizedMoveUci: `e8g8`

- CoachCard: **Castle before the Italian center opens** — O-O puts Black’s king safe before the Italian center can open. That is important when White is preparing c3, d4, or piece pressure on the kingside.

- Plain hint: Secure the king before White’s central pawn break becomes sharper.

- Opening themes: king safety, Italian center, castling timing

### Packet italian-black.line-025.ply-12.d7d6

- Move: `d6` / `d7d6` at ply 12

- CoachCard: **Brace the Italian center** — d6 reinforces Black’s e5 pawn and gives the c8 bishop a route. Against Italian c3/d4 ideas, this keeps Black’s center from being pulled apart too quickly.

- Plain hint: Support the central pawn so White’s planned pawn break does not come with tempo.

- Opening themes: e5 support, c3/d4 response, solid Italian structure
