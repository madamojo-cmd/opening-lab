# Ruy Lopez as White approved-content candidates — Batch 4

Opening ID: `ruy-lopez-white`  
Status: approved candidates only; not app-activated.


## ruy-lopez-white-line-001: 1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 4. Ba4 Nf6 5. O-O Be7 6. Re1 b5

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1b5,a7a6,b5a4,g8f6,e1h1,f8e7,f1e1,b7b5`  
Runtime totalGames field at line node: `1320168`

### Packet ruy-lopez-white.line-001.ply-05.f1b5

- Move: `Bb5` / `f1b5` at ply 5

- CoachCard: **Pin pressure on the e5 defender** — Bb5 is the Spanish bishop move: it pressures the knight that helps defend Black’s e5 pawn. The idea is long-term central pressure, not an immediate pawn win.

- Plain hint: Put pressure on the defender of the central pawn before committing the center.

- Opening themes: Bb5 pressure, e5 defender, Spanish long-term pressure

### Packet ruy-lopez-white.line-001.ply-07.b5a4

- Move: `Ba4` / `b5a4` at ply 7

- CoachCard: **Preserve the Spanish bishop** — Ba4 keeps the Ruy Lopez bishop active after ...a6. White preserves long-term pressure on the queenside knight and central e5 structure.

- Plain hint: Keep the bishop’s pressure after Black questions it with the rook pawn.

- Opening themes: bishop retreat, Spanish pressure, a6 response

### Packet ruy-lopez-white.line-001.ply-09.e1g1

- Move: `O-O` / `e1g1` at ply 9
- Source runtime moveUci: `e1h1`; normalizedMoveUci: `e1g1`

- CoachCard: **Castle before expanding the Spanish center** — O-O makes White’s king safe and connects the rook to the central files. In the Ruy Lopez, castling often comes before Re1, c3, or d4 ideas.

- Plain hint: Secure the king before using the rook or pawns to increase central pressure.

- Opening themes: king safety, Re1 preparation, Spanish central timing

### Packet ruy-lopez-white.line-001.ply-11.f1e1

- Move: `Re1` / `f1e1` at ply 11

- CoachCard: **Add rook pressure behind the e-pawn** — Re1 supports White’s e-pawn and prepares central expansion. In the Ruy Lopez, this rook move makes later d4 ideas more coherent.

- Plain hint: Put the rook behind the central pawn before the center opens.

- Opening themes: Re1 preparation, e-file support, Spanish center


## ruy-lopez-white-line-002: 1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 4. Ba4 b5 5. Bb3 Nf6 6. O-O Be7

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1b5,a7a6,b5a4,b7b5,a4b3,g8f6,e1h1,f8e7`  
Runtime totalGames field at line node: `1132863`

### Packet ruy-lopez-white.line-002.ply-05.f1b5

- Move: `Bb5` / `f1b5` at ply 5

- CoachCard: **Pin pressure on the e5 defender** — Bb5 is the Spanish bishop move: it pressures the knight that helps defend Black’s e5 pawn. The idea is long-term central pressure, not an immediate pawn win.

- Plain hint: Put pressure on the defender of the central pawn before committing the center.

- Opening themes: Bb5 pressure, e5 defender, Spanish long-term pressure

### Packet ruy-lopez-white.line-002.ply-07.b5a4

- Move: `Ba4` / `b5a4` at ply 7

- CoachCard: **Preserve the Spanish bishop** — Ba4 keeps the Ruy Lopez bishop active after ...a6. White preserves long-term pressure on the queenside knight and central e5 structure.

- Plain hint: Keep the bishop’s pressure after Black questions it with the rook pawn.

- Opening themes: bishop retreat, Spanish pressure, a6 response

### Packet ruy-lopez-white.line-002.ply-09.a4b3

- Move: `Bb3` / `a4b3` at ply 9

- CoachCard: **Keep the bishop on the Spanish diagonal** — Bb3 keeps the Spanish bishop active after Black expands with ...b5. From the retreat square, it still points toward Black’s kingside and supports central play.

- Plain hint: Retreat the bishop to keep kingside and central pressure alive.

- Opening themes: bishop preservation, Spanish diagonal, queenside space response

### Packet ruy-lopez-white.line-002.ply-11.e1g1

- Move: `O-O` / `e1g1` at ply 11
- Source runtime moveUci: `e1h1`; normalizedMoveUci: `e1g1`

- CoachCard: **Castle before expanding the Spanish center** — O-O makes White’s king safe and connects the rook to the central files. In the Ruy Lopez, castling often comes before Re1, c3, or d4 ideas.

- Plain hint: Secure the king before using the rook or pawns to increase central pressure.

- Opening themes: king safety, Re1 preparation, Spanish central timing


## ruy-lopez-white-line-003: 1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 4. Ba4 b5 5. Bb3 Bc5 6. O-O Nf6

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1b5,a7a6,b5a4,b7b5,a4b3,f8c5,e1h1,g8f6`  
Runtime totalGames field at line node: `1101026`

### Packet ruy-lopez-white.line-003.ply-05.f1b5

- Move: `Bb5` / `f1b5` at ply 5

- CoachCard: **Pin pressure on the e5 defender** — Bb5 is the Spanish bishop move: it pressures the knight that helps defend Black’s e5 pawn. The idea is long-term central pressure, not an immediate pawn win.

- Plain hint: Put pressure on the defender of the central pawn before committing the center.

- Opening themes: Bb5 pressure, e5 defender, Spanish long-term pressure

### Packet ruy-lopez-white.line-003.ply-07.b5a4

- Move: `Ba4` / `b5a4` at ply 7

- CoachCard: **Preserve the Spanish bishop** — Ba4 keeps the Ruy Lopez bishop active after ...a6. White preserves long-term pressure on the queenside knight and central e5 structure.

- Plain hint: Keep the bishop’s pressure after Black questions it with the rook pawn.

- Opening themes: bishop retreat, Spanish pressure, a6 response

### Packet ruy-lopez-white.line-003.ply-09.a4b3

- Move: `Bb3` / `a4b3` at ply 9

- CoachCard: **Keep the bishop on the Spanish diagonal** — Bb3 keeps the Spanish bishop active after Black expands with ...b5. From the retreat square, it still points toward Black’s kingside and supports central play.

- Plain hint: Retreat the bishop to keep kingside and central pressure alive.

- Opening themes: bishop preservation, Spanish diagonal, queenside space response

### Packet ruy-lopez-white.line-003.ply-11.e1g1

- Move: `O-O` / `e1g1` at ply 11
- Source runtime moveUci: `e1h1`; normalizedMoveUci: `e1g1`

- CoachCard: **Castle before expanding the Spanish center** — O-O makes White’s king safe and connects the rook to the central files. In the Ruy Lopez, castling often comes before Re1, c3, or d4 ideas.

- Plain hint: Secure the king before using the rook or pawns to increase central pressure.

- Opening themes: king safety, Re1 preparation, Spanish central timing


## ruy-lopez-white-line-004: 1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 4. Bxc6 dxc6 5. Nxe5 Qd4 6. Nf3 Qxe4+

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1b5,a7a6,b5c6,d7c6,f3e5,d8d4,e5f3,d4e4`  
Runtime totalGames field at line node: `648117`

### Packet ruy-lopez-white.line-004.ply-05.f1b5

- Move: `Bb5` / `f1b5` at ply 5

- CoachCard: **Pin pressure on the e5 defender** — Bb5 is the Spanish bishop move: it pressures the knight that helps defend Black’s e5 pawn. The idea is long-term central pressure, not an immediate pawn win.

- Plain hint: Put pressure on the defender of the central pawn before committing the center.

- Opening themes: Bb5 pressure, e5 defender, Spanish long-term pressure

### Packet ruy-lopez-white.line-004.ply-07.b5c6

- Move: `Bxc6` / `b5c6` at ply 7

- CoachCard: **Maintain Spanish pressure without forcing tactics** — Bxc6 keeps White’s Ruy Lopez plan tied to long-term pressure on Black’s center. The move is runtime-backed and supports the exact Spanish structure.

- Plain hint: Keep the move connected to bishop pressure, king safety, or central preparation.

- Opening themes: Spanish pressure, central preparation, piece coordination

### Packet ruy-lopez-white.line-004.ply-09.f3e5

- Move: `Nxe5` / `f3e5` at ply 9

- CoachCard: **Maintain Spanish pressure without forcing tactics** — Nxe5 keeps White’s Ruy Lopez plan tied to long-term pressure on Black’s center. The move is runtime-backed and supports the exact Spanish structure.

- Plain hint: Keep the move connected to bishop pressure, king safety, or central preparation.

- Opening themes: Spanish pressure, central preparation, piece coordination

### Packet ruy-lopez-white.line-004.ply-11.e5f3

- Move: `Nf3` / `e5f3` at ply 11

- CoachCard: **Maintain Spanish pressure without forcing tactics** — Nf3 keeps White’s Ruy Lopez plan tied to long-term pressure on Black’s center. The move is runtime-backed and supports the exact Spanish structure.

- Plain hint: Keep the move connected to bishop pressure, king safety, or central preparation.

- Opening themes: Spanish pressure, central preparation, piece coordination


## ruy-lopez-white-line-005: 1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 4. Bxc6 dxc6 5. Nxe5 Qe7 6. Nf3 Qxe4+

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1b5,a7a6,b5c6,d7c6,f3e5,d8e7,e5f3,e7e4`  
Runtime totalGames field at line node: `648117`

### Packet ruy-lopez-white.line-005.ply-05.f1b5

- Move: `Bb5` / `f1b5` at ply 5

- CoachCard: **Pin pressure on the e5 defender** — Bb5 is the Spanish bishop move: it pressures the knight that helps defend Black’s e5 pawn. The idea is long-term central pressure, not an immediate pawn win.

- Plain hint: Put pressure on the defender of the central pawn before committing the center.

- Opening themes: Bb5 pressure, e5 defender, Spanish long-term pressure

### Packet ruy-lopez-white.line-005.ply-07.b5c6

- Move: `Bxc6` / `b5c6` at ply 7

- CoachCard: **Maintain Spanish pressure without forcing tactics** — Bxc6 keeps White’s Ruy Lopez plan tied to long-term pressure on Black’s center. The move is runtime-backed and supports the exact Spanish structure.

- Plain hint: Keep the move connected to bishop pressure, king safety, or central preparation.

- Opening themes: Spanish pressure, central preparation, piece coordination

### Packet ruy-lopez-white.line-005.ply-09.f3e5

- Move: `Nxe5` / `f3e5` at ply 9

- CoachCard: **Maintain Spanish pressure without forcing tactics** — Nxe5 keeps White’s Ruy Lopez plan tied to long-term pressure on Black’s center. The move is runtime-backed and supports the exact Spanish structure.

- Plain hint: Keep the move connected to bishop pressure, king safety, or central preparation.

- Opening themes: Spanish pressure, central preparation, piece coordination

### Packet ruy-lopez-white.line-005.ply-11.e5f3

- Move: `Nf3` / `e5f3` at ply 11

- CoachCard: **Maintain Spanish pressure without forcing tactics** — Nf3 keeps White’s Ruy Lopez plan tied to long-term pressure on Black’s center. The move is runtime-backed and supports the exact Spanish structure.

- Plain hint: Keep the move connected to bishop pressure, king safety, or central preparation.

- Opening themes: Spanish pressure, central preparation, piece coordination


## ruy-lopez-white-line-006: 1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 4. Ba4 b5 5. Bb3 Nf6 6. d3 Bc5

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1b5,a7a6,b5a4,b7b5,a4b3,g8f6,d2d3,f8c5`  
Runtime totalGames field at line node: `606302`

### Packet ruy-lopez-white.line-006.ply-05.f1b5

- Move: `Bb5` / `f1b5` at ply 5

- CoachCard: **Pin pressure on the e5 defender** — Bb5 is the Spanish bishop move: it pressures the knight that helps defend Black’s e5 pawn. The idea is long-term central pressure, not an immediate pawn win.

- Plain hint: Put pressure on the defender of the central pawn before committing the center.

- Opening themes: Bb5 pressure, e5 defender, Spanish long-term pressure

### Packet ruy-lopez-white.line-006.ply-07.b5a4

- Move: `Ba4` / `b5a4` at ply 7

- CoachCard: **Preserve the Spanish bishop** — Ba4 keeps the Ruy Lopez bishop active after ...a6. White preserves long-term pressure on the queenside knight and central e5 structure.

- Plain hint: Keep the bishop’s pressure after Black questions it with the rook pawn.

- Opening themes: bishop retreat, Spanish pressure, a6 response

### Packet ruy-lopez-white.line-006.ply-09.a4b3

- Move: `Bb3` / `a4b3` at ply 9

- CoachCard: **Keep the bishop on the Spanish diagonal** — Bb3 keeps the Spanish bishop active after Black expands with ...b5. From the retreat square, it still points toward Black’s kingside and supports central play.

- Plain hint: Retreat the bishop to keep kingside and central pressure alive.

- Opening themes: bishop preservation, Spanish diagonal, queenside space response

### Packet ruy-lopez-white.line-006.ply-11.d2d3

- Move: `d3` / `d2d3` at ply 11

- CoachCard: **Choose a quieter Spanish center** — d3 supports e4 and keeps the Ruy Lopez structure flexible. White can maintain bishop pressure without forcing the center open yet.

- Plain hint: Support the king pawn and keep the center closed while pressure builds.

- Opening themes: quiet Spanish center, e4 support, slow pressure


## ruy-lopez-white-line-007: 1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 4. Ba4 b5 5. Bb3 Nf6 6. d3 Be7

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1b5,a7a6,b5a4,b7b5,a4b3,g8f6,d2d3,f8e7`  
Runtime totalGames field at line node: `526783`

### Packet ruy-lopez-white.line-007.ply-05.f1b5

- Move: `Bb5` / `f1b5` at ply 5

- CoachCard: **Pin pressure on the e5 defender** — Bb5 is the Spanish bishop move: it pressures the knight that helps defend Black’s e5 pawn. The idea is long-term central pressure, not an immediate pawn win.

- Plain hint: Put pressure on the defender of the central pawn before committing the center.

- Opening themes: Bb5 pressure, e5 defender, Spanish long-term pressure

### Packet ruy-lopez-white.line-007.ply-07.b5a4

- Move: `Ba4` / `b5a4` at ply 7

- CoachCard: **Preserve the Spanish bishop** — Ba4 keeps the Ruy Lopez bishop active after ...a6. White preserves long-term pressure on the queenside knight and central e5 structure.

- Plain hint: Keep the bishop’s pressure after Black questions it with the rook pawn.

- Opening themes: bishop retreat, Spanish pressure, a6 response

### Packet ruy-lopez-white.line-007.ply-09.a4b3

- Move: `Bb3` / `a4b3` at ply 9

- CoachCard: **Keep the bishop on the Spanish diagonal** — Bb3 keeps the Spanish bishop active after Black expands with ...b5. From the retreat square, it still points toward Black’s kingside and supports central play.

- Plain hint: Retreat the bishop to keep kingside and central pressure alive.

- Opening themes: bishop preservation, Spanish diagonal, queenside space response

### Packet ruy-lopez-white.line-007.ply-11.d2d3

- Move: `d3` / `d2d3` at ply 11

- CoachCard: **Choose a quieter Spanish center** — d3 supports e4 and keeps the Ruy Lopez structure flexible. White can maintain bishop pressure without forcing the center open yet.

- Plain hint: Support the king pawn and keep the center closed while pressure builds.

- Opening themes: quiet Spanish center, e4 support, slow pressure


## ruy-lopez-white-line-008: 1. e4 e5 2. Nf3 Nc6 3. Bb5 d6 4. O-O Bd7 5. c3 Nf6 6. Re1 Be7

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1b5,d7d6,e1h1,c8d7,c2c3,g8f6,f1e1,f8e7`  
Runtime totalGames field at line node: `425134`

### Packet ruy-lopez-white.line-008.ply-05.f1b5

- Move: `Bb5` / `f1b5` at ply 5

- CoachCard: **Pin pressure on the e5 defender** — Bb5 is the Spanish bishop move: it pressures the knight that helps defend Black’s e5 pawn. The idea is long-term central pressure, not an immediate pawn win.

- Plain hint: Put pressure on the defender of the central pawn before committing the center.

- Opening themes: Bb5 pressure, e5 defender, Spanish long-term pressure

### Packet ruy-lopez-white.line-008.ply-07.e1g1

- Move: `O-O` / `e1g1` at ply 7
- Source runtime moveUci: `e1h1`; normalizedMoveUci: `e1g1`

- CoachCard: **Castle before expanding the Spanish center** — O-O makes White’s king safe and connects the rook to the central files. In the Ruy Lopez, castling often comes before Re1, c3, or d4 ideas.

- Plain hint: Secure the king before using the rook or pawns to increase central pressure.

- Opening themes: king safety, Re1 preparation, Spanish central timing

### Packet ruy-lopez-white.line-008.ply-09.c2c3

- Move: `c3` / `c2c3` at ply 9

- CoachCard: **Prepare the Spanish central advance** — c3 supports the classic Ruy Lopez plan of building a pawn base for d4. White prepares central expansion without abandoning bishop pressure.

- Plain hint: Build the pawn base that lets the queen pawn challenge the center.

- Opening themes: c3 support, d4 preparation, Spanish pawn base

### Packet ruy-lopez-white.line-008.ply-11.f1e1

- Move: `Re1` / `f1e1` at ply 11

- CoachCard: **Add rook pressure behind the e-pawn** — Re1 supports White’s e-pawn and prepares central expansion. In the Ruy Lopez, this rook move makes later d4 ideas more coherent.

- Plain hint: Put the rook behind the central pawn before the center opens.

- Opening themes: Re1 preparation, e-file support, Spanish center


## ruy-lopez-white-line-009: 1. e4 e5 2. Nf3 Nc6 3. Bb5 d6 4. d4 exd4 5. Nxd4 Bd7 6. O-O Nf6

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1b5,d7d6,d2d4,e5d4,f3d4,c8d7,e1h1,g8f6`  
Runtime totalGames field at line node: `420911`

### Packet ruy-lopez-white.line-009.ply-05.f1b5

- Move: `Bb5` / `f1b5` at ply 5

- CoachCard: **Pin pressure on the e5 defender** — Bb5 is the Spanish bishop move: it pressures the knight that helps defend Black’s e5 pawn. The idea is long-term central pressure, not an immediate pawn win.

- Plain hint: Put pressure on the defender of the central pawn before committing the center.

- Opening themes: Bb5 pressure, e5 defender, Spanish long-term pressure

### Packet ruy-lopez-white.line-009.ply-07.d2d4

- Move: `d4` / `d2d4` at ply 7

- CoachCard: **Break with the prepared Spanish center** — d4 is the central break White has often prepared with castling, Re1, and c3. It challenges Black’s e5/d6 structure at the right moment.

- Plain hint: Use the prepared queen pawn to challenge the center now that the pieces support it.

- Opening themes: d4 break, prepared center, Spanish pressure

### Packet ruy-lopez-white.line-009.ply-09.f3d4

- Move: `Nxd4` / `f3d4` at ply 9

- CoachCard: **Maintain Spanish pressure without forcing tactics** — Nxd4 keeps White’s Ruy Lopez plan tied to long-term pressure on Black’s center. The move is runtime-backed and supports the exact Spanish structure.

- Plain hint: Keep the move connected to bishop pressure, king safety, or central preparation.

- Opening themes: Spanish pressure, central preparation, piece coordination

### Packet ruy-lopez-white.line-009.ply-11.e1g1

- Move: `O-O` / `e1g1` at ply 11
- Source runtime moveUci: `e1h1`; normalizedMoveUci: `e1g1`

- CoachCard: **Castle before expanding the Spanish center** — O-O makes White’s king safe and connects the rook to the central files. In the Ruy Lopez, castling often comes before Re1, c3, or d4 ideas.

- Plain hint: Secure the king before using the rook or pawns to increase central pressure.

- Opening themes: king safety, Re1 preparation, Spanish central timing


## ruy-lopez-white-line-010: 1. e4 e5 2. Nf3 Nc6 3. Bb5 d6 4. d4 exd4 5. Nxd4 Bd7 6. Nxc6 Bxc6

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1b5,d7d6,d2d4,e5d4,f3d4,c8d7,d4c6,d7c6`  
Runtime totalGames field at line node: `410420`

### Packet ruy-lopez-white.line-010.ply-05.f1b5

- Move: `Bb5` / `f1b5` at ply 5

- CoachCard: **Pin pressure on the e5 defender** — Bb5 is the Spanish bishop move: it pressures the knight that helps defend Black’s e5 pawn. The idea is long-term central pressure, not an immediate pawn win.

- Plain hint: Put pressure on the defender of the central pawn before committing the center.

- Opening themes: Bb5 pressure, e5 defender, Spanish long-term pressure

### Packet ruy-lopez-white.line-010.ply-07.d2d4

- Move: `d4` / `d2d4` at ply 7

- CoachCard: **Break with the prepared Spanish center** — d4 is the central break White has often prepared with castling, Re1, and c3. It challenges Black’s e5/d6 structure at the right moment.

- Plain hint: Use the prepared queen pawn to challenge the center now that the pieces support it.

- Opening themes: d4 break, prepared center, Spanish pressure

### Packet ruy-lopez-white.line-010.ply-09.f3d4

- Move: `Nxd4` / `f3d4` at ply 9

- CoachCard: **Maintain Spanish pressure without forcing tactics** — Nxd4 keeps White’s Ruy Lopez plan tied to long-term pressure on Black’s center. The move is runtime-backed and supports the exact Spanish structure.

- Plain hint: Keep the move connected to bishop pressure, king safety, or central preparation.

- Opening themes: Spanish pressure, central preparation, piece coordination

### Packet ruy-lopez-white.line-010.ply-11.d4c6

- Move: `Nxc6` / `d4c6` at ply 11

- CoachCard: **Maintain Spanish pressure without forcing tactics** — Nxc6 keeps White’s Ruy Lopez plan tied to long-term pressure on Black’s center. The move is runtime-backed and supports the exact Spanish structure.

- Plain hint: Keep the move connected to bishop pressure, king safety, or central preparation.

- Opening themes: Spanish pressure, central preparation, piece coordination


## ruy-lopez-white-line-011: 1. e4 e5 2. Nf3 Nc6 3. Bb5 d6 4. d4 exd4 5. Nxd4 Bd7 6. Nxc6 bxc6

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1b5,d7d6,d2d4,e5d4,f3d4,c8d7,d4c6,b7c6`  
Runtime totalGames field at line node: `389158`

### Packet ruy-lopez-white.line-011.ply-05.f1b5

- Move: `Bb5` / `f1b5` at ply 5

- CoachCard: **Pin pressure on the e5 defender** — Bb5 is the Spanish bishop move: it pressures the knight that helps defend Black’s e5 pawn. The idea is long-term central pressure, not an immediate pawn win.

- Plain hint: Put pressure on the defender of the central pawn before committing the center.

- Opening themes: Bb5 pressure, e5 defender, Spanish long-term pressure

### Packet ruy-lopez-white.line-011.ply-07.d2d4

- Move: `d4` / `d2d4` at ply 7

- CoachCard: **Break with the prepared Spanish center** — d4 is the central break White has often prepared with castling, Re1, and c3. It challenges Black’s e5/d6 structure at the right moment.

- Plain hint: Use the prepared queen pawn to challenge the center now that the pieces support it.

- Opening themes: d4 break, prepared center, Spanish pressure

### Packet ruy-lopez-white.line-011.ply-09.f3d4

- Move: `Nxd4` / `f3d4` at ply 9

- CoachCard: **Maintain Spanish pressure without forcing tactics** — Nxd4 keeps White’s Ruy Lopez plan tied to long-term pressure on Black’s center. The move is runtime-backed and supports the exact Spanish structure.

- Plain hint: Keep the move connected to bishop pressure, king safety, or central preparation.

- Opening themes: Spanish pressure, central preparation, piece coordination

### Packet ruy-lopez-white.line-011.ply-11.d4c6

- Move: `Nxc6` / `d4c6` at ply 11

- CoachCard: **Maintain Spanish pressure without forcing tactics** — Nxc6 keeps White’s Ruy Lopez plan tied to long-term pressure on Black’s center. The move is runtime-backed and supports the exact Spanish structure.

- Plain hint: Keep the move connected to bishop pressure, king safety, or central preparation.

- Opening themes: Spanish pressure, central preparation, piece coordination


## ruy-lopez-white-line-012: 1. e4 e5 2. Nf3 Nc6 3. Bb5 d6 4. O-O Bd7 5. d4 exd4 6. Nxd4 Nxd4

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1b5,d7d6,e1h1,c8d7,d2d4,e5d4,f3d4,c6d4`  
Runtime totalGames field at line node: `317106`

### Packet ruy-lopez-white.line-012.ply-05.f1b5

- Move: `Bb5` / `f1b5` at ply 5

- CoachCard: **Pin pressure on the e5 defender** — Bb5 is the Spanish bishop move: it pressures the knight that helps defend Black’s e5 pawn. The idea is long-term central pressure, not an immediate pawn win.

- Plain hint: Put pressure on the defender of the central pawn before committing the center.

- Opening themes: Bb5 pressure, e5 defender, Spanish long-term pressure

### Packet ruy-lopez-white.line-012.ply-07.e1g1

- Move: `O-O` / `e1g1` at ply 7
- Source runtime moveUci: `e1h1`; normalizedMoveUci: `e1g1`

- CoachCard: **Castle before expanding the Spanish center** — O-O makes White’s king safe and connects the rook to the central files. In the Ruy Lopez, castling often comes before Re1, c3, or d4 ideas.

- Plain hint: Secure the king before using the rook or pawns to increase central pressure.

- Opening themes: king safety, Re1 preparation, Spanish central timing

### Packet ruy-lopez-white.line-012.ply-09.d2d4

- Move: `d4` / `d2d4` at ply 9

- CoachCard: **Break with the prepared Spanish center** — d4 is the central break White has often prepared with castling, Re1, and c3. It challenges Black’s e5/d6 structure at the right moment.

- Plain hint: Use the prepared queen pawn to challenge the center now that the pieces support it.

- Opening themes: d4 break, prepared center, Spanish pressure

### Packet ruy-lopez-white.line-012.ply-11.f3d4

- Move: `Nxd4` / `f3d4` at ply 11

- CoachCard: **Maintain Spanish pressure without forcing tactics** — Nxd4 keeps White’s Ruy Lopez plan tied to long-term pressure on Black’s center. The move is runtime-backed and supports the exact Spanish structure.

- Plain hint: Keep the move connected to bishop pressure, king safety, or central preparation.

- Opening themes: Spanish pressure, central preparation, piece coordination


## ruy-lopez-white-line-013: 1. e4 e5 2. Nf3 Nc6 3. Bb5 Nf6 4. O-O Nxe4 5. Re1 Nd6 6. Bxc6 dxc6

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1b5,g8f6,e1h1,f6e4,f1e1,e4d6,b5c6,d7c6`  
Runtime totalGames field at line node: `289220`

### Packet ruy-lopez-white.line-013.ply-05.f1b5

- Move: `Bb5` / `f1b5` at ply 5

- CoachCard: **Pin pressure on the e5 defender** — Bb5 is the Spanish bishop move: it pressures the knight that helps defend Black’s e5 pawn. The idea is long-term central pressure, not an immediate pawn win.

- Plain hint: Put pressure on the defender of the central pawn before committing the center.

- Opening themes: Bb5 pressure, e5 defender, Spanish long-term pressure

### Packet ruy-lopez-white.line-013.ply-07.e1g1

- Move: `O-O` / `e1g1` at ply 7
- Source runtime moveUci: `e1h1`; normalizedMoveUci: `e1g1`

- CoachCard: **Castle before expanding the Spanish center** — O-O makes White’s king safe and connects the rook to the central files. In the Ruy Lopez, castling often comes before Re1, c3, or d4 ideas.

- Plain hint: Secure the king before using the rook or pawns to increase central pressure.

- Opening themes: king safety, Re1 preparation, Spanish central timing

### Packet ruy-lopez-white.line-013.ply-09.f1e1

- Move: `Re1` / `f1e1` at ply 9

- CoachCard: **Add rook pressure behind the e-pawn** — Re1 supports White’s e-pawn and prepares central expansion. In the Ruy Lopez, this rook move makes later d4 ideas more coherent.

- Plain hint: Put the rook behind the central pawn before the center opens.

- Opening themes: Re1 preparation, e-file support, Spanish center

### Packet ruy-lopez-white.line-013.ply-11.b5c6

- Move: `Bxc6` / `b5c6` at ply 11

- CoachCard: **Maintain Spanish pressure without forcing tactics** — Bxc6 keeps White’s Ruy Lopez plan tied to long-term pressure on Black’s center. The move is runtime-backed and supports the exact Spanish structure.

- Plain hint: Keep the move connected to bishop pressure, king safety, or central preparation.

- Opening themes: Spanish pressure, central preparation, piece coordination


## ruy-lopez-white-line-014: 1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 4. Bxc6 dxc6 5. O-O Bd6 6. d4 exd4

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1b5,a7a6,b5c6,d7c6,e1h1,f8d6,d2d4,e5d4`  
Runtime totalGames field at line node: `275339`

### Packet ruy-lopez-white.line-014.ply-05.f1b5

- Move: `Bb5` / `f1b5` at ply 5

- CoachCard: **Pin pressure on the e5 defender** — Bb5 is the Spanish bishop move: it pressures the knight that helps defend Black’s e5 pawn. The idea is long-term central pressure, not an immediate pawn win.

- Plain hint: Put pressure on the defender of the central pawn before committing the center.

- Opening themes: Bb5 pressure, e5 defender, Spanish long-term pressure

### Packet ruy-lopez-white.line-014.ply-07.b5c6

- Move: `Bxc6` / `b5c6` at ply 7

- CoachCard: **Maintain Spanish pressure without forcing tactics** — Bxc6 keeps White’s Ruy Lopez plan tied to long-term pressure on Black’s center. The move is runtime-backed and supports the exact Spanish structure.

- Plain hint: Keep the move connected to bishop pressure, king safety, or central preparation.

- Opening themes: Spanish pressure, central preparation, piece coordination

### Packet ruy-lopez-white.line-014.ply-09.e1g1

- Move: `O-O` / `e1g1` at ply 9
- Source runtime moveUci: `e1h1`; normalizedMoveUci: `e1g1`

- CoachCard: **Castle before expanding the Spanish center** — O-O makes White’s king safe and connects the rook to the central files. In the Ruy Lopez, castling often comes before Re1, c3, or d4 ideas.

- Plain hint: Secure the king before using the rook or pawns to increase central pressure.

- Opening themes: king safety, Re1 preparation, Spanish central timing

### Packet ruy-lopez-white.line-014.ply-11.d2d4

- Move: `d4` / `d2d4` at ply 11

- CoachCard: **Break with the prepared Spanish center** — d4 is the central break White has often prepared with castling, Re1, and c3. It challenges Black’s e5/d6 structure at the right moment.

- Plain hint: Use the prepared queen pawn to challenge the center now that the pieces support it.

- Opening themes: d4 break, prepared center, Spanish pressure


## ruy-lopez-white-line-015: 1. e4 e5 2. Nf3 Nc6 3. Bb5 d6 4. O-O Nf6 5. Re1 Be7 6. c3 O-O

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1b5,d7d6,e1h1,g8f6,f1e1,f8e7,c2c3,e8h8`  
Runtime totalGames field at line node: `258810`

### Packet ruy-lopez-white.line-015.ply-05.f1b5

- Move: `Bb5` / `f1b5` at ply 5

- CoachCard: **Pin pressure on the e5 defender** — Bb5 is the Spanish bishop move: it pressures the knight that helps defend Black’s e5 pawn. The idea is long-term central pressure, not an immediate pawn win.

- Plain hint: Put pressure on the defender of the central pawn before committing the center.

- Opening themes: Bb5 pressure, e5 defender, Spanish long-term pressure

### Packet ruy-lopez-white.line-015.ply-07.e1g1

- Move: `O-O` / `e1g1` at ply 7
- Source runtime moveUci: `e1h1`; normalizedMoveUci: `e1g1`

- CoachCard: **Castle before expanding the Spanish center** — O-O makes White’s king safe and connects the rook to the central files. In the Ruy Lopez, castling often comes before Re1, c3, or d4 ideas.

- Plain hint: Secure the king before using the rook or pawns to increase central pressure.

- Opening themes: king safety, Re1 preparation, Spanish central timing

### Packet ruy-lopez-white.line-015.ply-09.f1e1

- Move: `Re1` / `f1e1` at ply 9

- CoachCard: **Add rook pressure behind the e-pawn** — Re1 supports White’s e-pawn and prepares central expansion. In the Ruy Lopez, this rook move makes later d4 ideas more coherent.

- Plain hint: Put the rook behind the central pawn before the center opens.

- Opening themes: Re1 preparation, e-file support, Spanish center

### Packet ruy-lopez-white.line-015.ply-11.c2c3

- Move: `c3` / `c2c3` at ply 11

- CoachCard: **Prepare the Spanish central advance** — c3 supports the classic Ruy Lopez plan of building a pawn base for d4. White prepares central expansion without abandoning bishop pressure.

- Plain hint: Build the pawn base that lets the queen pawn challenge the center.

- Opening themes: c3 support, d4 preparation, Spanish pawn base


## ruy-lopez-white-line-016: 1. e4 e5 2. Nf3 Nc6 3. Bb5 Nf6 4. O-O Bc5 5. c3 O-O 6. d4 exd4

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1b5,g8f6,e1h1,f8c5,c2c3,e8h8,d2d4,e5d4`  
Runtime totalGames field at line node: `253697`

### Packet ruy-lopez-white.line-016.ply-05.f1b5

- Move: `Bb5` / `f1b5` at ply 5

- CoachCard: **Pin pressure on the e5 defender** — Bb5 is the Spanish bishop move: it pressures the knight that helps defend Black’s e5 pawn. The idea is long-term central pressure, not an immediate pawn win.

- Plain hint: Put pressure on the defender of the central pawn before committing the center.

- Opening themes: Bb5 pressure, e5 defender, Spanish long-term pressure

### Packet ruy-lopez-white.line-016.ply-07.e1g1

- Move: `O-O` / `e1g1` at ply 7
- Source runtime moveUci: `e1h1`; normalizedMoveUci: `e1g1`

- CoachCard: **Castle before expanding the Spanish center** — O-O makes White’s king safe and connects the rook to the central files. In the Ruy Lopez, castling often comes before Re1, c3, or d4 ideas.

- Plain hint: Secure the king before using the rook or pawns to increase central pressure.

- Opening themes: king safety, Re1 preparation, Spanish central timing

### Packet ruy-lopez-white.line-016.ply-09.c2c3

- Move: `c3` / `c2c3` at ply 9

- CoachCard: **Prepare the Spanish central advance** — c3 supports the classic Ruy Lopez plan of building a pawn base for d4. White prepares central expansion without abandoning bishop pressure.

- Plain hint: Build the pawn base that lets the queen pawn challenge the center.

- Opening themes: c3 support, d4 preparation, Spanish pawn base

### Packet ruy-lopez-white.line-016.ply-11.d2d4

- Move: `d4` / `d2d4` at ply 11

- CoachCard: **Break with the prepared Spanish center** — d4 is the central break White has often prepared with castling, Re1, and c3. It challenges Black’s e5/d6 structure at the right moment.

- Plain hint: Use the prepared queen pawn to challenge the center now that the pieces support it.

- Opening themes: d4 break, prepared center, Spanish pressure


## ruy-lopez-white-line-017: 1. e4 e5 2. Nf3 Nc6 3. Bb5 d6 4. d4 Bd7 5. d5 Nce7 6. Bxd7+ Qxd7

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1b5,d7d6,d2d4,c8d7,d4d5,c6e7,b5d7,d8d7`  
Runtime totalGames field at line node: `249450`

### Packet ruy-lopez-white.line-017.ply-05.f1b5

- Move: `Bb5` / `f1b5` at ply 5

- CoachCard: **Pin pressure on the e5 defender** — Bb5 is the Spanish bishop move: it pressures the knight that helps defend Black’s e5 pawn. The idea is long-term central pressure, not an immediate pawn win.

- Plain hint: Put pressure on the defender of the central pawn before committing the center.

- Opening themes: Bb5 pressure, e5 defender, Spanish long-term pressure

### Packet ruy-lopez-white.line-017.ply-07.d2d4

- Move: `d4` / `d2d4` at ply 7

- CoachCard: **Break with the prepared Spanish center** — d4 is the central break White has often prepared with castling, Re1, and c3. It challenges Black’s e5/d6 structure at the right moment.

- Plain hint: Use the prepared queen pawn to challenge the center now that the pieces support it.

- Opening themes: d4 break, prepared center, Spanish pressure

### Packet ruy-lopez-white.line-017.ply-09.d4d5

- Move: `d5` / `d4d5` at ply 9

- CoachCard: **Maintain Spanish pressure without forcing tactics** — d5 keeps White’s Ruy Lopez plan tied to long-term pressure on Black’s center. The move is runtime-backed and supports the exact Spanish structure.

- Plain hint: Keep the move connected to bishop pressure, king safety, or central preparation.

- Opening themes: Spanish pressure, central preparation, piece coordination

### Packet ruy-lopez-white.line-017.ply-11.b5d7

- Move: `Bxd7+` / `b5d7` at ply 11

- CoachCard: **Maintain Spanish pressure without forcing tactics** — Bxd7+ keeps White’s Ruy Lopez plan tied to long-term pressure on Black’s center. The move is runtime-backed and supports the exact Spanish structure.

- Plain hint: Keep the move connected to bishop pressure, king safety, or central preparation.

- Opening themes: Spanish pressure, central preparation, piece coordination


## ruy-lopez-white-line-018: 1. e4 e5 2. Nf3 Nc6 3. Bb5 Nf6 4. O-O Nxe4 5. d4 Nd6 6. Bxc6 dxc6

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1b5,g8f6,e1h1,f6e4,d2d4,e4d6,b5c6,d7c6`  
Runtime totalGames field at line node: `248127`

### Packet ruy-lopez-white.line-018.ply-05.f1b5

- Move: `Bb5` / `f1b5` at ply 5

- CoachCard: **Pin pressure on the e5 defender** — Bb5 is the Spanish bishop move: it pressures the knight that helps defend Black’s e5 pawn. The idea is long-term central pressure, not an immediate pawn win.

- Plain hint: Put pressure on the defender of the central pawn before committing the center.

- Opening themes: Bb5 pressure, e5 defender, Spanish long-term pressure

### Packet ruy-lopez-white.line-018.ply-07.e1g1

- Move: `O-O` / `e1g1` at ply 7
- Source runtime moveUci: `e1h1`; normalizedMoveUci: `e1g1`

- CoachCard: **Castle before expanding the Spanish center** — O-O makes White’s king safe and connects the rook to the central files. In the Ruy Lopez, castling often comes before Re1, c3, or d4 ideas.

- Plain hint: Secure the king before using the rook or pawns to increase central pressure.

- Opening themes: king safety, Re1 preparation, Spanish central timing

### Packet ruy-lopez-white.line-018.ply-09.d2d4

- Move: `d4` / `d2d4` at ply 9

- CoachCard: **Break with the prepared Spanish center** — d4 is the central break White has often prepared with castling, Re1, and c3. It challenges Black’s e5/d6 structure at the right moment.

- Plain hint: Use the prepared queen pawn to challenge the center now that the pieces support it.

- Opening themes: d4 break, prepared center, Spanish pressure

### Packet ruy-lopez-white.line-018.ply-11.b5c6

- Move: `Bxc6` / `b5c6` at ply 11

- CoachCard: **Maintain Spanish pressure without forcing tactics** — Bxc6 keeps White’s Ruy Lopez plan tied to long-term pressure on Black’s center. The move is runtime-backed and supports the exact Spanish structure.

- Plain hint: Keep the move connected to bishop pressure, king safety, or central preparation.

- Opening themes: Spanish pressure, central preparation, piece coordination


## ruy-lopez-white-line-019: 1. e4 e5 2. Nf3 Nc6 3. Bb5 Nf6 4. O-O Bc5 5. c3 d6 6. d4 exd4

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1b5,g8f6,e1h1,f8c5,c2c3,d7d6,d2d4,e5d4`  
Runtime totalGames field at line node: `221921`

### Packet ruy-lopez-white.line-019.ply-05.f1b5

- Move: `Bb5` / `f1b5` at ply 5

- CoachCard: **Pin pressure on the e5 defender** — Bb5 is the Spanish bishop move: it pressures the knight that helps defend Black’s e5 pawn. The idea is long-term central pressure, not an immediate pawn win.

- Plain hint: Put pressure on the defender of the central pawn before committing the center.

- Opening themes: Bb5 pressure, e5 defender, Spanish long-term pressure

### Packet ruy-lopez-white.line-019.ply-07.e1g1

- Move: `O-O` / `e1g1` at ply 7
- Source runtime moveUci: `e1h1`; normalizedMoveUci: `e1g1`

- CoachCard: **Castle before expanding the Spanish center** — O-O makes White’s king safe and connects the rook to the central files. In the Ruy Lopez, castling often comes before Re1, c3, or d4 ideas.

- Plain hint: Secure the king before using the rook or pawns to increase central pressure.

- Opening themes: king safety, Re1 preparation, Spanish central timing

### Packet ruy-lopez-white.line-019.ply-09.c2c3

- Move: `c3` / `c2c3` at ply 9

- CoachCard: **Prepare the Spanish central advance** — c3 supports the classic Ruy Lopez plan of building a pawn base for d4. White prepares central expansion without abandoning bishop pressure.

- Plain hint: Build the pawn base that lets the queen pawn challenge the center.

- Opening themes: c3 support, d4 preparation, Spanish pawn base

### Packet ruy-lopez-white.line-019.ply-11.d2d4

- Move: `d4` / `d2d4` at ply 11

- CoachCard: **Break with the prepared Spanish center** — d4 is the central break White has often prepared with castling, Re1, and c3. It challenges Black’s e5/d6 structure at the right moment.

- Plain hint: Use the prepared queen pawn to challenge the center now that the pieces support it.

- Opening themes: d4 break, prepared center, Spanish pressure


## ruy-lopez-white-line-020: 1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 4. Ba4 b5 5. Bb3 Bc5 6. O-O d6

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1b5,a7a6,b5a4,b7b5,a4b3,f8c5,e1h1,d7d6`  
Runtime totalGames field at line node: `210543`

### Packet ruy-lopez-white.line-020.ply-05.f1b5

- Move: `Bb5` / `f1b5` at ply 5

- CoachCard: **Pin pressure on the e5 defender** — Bb5 is the Spanish bishop move: it pressures the knight that helps defend Black’s e5 pawn. The idea is long-term central pressure, not an immediate pawn win.

- Plain hint: Put pressure on the defender of the central pawn before committing the center.

- Opening themes: Bb5 pressure, e5 defender, Spanish long-term pressure

### Packet ruy-lopez-white.line-020.ply-07.b5a4

- Move: `Ba4` / `b5a4` at ply 7

- CoachCard: **Preserve the Spanish bishop** — Ba4 keeps the Ruy Lopez bishop active after ...a6. White preserves long-term pressure on the queenside knight and central e5 structure.

- Plain hint: Keep the bishop’s pressure after Black questions it with the rook pawn.

- Opening themes: bishop retreat, Spanish pressure, a6 response

### Packet ruy-lopez-white.line-020.ply-09.a4b3

- Move: `Bb3` / `a4b3` at ply 9

- CoachCard: **Keep the bishop on the Spanish diagonal** — Bb3 keeps the Spanish bishop active after Black expands with ...b5. From the retreat square, it still points toward Black’s kingside and supports central play.

- Plain hint: Retreat the bishop to keep kingside and central pressure alive.

- Opening themes: bishop preservation, Spanish diagonal, queenside space response

### Packet ruy-lopez-white.line-020.ply-11.e1g1

- Move: `O-O` / `e1g1` at ply 11
- Source runtime moveUci: `e1h1`; normalizedMoveUci: `e1g1`

- CoachCard: **Castle before expanding the Spanish center** — O-O makes White’s king safe and connects the rook to the central files. In the Ruy Lopez, castling often comes before Re1, c3, or d4 ideas.

- Plain hint: Secure the king before using the rook or pawns to increase central pressure.

- Opening themes: king safety, Re1 preparation, Spanish central timing


## ruy-lopez-white-line-021: 1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 4. Ba4 b5 5. Bb3 Bc5 6. c3 Nf6

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1b5,a7a6,b5a4,b7b5,a4b3,f8c5,c2c3,g8f6`  
Runtime totalGames field at line node: `209509`

### Packet ruy-lopez-white.line-021.ply-05.f1b5

- Move: `Bb5` / `f1b5` at ply 5

- CoachCard: **Pin pressure on the e5 defender** — Bb5 is the Spanish bishop move: it pressures the knight that helps defend Black’s e5 pawn. The idea is long-term central pressure, not an immediate pawn win.

- Plain hint: Put pressure on the defender of the central pawn before committing the center.

- Opening themes: Bb5 pressure, e5 defender, Spanish long-term pressure

### Packet ruy-lopez-white.line-021.ply-07.b5a4

- Move: `Ba4` / `b5a4` at ply 7

- CoachCard: **Preserve the Spanish bishop** — Ba4 keeps the Ruy Lopez bishop active after ...a6. White preserves long-term pressure on the queenside knight and central e5 structure.

- Plain hint: Keep the bishop’s pressure after Black questions it with the rook pawn.

- Opening themes: bishop retreat, Spanish pressure, a6 response

### Packet ruy-lopez-white.line-021.ply-09.a4b3

- Move: `Bb3` / `a4b3` at ply 9

- CoachCard: **Keep the bishop on the Spanish diagonal** — Bb3 keeps the Spanish bishop active after Black expands with ...b5. From the retreat square, it still points toward Black’s kingside and supports central play.

- Plain hint: Retreat the bishop to keep kingside and central pressure alive.

- Opening themes: bishop preservation, Spanish diagonal, queenside space response

### Packet ruy-lopez-white.line-021.ply-11.c2c3

- Move: `c3` / `c2c3` at ply 11

- CoachCard: **Prepare the Spanish central advance** — c3 supports the classic Ruy Lopez plan of building a pawn base for d4. White prepares central expansion without abandoning bishop pressure.

- Plain hint: Build the pawn base that lets the queen pawn challenge the center.

- Opening themes: c3 support, d4 preparation, Spanish pawn base


## ruy-lopez-white-line-022: 1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 4. Ba4 b5 5. Bb3 Bc5 6. c3 d6

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1b5,a7a6,b5a4,b7b5,a4b3,f8c5,c2c3,d7d6`  
Runtime totalGames field at line node: `200408`

### Packet ruy-lopez-white.line-022.ply-05.f1b5

- Move: `Bb5` / `f1b5` at ply 5

- CoachCard: **Pin pressure on the e5 defender** — Bb5 is the Spanish bishop move: it pressures the knight that helps defend Black’s e5 pawn. The idea is long-term central pressure, not an immediate pawn win.

- Plain hint: Put pressure on the defender of the central pawn before committing the center.

- Opening themes: Bb5 pressure, e5 defender, Spanish long-term pressure

### Packet ruy-lopez-white.line-022.ply-07.b5a4

- Move: `Ba4` / `b5a4` at ply 7

- CoachCard: **Preserve the Spanish bishop** — Ba4 keeps the Ruy Lopez bishop active after ...a6. White preserves long-term pressure on the queenside knight and central e5 structure.

- Plain hint: Keep the bishop’s pressure after Black questions it with the rook pawn.

- Opening themes: bishop retreat, Spanish pressure, a6 response

### Packet ruy-lopez-white.line-022.ply-09.a4b3

- Move: `Bb3` / `a4b3` at ply 9

- CoachCard: **Keep the bishop on the Spanish diagonal** — Bb3 keeps the Spanish bishop active after Black expands with ...b5. From the retreat square, it still points toward Black’s kingside and supports central play.

- Plain hint: Retreat the bishop to keep kingside and central pressure alive.

- Opening themes: bishop preservation, Spanish diagonal, queenside space response

### Packet ruy-lopez-white.line-022.ply-11.c2c3

- Move: `c3` / `c2c3` at ply 11

- CoachCard: **Prepare the Spanish central advance** — c3 supports the classic Ruy Lopez plan of building a pawn base for d4. White prepares central expansion without abandoning bishop pressure.

- Plain hint: Build the pawn base that lets the queen pawn challenge the center.

- Opening themes: c3 support, d4 preparation, Spanish pawn base


## ruy-lopez-white-line-023: 1. e4 e5 2. Nf3 Nc6 3. Bb5 d6 4. O-O Bd7 5. c3 a6 6. Ba4 Nf6

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1b5,d7d6,e1h1,c8d7,c2c3,a7a6,b5a4,g8f6`  
Runtime totalGames field at line node: `190404`

### Packet ruy-lopez-white.line-023.ply-05.f1b5

- Move: `Bb5` / `f1b5` at ply 5

- CoachCard: **Pin pressure on the e5 defender** — Bb5 is the Spanish bishop move: it pressures the knight that helps defend Black’s e5 pawn. The idea is long-term central pressure, not an immediate pawn win.

- Plain hint: Put pressure on the defender of the central pawn before committing the center.

- Opening themes: Bb5 pressure, e5 defender, Spanish long-term pressure

### Packet ruy-lopez-white.line-023.ply-07.e1g1

- Move: `O-O` / `e1g1` at ply 7
- Source runtime moveUci: `e1h1`; normalizedMoveUci: `e1g1`

- CoachCard: **Castle before expanding the Spanish center** — O-O makes White’s king safe and connects the rook to the central files. In the Ruy Lopez, castling often comes before Re1, c3, or d4 ideas.

- Plain hint: Secure the king before using the rook or pawns to increase central pressure.

- Opening themes: king safety, Re1 preparation, Spanish central timing

### Packet ruy-lopez-white.line-023.ply-09.c2c3

- Move: `c3` / `c2c3` at ply 9

- CoachCard: **Prepare the Spanish central advance** — c3 supports the classic Ruy Lopez plan of building a pawn base for d4. White prepares central expansion without abandoning bishop pressure.

- Plain hint: Build the pawn base that lets the queen pawn challenge the center.

- Opening themes: c3 support, d4 preparation, Spanish pawn base

### Packet ruy-lopez-white.line-023.ply-11.b5a4

- Move: `Ba4` / `b5a4` at ply 11

- CoachCard: **Preserve the Spanish bishop** — Ba4 keeps the Ruy Lopez bishop active after ...a6. White preserves long-term pressure on the queenside knight and central e5 structure.

- Plain hint: Keep the bishop’s pressure after Black questions it with the rook pawn.

- Opening themes: bishop retreat, Spanish pressure, a6 response


## ruy-lopez-white-line-024: 1. e4 e5 2. Nf3 Nc6 3. Bb5 Nf6 4. Bxc6 dxc6 5. Nxe5 Qd4 6. Nf3 Qxe4+

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1b5,g8f6,b5c6,d7c6,f3e5,d8d4,e5f3,d4e4`  
Runtime totalGames field at line node: `188626`

### Packet ruy-lopez-white.line-024.ply-05.f1b5

- Move: `Bb5` / `f1b5` at ply 5

- CoachCard: **Pin pressure on the e5 defender** — Bb5 is the Spanish bishop move: it pressures the knight that helps defend Black’s e5 pawn. The idea is long-term central pressure, not an immediate pawn win.

- Plain hint: Put pressure on the defender of the central pawn before committing the center.

- Opening themes: Bb5 pressure, e5 defender, Spanish long-term pressure

### Packet ruy-lopez-white.line-024.ply-07.b5c6

- Move: `Bxc6` / `b5c6` at ply 7

- CoachCard: **Maintain Spanish pressure without forcing tactics** — Bxc6 keeps White’s Ruy Lopez plan tied to long-term pressure on Black’s center. The move is runtime-backed and supports the exact Spanish structure.

- Plain hint: Keep the move connected to bishop pressure, king safety, or central preparation.

- Opening themes: Spanish pressure, central preparation, piece coordination

### Packet ruy-lopez-white.line-024.ply-09.f3e5

- Move: `Nxe5` / `f3e5` at ply 9

- CoachCard: **Maintain Spanish pressure without forcing tactics** — Nxe5 keeps White’s Ruy Lopez plan tied to long-term pressure on Black’s center. The move is runtime-backed and supports the exact Spanish structure.

- Plain hint: Keep the move connected to bishop pressure, king safety, or central preparation.

- Opening themes: Spanish pressure, central preparation, piece coordination

### Packet ruy-lopez-white.line-024.ply-11.e5f3

- Move: `Nf3` / `e5f3` at ply 11

- CoachCard: **Maintain Spanish pressure without forcing tactics** — Nf3 keeps White’s Ruy Lopez plan tied to long-term pressure on Black’s center. The move is runtime-backed and supports the exact Spanish structure.

- Plain hint: Keep the move connected to bishop pressure, king safety, or central preparation.

- Opening themes: Spanish pressure, central preparation, piece coordination


## ruy-lopez-white-line-025: 1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 4. Bxc6 dxc6 5. O-O Bg4 6. h3 h5

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1b5,a7a6,b5c6,d7c6,e1h1,c8g4,h2h3,h7h5`  
Runtime totalGames field at line node: `183912`

### Packet ruy-lopez-white.line-025.ply-05.f1b5

- Move: `Bb5` / `f1b5` at ply 5

- CoachCard: **Pin pressure on the e5 defender** — Bb5 is the Spanish bishop move: it pressures the knight that helps defend Black’s e5 pawn. The idea is long-term central pressure, not an immediate pawn win.

- Plain hint: Put pressure on the defender of the central pawn before committing the center.

- Opening themes: Bb5 pressure, e5 defender, Spanish long-term pressure

### Packet ruy-lopez-white.line-025.ply-07.b5c6

- Move: `Bxc6` / `b5c6` at ply 7

- CoachCard: **Maintain Spanish pressure without forcing tactics** — Bxc6 keeps White’s Ruy Lopez plan tied to long-term pressure on Black’s center. The move is runtime-backed and supports the exact Spanish structure.

- Plain hint: Keep the move connected to bishop pressure, king safety, or central preparation.

- Opening themes: Spanish pressure, central preparation, piece coordination

### Packet ruy-lopez-white.line-025.ply-09.e1g1

- Move: `O-O` / `e1g1` at ply 9
- Source runtime moveUci: `e1h1`; normalizedMoveUci: `e1g1`

- CoachCard: **Castle before expanding the Spanish center** — O-O makes White’s king safe and connects the rook to the central files. In the Ruy Lopez, castling often comes before Re1, c3, or d4 ideas.

- Plain hint: Secure the king before using the rook or pawns to increase central pressure.

- Opening themes: king safety, Re1 preparation, Spanish central timing

### Packet ruy-lopez-white.line-025.ply-11.h2h3

- Move: `h3` / `h2h3` at ply 11

- CoachCard: **Maintain Spanish pressure without forcing tactics** — h3 keeps White’s Ruy Lopez plan tied to long-term pressure on Black’s center. The move is runtime-backed and supports the exact Spanish structure.

- Plain hint: Keep the move connected to bishop pressure, king safety, or central preparation.

- Opening themes: Spanish pressure, central preparation, piece coordination
