# Validation Report — Castling Normalization Repair

## Summary

- Total packets scanned: 625
- Total packets normalized: 86
- Packet IDs changed: 86
- Packet count before: 625
- Packet count after: 625
- Line count before: 150
- Line count after: 150

## Normalization count by opening

- `italian-black`: 11
- `kings-indian-black`: 25
- `nimzo-indian-black`: 21
- `queens-indian-black`: 9
- `ruy-lopez-white`: 15
- `scotch-white`: 5

## Validation checks

- Legal castling validation result: PASS; normalized app-target castling SAN remains `O-O` or `O-O-O` as applicable
- Runtime traceability result: PASS
- Visual recipe normalization result: PASS
- Plain View no-leak result: PASS
- Generic copy scan result: PASS
- Duplicate packet IDs: 0
- Duplicate openingId/lineId/moveUci/ply keys: 0
- Required fields present: PASS
- Status preserved as `approved_candidate`: PASS
- Approval readiness preserved as `ready_for_app_validation`: PASS
- No `e1h1`/`e8h8` remains in packet moveUci: PASS
- No `e1h1`/`e8h8` remains in visualRecipe.targetMoveUci: PASS
- No `e1->h1`/`e8->h8` arrows remain: PASS
- No h1/h8 king-destination highlights remain for normalized kingside castling: PASS
- Packet count remains 625: PASS
- Line count remains 150: PASS
- Opening count remains 6: PASS
- CONTENT_INVENTORY counts unchanged: PASS

## App-validation note

The app-validation layer should use `sourceRuntimeMoveUci` for runtime/source lookup and normalized `moveUci` / `visualRecipe.targetMoveUci` as the app move-authority target.

## Readiness

Package ready for app-side validation: YES
