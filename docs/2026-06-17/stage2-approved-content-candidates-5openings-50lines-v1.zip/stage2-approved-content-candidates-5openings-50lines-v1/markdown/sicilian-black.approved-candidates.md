# Sicilian Defense approved-content candidates

Opening ID: `sicilian-black`  
Status: approved candidates only; not app-activated.


## sicilian-black-line-001: 1. e4 c5 2. Nf3 d6 3. d4 cxd4 4. Nxd4 Nf6 5. Nc3 a6 6. Bg5 e6

Runtime playKey: `e2e4,c7c5,g1f3,d7d6,d2d4,c5d4,f3d4,g8f6,b1c3,a7a6,c1g5,e7e6`  
Runtime totalGames field at line node: `2723023`

### Packet sicilian-black.line-001.ply-02.c7c5

- Move: `c5` / `c7c5` at ply 2

- CoachCard: **Start the Sicilian imbalance** — c5 is the Sicilian’s defining answer: Black contests the center with the c-pawn instead of mirroring the e-pawn. This creates the asymmetrical pawn structure the opening relies on.

- Plain hint: Answer the king pawn asymmetrically by using the c-pawn to contest the central dark squares.

- Opening themes: ...c5 challenge, Sicilian asymmetry, d4 control

### Packet sicilian-black.line-001.ply-04.d7d6

- Move: `d6` / `d7d6` at ply 4

- CoachCard: **Build the flexible Sicilian center** — d6 supports the e5 square and prepares a flexible Open Sicilian structure. Black keeps options for ...Nf6, ...a6, ...e6, or ...g6 depending on White’s setup.

- Plain hint: Support the center and prepare flexible Sicilian development without weakening the king.

- Opening themes: ...d6 structure, Open Sicilian, flexible development

### Packet sicilian-black.line-001.ply-06.c5d4

- Move: `cxd4` / `c5d4` at ply 6

- CoachCard: **Trade into the Open Sicilian imbalance** — cxd4 exchanges Black’s c-pawn for White’s d-pawn, the classic Open Sicilian imbalance. Black gives White central space but gains half-open c-file and queenside counterplay.

- Plain hint: Trade the c-pawn for White’s central pawn and create the typical Sicilian imbalance.

- Opening themes: c-pawn for d-pawn, half-open c-file, Open Sicilian

### Packet sicilian-black.line-001.ply-08.g8f6

- Move: `Nf6` / `g8f6` at ply 8

- CoachCard: **Pressure White’s king pawn** — Nf6 develops with tempo against White’s e-pawn in many Sicilian lines. It also brings Black closer to castling while keeping the center under fire.

- Plain hint: Develop the kingside knight while pressuring White’s central pawn.

- Opening themes: ...Nf6 pressure, e4 target, king safety

### Packet sicilian-black.line-001.ply-10.a7a6

- Move: `a6` / `a7a6` at ply 10

- CoachCard: **Control b5 before queenside counterplay** — a6 controls b5 and prepares Najdorf-style queenside play. It keeps White’s pieces from using b5 while Black builds counterplay instead of grabbing pawns.

- Plain hint: Use the queenside rook-pawn to control the jump square and prepare Najdorf-style counterplay.

- Opening themes: Najdorf ...a6, b5 control, queenside counterplay

### Packet sicilian-black.line-001.ply-12.e7e6

- Move: `e6` / `e7e6` at ply 12

- CoachCard: **Set a Scheveningen-style base** — e6 creates a Scheveningen-style dark-square structure with pawns on e6 and d6 when paired with ...d6. Black stays solid while preparing development and central counterplay.

- Plain hint: Build a compact central wall and open the bishop route if needed.

- Opening themes: Scheveningen structure, dark-square center, bishop route


## sicilian-black-line-002: 1. e4 c5 2. Nf3 d6 3. d4 cxd4 4. Nxd4 Nf6 5. Nc3 g6 6. Be3 Bg7

Runtime playKey: `e2e4,c7c5,g1f3,d7d6,d2d4,c5d4,f3d4,g8f6,b1c3,g7g6,c1e3,f8g7`  
Runtime totalGames field at line node: `2486103`

### Packet sicilian-black.line-002.ply-02.c7c5

- Move: `c5` / `c7c5` at ply 2

- CoachCard: **Start the Sicilian imbalance** — c5 is the Sicilian’s defining answer: Black contests the center with the c-pawn instead of mirroring the e-pawn. This creates the asymmetrical pawn structure the opening relies on.

- Plain hint: Answer the king pawn asymmetrically by using the c-pawn to contest the central dark squares.

- Opening themes: ...c5 challenge, Sicilian asymmetry, d4 control

### Packet sicilian-black.line-002.ply-04.d7d6

- Move: `d6` / `d7d6` at ply 4

- CoachCard: **Build the flexible Sicilian center** — d6 supports the e5 square and prepares a flexible Open Sicilian structure. Black keeps options for ...Nf6, ...a6, ...e6, or ...g6 depending on White’s setup.

- Plain hint: Support the center and prepare flexible Sicilian development without weakening the king.

- Opening themes: ...d6 structure, Open Sicilian, flexible development

### Packet sicilian-black.line-002.ply-06.c5d4

- Move: `cxd4` / `c5d4` at ply 6

- CoachCard: **Trade into the Open Sicilian imbalance** — cxd4 exchanges Black’s c-pawn for White’s d-pawn, the classic Open Sicilian imbalance. Black gives White central space but gains half-open c-file and queenside counterplay.

- Plain hint: Trade the c-pawn for White’s central pawn and create the typical Sicilian imbalance.

- Opening themes: c-pawn for d-pawn, half-open c-file, Open Sicilian

### Packet sicilian-black.line-002.ply-08.g8f6

- Move: `Nf6` / `g8f6` at ply 8

- CoachCard: **Pressure White’s king pawn** — Nf6 develops with tempo against White’s e-pawn in many Sicilian lines. It also brings Black closer to castling while keeping the center under fire.

- Plain hint: Develop the kingside knight while pressuring White’s central pawn.

- Opening themes: ...Nf6 pressure, e4 target, king safety

### Packet sicilian-black.line-002.ply-10.g7g6

- Move: `g6` / `g7g6` at ply 10

- CoachCard: **Choose the Dragon fianchetto** — g6 signals a Dragon-style setup. Black prepares to put the bishop on the long diagonal, where it contests the center from a distance.

- Plain hint: Choose a kingside fianchetto while keeping pressure on the long diagonal.

- Opening themes: Dragon setup, long diagonal, fianchetto pressure

### Packet sicilian-black.line-002.ply-12.f8g7

- Move: `Bg7` / `f8g7` at ply 12

- CoachCard: **Finish the Sicilian long diagonal** — Bg7 completes the Dragon-style bishop setup. The bishop bears down the long diagonal and supports central counterplay from a safe square.

- Plain hint: Complete the fianchetto so the bishop influences the center from the long diagonal.

- Opening themes: Dragon bishop, long diagonal, central pressure


## sicilian-black-line-003: 1. e4 c5 2. Nf3 Nc6 3. d4 cxd4 4. Nxd4 Nf6 5. Nc3 e5 6. Ndb5 d6

Runtime playKey: `e2e4,c7c5,g1f3,b8c6,d2d4,c5d4,f3d4,g8f6,b1c3,e7e5,d4b5,d7d6`  
Runtime totalGames field at line node: `1963129`

### Packet sicilian-black.line-003.ply-02.c7c5

- Move: `c5` / `c7c5` at ply 2

- CoachCard: **Start the Sicilian imbalance** — c5 is the Sicilian’s defining answer: Black contests the center with the c-pawn instead of mirroring the e-pawn. This creates the asymmetrical pawn structure the opening relies on.

- Plain hint: Answer the king pawn asymmetrically by using the c-pawn to contest the central dark squares.

- Opening themes: ...c5 challenge, Sicilian asymmetry, d4 control

### Packet sicilian-black.line-003.ply-04.b8c6

- Move: `Nc6` / `b8c6` at ply 4

- CoachCard: **Develop into central pressure** — Nc6 develops the queenside knight toward the d4/e5 fight. In Sicilian structures it also supports queenside counterplay and increases pressure on White’s center.

- Plain hint: Develop the queenside knight to attack the center and support queenside counterplay.

- Opening themes: ...Nc6 pressure, d4 fight, queenside counterplay

### Packet sicilian-black.line-003.ply-06.c5d4

- Move: `cxd4` / `c5d4` at ply 6

- CoachCard: **Trade into the Open Sicilian imbalance** — cxd4 exchanges Black’s c-pawn for White’s d-pawn, the classic Open Sicilian imbalance. Black gives White central space but gains half-open c-file and queenside counterplay.

- Plain hint: Trade the c-pawn for White’s central pawn and create the typical Sicilian imbalance.

- Opening themes: c-pawn for d-pawn, half-open c-file, Open Sicilian

### Packet sicilian-black.line-003.ply-08.g8f6

- Move: `Nf6` / `g8f6` at ply 8

- CoachCard: **Pressure White’s king pawn** — Nf6 develops with tempo against White’s e-pawn in many Sicilian lines. It also brings Black closer to castling while keeping the center under fire.

- Plain hint: Develop the kingside knight while pressuring White’s central pawn.

- Opening themes: ...Nf6 pressure, e4 target, king safety

### Packet sicilian-black.line-003.ply-10.e7e5

- Move: `e5` / `e7e5` at ply 10

- CoachCard: **Gain Sveshnikov-style central space** — e5 grabs central space and often hits a white knight in Sveshnikov-type structures. Black accepts long-term square weaknesses in exchange for active central play.

- Plain hint: Gain central space and challenge White’s knight in a Sveshnikov-style structure.

- Opening themes: Sveshnikov space, central challenge, piece tempo

### Packet sicilian-black.line-003.ply-12.d7d6

- Move: `d6` / `d7d6` at ply 12

- CoachCard: **Build the flexible Sicilian center** — d6 supports the e5 square and prepares a flexible Open Sicilian structure. Black keeps options for ...Nf6, ...a6, ...e6, or ...g6 depending on White’s setup.

- Plain hint: Support the center and prepare flexible Sicilian development without weakening the king.

- Opening themes: ...d6 structure, Open Sicilian, flexible development


## sicilian-black-line-004: 1. e4 c5 2. Bc4 d6 3. Nc3 e6 4. Nf3 Nf6 5. d4 cxd4 6. Nxd4 a6

Runtime playKey: `e2e4,c7c5,f1c4,d7d6,b1c3,e7e6,g1f3,g8f6,d2d4,c5d4,f3d4,a7a6`  
Runtime totalGames field at line node: `1909727`

### Packet sicilian-black.line-004.ply-02.c7c5

- Move: `c5` / `c7c5` at ply 2

- CoachCard: **Start the Sicilian imbalance** — c5 is the Sicilian’s defining answer: Black contests the center with the c-pawn instead of mirroring the e-pawn. This creates the asymmetrical pawn structure the opening relies on.

- Plain hint: Answer the king pawn asymmetrically by using the c-pawn to contest the central dark squares.

- Opening themes: ...c5 challenge, Sicilian asymmetry, d4 control

### Packet sicilian-black.line-004.ply-04.d7d6

- Move: `d6` / `d7d6` at ply 4

- CoachCard: **Build the flexible Sicilian center** — d6 supports the e5 square and prepares a flexible Open Sicilian structure. Black keeps options for ...Nf6, ...a6, ...e6, or ...g6 depending on White’s setup.

- Plain hint: Support the center and prepare flexible Sicilian development without weakening the king.

- Opening themes: ...d6 structure, Open Sicilian, flexible development

### Packet sicilian-black.line-004.ply-06.e7e6

- Move: `e6` / `e7e6` at ply 6

- CoachCard: **Set a Scheveningen-style base** — e6 creates a Scheveningen-style dark-square structure with pawns on e6 and d6 when paired with ...d6. Black stays solid while preparing development and central counterplay.

- Plain hint: Build a compact central wall and open the bishop route if needed.

- Opening themes: Scheveningen structure, dark-square center, bishop route

### Packet sicilian-black.line-004.ply-08.g8f6

- Move: `Nf6` / `g8f6` at ply 8

- CoachCard: **Pressure White’s king pawn** — Nf6 develops with tempo against White’s e-pawn in many Sicilian lines. It also brings Black closer to castling while keeping the center under fire.

- Plain hint: Develop the kingside knight while pressuring White’s central pawn.

- Opening themes: ...Nf6 pressure, e4 target, king safety

### Packet sicilian-black.line-004.ply-10.c5d4

- Move: `cxd4` / `c5d4` at ply 10

- CoachCard: **Trade into the Open Sicilian imbalance** — cxd4 exchanges Black’s c-pawn for White’s d-pawn, the classic Open Sicilian imbalance. Black gives White central space but gains half-open c-file and queenside counterplay.

- Plain hint: Trade the c-pawn for White’s central pawn and create the typical Sicilian imbalance.

- Opening themes: c-pawn for d-pawn, half-open c-file, Open Sicilian

### Packet sicilian-black.line-004.ply-12.a7a6

- Move: `a6` / `a7a6` at ply 12

- CoachCard: **Control b5 before queenside counterplay** — a6 controls b5 and prepares Najdorf-style queenside play. It keeps White’s pieces from using b5 while Black builds counterplay instead of grabbing pawns.

- Plain hint: Use the queenside rook-pawn to control the jump square and prepare Najdorf-style counterplay.

- Opening themes: Najdorf ...a6, b5 control, queenside counterplay


## sicilian-black-line-005: 1. e4 c5 2. Nf3 Nc6 3. d4 cxd4 4. Nxd4 Nf6 5. Nc3 e5 6. Nxc6 bxc6

Runtime playKey: `e2e4,c7c5,g1f3,b8c6,d2d4,c5d4,f3d4,g8f6,b1c3,e7e5,d4c6,b7c6`  
Runtime totalGames field at line node: `1616871`

### Packet sicilian-black.line-005.ply-02.c7c5

- Move: `c5` / `c7c5` at ply 2

- CoachCard: **Start the Sicilian imbalance** — c5 is the Sicilian’s defining answer: Black contests the center with the c-pawn instead of mirroring the e-pawn. This creates the asymmetrical pawn structure the opening relies on.

- Plain hint: Answer the king pawn asymmetrically by using the c-pawn to contest the central dark squares.

- Opening themes: ...c5 challenge, Sicilian asymmetry, d4 control

### Packet sicilian-black.line-005.ply-04.b8c6

- Move: `Nc6` / `b8c6` at ply 4

- CoachCard: **Develop into central pressure** — Nc6 develops the queenside knight toward the d4/e5 fight. In Sicilian structures it also supports queenside counterplay and increases pressure on White’s center.

- Plain hint: Develop the queenside knight to attack the center and support queenside counterplay.

- Opening themes: ...Nc6 pressure, d4 fight, queenside counterplay

### Packet sicilian-black.line-005.ply-06.c5d4

- Move: `cxd4` / `c5d4` at ply 6

- CoachCard: **Trade into the Open Sicilian imbalance** — cxd4 exchanges Black’s c-pawn for White’s d-pawn, the classic Open Sicilian imbalance. Black gives White central space but gains half-open c-file and queenside counterplay.

- Plain hint: Trade the c-pawn for White’s central pawn and create the typical Sicilian imbalance.

- Opening themes: c-pawn for d-pawn, half-open c-file, Open Sicilian

### Packet sicilian-black.line-005.ply-08.g8f6

- Move: `Nf6` / `g8f6` at ply 8

- CoachCard: **Pressure White’s king pawn** — Nf6 develops with tempo against White’s e-pawn in many Sicilian lines. It also brings Black closer to castling while keeping the center under fire.

- Plain hint: Develop the kingside knight while pressuring White’s central pawn.

- Opening themes: ...Nf6 pressure, e4 target, king safety

### Packet sicilian-black.line-005.ply-10.e7e5

- Move: `e5` / `e7e5` at ply 10

- CoachCard: **Gain Sveshnikov-style central space** — e5 grabs central space and often hits a white knight in Sveshnikov-type structures. Black accepts long-term square weaknesses in exchange for active central play.

- Plain hint: Gain central space and challenge White’s knight in a Sveshnikov-style structure.

- Opening themes: Sveshnikov space, central challenge, piece tempo

### Packet sicilian-black.line-005.ply-12.b7c6

- Move: `bxc6` / `b7c6` at ply 12

- CoachCard: **Keep central control after the queenside trade** — bxc6 recaptures toward the center after White trades on c6. Black may accept doubled pawns, but keeps central presence and open lines for piece play.

- Plain hint: Accept doubled pawns to keep central control after White captures on the queenside.

- Opening themes: structural concession, central control, open lines


## sicilian-black-line-006: 1. e4 c5 2. Nf3 d6 3. d4 cxd4 4. Nxd4 Nf6 5. Nc3 a6 6. Be3 e5

Runtime playKey: `e2e4,c7c5,g1f3,d7d6,d2d4,c5d4,f3d4,g8f6,b1c3,a7a6,c1e3,e7e5`  
Runtime totalGames field at line node: `1538897`

### Packet sicilian-black.line-006.ply-02.c7c5

- Move: `c5` / `c7c5` at ply 2

- CoachCard: **Start the Sicilian imbalance** — c5 is the Sicilian’s defining answer: Black contests the center with the c-pawn instead of mirroring the e-pawn. This creates the asymmetrical pawn structure the opening relies on.

- Plain hint: Answer the king pawn asymmetrically by using the c-pawn to contest the central dark squares.

- Opening themes: ...c5 challenge, Sicilian asymmetry, d4 control

### Packet sicilian-black.line-006.ply-04.d7d6

- Move: `d6` / `d7d6` at ply 4

- CoachCard: **Build the flexible Sicilian center** — d6 supports the e5 square and prepares a flexible Open Sicilian structure. Black keeps options for ...Nf6, ...a6, ...e6, or ...g6 depending on White’s setup.

- Plain hint: Support the center and prepare flexible Sicilian development without weakening the king.

- Opening themes: ...d6 structure, Open Sicilian, flexible development

### Packet sicilian-black.line-006.ply-06.c5d4

- Move: `cxd4` / `c5d4` at ply 6

- CoachCard: **Trade into the Open Sicilian imbalance** — cxd4 exchanges Black’s c-pawn for White’s d-pawn, the classic Open Sicilian imbalance. Black gives White central space but gains half-open c-file and queenside counterplay.

- Plain hint: Trade the c-pawn for White’s central pawn and create the typical Sicilian imbalance.

- Opening themes: c-pawn for d-pawn, half-open c-file, Open Sicilian

### Packet sicilian-black.line-006.ply-08.g8f6

- Move: `Nf6` / `g8f6` at ply 8

- CoachCard: **Pressure White’s king pawn** — Nf6 develops with tempo against White’s e-pawn in many Sicilian lines. It also brings Black closer to castling while keeping the center under fire.

- Plain hint: Develop the kingside knight while pressuring White’s central pawn.

- Opening themes: ...Nf6 pressure, e4 target, king safety

### Packet sicilian-black.line-006.ply-10.a7a6

- Move: `a6` / `a7a6` at ply 10

- CoachCard: **Control b5 before queenside counterplay** — a6 controls b5 and prepares Najdorf-style queenside play. It keeps White’s pieces from using b5 while Black builds counterplay instead of grabbing pawns.

- Plain hint: Use the queenside rook-pawn to control the jump square and prepare Najdorf-style counterplay.

- Opening themes: Najdorf ...a6, b5 control, queenside counterplay

### Packet sicilian-black.line-006.ply-12.e7e5

- Move: `e5` / `e7e5` at ply 12

- CoachCard: **Gain Sveshnikov-style central space** — e5 grabs central space and often hits a white knight in Sveshnikov-type structures. Black accepts long-term square weaknesses in exchange for active central play.

- Plain hint: Gain central space and challenge White’s knight in a Sveshnikov-style structure.

- Opening themes: Sveshnikov space, central challenge, piece tempo


## sicilian-black-line-007: 1. e4 c5 2. Nf3 d6 3. d4 cxd4 4. Nxd4 Nc6 5. Nc3 g6 6. Be3 Bg7

Runtime playKey: `e2e4,c7c5,g1f3,d7d6,d2d4,c5d4,f3d4,b8c6,b1c3,g7g6,c1e3,f8g7`  
Runtime totalGames field at line node: `1477233`

### Packet sicilian-black.line-007.ply-02.c7c5

- Move: `c5` / `c7c5` at ply 2

- CoachCard: **Start the Sicilian imbalance** — c5 is the Sicilian’s defining answer: Black contests the center with the c-pawn instead of mirroring the e-pawn. This creates the asymmetrical pawn structure the opening relies on.

- Plain hint: Answer the king pawn asymmetrically by using the c-pawn to contest the central dark squares.

- Opening themes: ...c5 challenge, Sicilian asymmetry, d4 control

### Packet sicilian-black.line-007.ply-04.d7d6

- Move: `d6` / `d7d6` at ply 4

- CoachCard: **Build the flexible Sicilian center** — d6 supports the e5 square and prepares a flexible Open Sicilian structure. Black keeps options for ...Nf6, ...a6, ...e6, or ...g6 depending on White’s setup.

- Plain hint: Support the center and prepare flexible Sicilian development without weakening the king.

- Opening themes: ...d6 structure, Open Sicilian, flexible development

### Packet sicilian-black.line-007.ply-06.c5d4

- Move: `cxd4` / `c5d4` at ply 6

- CoachCard: **Trade into the Open Sicilian imbalance** — cxd4 exchanges Black’s c-pawn for White’s d-pawn, the classic Open Sicilian imbalance. Black gives White central space but gains half-open c-file and queenside counterplay.

- Plain hint: Trade the c-pawn for White’s central pawn and create the typical Sicilian imbalance.

- Opening themes: c-pawn for d-pawn, half-open c-file, Open Sicilian

### Packet sicilian-black.line-007.ply-08.b8c6

- Move: `Nc6` / `b8c6` at ply 8

- CoachCard: **Develop into central pressure** — Nc6 develops the queenside knight toward the d4/e5 fight. In Sicilian structures it also supports queenside counterplay and increases pressure on White’s center.

- Plain hint: Develop the queenside knight to attack the center and support queenside counterplay.

- Opening themes: ...Nc6 pressure, d4 fight, queenside counterplay

### Packet sicilian-black.line-007.ply-10.g7g6

- Move: `g6` / `g7g6` at ply 10

- CoachCard: **Choose the Dragon fianchetto** — g6 signals a Dragon-style setup. Black prepares to put the bishop on the long diagonal, where it contests the center from a distance.

- Plain hint: Choose a kingside fianchetto while keeping pressure on the long diagonal.

- Opening themes: Dragon setup, long diagonal, fianchetto pressure

### Packet sicilian-black.line-007.ply-12.f8g7

- Move: `Bg7` / `f8g7` at ply 12

- CoachCard: **Finish the Sicilian long diagonal** — Bg7 completes the Dragon-style bishop setup. The bishop bears down the long diagonal and supports central counterplay from a safe square.

- Plain hint: Complete the fianchetto so the bishop influences the center from the long diagonal.

- Opening themes: Dragon bishop, long diagonal, central pressure


## sicilian-black-line-008: 1. e4 c5 2. Nf3 Nc6 3. d4 cxd4 4. Nxd4 e5 5. Nb5 d6 6. N1c3 a6

Runtime playKey: `e2e4,c7c5,g1f3,b8c6,d2d4,c5d4,f3d4,e7e5,d4b5,d7d6,b1c3,a7a6`  
Runtime totalGames field at line node: `1447422`

### Packet sicilian-black.line-008.ply-02.c7c5

- Move: `c5` / `c7c5` at ply 2

- CoachCard: **Start the Sicilian imbalance** — c5 is the Sicilian’s defining answer: Black contests the center with the c-pawn instead of mirroring the e-pawn. This creates the asymmetrical pawn structure the opening relies on.

- Plain hint: Answer the king pawn asymmetrically by using the c-pawn to contest the central dark squares.

- Opening themes: ...c5 challenge, Sicilian asymmetry, d4 control

### Packet sicilian-black.line-008.ply-04.b8c6

- Move: `Nc6` / `b8c6` at ply 4

- CoachCard: **Develop into central pressure** — Nc6 develops the queenside knight toward the d4/e5 fight. In Sicilian structures it also supports queenside counterplay and increases pressure on White’s center.

- Plain hint: Develop the queenside knight to attack the center and support queenside counterplay.

- Opening themes: ...Nc6 pressure, d4 fight, queenside counterplay

### Packet sicilian-black.line-008.ply-06.c5d4

- Move: `cxd4` / `c5d4` at ply 6

- CoachCard: **Trade into the Open Sicilian imbalance** — cxd4 exchanges Black’s c-pawn for White’s d-pawn, the classic Open Sicilian imbalance. Black gives White central space but gains half-open c-file and queenside counterplay.

- Plain hint: Trade the c-pawn for White’s central pawn and create the typical Sicilian imbalance.

- Opening themes: c-pawn for d-pawn, half-open c-file, Open Sicilian

### Packet sicilian-black.line-008.ply-08.e7e5

- Move: `e5` / `e7e5` at ply 8

- CoachCard: **Gain Sveshnikov-style central space** — e5 grabs central space and often hits a white knight in Sveshnikov-type structures. Black accepts long-term square weaknesses in exchange for active central play.

- Plain hint: Gain central space and challenge White’s knight in a Sveshnikov-style structure.

- Opening themes: Sveshnikov space, central challenge, piece tempo

### Packet sicilian-black.line-008.ply-10.d7d6

- Move: `d6` / `d7d6` at ply 10

- CoachCard: **Build the flexible Sicilian center** — d6 supports the e5 square and prepares a flexible Open Sicilian structure. Black keeps options for ...Nf6, ...a6, ...e6, or ...g6 depending on White’s setup.

- Plain hint: Support the center and prepare flexible Sicilian development without weakening the king.

- Opening themes: ...d6 structure, Open Sicilian, flexible development

### Packet sicilian-black.line-008.ply-12.a7a6

- Move: `a6` / `a7a6` at ply 12

- CoachCard: **Control b5 before queenside counterplay** — a6 controls b5 and prepares Najdorf-style queenside play. It keeps White’s pieces from using b5 while Black builds counterplay instead of grabbing pawns.

- Plain hint: Use the queenside rook-pawn to control the jump square and prepare Najdorf-style counterplay.

- Opening themes: Najdorf ...a6, b5 control, queenside counterplay


## sicilian-black-line-009: 1. e4 c5 2. Nf3 e6 3. c3 Nc6 4. d4 d5 5. e5 Bd7 6. Bd3 Qb6

Runtime playKey: `e2e4,c7c5,g1f3,e7e6,c2c3,b8c6,d2d4,d7d5,e4e5,c8d7,f1d3,d8b6`  
Runtime totalGames field at line node: `1398633`

### Packet sicilian-black.line-009.ply-02.c7c5

- Move: `c5` / `c7c5` at ply 2

- CoachCard: **Start the Sicilian imbalance** — c5 is the Sicilian’s defining answer: Black contests the center with the c-pawn instead of mirroring the e-pawn. This creates the asymmetrical pawn structure the opening relies on.

- Plain hint: Answer the king pawn asymmetrically by using the c-pawn to contest the central dark squares.

- Opening themes: ...c5 challenge, Sicilian asymmetry, d4 control

### Packet sicilian-black.line-009.ply-04.e7e6

- Move: `e6` / `e7e6` at ply 4

- CoachCard: **Set a Scheveningen-style base** — e6 creates a Scheveningen-style dark-square structure with pawns on e6 and d6 when paired with ...d6. Black stays solid while preparing development and central counterplay.

- Plain hint: Build a compact central wall and open the bishop route if needed.

- Opening themes: Scheveningen structure, dark-square center, bishop route

### Packet sicilian-black.line-009.ply-06.b8c6

- Move: `Nc6` / `b8c6` at ply 6

- CoachCard: **Develop into central pressure** — Nc6 develops the queenside knight toward the d4/e5 fight. In Sicilian structures it also supports queenside counterplay and increases pressure on White’s center.

- Plain hint: Develop the queenside knight to attack the center and support queenside counterplay.

- Opening themes: ...Nc6 pressure, d4 fight, queenside counterplay

### Packet sicilian-black.line-009.ply-08.d7d5

- Move: `d5` / `d7d5` at ply 8

- CoachCard: **Use the Sicilian central counterbreak** — d5 is the thematic Sicilian central break. Black uses it to challenge White’s space before White can build a free attack.

- Plain hint: Break in the center when White’s setup gives Black a direct counterstrike.

- Opening themes: ...d5 break, central counterplay, space challenge

### Packet sicilian-black.line-009.ply-10.c8d7

- Move: `Bd7` / `c8d7` at ply 10

- CoachCard: **Keep Sicilian counterplay connected** — Bd7 stays tied to the Sicilian plan of asymmetrical center pressure and counterplay. Black’s move supports the structure created by ...c5 instead of drifting into passive symmetry.

- Plain hint: Keep the Sicilian imbalance: contest the center, develop quickly, and prepare queenside or central counterplay.

- Opening themes: Sicilian counterplay, asymmetry, center pressure

### Packet sicilian-black.line-009.ply-12.d8b6

- Move: `Qb6` / `d8b6` at ply 12

- CoachCard: **Keep Sicilian counterplay connected** — Qb6 stays tied to the Sicilian plan of asymmetrical center pressure and counterplay. Black’s move supports the structure created by ...c5 instead of drifting into passive symmetry.

- Plain hint: Keep the Sicilian imbalance: contest the center, develop quickly, and prepare queenside or central counterplay.

- Opening themes: Sicilian counterplay, asymmetry, center pressure


## sicilian-black-line-010: 1. e4 c5 2. Nf3 e6 3. c3 Nc6 4. d4 cxd4 5. cxd4 d5 6. e5 Nge7

Runtime playKey: `e2e4,c7c5,g1f3,e7e6,c2c3,b8c6,d2d4,c5d4,c3d4,d7d5,e4e5,g8e7`  
Runtime totalGames field at line node: `1050988`

### Packet sicilian-black.line-010.ply-02.c7c5

- Move: `c5` / `c7c5` at ply 2

- CoachCard: **Start the Sicilian imbalance** — c5 is the Sicilian’s defining answer: Black contests the center with the c-pawn instead of mirroring the e-pawn. This creates the asymmetrical pawn structure the opening relies on.

- Plain hint: Answer the king pawn asymmetrically by using the c-pawn to contest the central dark squares.

- Opening themes: ...c5 challenge, Sicilian asymmetry, d4 control

### Packet sicilian-black.line-010.ply-04.e7e6

- Move: `e6` / `e7e6` at ply 4

- CoachCard: **Set a Scheveningen-style base** — e6 creates a Scheveningen-style dark-square structure with pawns on e6 and d6 when paired with ...d6. Black stays solid while preparing development and central counterplay.

- Plain hint: Build a compact central wall and open the bishop route if needed.

- Opening themes: Scheveningen structure, dark-square center, bishop route

### Packet sicilian-black.line-010.ply-06.b8c6

- Move: `Nc6` / `b8c6` at ply 6

- CoachCard: **Develop into central pressure** — Nc6 develops the queenside knight toward the d4/e5 fight. In Sicilian structures it also supports queenside counterplay and increases pressure on White’s center.

- Plain hint: Develop the queenside knight to attack the center and support queenside counterplay.

- Opening themes: ...Nc6 pressure, d4 fight, queenside counterplay

### Packet sicilian-black.line-010.ply-08.c5d4

- Move: `cxd4` / `c5d4` at ply 8

- CoachCard: **Trade into the Open Sicilian imbalance** — cxd4 exchanges Black’s c-pawn for White’s d-pawn, the classic Open Sicilian imbalance. Black gives White central space but gains half-open c-file and queenside counterplay.

- Plain hint: Trade the c-pawn for White’s central pawn and create the typical Sicilian imbalance.

- Opening themes: c-pawn for d-pawn, half-open c-file, Open Sicilian

### Packet sicilian-black.line-010.ply-10.d7d5

- Move: `d5` / `d7d5` at ply 10

- CoachCard: **Use the Sicilian central counterbreak** — d5 is the thematic Sicilian central break. Black uses it to challenge White’s space before White can build a free attack.

- Plain hint: Break in the center when White’s setup gives Black a direct counterstrike.

- Opening themes: ...d5 break, central counterplay, space challenge

### Packet sicilian-black.line-010.ply-12.g8e7

- Move: `Nge7` / `g8e7` at ply 12

- CoachCard: **Keep Sicilian counterplay connected** — Nge7 stays tied to the Sicilian plan of asymmetrical center pressure and counterplay. Black’s move supports the structure created by ...c5 instead of drifting into passive symmetry.

- Plain hint: Keep the Sicilian imbalance: contest the center, develop quickly, and prepare queenside or central counterplay.

- Opening themes: Sicilian counterplay, asymmetry, center pressure


## sicilian-black-line-011: 1. e4 c5 2. Nf3 d6 3. d4 cxd4 4. Nxd4 Nf6 5. Nc3 a6 6. Be3 e6

Runtime playKey: `e2e4,c7c5,g1f3,d7d6,d2d4,c5d4,f3d4,g8f6,b1c3,a7a6,c1e3,e7e6`  
Runtime totalGames field at line node: `998359`

### Packet sicilian-black.line-011.ply-02.c7c5

- Move: `c5` / `c7c5` at ply 2

- CoachCard: **Start the Sicilian imbalance** — c5 is the Sicilian’s defining answer: Black contests the center with the c-pawn instead of mirroring the e-pawn. This creates the asymmetrical pawn structure the opening relies on.

- Plain hint: Answer the king pawn asymmetrically by using the c-pawn to contest the central dark squares.

- Opening themes: ...c5 challenge, Sicilian asymmetry, d4 control

### Packet sicilian-black.line-011.ply-04.d7d6

- Move: `d6` / `d7d6` at ply 4

- CoachCard: **Build the flexible Sicilian center** — d6 supports the e5 square and prepares a flexible Open Sicilian structure. Black keeps options for ...Nf6, ...a6, ...e6, or ...g6 depending on White’s setup.

- Plain hint: Support the center and prepare flexible Sicilian development without weakening the king.

- Opening themes: ...d6 structure, Open Sicilian, flexible development

### Packet sicilian-black.line-011.ply-06.c5d4

- Move: `cxd4` / `c5d4` at ply 6

- CoachCard: **Trade into the Open Sicilian imbalance** — cxd4 exchanges Black’s c-pawn for White’s d-pawn, the classic Open Sicilian imbalance. Black gives White central space but gains half-open c-file and queenside counterplay.

- Plain hint: Trade the c-pawn for White’s central pawn and create the typical Sicilian imbalance.

- Opening themes: c-pawn for d-pawn, half-open c-file, Open Sicilian

### Packet sicilian-black.line-011.ply-08.g8f6

- Move: `Nf6` / `g8f6` at ply 8

- CoachCard: **Pressure White’s king pawn** — Nf6 develops with tempo against White’s e-pawn in many Sicilian lines. It also brings Black closer to castling while keeping the center under fire.

- Plain hint: Develop the kingside knight while pressuring White’s central pawn.

- Opening themes: ...Nf6 pressure, e4 target, king safety

### Packet sicilian-black.line-011.ply-10.a7a6

- Move: `a6` / `a7a6` at ply 10

- CoachCard: **Control b5 before queenside counterplay** — a6 controls b5 and prepares Najdorf-style queenside play. It keeps White’s pieces from using b5 while Black builds counterplay instead of grabbing pawns.

- Plain hint: Use the queenside rook-pawn to control the jump square and prepare Najdorf-style counterplay.

- Opening themes: Najdorf ...a6, b5 control, queenside counterplay

### Packet sicilian-black.line-011.ply-12.e7e6

- Move: `e6` / `e7e6` at ply 12

- CoachCard: **Set a Scheveningen-style base** — e6 creates a Scheveningen-style dark-square structure with pawns on e6 and d6 when paired with ...d6. Black stays solid while preparing development and central counterplay.

- Plain hint: Build a compact central wall and open the bishop route if needed.

- Opening themes: Scheveningen structure, dark-square center, bishop route


## sicilian-black-line-012: 1. e4 c5 2. Nf3 e6 3. c3 Nc6 4. d4 cxd4 5. cxd4 d5 6. e5 Bb4+

Runtime playKey: `e2e4,c7c5,g1f3,e7e6,c2c3,b8c6,d2d4,c5d4,c3d4,d7d5,e4e5,f8b4`  
Runtime totalGames field at line node: `954817`

### Packet sicilian-black.line-012.ply-02.c7c5

- Move: `c5` / `c7c5` at ply 2

- CoachCard: **Start the Sicilian imbalance** — c5 is the Sicilian’s defining answer: Black contests the center with the c-pawn instead of mirroring the e-pawn. This creates the asymmetrical pawn structure the opening relies on.

- Plain hint: Answer the king pawn asymmetrically by using the c-pawn to contest the central dark squares.

- Opening themes: ...c5 challenge, Sicilian asymmetry, d4 control

### Packet sicilian-black.line-012.ply-04.e7e6

- Move: `e6` / `e7e6` at ply 4

- CoachCard: **Set a Scheveningen-style base** — e6 creates a Scheveningen-style dark-square structure with pawns on e6 and d6 when paired with ...d6. Black stays solid while preparing development and central counterplay.

- Plain hint: Build a compact central wall and open the bishop route if needed.

- Opening themes: Scheveningen structure, dark-square center, bishop route

### Packet sicilian-black.line-012.ply-06.b8c6

- Move: `Nc6` / `b8c6` at ply 6

- CoachCard: **Develop into central pressure** — Nc6 develops the queenside knight toward the d4/e5 fight. In Sicilian structures it also supports queenside counterplay and increases pressure on White’s center.

- Plain hint: Develop the queenside knight to attack the center and support queenside counterplay.

- Opening themes: ...Nc6 pressure, d4 fight, queenside counterplay

### Packet sicilian-black.line-012.ply-08.c5d4

- Move: `cxd4` / `c5d4` at ply 8

- CoachCard: **Trade into the Open Sicilian imbalance** — cxd4 exchanges Black’s c-pawn for White’s d-pawn, the classic Open Sicilian imbalance. Black gives White central space but gains half-open c-file and queenside counterplay.

- Plain hint: Trade the c-pawn for White’s central pawn and create the typical Sicilian imbalance.

- Opening themes: c-pawn for d-pawn, half-open c-file, Open Sicilian

### Packet sicilian-black.line-012.ply-10.d7d5

- Move: `d5` / `d7d5` at ply 10

- CoachCard: **Use the Sicilian central counterbreak** — d5 is the thematic Sicilian central break. Black uses it to challenge White’s space before White can build a free attack.

- Plain hint: Break in the center when White’s setup gives Black a direct counterstrike.

- Opening themes: ...d5 break, central counterplay, space challenge

### Packet sicilian-black.line-012.ply-12.f8b4

- Move: `Bb4+` / `f8b4` at ply 12

- CoachCard: **Keep Sicilian counterplay connected** — Bb4+ stays tied to the Sicilian plan of asymmetrical center pressure and counterplay. Black’s move supports the structure created by ...c5 instead of drifting into passive symmetry.

- Plain hint: Keep the Sicilian imbalance: contest the center, develop quickly, and prepare queenside or central counterplay.

- Opening themes: Sicilian counterplay, asymmetry, center pressure


## sicilian-black-line-013: 1. e4 c5 2. Nf3 d6 3. d4 cxd4 4. Nxd4 Nf6 5. Nc3 g6 6. Bc4 Bg7

Runtime playKey: `e2e4,c7c5,g1f3,d7d6,d2d4,c5d4,f3d4,g8f6,b1c3,g7g6,f1c4,f8g7`  
Runtime totalGames field at line node: `939058`

### Packet sicilian-black.line-013.ply-02.c7c5

- Move: `c5` / `c7c5` at ply 2

- CoachCard: **Start the Sicilian imbalance** — c5 is the Sicilian’s defining answer: Black contests the center with the c-pawn instead of mirroring the e-pawn. This creates the asymmetrical pawn structure the opening relies on.

- Plain hint: Answer the king pawn asymmetrically by using the c-pawn to contest the central dark squares.

- Opening themes: ...c5 challenge, Sicilian asymmetry, d4 control

### Packet sicilian-black.line-013.ply-04.d7d6

- Move: `d6` / `d7d6` at ply 4

- CoachCard: **Build the flexible Sicilian center** — d6 supports the e5 square and prepares a flexible Open Sicilian structure. Black keeps options for ...Nf6, ...a6, ...e6, or ...g6 depending on White’s setup.

- Plain hint: Support the center and prepare flexible Sicilian development without weakening the king.

- Opening themes: ...d6 structure, Open Sicilian, flexible development

### Packet sicilian-black.line-013.ply-06.c5d4

- Move: `cxd4` / `c5d4` at ply 6

- CoachCard: **Trade into the Open Sicilian imbalance** — cxd4 exchanges Black’s c-pawn for White’s d-pawn, the classic Open Sicilian imbalance. Black gives White central space but gains half-open c-file and queenside counterplay.

- Plain hint: Trade the c-pawn for White’s central pawn and create the typical Sicilian imbalance.

- Opening themes: c-pawn for d-pawn, half-open c-file, Open Sicilian

### Packet sicilian-black.line-013.ply-08.g8f6

- Move: `Nf6` / `g8f6` at ply 8

- CoachCard: **Pressure White’s king pawn** — Nf6 develops with tempo against White’s e-pawn in many Sicilian lines. It also brings Black closer to castling while keeping the center under fire.

- Plain hint: Develop the kingside knight while pressuring White’s central pawn.

- Opening themes: ...Nf6 pressure, e4 target, king safety

### Packet sicilian-black.line-013.ply-10.g7g6

- Move: `g6` / `g7g6` at ply 10

- CoachCard: **Choose the Dragon fianchetto** — g6 signals a Dragon-style setup. Black prepares to put the bishop on the long diagonal, where it contests the center from a distance.

- Plain hint: Choose a kingside fianchetto while keeping pressure on the long diagonal.

- Opening themes: Dragon setup, long diagonal, fianchetto pressure

### Packet sicilian-black.line-013.ply-12.f8g7

- Move: `Bg7` / `f8g7` at ply 12

- CoachCard: **Finish the Sicilian long diagonal** — Bg7 completes the Dragon-style bishop setup. The bishop bears down the long diagonal and supports central counterplay from a safe square.

- Plain hint: Complete the fianchetto so the bishop influences the center from the long diagonal.

- Opening themes: Dragon bishop, long diagonal, central pressure


## sicilian-black-line-014: 1. e4 c5 2. Nf3 e6 3. d4 cxd4 4. Nxd4 Nc6 5. Nc3 Nf6 6. Nxc6 bxc6

Runtime playKey: `e2e4,c7c5,g1f3,e7e6,d2d4,c5d4,f3d4,b8c6,b1c3,g8f6,d4c6,b7c6`  
Runtime totalGames field at line node: `926047`

### Packet sicilian-black.line-014.ply-02.c7c5

- Move: `c5` / `c7c5` at ply 2

- CoachCard: **Start the Sicilian imbalance** — c5 is the Sicilian’s defining answer: Black contests the center with the c-pawn instead of mirroring the e-pawn. This creates the asymmetrical pawn structure the opening relies on.

- Plain hint: Answer the king pawn asymmetrically by using the c-pawn to contest the central dark squares.

- Opening themes: ...c5 challenge, Sicilian asymmetry, d4 control

### Packet sicilian-black.line-014.ply-04.e7e6

- Move: `e6` / `e7e6` at ply 4

- CoachCard: **Set a Scheveningen-style base** — e6 creates a Scheveningen-style dark-square structure with pawns on e6 and d6 when paired with ...d6. Black stays solid while preparing development and central counterplay.

- Plain hint: Build a compact central wall and open the bishop route if needed.

- Opening themes: Scheveningen structure, dark-square center, bishop route

### Packet sicilian-black.line-014.ply-06.c5d4

- Move: `cxd4` / `c5d4` at ply 6

- CoachCard: **Trade into the Open Sicilian imbalance** — cxd4 exchanges Black’s c-pawn for White’s d-pawn, the classic Open Sicilian imbalance. Black gives White central space but gains half-open c-file and queenside counterplay.

- Plain hint: Trade the c-pawn for White’s central pawn and create the typical Sicilian imbalance.

- Opening themes: c-pawn for d-pawn, half-open c-file, Open Sicilian

### Packet sicilian-black.line-014.ply-08.b8c6

- Move: `Nc6` / `b8c6` at ply 8

- CoachCard: **Develop into central pressure** — Nc6 develops the queenside knight toward the d4/e5 fight. In Sicilian structures it also supports queenside counterplay and increases pressure on White’s center.

- Plain hint: Develop the queenside knight to attack the center and support queenside counterplay.

- Opening themes: ...Nc6 pressure, d4 fight, queenside counterplay

### Packet sicilian-black.line-014.ply-10.g8f6

- Move: `Nf6` / `g8f6` at ply 10

- CoachCard: **Pressure White’s king pawn** — Nf6 develops with tempo against White’s e-pawn in many Sicilian lines. It also brings Black closer to castling while keeping the center under fire.

- Plain hint: Develop the kingside knight while pressuring White’s central pawn.

- Opening themes: ...Nf6 pressure, e4 target, king safety

### Packet sicilian-black.line-014.ply-12.b7c6

- Move: `bxc6` / `b7c6` at ply 12

- CoachCard: **Keep central control after the queenside trade** — bxc6 recaptures toward the center after White trades on c6. Black may accept doubled pawns, but keeps central presence and open lines for piece play.

- Plain hint: Accept doubled pawns to keep central control after White captures on the queenside.

- Opening themes: structural concession, central control, open lines


## sicilian-black-line-015: 1. e4 c5 2. Nf3 e6 3. d4 cxd4 4. Nxd4 Nc6 5. Nc3 a6 6. Be3 Qc7

Runtime playKey: `e2e4,c7c5,g1f3,e7e6,d2d4,c5d4,f3d4,b8c6,b1c3,a7a6,c1e3,d8c7`  
Runtime totalGames field at line node: `867437`

### Packet sicilian-black.line-015.ply-02.c7c5

- Move: `c5` / `c7c5` at ply 2

- CoachCard: **Start the Sicilian imbalance** — c5 is the Sicilian’s defining answer: Black contests the center with the c-pawn instead of mirroring the e-pawn. This creates the asymmetrical pawn structure the opening relies on.

- Plain hint: Answer the king pawn asymmetrically by using the c-pawn to contest the central dark squares.

- Opening themes: ...c5 challenge, Sicilian asymmetry, d4 control

### Packet sicilian-black.line-015.ply-04.e7e6

- Move: `e6` / `e7e6` at ply 4

- CoachCard: **Set a Scheveningen-style base** — e6 creates a Scheveningen-style dark-square structure with pawns on e6 and d6 when paired with ...d6. Black stays solid while preparing development and central counterplay.

- Plain hint: Build a compact central wall and open the bishop route if needed.

- Opening themes: Scheveningen structure, dark-square center, bishop route

### Packet sicilian-black.line-015.ply-06.c5d4

- Move: `cxd4` / `c5d4` at ply 6

- CoachCard: **Trade into the Open Sicilian imbalance** — cxd4 exchanges Black’s c-pawn for White’s d-pawn, the classic Open Sicilian imbalance. Black gives White central space but gains half-open c-file and queenside counterplay.

- Plain hint: Trade the c-pawn for White’s central pawn and create the typical Sicilian imbalance.

- Opening themes: c-pawn for d-pawn, half-open c-file, Open Sicilian

### Packet sicilian-black.line-015.ply-08.b8c6

- Move: `Nc6` / `b8c6` at ply 8

- CoachCard: **Develop into central pressure** — Nc6 develops the queenside knight toward the d4/e5 fight. In Sicilian structures it also supports queenside counterplay and increases pressure on White’s center.

- Plain hint: Develop the queenside knight to attack the center and support queenside counterplay.

- Opening themes: ...Nc6 pressure, d4 fight, queenside counterplay

### Packet sicilian-black.line-015.ply-10.a7a6

- Move: `a6` / `a7a6` at ply 10

- CoachCard: **Control b5 before queenside counterplay** — a6 controls b5 and prepares Najdorf-style queenside play. It keeps White’s pieces from using b5 while Black builds counterplay instead of grabbing pawns.

- Plain hint: Use the queenside rook-pawn to control the jump square and prepare Najdorf-style counterplay.

- Opening themes: Najdorf ...a6, b5 control, queenside counterplay

### Packet sicilian-black.line-015.ply-12.d8c7

- Move: `Qc7` / `d8c7` at ply 12

- CoachCard: **Keep Sicilian counterplay connected** — Qc7 stays tied to the Sicilian plan of asymmetrical center pressure and counterplay. Black’s move supports the structure created by ...c5 instead of drifting into passive symmetry.

- Plain hint: Keep the Sicilian imbalance: contest the center, develop quickly, and prepare queenside or central counterplay.

- Opening themes: Sicilian counterplay, asymmetry, center pressure


## sicilian-black-line-016: 1. e4 c5 2. Nf3 Nc6 3. d4 cxd4 4. Nxd4 e5 5. Nb5 a6 6. Nd6+ Bxd6

Runtime playKey: `e2e4,c7c5,g1f3,b8c6,d2d4,c5d4,f3d4,e7e5,d4b5,a7a6,b5d6,f8d6`  
Runtime totalGames field at line node: `851742`

### Packet sicilian-black.line-016.ply-02.c7c5

- Move: `c5` / `c7c5` at ply 2

- CoachCard: **Start the Sicilian imbalance** — c5 is the Sicilian’s defining answer: Black contests the center with the c-pawn instead of mirroring the e-pawn. This creates the asymmetrical pawn structure the opening relies on.

- Plain hint: Answer the king pawn asymmetrically by using the c-pawn to contest the central dark squares.

- Opening themes: ...c5 challenge, Sicilian asymmetry, d4 control

### Packet sicilian-black.line-016.ply-04.b8c6

- Move: `Nc6` / `b8c6` at ply 4

- CoachCard: **Develop into central pressure** — Nc6 develops the queenside knight toward the d4/e5 fight. In Sicilian structures it also supports queenside counterplay and increases pressure on White’s center.

- Plain hint: Develop the queenside knight to attack the center and support queenside counterplay.

- Opening themes: ...Nc6 pressure, d4 fight, queenside counterplay

### Packet sicilian-black.line-016.ply-06.c5d4

- Move: `cxd4` / `c5d4` at ply 6

- CoachCard: **Trade into the Open Sicilian imbalance** — cxd4 exchanges Black’s c-pawn for White’s d-pawn, the classic Open Sicilian imbalance. Black gives White central space but gains half-open c-file and queenside counterplay.

- Plain hint: Trade the c-pawn for White’s central pawn and create the typical Sicilian imbalance.

- Opening themes: c-pawn for d-pawn, half-open c-file, Open Sicilian

### Packet sicilian-black.line-016.ply-08.e7e5

- Move: `e5` / `e7e5` at ply 8

- CoachCard: **Gain Sveshnikov-style central space** — e5 grabs central space and often hits a white knight in Sveshnikov-type structures. Black accepts long-term square weaknesses in exchange for active central play.

- Plain hint: Gain central space and challenge White’s knight in a Sveshnikov-style structure.

- Opening themes: Sveshnikov space, central challenge, piece tempo

### Packet sicilian-black.line-016.ply-10.a7a6

- Move: `a6` / `a7a6` at ply 10

- CoachCard: **Control b5 before queenside counterplay** — a6 controls b5 and prepares Najdorf-style queenside play. It keeps White’s pieces from using b5 while Black builds counterplay instead of grabbing pawns.

- Plain hint: Use the queenside rook-pawn to control the jump square and prepare Najdorf-style counterplay.

- Opening themes: Najdorf ...a6, b5 control, queenside counterplay

### Packet sicilian-black.line-016.ply-12.f8d6

- Move: `Bxd6` / `f8d6` at ply 12

- CoachCard: **Keep Sicilian counterplay connected** — Bxd6 stays tied to the Sicilian plan of asymmetrical center pressure and counterplay. Black’s move supports the structure created by ...c5 instead of drifting into passive symmetry.

- Plain hint: Keep the Sicilian imbalance: contest the center, develop quickly, and prepare queenside or central counterplay.

- Opening themes: Sicilian counterplay, asymmetry, center pressure


## sicilian-black-line-017: 1. e4 c5 2. Nf3 e6 3. d4 cxd4 4. Nxd4 Nc6 5. Nc3 Nf6 6. Be3 Bb4

Runtime playKey: `e2e4,c7c5,g1f3,e7e6,d2d4,c5d4,f3d4,b8c6,b1c3,g8f6,c1e3,f8b4`  
Runtime totalGames field at line node: `797839`

### Packet sicilian-black.line-017.ply-02.c7c5

- Move: `c5` / `c7c5` at ply 2

- CoachCard: **Start the Sicilian imbalance** — c5 is the Sicilian’s defining answer: Black contests the center with the c-pawn instead of mirroring the e-pawn. This creates the asymmetrical pawn structure the opening relies on.

- Plain hint: Answer the king pawn asymmetrically by using the c-pawn to contest the central dark squares.

- Opening themes: ...c5 challenge, Sicilian asymmetry, d4 control

### Packet sicilian-black.line-017.ply-04.e7e6

- Move: `e6` / `e7e6` at ply 4

- CoachCard: **Set a Scheveningen-style base** — e6 creates a Scheveningen-style dark-square structure with pawns on e6 and d6 when paired with ...d6. Black stays solid while preparing development and central counterplay.

- Plain hint: Build a compact central wall and open the bishop route if needed.

- Opening themes: Scheveningen structure, dark-square center, bishop route

### Packet sicilian-black.line-017.ply-06.c5d4

- Move: `cxd4` / `c5d4` at ply 6

- CoachCard: **Trade into the Open Sicilian imbalance** — cxd4 exchanges Black’s c-pawn for White’s d-pawn, the classic Open Sicilian imbalance. Black gives White central space but gains half-open c-file and queenside counterplay.

- Plain hint: Trade the c-pawn for White’s central pawn and create the typical Sicilian imbalance.

- Opening themes: c-pawn for d-pawn, half-open c-file, Open Sicilian

### Packet sicilian-black.line-017.ply-08.b8c6

- Move: `Nc6` / `b8c6` at ply 8

- CoachCard: **Develop into central pressure** — Nc6 develops the queenside knight toward the d4/e5 fight. In Sicilian structures it also supports queenside counterplay and increases pressure on White’s center.

- Plain hint: Develop the queenside knight to attack the center and support queenside counterplay.

- Opening themes: ...Nc6 pressure, d4 fight, queenside counterplay

### Packet sicilian-black.line-017.ply-10.g8f6

- Move: `Nf6` / `g8f6` at ply 10

- CoachCard: **Pressure White’s king pawn** — Nf6 develops with tempo against White’s e-pawn in many Sicilian lines. It also brings Black closer to castling while keeping the center under fire.

- Plain hint: Develop the kingside knight while pressuring White’s central pawn.

- Opening themes: ...Nf6 pressure, e4 target, king safety

### Packet sicilian-black.line-017.ply-12.f8b4

- Move: `Bb4` / `f8b4` at ply 12

- CoachCard: **Keep Sicilian counterplay connected** — Bb4 stays tied to the Sicilian plan of asymmetrical center pressure and counterplay. Black’s move supports the structure created by ...c5 instead of drifting into passive symmetry.

- Plain hint: Keep the Sicilian imbalance: contest the center, develop quickly, and prepare queenside or central counterplay.

- Opening themes: Sicilian counterplay, asymmetry, center pressure


## sicilian-black-line-018: 1. e4 c5 2. Nf3 e6 3. c3 Nc6 4. d4 d5 5. e5 Qb6 6. Bd3 cxd4

Runtime playKey: `e2e4,c7c5,g1f3,e7e6,c2c3,b8c6,d2d4,d7d5,e4e5,d8b6,f1d3,c5d4`  
Runtime totalGames field at line node: `764828`

### Packet sicilian-black.line-018.ply-02.c7c5

- Move: `c5` / `c7c5` at ply 2

- CoachCard: **Start the Sicilian imbalance** — c5 is the Sicilian’s defining answer: Black contests the center with the c-pawn instead of mirroring the e-pawn. This creates the asymmetrical pawn structure the opening relies on.

- Plain hint: Answer the king pawn asymmetrically by using the c-pawn to contest the central dark squares.

- Opening themes: ...c5 challenge, Sicilian asymmetry, d4 control

### Packet sicilian-black.line-018.ply-04.e7e6

- Move: `e6` / `e7e6` at ply 4

- CoachCard: **Set a Scheveningen-style base** — e6 creates a Scheveningen-style dark-square structure with pawns on e6 and d6 when paired with ...d6. Black stays solid while preparing development and central counterplay.

- Plain hint: Build a compact central wall and open the bishop route if needed.

- Opening themes: Scheveningen structure, dark-square center, bishop route

### Packet sicilian-black.line-018.ply-06.b8c6

- Move: `Nc6` / `b8c6` at ply 6

- CoachCard: **Develop into central pressure** — Nc6 develops the queenside knight toward the d4/e5 fight. In Sicilian structures it also supports queenside counterplay and increases pressure on White’s center.

- Plain hint: Develop the queenside knight to attack the center and support queenside counterplay.

- Opening themes: ...Nc6 pressure, d4 fight, queenside counterplay

### Packet sicilian-black.line-018.ply-08.d7d5

- Move: `d5` / `d7d5` at ply 8

- CoachCard: **Use the Sicilian central counterbreak** — d5 is the thematic Sicilian central break. Black uses it to challenge White’s space before White can build a free attack.

- Plain hint: Break in the center when White’s setup gives Black a direct counterstrike.

- Opening themes: ...d5 break, central counterplay, space challenge

### Packet sicilian-black.line-018.ply-10.d8b6

- Move: `Qb6` / `d8b6` at ply 10

- CoachCard: **Keep Sicilian counterplay connected** — Qb6 stays tied to the Sicilian plan of asymmetrical center pressure and counterplay. Black’s move supports the structure created by ...c5 instead of drifting into passive symmetry.

- Plain hint: Keep the Sicilian imbalance: contest the center, develop quickly, and prepare queenside or central counterplay.

- Opening themes: Sicilian counterplay, asymmetry, center pressure

### Packet sicilian-black.line-018.ply-12.c5d4

- Move: `cxd4` / `c5d4` at ply 12

- CoachCard: **Trade into the Open Sicilian imbalance** — cxd4 exchanges Black’s c-pawn for White’s d-pawn, the classic Open Sicilian imbalance. Black gives White central space but gains half-open c-file and queenside counterplay.

- Plain hint: Trade the c-pawn for White’s central pawn and create the typical Sicilian imbalance.

- Opening themes: c-pawn for d-pawn, half-open c-file, Open Sicilian


## sicilian-black-line-019: 1. e4 c5 2. Nf3 Nc6 3. d4 cxd4 4. Nxd4 e5 5. Nxc6 bxc6 6. Bc4 Nf6

Runtime playKey: `e2e4,c7c5,g1f3,b8c6,d2d4,c5d4,f3d4,e7e5,d4c6,b7c6,f1c4,g8f6`  
Runtime totalGames field at line node: `752160`

### Packet sicilian-black.line-019.ply-02.c7c5

- Move: `c5` / `c7c5` at ply 2

- CoachCard: **Start the Sicilian imbalance** — c5 is the Sicilian’s defining answer: Black contests the center with the c-pawn instead of mirroring the e-pawn. This creates the asymmetrical pawn structure the opening relies on.

- Plain hint: Answer the king pawn asymmetrically by using the c-pawn to contest the central dark squares.

- Opening themes: ...c5 challenge, Sicilian asymmetry, d4 control

### Packet sicilian-black.line-019.ply-04.b8c6

- Move: `Nc6` / `b8c6` at ply 4

- CoachCard: **Develop into central pressure** — Nc6 develops the queenside knight toward the d4/e5 fight. In Sicilian structures it also supports queenside counterplay and increases pressure on White’s center.

- Plain hint: Develop the queenside knight to attack the center and support queenside counterplay.

- Opening themes: ...Nc6 pressure, d4 fight, queenside counterplay

### Packet sicilian-black.line-019.ply-06.c5d4

- Move: `cxd4` / `c5d4` at ply 6

- CoachCard: **Trade into the Open Sicilian imbalance** — cxd4 exchanges Black’s c-pawn for White’s d-pawn, the classic Open Sicilian imbalance. Black gives White central space but gains half-open c-file and queenside counterplay.

- Plain hint: Trade the c-pawn for White’s central pawn and create the typical Sicilian imbalance.

- Opening themes: c-pawn for d-pawn, half-open c-file, Open Sicilian

### Packet sicilian-black.line-019.ply-08.e7e5

- Move: `e5` / `e7e5` at ply 8

- CoachCard: **Gain Sveshnikov-style central space** — e5 grabs central space and often hits a white knight in Sveshnikov-type structures. Black accepts long-term square weaknesses in exchange for active central play.

- Plain hint: Gain central space and challenge White’s knight in a Sveshnikov-style structure.

- Opening themes: Sveshnikov space, central challenge, piece tempo

### Packet sicilian-black.line-019.ply-10.b7c6

- Move: `bxc6` / `b7c6` at ply 10

- CoachCard: **Keep central control after the queenside trade** — bxc6 recaptures toward the center after White trades on c6. Black may accept doubled pawns, but keeps central presence and open lines for piece play.

- Plain hint: Accept doubled pawns to keep central control after White captures on the queenside.

- Opening themes: structural concession, central control, open lines

### Packet sicilian-black.line-019.ply-12.g8f6

- Move: `Nf6` / `g8f6` at ply 12

- CoachCard: **Pressure White’s king pawn** — Nf6 develops with tempo against White’s e-pawn in many Sicilian lines. It also brings Black closer to castling while keeping the center under fire.

- Plain hint: Develop the kingside knight while pressuring White’s central pawn.

- Opening themes: ...Nf6 pressure, e4 target, king safety


## sicilian-black-line-020: 1. e4 c5 2. Nf3 d6 3. d4 cxd4 4. Nxd4 Nc6 5. Nxc6 bxc6 6. Nc3 Nf6

Runtime playKey: `e2e4,c7c5,g1f3,d7d6,d2d4,c5d4,f3d4,b8c6,d4c6,b7c6,b1c3,g8f6`  
Runtime totalGames field at line node: `703421`

### Packet sicilian-black.line-020.ply-02.c7c5

- Move: `c5` / `c7c5` at ply 2

- CoachCard: **Start the Sicilian imbalance** — c5 is the Sicilian’s defining answer: Black contests the center with the c-pawn instead of mirroring the e-pawn. This creates the asymmetrical pawn structure the opening relies on.

- Plain hint: Answer the king pawn asymmetrically by using the c-pawn to contest the central dark squares.

- Opening themes: ...c5 challenge, Sicilian asymmetry, d4 control

### Packet sicilian-black.line-020.ply-04.d7d6

- Move: `d6` / `d7d6` at ply 4

- CoachCard: **Build the flexible Sicilian center** — d6 supports the e5 square and prepares a flexible Open Sicilian structure. Black keeps options for ...Nf6, ...a6, ...e6, or ...g6 depending on White’s setup.

- Plain hint: Support the center and prepare flexible Sicilian development without weakening the king.

- Opening themes: ...d6 structure, Open Sicilian, flexible development

### Packet sicilian-black.line-020.ply-06.c5d4

- Move: `cxd4` / `c5d4` at ply 6

- CoachCard: **Trade into the Open Sicilian imbalance** — cxd4 exchanges Black’s c-pawn for White’s d-pawn, the classic Open Sicilian imbalance. Black gives White central space but gains half-open c-file and queenside counterplay.

- Plain hint: Trade the c-pawn for White’s central pawn and create the typical Sicilian imbalance.

- Opening themes: c-pawn for d-pawn, half-open c-file, Open Sicilian

### Packet sicilian-black.line-020.ply-08.b8c6

- Move: `Nc6` / `b8c6` at ply 8

- CoachCard: **Develop into central pressure** — Nc6 develops the queenside knight toward the d4/e5 fight. In Sicilian structures it also supports queenside counterplay and increases pressure on White’s center.

- Plain hint: Develop the queenside knight to attack the center and support queenside counterplay.

- Opening themes: ...Nc6 pressure, d4 fight, queenside counterplay

### Packet sicilian-black.line-020.ply-10.b7c6

- Move: `bxc6` / `b7c6` at ply 10

- CoachCard: **Keep central control after the queenside trade** — bxc6 recaptures toward the center after White trades on c6. Black may accept doubled pawns, but keeps central presence and open lines for piece play.

- Plain hint: Accept doubled pawns to keep central control after White captures on the queenside.

- Opening themes: structural concession, central control, open lines

### Packet sicilian-black.line-020.ply-12.g8f6

- Move: `Nf6` / `g8f6` at ply 12

- CoachCard: **Pressure White’s king pawn** — Nf6 develops with tempo against White’s e-pawn in many Sicilian lines. It also brings Black closer to castling while keeping the center under fire.

- Plain hint: Develop the kingside knight while pressuring White’s central pawn.

- Opening themes: ...Nf6 pressure, e4 target, king safety
