# Caro-Kann Defense approved-content candidates

Opening ID: `caro-kann-black`  
Status: approved candidates only; not app-activated.


## caro-kann-black-line-001: 1. e4 c6 2. d4 d5 3. Nc3 dxe4 4. Nxe4 Nf6 5. Nxf6+ exf6 6. Nf3 Bd6

Runtime playKey: `e2e4,c7c6,d2d4,d7d5,b1c3,d5e4,c3e4,g8f6,e4f6,e7f6,g1f3,f8d6`  
Runtime totalGames field at line node: `1246169`

### Packet caro-kann-black.line-001.ply-02.c7c6

- Move: `c6` / `c7c6` at ply 2

- CoachCard: **Prepare the Caro-Kann center** — c6 is the Caro-Kann foundation: Black supports ...d5 before challenging White’s e-pawn. The structure stays solid without weakening the kingside.

- Plain hint: Prepare the queen-pawn challenge while keeping the kingside pawn shield intact.

- Opening themes: ...c6 foundation, ...d5 preparation, solid structure

### Packet caro-kann-black.line-001.ply-04.d7d5

- Move: `d5` / `d7d5` at ply 4

- CoachCard: **Challenge e4 from a solid base** — d5 executes the Caro-Kann plan by challenging White’s e-pawn after ...c6. Black fights the center without loosening the king.

- Plain hint: Challenge White’s king pawn from a solid Caro-Kann base.

- Opening themes: ...d5 challenge, e4 pressure, Caro-Kann solidity

### Packet caro-kann-black.line-001.ply-06.d5e4

- Move: `dxe4` / `d5e4` at ply 6

- CoachCard: **Clarify the Caro-Kann center** — dxe4 releases the d-pawn tension and asks White to spend time recapturing or restoring the center. This is a common Caro-Kann way to reduce White’s space.

- Plain hint: Clarify the center and make White spend a tempo restoring the king pawn.

- Opening themes: central clarification, e4 challenge, tempo on center

### Packet caro-kann-black.line-001.ply-08.g8f6

- Move: `Nf6` / `g8f6` at ply 8

- CoachCard: **Challenge White’s central control** — Nf6 develops the knight toward e4 and d5 pressure. In Caro-Kann structures, Black uses solid pawns plus active pieces to question White’s center.

- Plain hint: Develop the kingside knight to challenge White’s central control.

- Opening themes: ...Nf6 pressure, central control, solid development

### Packet caro-kann-black.line-001.ply-10.e7f6

- Move: `exf6` / `e7f6` at ply 10

- CoachCard: **Preserve Caro-Kann solidity** — exf6 keeps Black connected to Caro-Kann priorities: a solid ...c6/...d5 center, active minor pieces, and timely pressure against White’s pawn structure.

- Plain hint: Use the Caro-Kann plan: solid center first, active light-square bishop when possible, and timely pressure against White’s pawns.

- Opening themes: Caro-Kann structure, piece activity, pawn pressure

### Packet caro-kann-black.line-001.ply-12.f8d6

- Move: `Bd6` / `f8d6` at ply 12

- CoachCard: **Activate the bishop after the center settles** — Bd6 develops the bishop to a useful diagonal after Black’s Caro-Kann center is established. It supports kingside coordination without abandoning central solidity.

- Plain hint: Place the bishop on an active diagonal once the central structure is stable.

- Opening themes: bishop activity, solid center, kingside coordination


## caro-kann-black-line-002: 1. e4 c6 2. d4 d5 3. Nc3 dxe4 4. Nxe4 Bf5 5. Ng3 Bg6 6. h4 h6

Runtime playKey: `e2e4,c7c6,d2d4,d7d5,b1c3,d5e4,c3e4,c8f5,e4g3,f5g6,h2h4,h7h6`  
Runtime totalGames field at line node: `1240184`

### Packet caro-kann-black.line-002.ply-02.c7c6

- Move: `c6` / `c7c6` at ply 2

- CoachCard: **Prepare the Caro-Kann center** — c6 is the Caro-Kann foundation: Black supports ...d5 before challenging White’s e-pawn. The structure stays solid without weakening the kingside.

- Plain hint: Prepare the queen-pawn challenge while keeping the kingside pawn shield intact.

- Opening themes: ...c6 foundation, ...d5 preparation, solid structure

### Packet caro-kann-black.line-002.ply-04.d7d5

- Move: `d5` / `d7d5` at ply 4

- CoachCard: **Challenge e4 from a solid base** — d5 executes the Caro-Kann plan by challenging White’s e-pawn after ...c6. Black fights the center without loosening the king.

- Plain hint: Challenge White’s king pawn from a solid Caro-Kann base.

- Opening themes: ...d5 challenge, e4 pressure, Caro-Kann solidity

### Packet caro-kann-black.line-002.ply-06.d5e4

- Move: `dxe4` / `d5e4` at ply 6

- CoachCard: **Clarify the Caro-Kann center** — dxe4 releases the d-pawn tension and asks White to spend time recapturing or restoring the center. This is a common Caro-Kann way to reduce White’s space.

- Plain hint: Clarify the center and make White spend a tempo restoring the king pawn.

- Opening themes: central clarification, e4 challenge, tempo on center

### Packet caro-kann-black.line-002.ply-08.c8f5

- Move: `Bf5` / `c8f5` at ply 8

- CoachCard: **Free the light-square bishop early** — Bf5 solves a major Caro-Kann issue by developing the light-square bishop before ...e6 shuts it in. The bishop stays active while Black keeps a solid center.

- Plain hint: Develop the light-square bishop outside the pawn chain before it can be boxed in.

- Opening themes: light-square bishop, outside pawn chain, Caro-Kann development

### Packet caro-kann-black.line-002.ply-10.f5g6

- Move: `Bg6` / `f5g6` at ply 10

- CoachCard: **Preserve Caro-Kann solidity** — Bg6 keeps Black connected to Caro-Kann priorities: a solid ...c6/...d5 center, active minor pieces, and timely pressure against White’s pawn structure.

- Plain hint: Use the Caro-Kann plan: solid center first, active light-square bishop when possible, and timely pressure against White’s pawns.

- Opening themes: Caro-Kann structure, piece activity, pawn pressure

### Packet caro-kann-black.line-002.ply-12.h7h6

- Move: `h6` / `h7h6` at ply 12

- CoachCard: **Question White’s advanced piece** — h6 asks White’s advanced piece to decide, giving Black breathing room in a compact Caro-Kann structure. The move is useful when it supports bishop or kingside coordination.

- Plain hint: Question White’s advanced piece and keep the Caro-Kann setup from being pinned down.

- Opening themes: tempo on piece, king-side space, Caro-Kann coordination


## caro-kann-black-line-003: 1. e4 c6 2. d4 d5 3. exd5 cxd5 4. Bd3 Nf6 5. c3 Bg4 6. Nf3 Nc6

Runtime playKey: `e2e4,c7c6,d2d4,d7d5,e4d5,c6d5,f1d3,g8f6,c2c3,c8g4,g1f3,b8c6`  
Runtime totalGames field at line node: `1183414`

### Packet caro-kann-black.line-003.ply-02.c7c6

- Move: `c6` / `c7c6` at ply 2

- CoachCard: **Prepare the Caro-Kann center** — c6 is the Caro-Kann foundation: Black supports ...d5 before challenging White’s e-pawn. The structure stays solid without weakening the kingside.

- Plain hint: Prepare the queen-pawn challenge while keeping the kingside pawn shield intact.

- Opening themes: ...c6 foundation, ...d5 preparation, solid structure

### Packet caro-kann-black.line-003.ply-04.d7d5

- Move: `d5` / `d7d5` at ply 4

- CoachCard: **Challenge e4 from a solid base** — d5 executes the Caro-Kann plan by challenging White’s e-pawn after ...c6. Black fights the center without loosening the king.

- Plain hint: Challenge White’s king pawn from a solid Caro-Kann base.

- Opening themes: ...d5 challenge, e4 pressure, Caro-Kann solidity

### Packet caro-kann-black.line-003.ply-06.c6d5

- Move: `cxd5` / `c6d5` at ply 6

- CoachCard: **Keep the compact Caro-Kann structure** — cxd5 recaptures toward the center and keeps Black’s pawn structure compact. In Exchange structures, Black’s goal is solidity plus active minor-piece play.

- Plain hint: Recapture toward the center to keep the Caro-Kann structure compact.

- Opening themes: Exchange structure, compact center, solid recapture

### Packet caro-kann-black.line-003.ply-08.g8f6

- Move: `Nf6` / `g8f6` at ply 8

- CoachCard: **Challenge White’s central control** — Nf6 develops the knight toward e4 and d5 pressure. In Caro-Kann structures, Black uses solid pawns plus active pieces to question White’s center.

- Plain hint: Develop the kingside knight to challenge White’s central control.

- Opening themes: ...Nf6 pressure, central control, solid development

### Packet caro-kann-black.line-003.ply-10.c8g4

- Move: `Bg4` / `c8g4` at ply 10

- CoachCard: **Use the bishop actively before the structure locks** — Bg4 develops the light-square bishop actively, often pinning or pressuring a knight that helps White’s center. It addresses the Caro-Kann bishop issue before the position closes.

- Plain hint: Use the light-square bishop actively before settling the central pawn structure.

- Opening themes: active bishop, pin pressure, Caro-Kann bishop issue

### Packet caro-kann-black.line-003.ply-12.b8c6

- Move: `Nc6` / `b8c6` at ply 12

- CoachCard: **Increase pressure on White’s pawn structure** — Nc6 develops toward central pressure in a Caro-Kann structure. It helps Black challenge White’s pawns rather than remaining purely defensive.

- Plain hint: Develop toward the center and increase pressure on White’s pawn structure.

- Opening themes: central pressure, knight development, pawn structure


## caro-kann-black-line-004: 1. e4 c6 2. d4 d5 3. e5 Bf5 4. Bd3 Bxd3 5. Qxd3 e6 6. Nf3 c5

Runtime playKey: `e2e4,c7c6,d2d4,d7d5,e4e5,c8f5,f1d3,f5d3,d1d3,e7e6,g1f3,c6c5`  
Runtime totalGames field at line node: `1134061`

### Packet caro-kann-black.line-004.ply-02.c7c6

- Move: `c6` / `c7c6` at ply 2

- CoachCard: **Prepare the Caro-Kann center** — c6 is the Caro-Kann foundation: Black supports ...d5 before challenging White’s e-pawn. The structure stays solid without weakening the kingside.

- Plain hint: Prepare the queen-pawn challenge while keeping the kingside pawn shield intact.

- Opening themes: ...c6 foundation, ...d5 preparation, solid structure

### Packet caro-kann-black.line-004.ply-04.d7d5

- Move: `d5` / `d7d5` at ply 4

- CoachCard: **Challenge e4 from a solid base** — d5 executes the Caro-Kann plan by challenging White’s e-pawn after ...c6. Black fights the center without loosening the king.

- Plain hint: Challenge White’s king pawn from a solid Caro-Kann base.

- Opening themes: ...d5 challenge, e4 pressure, Caro-Kann solidity

### Packet caro-kann-black.line-004.ply-06.c8f5

- Move: `Bf5` / `c8f5` at ply 6

- CoachCard: **Free the light-square bishop early** — Bf5 solves a major Caro-Kann issue by developing the light-square bishop before ...e6 shuts it in. The bishop stays active while Black keeps a solid center.

- Plain hint: Develop the light-square bishop outside the pawn chain before it can be boxed in.

- Opening themes: light-square bishop, outside pawn chain, Caro-Kann development

### Packet caro-kann-black.line-004.ply-08.f5d3

- Move: `Bxd3` / `f5d3` at ply 8

- CoachCard: **Preserve Caro-Kann solidity** — Bxd3 keeps Black connected to Caro-Kann priorities: a solid ...c6/...d5 center, active minor pieces, and timely pressure against White’s pawn structure.

- Plain hint: Use the Caro-Kann plan: solid center first, active light-square bishop when possible, and timely pressure against White’s pawns.

- Opening themes: Caro-Kann structure, piece activity, pawn pressure

### Packet caro-kann-black.line-004.ply-10.e7e6

- Move: `e6` / `e7e6` at ply 10

- CoachCard: **Lock in the solid Caro-Kann center** — e6 supports the central dark squares and completes a solid Caro-Kann shell. It is especially comfortable after the light-square bishop has already reached an active square.

- Plain hint: Support the dark-square center after the light-square bishop has found activity.

- Opening themes: solid center, bishop timing, dark-square support

### Packet caro-kann-black.line-004.ply-12.c6c5

- Move: `c5` / `c6c5` at ply 12

- CoachCard: **Strike at the Caro-Kann pawn chain** — c5 is a standard Caro-Kann counterbreak against White’s advanced center. Black attacks the pawn chain from the side instead of passively defending space.

- Plain hint: Strike at White’s pawn chain from the side, a standard Caro-Kann counterbreak.

- Opening themes: ...c5 counterbreak, Advance structure, pawn-chain pressure


## caro-kann-black-line-005: 1. e4 c6 2. d4 d5 3. Nc3 dxe4 4. Nxe4 Bf5 5. Ng3 Bg6 6. Nf3 Nd7

Runtime playKey: `e2e4,c7c6,d2d4,d7d5,b1c3,d5e4,c3e4,c8f5,e4g3,f5g6,g1f3,b8d7`  
Runtime totalGames field at line node: `1017831`

### Packet caro-kann-black.line-005.ply-02.c7c6

- Move: `c6` / `c7c6` at ply 2

- CoachCard: **Prepare the Caro-Kann center** — c6 is the Caro-Kann foundation: Black supports ...d5 before challenging White’s e-pawn. The structure stays solid without weakening the kingside.

- Plain hint: Prepare the queen-pawn challenge while keeping the kingside pawn shield intact.

- Opening themes: ...c6 foundation, ...d5 preparation, solid structure

### Packet caro-kann-black.line-005.ply-04.d7d5

- Move: `d5` / `d7d5` at ply 4

- CoachCard: **Challenge e4 from a solid base** — d5 executes the Caro-Kann plan by challenging White’s e-pawn after ...c6. Black fights the center without loosening the king.

- Plain hint: Challenge White’s king pawn from a solid Caro-Kann base.

- Opening themes: ...d5 challenge, e4 pressure, Caro-Kann solidity

### Packet caro-kann-black.line-005.ply-06.d5e4

- Move: `dxe4` / `d5e4` at ply 6

- CoachCard: **Clarify the Caro-Kann center** — dxe4 releases the d-pawn tension and asks White to spend time recapturing or restoring the center. This is a common Caro-Kann way to reduce White’s space.

- Plain hint: Clarify the center and make White spend a tempo restoring the king pawn.

- Opening themes: central clarification, e4 challenge, tempo on center

### Packet caro-kann-black.line-005.ply-08.c8f5

- Move: `Bf5` / `c8f5` at ply 8

- CoachCard: **Free the light-square bishop early** — Bf5 solves a major Caro-Kann issue by developing the light-square bishop before ...e6 shuts it in. The bishop stays active while Black keeps a solid center.

- Plain hint: Develop the light-square bishop outside the pawn chain before it can be boxed in.

- Opening themes: light-square bishop, outside pawn chain, Caro-Kann development

### Packet caro-kann-black.line-005.ply-10.f5g6

- Move: `Bg6` / `f5g6` at ply 10

- CoachCard: **Preserve Caro-Kann solidity** — Bg6 keeps Black connected to Caro-Kann priorities: a solid ...c6/...d5 center, active minor pieces, and timely pressure against White’s pawn structure.

- Plain hint: Use the Caro-Kann plan: solid center first, active light-square bishop when possible, and timely pressure against White’s pawns.

- Opening themes: Caro-Kann structure, piece activity, pawn pressure

### Packet caro-kann-black.line-005.ply-12.b8d7

- Move: `Nd7` / `b8d7` at ply 12

- CoachCard: **Add a solid central defender** — Nd7 develops a knight without weakening the Caro-Kann pawn shell. It reinforces central squares and keeps Black ready to challenge White’s setup.

- Plain hint: Add a defender to the center while keeping the structure solid.

- Opening themes: solid knight route, central support, Caro-Kann structure


## caro-kann-black-line-006: 1. e4 c6 2. d4 d5 3. exd5 cxd5 4. Nf3 Nc6 5. Nc3 Bg4 6. Bb5 Nf6

Runtime playKey: `e2e4,c7c6,d2d4,d7d5,e4d5,c6d5,g1f3,b8c6,b1c3,c8g4,f1b5,g8f6`  
Runtime totalGames field at line node: `829925`

### Packet caro-kann-black.line-006.ply-02.c7c6

- Move: `c6` / `c7c6` at ply 2

- CoachCard: **Prepare the Caro-Kann center** — c6 is the Caro-Kann foundation: Black supports ...d5 before challenging White’s e-pawn. The structure stays solid without weakening the kingside.

- Plain hint: Prepare the queen-pawn challenge while keeping the kingside pawn shield intact.

- Opening themes: ...c6 foundation, ...d5 preparation, solid structure

### Packet caro-kann-black.line-006.ply-04.d7d5

- Move: `d5` / `d7d5` at ply 4

- CoachCard: **Challenge e4 from a solid base** — d5 executes the Caro-Kann plan by challenging White’s e-pawn after ...c6. Black fights the center without loosening the king.

- Plain hint: Challenge White’s king pawn from a solid Caro-Kann base.

- Opening themes: ...d5 challenge, e4 pressure, Caro-Kann solidity

### Packet caro-kann-black.line-006.ply-06.c6d5

- Move: `cxd5` / `c6d5` at ply 6

- CoachCard: **Keep the compact Caro-Kann structure** — cxd5 recaptures toward the center and keeps Black’s pawn structure compact. In Exchange structures, Black’s goal is solidity plus active minor-piece play.

- Plain hint: Recapture toward the center to keep the Caro-Kann structure compact.

- Opening themes: Exchange structure, compact center, solid recapture

### Packet caro-kann-black.line-006.ply-08.b8c6

- Move: `Nc6` / `b8c6` at ply 8

- CoachCard: **Increase pressure on White’s pawn structure** — Nc6 develops toward central pressure in a Caro-Kann structure. It helps Black challenge White’s pawns rather than remaining purely defensive.

- Plain hint: Develop toward the center and increase pressure on White’s pawn structure.

- Opening themes: central pressure, knight development, pawn structure

### Packet caro-kann-black.line-006.ply-10.c8g4

- Move: `Bg4` / `c8g4` at ply 10

- CoachCard: **Use the bishop actively before the structure locks** — Bg4 develops the light-square bishop actively, often pinning or pressuring a knight that helps White’s center. It addresses the Caro-Kann bishop issue before the position closes.

- Plain hint: Use the light-square bishop actively before settling the central pawn structure.

- Opening themes: active bishop, pin pressure, Caro-Kann bishop issue

### Packet caro-kann-black.line-006.ply-12.g8f6

- Move: `Nf6` / `g8f6` at ply 12

- CoachCard: **Challenge White’s central control** — Nf6 develops the knight toward e4 and d5 pressure. In Caro-Kann structures, Black uses solid pawns plus active pieces to question White’s center.

- Plain hint: Develop the kingside knight to challenge White’s central control.

- Opening themes: ...Nf6 pressure, central control, solid development


## caro-kann-black-line-007: 1. e4 c6 2. Nf3 d5 3. e5 Bg4 4. d4 c5 5. c3 e6 6. Be2 Nc6

Runtime playKey: `e2e4,c7c6,g1f3,d7d5,e4e5,c8g4,d2d4,c6c5,c2c3,e7e6,f1e2,b8c6`  
Runtime totalGames field at line node: `822368`

### Packet caro-kann-black.line-007.ply-02.c7c6

- Move: `c6` / `c7c6` at ply 2

- CoachCard: **Prepare the Caro-Kann center** — c6 is the Caro-Kann foundation: Black supports ...d5 before challenging White’s e-pawn. The structure stays solid without weakening the kingside.

- Plain hint: Prepare the queen-pawn challenge while keeping the kingside pawn shield intact.

- Opening themes: ...c6 foundation, ...d5 preparation, solid structure

### Packet caro-kann-black.line-007.ply-04.d7d5

- Move: `d5` / `d7d5` at ply 4

- CoachCard: **Challenge e4 from a solid base** — d5 executes the Caro-Kann plan by challenging White’s e-pawn after ...c6. Black fights the center without loosening the king.

- Plain hint: Challenge White’s king pawn from a solid Caro-Kann base.

- Opening themes: ...d5 challenge, e4 pressure, Caro-Kann solidity

### Packet caro-kann-black.line-007.ply-06.c8g4

- Move: `Bg4` / `c8g4` at ply 6

- CoachCard: **Use the bishop actively before the structure locks** — Bg4 develops the light-square bishop actively, often pinning or pressuring a knight that helps White’s center. It addresses the Caro-Kann bishop issue before the position closes.

- Plain hint: Use the light-square bishop actively before settling the central pawn structure.

- Opening themes: active bishop, pin pressure, Caro-Kann bishop issue

### Packet caro-kann-black.line-007.ply-08.c6c5

- Move: `c5` / `c6c5` at ply 8

- CoachCard: **Strike at the Caro-Kann pawn chain** — c5 is a standard Caro-Kann counterbreak against White’s advanced center. Black attacks the pawn chain from the side instead of passively defending space.

- Plain hint: Strike at White’s pawn chain from the side, a standard Caro-Kann counterbreak.

- Opening themes: ...c5 counterbreak, Advance structure, pawn-chain pressure

### Packet caro-kann-black.line-007.ply-10.e7e6

- Move: `e6` / `e7e6` at ply 10

- CoachCard: **Lock in the solid Caro-Kann center** — e6 supports the central dark squares and completes a solid Caro-Kann shell. It is especially comfortable after the light-square bishop has already reached an active square.

- Plain hint: Support the dark-square center after the light-square bishop has found activity.

- Opening themes: solid center, bishop timing, dark-square support

### Packet caro-kann-black.line-007.ply-12.b8c6

- Move: `Nc6` / `b8c6` at ply 12

- CoachCard: **Increase pressure on White’s pawn structure** — Nc6 develops toward central pressure in a Caro-Kann structure. It helps Black challenge White’s pawns rather than remaining purely defensive.

- Plain hint: Develop toward the center and increase pressure on White’s pawn structure.

- Opening themes: central pressure, knight development, pawn structure


## caro-kann-black-line-008: 1. e4 c6 2. Nf3 d5 3. Nc3 Bg4 4. exd5 cxd5 5. d4 Nc6 6. Be2 e6

Runtime playKey: `e2e4,c7c6,g1f3,d7d5,b1c3,c8g4,e4d5,c6d5,d2d4,b8c6,f1e2,e7e6`  
Runtime totalGames field at line node: `755405`

### Packet caro-kann-black.line-008.ply-02.c7c6

- Move: `c6` / `c7c6` at ply 2

- CoachCard: **Prepare the Caro-Kann center** — c6 is the Caro-Kann foundation: Black supports ...d5 before challenging White’s e-pawn. The structure stays solid without weakening the kingside.

- Plain hint: Prepare the queen-pawn challenge while keeping the kingside pawn shield intact.

- Opening themes: ...c6 foundation, ...d5 preparation, solid structure

### Packet caro-kann-black.line-008.ply-04.d7d5

- Move: `d5` / `d7d5` at ply 4

- CoachCard: **Challenge e4 from a solid base** — d5 executes the Caro-Kann plan by challenging White’s e-pawn after ...c6. Black fights the center without loosening the king.

- Plain hint: Challenge White’s king pawn from a solid Caro-Kann base.

- Opening themes: ...d5 challenge, e4 pressure, Caro-Kann solidity

### Packet caro-kann-black.line-008.ply-06.c8g4

- Move: `Bg4` / `c8g4` at ply 6

- CoachCard: **Use the bishop actively before the structure locks** — Bg4 develops the light-square bishop actively, often pinning or pressuring a knight that helps White’s center. It addresses the Caro-Kann bishop issue before the position closes.

- Plain hint: Use the light-square bishop actively before settling the central pawn structure.

- Opening themes: active bishop, pin pressure, Caro-Kann bishop issue

### Packet caro-kann-black.line-008.ply-08.c6d5

- Move: `cxd5` / `c6d5` at ply 8

- CoachCard: **Keep the compact Caro-Kann structure** — cxd5 recaptures toward the center and keeps Black’s pawn structure compact. In Exchange structures, Black’s goal is solidity plus active minor-piece play.

- Plain hint: Recapture toward the center to keep the Caro-Kann structure compact.

- Opening themes: Exchange structure, compact center, solid recapture

### Packet caro-kann-black.line-008.ply-10.b8c6

- Move: `Nc6` / `b8c6` at ply 10

- CoachCard: **Increase pressure on White’s pawn structure** — Nc6 develops toward central pressure in a Caro-Kann structure. It helps Black challenge White’s pawns rather than remaining purely defensive.

- Plain hint: Develop toward the center and increase pressure on White’s pawn structure.

- Opening themes: central pressure, knight development, pawn structure

### Packet caro-kann-black.line-008.ply-12.e7e6

- Move: `e6` / `e7e6` at ply 12

- CoachCard: **Lock in the solid Caro-Kann center** — e6 supports the central dark squares and completes a solid Caro-Kann shell. It is especially comfortable after the light-square bishop has already reached an active square.

- Plain hint: Support the dark-square center after the light-square bishop has found activity.

- Opening themes: solid center, bishop timing, dark-square support


## caro-kann-black-line-009: 1. e4 c6 2. d4 d5 3. Nc3 dxe4 4. Nxe4 Nf6 5. Nxf6+ exf6 6. c3 Bd6

Runtime playKey: `e2e4,c7c6,d2d4,d7d5,b1c3,d5e4,c3e4,g8f6,e4f6,e7f6,c2c3,f8d6`  
Runtime totalGames field at line node: `709344`

### Packet caro-kann-black.line-009.ply-02.c7c6

- Move: `c6` / `c7c6` at ply 2

- CoachCard: **Prepare the Caro-Kann center** — c6 is the Caro-Kann foundation: Black supports ...d5 before challenging White’s e-pawn. The structure stays solid without weakening the kingside.

- Plain hint: Prepare the queen-pawn challenge while keeping the kingside pawn shield intact.

- Opening themes: ...c6 foundation, ...d5 preparation, solid structure

### Packet caro-kann-black.line-009.ply-04.d7d5

- Move: `d5` / `d7d5` at ply 4

- CoachCard: **Challenge e4 from a solid base** — d5 executes the Caro-Kann plan by challenging White’s e-pawn after ...c6. Black fights the center without loosening the king.

- Plain hint: Challenge White’s king pawn from a solid Caro-Kann base.

- Opening themes: ...d5 challenge, e4 pressure, Caro-Kann solidity

### Packet caro-kann-black.line-009.ply-06.d5e4

- Move: `dxe4` / `d5e4` at ply 6

- CoachCard: **Clarify the Caro-Kann center** — dxe4 releases the d-pawn tension and asks White to spend time recapturing or restoring the center. This is a common Caro-Kann way to reduce White’s space.

- Plain hint: Clarify the center and make White spend a tempo restoring the king pawn.

- Opening themes: central clarification, e4 challenge, tempo on center

### Packet caro-kann-black.line-009.ply-08.g8f6

- Move: `Nf6` / `g8f6` at ply 8

- CoachCard: **Challenge White’s central control** — Nf6 develops the knight toward e4 and d5 pressure. In Caro-Kann structures, Black uses solid pawns plus active pieces to question White’s center.

- Plain hint: Develop the kingside knight to challenge White’s central control.

- Opening themes: ...Nf6 pressure, central control, solid development

### Packet caro-kann-black.line-009.ply-10.e7f6

- Move: `exf6` / `e7f6` at ply 10

- CoachCard: **Preserve Caro-Kann solidity** — exf6 keeps Black connected to Caro-Kann priorities: a solid ...c6/...d5 center, active minor pieces, and timely pressure against White’s pawn structure.

- Plain hint: Use the Caro-Kann plan: solid center first, active light-square bishop when possible, and timely pressure against White’s pawns.

- Opening themes: Caro-Kann structure, piece activity, pawn pressure

### Packet caro-kann-black.line-009.ply-12.f8d6

- Move: `Bd6` / `f8d6` at ply 12

- CoachCard: **Activate the bishop after the center settles** — Bd6 develops the bishop to a useful diagonal after Black’s Caro-Kann center is established. It supports kingside coordination without abandoning central solidity.

- Plain hint: Place the bishop on an active diagonal once the central structure is stable.

- Opening themes: bishop activity, solid center, kingside coordination


## caro-kann-black-line-010: 1. e4 c6 2. d4 d5 3. e5 Bf5 4. Bd3 Bxd3 5. Qxd3 e6 6. Nf3 Nd7

Runtime playKey: `e2e4,c7c6,d2d4,d7d5,e4e5,c8f5,f1d3,f5d3,d1d3,e7e6,g1f3,b8d7`  
Runtime totalGames field at line node: `680778`

### Packet caro-kann-black.line-010.ply-02.c7c6

- Move: `c6` / `c7c6` at ply 2

- CoachCard: **Prepare the Caro-Kann center** — c6 is the Caro-Kann foundation: Black supports ...d5 before challenging White’s e-pawn. The structure stays solid without weakening the kingside.

- Plain hint: Prepare the queen-pawn challenge while keeping the kingside pawn shield intact.

- Opening themes: ...c6 foundation, ...d5 preparation, solid structure

### Packet caro-kann-black.line-010.ply-04.d7d5

- Move: `d5` / `d7d5` at ply 4

- CoachCard: **Challenge e4 from a solid base** — d5 executes the Caro-Kann plan by challenging White’s e-pawn after ...c6. Black fights the center without loosening the king.

- Plain hint: Challenge White’s king pawn from a solid Caro-Kann base.

- Opening themes: ...d5 challenge, e4 pressure, Caro-Kann solidity

### Packet caro-kann-black.line-010.ply-06.c8f5

- Move: `Bf5` / `c8f5` at ply 6

- CoachCard: **Free the light-square bishop early** — Bf5 solves a major Caro-Kann issue by developing the light-square bishop before ...e6 shuts it in. The bishop stays active while Black keeps a solid center.

- Plain hint: Develop the light-square bishop outside the pawn chain before it can be boxed in.

- Opening themes: light-square bishop, outside pawn chain, Caro-Kann development

### Packet caro-kann-black.line-010.ply-08.f5d3

- Move: `Bxd3` / `f5d3` at ply 8

- CoachCard: **Preserve Caro-Kann solidity** — Bxd3 keeps Black connected to Caro-Kann priorities: a solid ...c6/...d5 center, active minor pieces, and timely pressure against White’s pawn structure.

- Plain hint: Use the Caro-Kann plan: solid center first, active light-square bishop when possible, and timely pressure against White’s pawns.

- Opening themes: Caro-Kann structure, piece activity, pawn pressure

### Packet caro-kann-black.line-010.ply-10.e7e6

- Move: `e6` / `e7e6` at ply 10

- CoachCard: **Lock in the solid Caro-Kann center** — e6 supports the central dark squares and completes a solid Caro-Kann shell. It is especially comfortable after the light-square bishop has already reached an active square.

- Plain hint: Support the dark-square center after the light-square bishop has found activity.

- Opening themes: solid center, bishop timing, dark-square support

### Packet caro-kann-black.line-010.ply-12.b8d7

- Move: `Nd7` / `b8d7` at ply 12

- CoachCard: **Add a solid central defender** — Nd7 develops a knight without weakening the Caro-Kann pawn shell. It reinforces central squares and keeps Black ready to challenge White’s setup.

- Plain hint: Add a defender to the center while keeping the structure solid.

- Opening themes: solid knight route, central support, Caro-Kann structure


## caro-kann-black-line-011: 1. e4 c6 2. Nf3 d5 3. Nc3 Bg4 4. exd5 cxd5 5. d4 e6 6. Be2 Nf6

Runtime playKey: `e2e4,c7c6,g1f3,d7d5,b1c3,c8g4,e4d5,c6d5,d2d4,e7e6,f1e2,g8f6`  
Runtime totalGames field at line node: `678246`

### Packet caro-kann-black.line-011.ply-02.c7c6

- Move: `c6` / `c7c6` at ply 2

- CoachCard: **Prepare the Caro-Kann center** — c6 is the Caro-Kann foundation: Black supports ...d5 before challenging White’s e-pawn. The structure stays solid without weakening the kingside.

- Plain hint: Prepare the queen-pawn challenge while keeping the kingside pawn shield intact.

- Opening themes: ...c6 foundation, ...d5 preparation, solid structure

### Packet caro-kann-black.line-011.ply-04.d7d5

- Move: `d5` / `d7d5` at ply 4

- CoachCard: **Challenge e4 from a solid base** — d5 executes the Caro-Kann plan by challenging White’s e-pawn after ...c6. Black fights the center without loosening the king.

- Plain hint: Challenge White’s king pawn from a solid Caro-Kann base.

- Opening themes: ...d5 challenge, e4 pressure, Caro-Kann solidity

### Packet caro-kann-black.line-011.ply-06.c8g4

- Move: `Bg4` / `c8g4` at ply 6

- CoachCard: **Use the bishop actively before the structure locks** — Bg4 develops the light-square bishop actively, often pinning or pressuring a knight that helps White’s center. It addresses the Caro-Kann bishop issue before the position closes.

- Plain hint: Use the light-square bishop actively before settling the central pawn structure.

- Opening themes: active bishop, pin pressure, Caro-Kann bishop issue

### Packet caro-kann-black.line-011.ply-08.c6d5

- Move: `cxd5` / `c6d5` at ply 8

- CoachCard: **Keep the compact Caro-Kann structure** — cxd5 recaptures toward the center and keeps Black’s pawn structure compact. In Exchange structures, Black’s goal is solidity plus active minor-piece play.

- Plain hint: Recapture toward the center to keep the Caro-Kann structure compact.

- Opening themes: Exchange structure, compact center, solid recapture

### Packet caro-kann-black.line-011.ply-10.e7e6

- Move: `e6` / `e7e6` at ply 10

- CoachCard: **Lock in the solid Caro-Kann center** — e6 supports the central dark squares and completes a solid Caro-Kann shell. It is especially comfortable after the light-square bishop has already reached an active square.

- Plain hint: Support the dark-square center after the light-square bishop has found activity.

- Opening themes: solid center, bishop timing, dark-square support

### Packet caro-kann-black.line-011.ply-12.g8f6

- Move: `Nf6` / `g8f6` at ply 12

- CoachCard: **Challenge White’s central control** — Nf6 develops the knight toward e4 and d5 pressure. In Caro-Kann structures, Black uses solid pawns plus active pieces to question White’s center.

- Plain hint: Develop the kingside knight to challenge White’s central control.

- Opening themes: ...Nf6 pressure, central control, solid development


## caro-kann-black-line-012: 1. e4 c6 2. d4 d5 3. e5 c5 4. c3 Nc6 5. Nf3 cxd4 6. cxd4 Bg4

Runtime playKey: `e2e4,c7c6,d2d4,d7d5,e4e5,c6c5,c2c3,b8c6,g1f3,c5d4,c3d4,c8g4`  
Runtime totalGames field at line node: `666376`

### Packet caro-kann-black.line-012.ply-02.c7c6

- Move: `c6` / `c7c6` at ply 2

- CoachCard: **Prepare the Caro-Kann center** — c6 is the Caro-Kann foundation: Black supports ...d5 before challenging White’s e-pawn. The structure stays solid without weakening the kingside.

- Plain hint: Prepare the queen-pawn challenge while keeping the kingside pawn shield intact.

- Opening themes: ...c6 foundation, ...d5 preparation, solid structure

### Packet caro-kann-black.line-012.ply-04.d7d5

- Move: `d5` / `d7d5` at ply 4

- CoachCard: **Challenge e4 from a solid base** — d5 executes the Caro-Kann plan by challenging White’s e-pawn after ...c6. Black fights the center without loosening the king.

- Plain hint: Challenge White’s king pawn from a solid Caro-Kann base.

- Opening themes: ...d5 challenge, e4 pressure, Caro-Kann solidity

### Packet caro-kann-black.line-012.ply-06.c6c5

- Move: `c5` / `c6c5` at ply 6

- CoachCard: **Strike at the Caro-Kann pawn chain** — c5 is a standard Caro-Kann counterbreak against White’s advanced center. Black attacks the pawn chain from the side instead of passively defending space.

- Plain hint: Strike at White’s pawn chain from the side, a standard Caro-Kann counterbreak.

- Opening themes: ...c5 counterbreak, Advance structure, pawn-chain pressure

### Packet caro-kann-black.line-012.ply-08.b8c6

- Move: `Nc6` / `b8c6` at ply 8

- CoachCard: **Increase pressure on White’s pawn structure** — Nc6 develops toward central pressure in a Caro-Kann structure. It helps Black challenge White’s pawns rather than remaining purely defensive.

- Plain hint: Develop toward the center and increase pressure on White’s pawn structure.

- Opening themes: central pressure, knight development, pawn structure

### Packet caro-kann-black.line-012.ply-10.c5d4

- Move: `cxd4` / `c5d4` at ply 10

- CoachCard: **Preserve Caro-Kann solidity** — cxd4 keeps Black connected to Caro-Kann priorities: a solid ...c6/...d5 center, active minor pieces, and timely pressure against White’s pawn structure.

- Plain hint: Use the Caro-Kann plan: solid center first, active light-square bishop when possible, and timely pressure against White’s pawns.

- Opening themes: Caro-Kann structure, piece activity, pawn pressure

### Packet caro-kann-black.line-012.ply-12.c8g4

- Move: `Bg4` / `c8g4` at ply 12

- CoachCard: **Use the bishop actively before the structure locks** — Bg4 develops the light-square bishop actively, often pinning or pressuring a knight that helps White’s center. It addresses the Caro-Kann bishop issue before the position closes.

- Plain hint: Use the light-square bishop actively before settling the central pawn structure.

- Opening themes: active bishop, pin pressure, Caro-Kann bishop issue


## caro-kann-black-line-013: 1. e4 c6 2. d4 d5 3. exd5 cxd5 4. Bd3 Nc6 5. Nf3 Bg4 6. c3 e6

Runtime playKey: `e2e4,c7c6,d2d4,d7d5,e4d5,c6d5,f1d3,b8c6,g1f3,c8g4,c2c3,e7e6`  
Runtime totalGames field at line node: `628720`

### Packet caro-kann-black.line-013.ply-02.c7c6

- Move: `c6` / `c7c6` at ply 2

- CoachCard: **Prepare the Caro-Kann center** — c6 is the Caro-Kann foundation: Black supports ...d5 before challenging White’s e-pawn. The structure stays solid without weakening the kingside.

- Plain hint: Prepare the queen-pawn challenge while keeping the kingside pawn shield intact.

- Opening themes: ...c6 foundation, ...d5 preparation, solid structure

### Packet caro-kann-black.line-013.ply-04.d7d5

- Move: `d5` / `d7d5` at ply 4

- CoachCard: **Challenge e4 from a solid base** — d5 executes the Caro-Kann plan by challenging White’s e-pawn after ...c6. Black fights the center without loosening the king.

- Plain hint: Challenge White’s king pawn from a solid Caro-Kann base.

- Opening themes: ...d5 challenge, e4 pressure, Caro-Kann solidity

### Packet caro-kann-black.line-013.ply-06.c6d5

- Move: `cxd5` / `c6d5` at ply 6

- CoachCard: **Keep the compact Caro-Kann structure** — cxd5 recaptures toward the center and keeps Black’s pawn structure compact. In Exchange structures, Black’s goal is solidity plus active minor-piece play.

- Plain hint: Recapture toward the center to keep the Caro-Kann structure compact.

- Opening themes: Exchange structure, compact center, solid recapture

### Packet caro-kann-black.line-013.ply-08.b8c6

- Move: `Nc6` / `b8c6` at ply 8

- CoachCard: **Increase pressure on White’s pawn structure** — Nc6 develops toward central pressure in a Caro-Kann structure. It helps Black challenge White’s pawns rather than remaining purely defensive.

- Plain hint: Develop toward the center and increase pressure on White’s pawn structure.

- Opening themes: central pressure, knight development, pawn structure

### Packet caro-kann-black.line-013.ply-10.c8g4

- Move: `Bg4` / `c8g4` at ply 10

- CoachCard: **Use the bishop actively before the structure locks** — Bg4 develops the light-square bishop actively, often pinning or pressuring a knight that helps White’s center. It addresses the Caro-Kann bishop issue before the position closes.

- Plain hint: Use the light-square bishop actively before settling the central pawn structure.

- Opening themes: active bishop, pin pressure, Caro-Kann bishop issue

### Packet caro-kann-black.line-013.ply-12.e7e6

- Move: `e6` / `e7e6` at ply 12

- CoachCard: **Lock in the solid Caro-Kann center** — e6 supports the central dark squares and completes a solid Caro-Kann shell. It is especially comfortable after the light-square bishop has already reached an active square.

- Plain hint: Support the dark-square center after the light-square bishop has found activity.

- Opening themes: solid center, bishop timing, dark-square support


## caro-kann-black-line-014: 1. e4 c6 2. d4 d5 3. Nc3 dxe4 4. Nxe4 Bf5 5. Ng3 Bg6 6. Nf3 e6

Runtime playKey: `e2e4,c7c6,d2d4,d7d5,b1c3,d5e4,c3e4,c8f5,e4g3,f5g6,g1f3,e7e6`  
Runtime totalGames field at line node: `592153`

### Packet caro-kann-black.line-014.ply-02.c7c6

- Move: `c6` / `c7c6` at ply 2

- CoachCard: **Prepare the Caro-Kann center** — c6 is the Caro-Kann foundation: Black supports ...d5 before challenging White’s e-pawn. The structure stays solid without weakening the kingside.

- Plain hint: Prepare the queen-pawn challenge while keeping the kingside pawn shield intact.

- Opening themes: ...c6 foundation, ...d5 preparation, solid structure

### Packet caro-kann-black.line-014.ply-04.d7d5

- Move: `d5` / `d7d5` at ply 4

- CoachCard: **Challenge e4 from a solid base** — d5 executes the Caro-Kann plan by challenging White’s e-pawn after ...c6. Black fights the center without loosening the king.

- Plain hint: Challenge White’s king pawn from a solid Caro-Kann base.

- Opening themes: ...d5 challenge, e4 pressure, Caro-Kann solidity

### Packet caro-kann-black.line-014.ply-06.d5e4

- Move: `dxe4` / `d5e4` at ply 6

- CoachCard: **Clarify the Caro-Kann center** — dxe4 releases the d-pawn tension and asks White to spend time recapturing or restoring the center. This is a common Caro-Kann way to reduce White’s space.

- Plain hint: Clarify the center and make White spend a tempo restoring the king pawn.

- Opening themes: central clarification, e4 challenge, tempo on center

### Packet caro-kann-black.line-014.ply-08.c8f5

- Move: `Bf5` / `c8f5` at ply 8

- CoachCard: **Free the light-square bishop early** — Bf5 solves a major Caro-Kann issue by developing the light-square bishop before ...e6 shuts it in. The bishop stays active while Black keeps a solid center.

- Plain hint: Develop the light-square bishop outside the pawn chain before it can be boxed in.

- Opening themes: light-square bishop, outside pawn chain, Caro-Kann development

### Packet caro-kann-black.line-014.ply-10.f5g6

- Move: `Bg6` / `f5g6` at ply 10

- CoachCard: **Preserve Caro-Kann solidity** — Bg6 keeps Black connected to Caro-Kann priorities: a solid ...c6/...d5 center, active minor pieces, and timely pressure against White’s pawn structure.

- Plain hint: Use the Caro-Kann plan: solid center first, active light-square bishop when possible, and timely pressure against White’s pawns.

- Opening themes: Caro-Kann structure, piece activity, pawn pressure

### Packet caro-kann-black.line-014.ply-12.e7e6

- Move: `e6` / `e7e6` at ply 12

- CoachCard: **Lock in the solid Caro-Kann center** — e6 supports the central dark squares and completes a solid Caro-Kann shell. It is especially comfortable after the light-square bishop has already reached an active square.

- Plain hint: Support the dark-square center after the light-square bishop has found activity.

- Opening themes: solid center, bishop timing, dark-square support


## caro-kann-black-line-015: 1. e4 c6 2. d4 d5 3. exd5 cxd5 4. Bd3 Nc6 5. c3 Nf6 6. Bf4 Bg4

Runtime playKey: `e2e4,c7c6,d2d4,d7d5,e4d5,c6d5,f1d3,b8c6,c2c3,g8f6,c1f4,c8g4`  
Runtime totalGames field at line node: `588492`

### Packet caro-kann-black.line-015.ply-02.c7c6

- Move: `c6` / `c7c6` at ply 2

- CoachCard: **Prepare the Caro-Kann center** — c6 is the Caro-Kann foundation: Black supports ...d5 before challenging White’s e-pawn. The structure stays solid without weakening the kingside.

- Plain hint: Prepare the queen-pawn challenge while keeping the kingside pawn shield intact.

- Opening themes: ...c6 foundation, ...d5 preparation, solid structure

### Packet caro-kann-black.line-015.ply-04.d7d5

- Move: `d5` / `d7d5` at ply 4

- CoachCard: **Challenge e4 from a solid base** — d5 executes the Caro-Kann plan by challenging White’s e-pawn after ...c6. Black fights the center without loosening the king.

- Plain hint: Challenge White’s king pawn from a solid Caro-Kann base.

- Opening themes: ...d5 challenge, e4 pressure, Caro-Kann solidity

### Packet caro-kann-black.line-015.ply-06.c6d5

- Move: `cxd5` / `c6d5` at ply 6

- CoachCard: **Keep the compact Caro-Kann structure** — cxd5 recaptures toward the center and keeps Black’s pawn structure compact. In Exchange structures, Black’s goal is solidity plus active minor-piece play.

- Plain hint: Recapture toward the center to keep the Caro-Kann structure compact.

- Opening themes: Exchange structure, compact center, solid recapture

### Packet caro-kann-black.line-015.ply-08.b8c6

- Move: `Nc6` / `b8c6` at ply 8

- CoachCard: **Increase pressure on White’s pawn structure** — Nc6 develops toward central pressure in a Caro-Kann structure. It helps Black challenge White’s pawns rather than remaining purely defensive.

- Plain hint: Develop toward the center and increase pressure on White’s pawn structure.

- Opening themes: central pressure, knight development, pawn structure

### Packet caro-kann-black.line-015.ply-10.g8f6

- Move: `Nf6` / `g8f6` at ply 10

- CoachCard: **Challenge White’s central control** — Nf6 develops the knight toward e4 and d5 pressure. In Caro-Kann structures, Black uses solid pawns plus active pieces to question White’s center.

- Plain hint: Develop the kingside knight to challenge White’s central control.

- Opening themes: ...Nf6 pressure, central control, solid development

### Packet caro-kann-black.line-015.ply-12.c8g4

- Move: `Bg4` / `c8g4` at ply 12

- CoachCard: **Use the bishop actively before the structure locks** — Bg4 develops the light-square bishop actively, often pinning or pressuring a knight that helps White’s center. It addresses the Caro-Kann bishop issue before the position closes.

- Plain hint: Use the light-square bishop actively before settling the central pawn structure.

- Opening themes: active bishop, pin pressure, Caro-Kann bishop issue


## caro-kann-black-line-016: 1. e4 c6 2. d4 d5 3. exd5 cxd5 4. Nf3 Nf6 5. Nc3 Bg4 6. Be2 Nc6

Runtime playKey: `e2e4,c7c6,d2d4,d7d5,e4d5,c6d5,g1f3,g8f6,b1c3,c8g4,f1e2,b8c6`  
Runtime totalGames field at line node: `550271`

### Packet caro-kann-black.line-016.ply-02.c7c6

- Move: `c6` / `c7c6` at ply 2

- CoachCard: **Prepare the Caro-Kann center** — c6 is the Caro-Kann foundation: Black supports ...d5 before challenging White’s e-pawn. The structure stays solid without weakening the kingside.

- Plain hint: Prepare the queen-pawn challenge while keeping the kingside pawn shield intact.

- Opening themes: ...c6 foundation, ...d5 preparation, solid structure

### Packet caro-kann-black.line-016.ply-04.d7d5

- Move: `d5` / `d7d5` at ply 4

- CoachCard: **Challenge e4 from a solid base** — d5 executes the Caro-Kann plan by challenging White’s e-pawn after ...c6. Black fights the center without loosening the king.

- Plain hint: Challenge White’s king pawn from a solid Caro-Kann base.

- Opening themes: ...d5 challenge, e4 pressure, Caro-Kann solidity

### Packet caro-kann-black.line-016.ply-06.c6d5

- Move: `cxd5` / `c6d5` at ply 6

- CoachCard: **Keep the compact Caro-Kann structure** — cxd5 recaptures toward the center and keeps Black’s pawn structure compact. In Exchange structures, Black’s goal is solidity plus active minor-piece play.

- Plain hint: Recapture toward the center to keep the Caro-Kann structure compact.

- Opening themes: Exchange structure, compact center, solid recapture

### Packet caro-kann-black.line-016.ply-08.g8f6

- Move: `Nf6` / `g8f6` at ply 8

- CoachCard: **Challenge White’s central control** — Nf6 develops the knight toward e4 and d5 pressure. In Caro-Kann structures, Black uses solid pawns plus active pieces to question White’s center.

- Plain hint: Develop the kingside knight to challenge White’s central control.

- Opening themes: ...Nf6 pressure, central control, solid development

### Packet caro-kann-black.line-016.ply-10.c8g4

- Move: `Bg4` / `c8g4` at ply 10

- CoachCard: **Use the bishop actively before the structure locks** — Bg4 develops the light-square bishop actively, often pinning or pressuring a knight that helps White’s center. It addresses the Caro-Kann bishop issue before the position closes.

- Plain hint: Use the light-square bishop actively before settling the central pawn structure.

- Opening themes: active bishop, pin pressure, Caro-Kann bishop issue

### Packet caro-kann-black.line-016.ply-12.b8c6

- Move: `Nc6` / `b8c6` at ply 12

- CoachCard: **Increase pressure on White’s pawn structure** — Nc6 develops toward central pressure in a Caro-Kann structure. It helps Black challenge White’s pawns rather than remaining purely defensive.

- Plain hint: Develop toward the center and increase pressure on White’s pawn structure.

- Opening themes: central pressure, knight development, pawn structure


## caro-kann-black-line-017: 1. e4 c6 2. Nf3 d5 3. Nc3 Bg4 4. exd5 cxd5 5. d4 Nc6 6. Bb5 e6

Runtime playKey: `e2e4,c7c6,g1f3,d7d5,b1c3,c8g4,e4d5,c6d5,d2d4,b8c6,f1b5,e7e6`  
Runtime totalGames field at line node: `426641`

### Packet caro-kann-black.line-017.ply-02.c7c6

- Move: `c6` / `c7c6` at ply 2

- CoachCard: **Prepare the Caro-Kann center** — c6 is the Caro-Kann foundation: Black supports ...d5 before challenging White’s e-pawn. The structure stays solid without weakening the kingside.

- Plain hint: Prepare the queen-pawn challenge while keeping the kingside pawn shield intact.

- Opening themes: ...c6 foundation, ...d5 preparation, solid structure

### Packet caro-kann-black.line-017.ply-04.d7d5

- Move: `d5` / `d7d5` at ply 4

- CoachCard: **Challenge e4 from a solid base** — d5 executes the Caro-Kann plan by challenging White’s e-pawn after ...c6. Black fights the center without loosening the king.

- Plain hint: Challenge White’s king pawn from a solid Caro-Kann base.

- Opening themes: ...d5 challenge, e4 pressure, Caro-Kann solidity

### Packet caro-kann-black.line-017.ply-06.c8g4

- Move: `Bg4` / `c8g4` at ply 6

- CoachCard: **Use the bishop actively before the structure locks** — Bg4 develops the light-square bishop actively, often pinning or pressuring a knight that helps White’s center. It addresses the Caro-Kann bishop issue before the position closes.

- Plain hint: Use the light-square bishop actively before settling the central pawn structure.

- Opening themes: active bishop, pin pressure, Caro-Kann bishop issue

### Packet caro-kann-black.line-017.ply-08.c6d5

- Move: `cxd5` / `c6d5` at ply 8

- CoachCard: **Keep the compact Caro-Kann structure** — cxd5 recaptures toward the center and keeps Black’s pawn structure compact. In Exchange structures, Black’s goal is solidity plus active minor-piece play.

- Plain hint: Recapture toward the center to keep the Caro-Kann structure compact.

- Opening themes: Exchange structure, compact center, solid recapture

### Packet caro-kann-black.line-017.ply-10.b8c6

- Move: `Nc6` / `b8c6` at ply 10

- CoachCard: **Increase pressure on White’s pawn structure** — Nc6 develops toward central pressure in a Caro-Kann structure. It helps Black challenge White’s pawns rather than remaining purely defensive.

- Plain hint: Develop toward the center and increase pressure on White’s pawn structure.

- Opening themes: central pressure, knight development, pawn structure

### Packet caro-kann-black.line-017.ply-12.e7e6

- Move: `e6` / `e7e6` at ply 12

- CoachCard: **Lock in the solid Caro-Kann center** — e6 supports the central dark squares and completes a solid Caro-Kann shell. It is especially comfortable after the light-square bishop has already reached an active square.

- Plain hint: Support the dark-square center after the light-square bishop has found activity.

- Opening themes: solid center, bishop timing, dark-square support


## caro-kann-black-line-018: 1. e4 c6 2. Nf3 d5 3. Nc3 dxe4 4. Nxe4 Bf5 5. Ng3 Bg6 6. h4 h6

Runtime playKey: `e2e4,c7c6,g1f3,d7d5,b1c3,d5e4,c3e4,c8f5,e4g3,f5g6,h2h4,h7h6`  
Runtime totalGames field at line node: `303775`

### Packet caro-kann-black.line-018.ply-02.c7c6

- Move: `c6` / `c7c6` at ply 2

- CoachCard: **Prepare the Caro-Kann center** — c6 is the Caro-Kann foundation: Black supports ...d5 before challenging White’s e-pawn. The structure stays solid without weakening the kingside.

- Plain hint: Prepare the queen-pawn challenge while keeping the kingside pawn shield intact.

- Opening themes: ...c6 foundation, ...d5 preparation, solid structure

### Packet caro-kann-black.line-018.ply-04.d7d5

- Move: `d5` / `d7d5` at ply 4

- CoachCard: **Challenge e4 from a solid base** — d5 executes the Caro-Kann plan by challenging White’s e-pawn after ...c6. Black fights the center without loosening the king.

- Plain hint: Challenge White’s king pawn from a solid Caro-Kann base.

- Opening themes: ...d5 challenge, e4 pressure, Caro-Kann solidity

### Packet caro-kann-black.line-018.ply-06.d5e4

- Move: `dxe4` / `d5e4` at ply 6

- CoachCard: **Clarify the Caro-Kann center** — dxe4 releases the d-pawn tension and asks White to spend time recapturing or restoring the center. This is a common Caro-Kann way to reduce White’s space.

- Plain hint: Clarify the center and make White spend a tempo restoring the king pawn.

- Opening themes: central clarification, e4 challenge, tempo on center

### Packet caro-kann-black.line-018.ply-08.c8f5

- Move: `Bf5` / `c8f5` at ply 8

- CoachCard: **Free the light-square bishop early** — Bf5 solves a major Caro-Kann issue by developing the light-square bishop before ...e6 shuts it in. The bishop stays active while Black keeps a solid center.

- Plain hint: Develop the light-square bishop outside the pawn chain before it can be boxed in.

- Opening themes: light-square bishop, outside pawn chain, Caro-Kann development

### Packet caro-kann-black.line-018.ply-10.f5g6

- Move: `Bg6` / `f5g6` at ply 10

- CoachCard: **Preserve Caro-Kann solidity** — Bg6 keeps Black connected to Caro-Kann priorities: a solid ...c6/...d5 center, active minor pieces, and timely pressure against White’s pawn structure.

- Plain hint: Use the Caro-Kann plan: solid center first, active light-square bishop when possible, and timely pressure against White’s pawns.

- Opening themes: Caro-Kann structure, piece activity, pawn pressure

### Packet caro-kann-black.line-018.ply-12.h7h6

- Move: `h6` / `h7h6` at ply 12

- CoachCard: **Question White’s advanced piece** — h6 asks White’s advanced piece to decide, giving Black breathing room in a compact Caro-Kann structure. The move is useful when it supports bishop or kingside coordination.

- Plain hint: Question White’s advanced piece and keep the Caro-Kann setup from being pinned down.

- Opening themes: tempo on piece, king-side space, Caro-Kann coordination


## caro-kann-black-line-019: 1. e4 c6 2. Nf3 d5 3. e5 Bg4 4. d4 e6 5. h3 Bxf3 6. Qxf3 c5

Runtime playKey: `e2e4,c7c6,g1f3,d7d5,e4e5,c8g4,d2d4,e7e6,h2h3,g4f3,d1f3,c6c5`  
Runtime totalGames field at line node: `298568`

### Packet caro-kann-black.line-019.ply-02.c7c6

- Move: `c6` / `c7c6` at ply 2

- CoachCard: **Prepare the Caro-Kann center** — c6 is the Caro-Kann foundation: Black supports ...d5 before challenging White’s e-pawn. The structure stays solid without weakening the kingside.

- Plain hint: Prepare the queen-pawn challenge while keeping the kingside pawn shield intact.

- Opening themes: ...c6 foundation, ...d5 preparation, solid structure

### Packet caro-kann-black.line-019.ply-04.d7d5

- Move: `d5` / `d7d5` at ply 4

- CoachCard: **Challenge e4 from a solid base** — d5 executes the Caro-Kann plan by challenging White’s e-pawn after ...c6. Black fights the center without loosening the king.

- Plain hint: Challenge White’s king pawn from a solid Caro-Kann base.

- Opening themes: ...d5 challenge, e4 pressure, Caro-Kann solidity

### Packet caro-kann-black.line-019.ply-06.c8g4

- Move: `Bg4` / `c8g4` at ply 6

- CoachCard: **Use the bishop actively before the structure locks** — Bg4 develops the light-square bishop actively, often pinning or pressuring a knight that helps White’s center. It addresses the Caro-Kann bishop issue before the position closes.

- Plain hint: Use the light-square bishop actively before settling the central pawn structure.

- Opening themes: active bishop, pin pressure, Caro-Kann bishop issue

### Packet caro-kann-black.line-019.ply-08.e7e6

- Move: `e6` / `e7e6` at ply 8

- CoachCard: **Lock in the solid Caro-Kann center** — e6 supports the central dark squares and completes a solid Caro-Kann shell. It is especially comfortable after the light-square bishop has already reached an active square.

- Plain hint: Support the dark-square center after the light-square bishop has found activity.

- Opening themes: solid center, bishop timing, dark-square support

### Packet caro-kann-black.line-019.ply-10.g4f3

- Move: `Bxf3` / `g4f3` at ply 10

- CoachCard: **Preserve Caro-Kann solidity** — Bxf3 keeps Black connected to Caro-Kann priorities: a solid ...c6/...d5 center, active minor pieces, and timely pressure against White’s pawn structure.

- Plain hint: Use the Caro-Kann plan: solid center first, active light-square bishop when possible, and timely pressure against White’s pawns.

- Opening themes: Caro-Kann structure, piece activity, pawn pressure

### Packet caro-kann-black.line-019.ply-12.c6c5

- Move: `c5` / `c6c5` at ply 12

- CoachCard: **Strike at the Caro-Kann pawn chain** — c5 is a standard Caro-Kann counterbreak against White’s advanced center. Black attacks the pawn chain from the side instead of passively defending space.

- Plain hint: Strike at White’s pawn chain from the side, a standard Caro-Kann counterbreak.

- Opening themes: ...c5 counterbreak, Advance structure, pawn-chain pressure


## caro-kann-black-line-020: 1. e4 c6 2. d4 d5 3. Nc3 dxe4 4. Nxe4 Nf6 5. Nxf6+ exf6 6. Nf3 Bg4

Runtime playKey: `e2e4,c7c6,d2d4,d7d5,b1c3,d5e4,c3e4,g8f6,e4f6,e7f6,g1f3,c8g4`  
Runtime totalGames field at line node: `291680`

### Packet caro-kann-black.line-020.ply-02.c7c6

- Move: `c6` / `c7c6` at ply 2

- CoachCard: **Prepare the Caro-Kann center** — c6 is the Caro-Kann foundation: Black supports ...d5 before challenging White’s e-pawn. The structure stays solid without weakening the kingside.

- Plain hint: Prepare the queen-pawn challenge while keeping the kingside pawn shield intact.

- Opening themes: ...c6 foundation, ...d5 preparation, solid structure

### Packet caro-kann-black.line-020.ply-04.d7d5

- Move: `d5` / `d7d5` at ply 4

- CoachCard: **Challenge e4 from a solid base** — d5 executes the Caro-Kann plan by challenging White’s e-pawn after ...c6. Black fights the center without loosening the king.

- Plain hint: Challenge White’s king pawn from a solid Caro-Kann base.

- Opening themes: ...d5 challenge, e4 pressure, Caro-Kann solidity

### Packet caro-kann-black.line-020.ply-06.d5e4

- Move: `dxe4` / `d5e4` at ply 6

- CoachCard: **Clarify the Caro-Kann center** — dxe4 releases the d-pawn tension and asks White to spend time recapturing or restoring the center. This is a common Caro-Kann way to reduce White’s space.

- Plain hint: Clarify the center and make White spend a tempo restoring the king pawn.

- Opening themes: central clarification, e4 challenge, tempo on center

### Packet caro-kann-black.line-020.ply-08.g8f6

- Move: `Nf6` / `g8f6` at ply 8

- CoachCard: **Challenge White’s central control** — Nf6 develops the knight toward e4 and d5 pressure. In Caro-Kann structures, Black uses solid pawns plus active pieces to question White’s center.

- Plain hint: Develop the kingside knight to challenge White’s central control.

- Opening themes: ...Nf6 pressure, central control, solid development

### Packet caro-kann-black.line-020.ply-10.e7f6

- Move: `exf6` / `e7f6` at ply 10

- CoachCard: **Preserve Caro-Kann solidity** — exf6 keeps Black connected to Caro-Kann priorities: a solid ...c6/...d5 center, active minor pieces, and timely pressure against White’s pawn structure.

- Plain hint: Use the Caro-Kann plan: solid center first, active light-square bishop when possible, and timely pressure against White’s pawns.

- Opening themes: Caro-Kann structure, piece activity, pawn pressure

### Packet caro-kann-black.line-020.ply-12.c8g4

- Move: `Bg4` / `c8g4` at ply 12

- CoachCard: **Use the bishop actively before the structure locks** — Bg4 develops the light-square bishop actively, often pinning or pressuring a knight that helps White’s center. It addresses the Caro-Kann bishop issue before the position closes.

- Plain hint: Use the light-square bishop actively before settling the central pawn structure.

- Opening themes: active bishop, pin pressure, Caro-Kann bishop issue
