# London System approved-content candidates

Opening ID: `london-white`  
Status: approved candidates only; not app-activated.


## london-white-line-001: 1. d4 Nf6 2. Bf4 e6 3. e3 c5 4. c3 Nc6 5. Nd2 d5 6. Ngf3 Bd6

Runtime playKey: `d2d4,g8f6,c1f4,e7e6,e2e3,c7c5,c2c3,b8c6,b1d2,d7d5,g1f3,f8d6`  
Runtime totalGames field at line node: `663114`

### Packet london-white.line-001.ply-01.d2d4

- Move: `d4` / `d2d4` at ply 1

- CoachCard: **Anchor the London queen-pawn center** — d4 creates the d-pawn base the London System is built around. White can now develop the dark-square bishop before closing the pawn triangle.

- Plain hint: Anchor the queen-pawn center before building the London piece shell.

- Opening themes: London d-pawn base, compact setup, bishop outside chain

### Packet london-white.line-001.ply-03.c1f4

- Move: `Bf4` / `c1f4` at ply 3

- CoachCard: **Develop the London bishop before e3** — Bf4 is the key London move: the dark-square bishop comes out before the e-pawn closes the diagonal. That keeps White’s setup active instead of burying the bishop.

- Plain hint: Bring the dark-square bishop outside the pawn chain before closing the triangle.

- Opening themes: bishop outside chain, London identity, d4/e3/c3 shell

### Packet london-white.line-001.ply-05.e2e3

- Move: `e3` / `e2e3` at ply 5

- CoachCard: **Close the London triangle** — e3 supports d4 and forms the London triangle with the c-pawn support when available. It also opens the route for the light-square bishop and castling.

- Plain hint: Close the London triangle while freeing the kingside bishop.

- Opening themes: London triangle, d4 support, king safety route

### Packet london-white.line-001.ply-07.c2c3

- Move: `c3` / `c2c3` at ply 7

- CoachCard: **Reinforce the London shell** — c3 reinforces d4 and completes the compact London pawn shell. This limits Black’s central breaks and prepares quiet development behind the structure.

- Plain hint: Reinforce the queen-pawn center and make the London shell harder to disturb.

- Opening themes: c3/e3/d4 triangle, d4 support, compact London

### Packet london-white.line-001.ply-09.b1d2

- Move: `Nd2` / `b1d2` at ply 9

- CoachCard: **Use the London Nbd2 route** — Nd2 is a typical London knight route: the knight supports the center from behind and keeps c-pawn structures flexible. It also helps prepare a future central push.

- Plain hint: Route the queenside knight behind the center to support future central breaks.

- Opening themes: Nbd2 route, central support, London flexibility

### Packet london-white.line-001.ply-11.g1f3

- Move: `Ngf3` / `g1f3` at ply 11

- CoachCard: **Guard the London center with the kingside knight** — Ngf3 develops behind the London center and helps White castle. The knight also supports the e5 and d4 squares that often decide when White can break.

- Plain hint: Develop the kingside knight to guard the queen-pawn center and prepare castling.

- Opening themes: kingside development, d4/e5 control, castling preparation


## london-white-line-002: 1. d4 Nf6 2. Bf4 d5 3. Nf3 Bf5 4. e3 Nc6 5. c3 e6 6. Nbd2 Bd6

Runtime playKey: `d2d4,g8f6,c1f4,d7d5,g1f3,c8f5,e2e3,b8c6,c2c3,e7e6,b1d2,f8d6`  
Runtime totalGames field at line node: `520123`

### Packet london-white.line-002.ply-01.d2d4

- Move: `d4` / `d2d4` at ply 1

- CoachCard: **Anchor the London queen-pawn center** — d4 creates the d-pawn base the London System is built around. White can now develop the dark-square bishop before closing the pawn triangle.

- Plain hint: Anchor the queen-pawn center before building the London piece shell.

- Opening themes: London d-pawn base, compact setup, bishop outside chain

### Packet london-white.line-002.ply-03.c1f4

- Move: `Bf4` / `c1f4` at ply 3

- CoachCard: **Develop the London bishop before e3** — Bf4 is the key London move: the dark-square bishop comes out before the e-pawn closes the diagonal. That keeps White’s setup active instead of burying the bishop.

- Plain hint: Bring the dark-square bishop outside the pawn chain before closing the triangle.

- Opening themes: bishop outside chain, London identity, d4/e3/c3 shell

### Packet london-white.line-002.ply-05.g1f3

- Move: `Nf3` / `g1f3` at ply 5

- CoachCard: **Guard the London center with the kingside knight** — Nf3 develops behind the London center and helps White castle. The knight also supports the e5 and d4 squares that often decide when White can break.

- Plain hint: Develop the kingside knight to guard the queen-pawn center and prepare castling.

- Opening themes: kingside development, d4/e5 control, castling preparation

### Packet london-white.line-002.ply-07.e2e3

- Move: `e3` / `e2e3` at ply 7

- CoachCard: **Close the London triangle** — e3 supports d4 and forms the London triangle with the c-pawn support when available. It also opens the route for the light-square bishop and castling.

- Plain hint: Close the London triangle while freeing the kingside bishop.

- Opening themes: London triangle, d4 support, king safety route

### Packet london-white.line-002.ply-09.c2c3

- Move: `c3` / `c2c3` at ply 9

- CoachCard: **Reinforce the London shell** — c3 reinforces d4 and completes the compact London pawn shell. This limits Black’s central breaks and prepares quiet development behind the structure.

- Plain hint: Reinforce the queen-pawn center and make the London shell harder to disturb.

- Opening themes: c3/e3/d4 triangle, d4 support, compact London

### Packet london-white.line-002.ply-11.b1d2

- Move: `Nbd2` / `b1d2` at ply 11

- CoachCard: **Use the London Nbd2 route** — Nbd2 is a typical London knight route: the knight supports the center from behind and keeps c-pawn structures flexible. It also helps prepare a future central push.

- Plain hint: Route the queenside knight behind the center to support future central breaks.

- Opening themes: Nbd2 route, central support, London flexibility


## london-white-line-003: 1. d4 Nf6 2. Bf4 e6 3. e3 c5 4. c3 Nc6 5. Nf3 cxd4 6. exd4 d5

Runtime playKey: `d2d4,g8f6,c1f4,e7e6,e2e3,c7c5,c2c3,b8c6,g1f3,c5d4,e3d4,d7d5`  
Runtime totalGames field at line node: `442410`

### Packet london-white.line-003.ply-01.d2d4

- Move: `d4` / `d2d4` at ply 1

- CoachCard: **Anchor the London queen-pawn center** — d4 creates the d-pawn base the London System is built around. White can now develop the dark-square bishop before closing the pawn triangle.

- Plain hint: Anchor the queen-pawn center before building the London piece shell.

- Opening themes: London d-pawn base, compact setup, bishop outside chain

### Packet london-white.line-003.ply-03.c1f4

- Move: `Bf4` / `c1f4` at ply 3

- CoachCard: **Develop the London bishop before e3** — Bf4 is the key London move: the dark-square bishop comes out before the e-pawn closes the diagonal. That keeps White’s setup active instead of burying the bishop.

- Plain hint: Bring the dark-square bishop outside the pawn chain before closing the triangle.

- Opening themes: bishop outside chain, London identity, d4/e3/c3 shell

### Packet london-white.line-003.ply-05.e2e3

- Move: `e3` / `e2e3` at ply 5

- CoachCard: **Close the London triangle** — e3 supports d4 and forms the London triangle with the c-pawn support when available. It also opens the route for the light-square bishop and castling.

- Plain hint: Close the London triangle while freeing the kingside bishop.

- Opening themes: London triangle, d4 support, king safety route

### Packet london-white.line-003.ply-07.c2c3

- Move: `c3` / `c2c3` at ply 7

- CoachCard: **Reinforce the London shell** — c3 reinforces d4 and completes the compact London pawn shell. This limits Black’s central breaks and prepares quiet development behind the structure.

- Plain hint: Reinforce the queen-pawn center and make the London shell harder to disturb.

- Opening themes: c3/e3/d4 triangle, d4 support, compact London

### Packet london-white.line-003.ply-09.g1f3

- Move: `Nf3` / `g1f3` at ply 9

- CoachCard: **Guard the London center with the kingside knight** — Nf3 develops behind the London center and helps White castle. The knight also supports the e5 and d4 squares that often decide when White can break.

- Plain hint: Develop the kingside knight to guard the queen-pawn center and prepare castling.

- Opening themes: kingside development, d4/e5 control, castling preparation

### Packet london-white.line-003.ply-11.e3d4

- Move: `exd4` / `e3d4` at ply 11

- CoachCard: **Keep the London shell coherent** — exd4 stays within the London plan by supporting the d-pawn shell and piece coordination rather than chasing early tactics.

- Plain hint: Keep the London structure compact: bishop outside the chain, pawns supporting the center, and safe kingside development.

- Opening themes: London shell, compact development, center support


## london-white-line-004: 1. d4 Nf6 2. Bf4 d5 3. Nf3 Bf5 4. e3 e6 5. c4 c6 6. Nc3 Bd6

Runtime playKey: `d2d4,g8f6,c1f4,d7d5,g1f3,c8f5,e2e3,e7e6,c2c4,c7c6,b1c3,f8d6`  
Runtime totalGames field at line node: `429847`

### Packet london-white.line-004.ply-01.d2d4

- Move: `d4` / `d2d4` at ply 1

- CoachCard: **Anchor the London queen-pawn center** — d4 creates the d-pawn base the London System is built around. White can now develop the dark-square bishop before closing the pawn triangle.

- Plain hint: Anchor the queen-pawn center before building the London piece shell.

- Opening themes: London d-pawn base, compact setup, bishop outside chain

### Packet london-white.line-004.ply-03.c1f4

- Move: `Bf4` / `c1f4` at ply 3

- CoachCard: **Develop the London bishop before e3** — Bf4 is the key London move: the dark-square bishop comes out before the e-pawn closes the diagonal. That keeps White’s setup active instead of burying the bishop.

- Plain hint: Bring the dark-square bishop outside the pawn chain before closing the triangle.

- Opening themes: bishop outside chain, London identity, d4/e3/c3 shell

### Packet london-white.line-004.ply-05.g1f3

- Move: `Nf3` / `g1f3` at ply 5

- CoachCard: **Guard the London center with the kingside knight** — Nf3 develops behind the London center and helps White castle. The knight also supports the e5 and d4 squares that often decide when White can break.

- Plain hint: Develop the kingside knight to guard the queen-pawn center and prepare castling.

- Opening themes: kingside development, d4/e5 control, castling preparation

### Packet london-white.line-004.ply-07.e2e3

- Move: `e3` / `e2e3` at ply 7

- CoachCard: **Close the London triangle** — e3 supports d4 and forms the London triangle with the c-pawn support when available. It also opens the route for the light-square bishop and castling.

- Plain hint: Close the London triangle while freeing the kingside bishop.

- Opening themes: London triangle, d4 support, king safety route

### Packet london-white.line-004.ply-09.c2c4

- Move: `c4` / `c2c4` at ply 9

- CoachCard: **Add Queen’s Gambit tension from a London move order** — c4 adds pressure against Black’s d-pawn while the London development remains intact. This line blends London setup logic with Queen’s Gambit-style central tension.

- Plain hint: Add queenside pawn tension without abandoning the compact London development scheme.

- Opening themes: c-pawn tension, London move order, d5 pressure

### Packet london-white.line-004.ply-11.b1c3

- Move: `Nc3` / `b1c3` at ply 11

- CoachCard: **Keep the London shell coherent** — Nc3 stays within the London plan by supporting the d-pawn shell and piece coordination rather than chasing early tactics.

- Plain hint: Keep the London structure compact: bishop outside the chain, pawns supporting the center, and safe kingside development.

- Opening themes: London shell, compact development, center support


## london-white-line-005: 1. d4 Nf6 2. Bf4 d5 3. Nf3 Bf5 4. e3 Nc6 5. Bd3 Bxd3 6. Qxd3 e6

Runtime playKey: `d2d4,g8f6,c1f4,d7d5,g1f3,c8f5,e2e3,b8c6,f1d3,f5d3,d1d3,e7e6`  
Runtime totalGames field at line node: `414712`

### Packet london-white.line-005.ply-01.d2d4

- Move: `d4` / `d2d4` at ply 1

- CoachCard: **Anchor the London queen-pawn center** — d4 creates the d-pawn base the London System is built around. White can now develop the dark-square bishop before closing the pawn triangle.

- Plain hint: Anchor the queen-pawn center before building the London piece shell.

- Opening themes: London d-pawn base, compact setup, bishop outside chain

### Packet london-white.line-005.ply-03.c1f4

- Move: `Bf4` / `c1f4` at ply 3

- CoachCard: **Develop the London bishop before e3** — Bf4 is the key London move: the dark-square bishop comes out before the e-pawn closes the diagonal. That keeps White’s setup active instead of burying the bishop.

- Plain hint: Bring the dark-square bishop outside the pawn chain before closing the triangle.

- Opening themes: bishop outside chain, London identity, d4/e3/c3 shell

### Packet london-white.line-005.ply-05.g1f3

- Move: `Nf3` / `g1f3` at ply 5

- CoachCard: **Guard the London center with the kingside knight** — Nf3 develops behind the London center and helps White castle. The knight also supports the e5 and d4 squares that often decide when White can break.

- Plain hint: Develop the kingside knight to guard the queen-pawn center and prepare castling.

- Opening themes: kingside development, d4/e5 control, castling preparation

### Packet london-white.line-005.ply-07.e2e3

- Move: `e3` / `e2e3` at ply 7

- CoachCard: **Close the London triangle** — e3 supports d4 and forms the London triangle with the c-pawn support when available. It also opens the route for the light-square bishop and castling.

- Plain hint: Close the London triangle while freeing the kingside bishop.

- Opening themes: London triangle, d4 support, king safety route

### Packet london-white.line-005.ply-09.f1d3

- Move: `Bd3` / `f1d3` at ply 9

- CoachCard: **Aim the light-square bishop at the kingside** — Bd3 develops the light-square bishop into the London attacking structure. It complements the bishop outside the chain and prepares castling or kingside pressure.

- Plain hint: Aim the light-square bishop toward the kingside after the London triangle is stable.

- Opening themes: light-square bishop, king safety, London coordination

### Packet london-white.line-005.ply-11.d1d3

- Move: `Qxd3` / `d1d3` at ply 11

- CoachCard: **Keep the London shell coherent** — Qxd3 stays within the London plan by supporting the d-pawn shell and piece coordination rather than chasing early tactics.

- Plain hint: Keep the London structure compact: bishop outside the chain, pawns supporting the center, and safe kingside development.

- Opening themes: London shell, compact development, center support


## london-white-line-006: 1. d4 Nf6 2. Bf4 e6 3. e3 c5 4. c3 Nc6 5. Nf3 d5 6. Bd3 Bd6

Runtime playKey: `d2d4,g8f6,c1f4,e7e6,e2e3,c7c5,c2c3,b8c6,g1f3,d7d5,f1d3,f8d6`  
Runtime totalGames field at line node: `395442`

### Packet london-white.line-006.ply-01.d2d4

- Move: `d4` / `d2d4` at ply 1

- CoachCard: **Anchor the London queen-pawn center** — d4 creates the d-pawn base the London System is built around. White can now develop the dark-square bishop before closing the pawn triangle.

- Plain hint: Anchor the queen-pawn center before building the London piece shell.

- Opening themes: London d-pawn base, compact setup, bishop outside chain

### Packet london-white.line-006.ply-03.c1f4

- Move: `Bf4` / `c1f4` at ply 3

- CoachCard: **Develop the London bishop before e3** — Bf4 is the key London move: the dark-square bishop comes out before the e-pawn closes the diagonal. That keeps White’s setup active instead of burying the bishop.

- Plain hint: Bring the dark-square bishop outside the pawn chain before closing the triangle.

- Opening themes: bishop outside chain, London identity, d4/e3/c3 shell

### Packet london-white.line-006.ply-05.e2e3

- Move: `e3` / `e2e3` at ply 5

- CoachCard: **Close the London triangle** — e3 supports d4 and forms the London triangle with the c-pawn support when available. It also opens the route for the light-square bishop and castling.

- Plain hint: Close the London triangle while freeing the kingside bishop.

- Opening themes: London triangle, d4 support, king safety route

### Packet london-white.line-006.ply-07.c2c3

- Move: `c3` / `c2c3` at ply 7

- CoachCard: **Reinforce the London shell** — c3 reinforces d4 and completes the compact London pawn shell. This limits Black’s central breaks and prepares quiet development behind the structure.

- Plain hint: Reinforce the queen-pawn center and make the London shell harder to disturb.

- Opening themes: c3/e3/d4 triangle, d4 support, compact London

### Packet london-white.line-006.ply-09.g1f3

- Move: `Nf3` / `g1f3` at ply 9

- CoachCard: **Guard the London center with the kingside knight** — Nf3 develops behind the London center and helps White castle. The knight also supports the e5 and d4 squares that often decide when White can break.

- Plain hint: Develop the kingside knight to guard the queen-pawn center and prepare castling.

- Opening themes: kingside development, d4/e5 control, castling preparation

### Packet london-white.line-006.ply-11.f1d3

- Move: `Bd3` / `f1d3` at ply 11

- CoachCard: **Aim the light-square bishop at the kingside** — Bd3 develops the light-square bishop into the London attacking structure. It complements the bishop outside the chain and prepares castling or kingside pressure.

- Plain hint: Aim the light-square bishop toward the kingside after the London triangle is stable.

- Opening themes: light-square bishop, king safety, London coordination


## london-white-line-007: 1. d4 Nf6 2. Bf4 e6 3. e3 d5 4. Nf3 Bd6 5. Bg3 Bxg3 6. hxg3 Nc6

Runtime playKey: `d2d4,g8f6,c1f4,e7e6,e2e3,d7d5,g1f3,f8d6,f4g3,d6g3,h2g3,b8c6`  
Runtime totalGames field at line node: `388935`

### Packet london-white.line-007.ply-01.d2d4

- Move: `d4` / `d2d4` at ply 1

- CoachCard: **Anchor the London queen-pawn center** — d4 creates the d-pawn base the London System is built around. White can now develop the dark-square bishop before closing the pawn triangle.

- Plain hint: Anchor the queen-pawn center before building the London piece shell.

- Opening themes: London d-pawn base, compact setup, bishop outside chain

### Packet london-white.line-007.ply-03.c1f4

- Move: `Bf4` / `c1f4` at ply 3

- CoachCard: **Develop the London bishop before e3** — Bf4 is the key London move: the dark-square bishop comes out before the e-pawn closes the diagonal. That keeps White’s setup active instead of burying the bishop.

- Plain hint: Bring the dark-square bishop outside the pawn chain before closing the triangle.

- Opening themes: bishop outside chain, London identity, d4/e3/c3 shell

### Packet london-white.line-007.ply-05.e2e3

- Move: `e3` / `e2e3` at ply 5

- CoachCard: **Close the London triangle** — e3 supports d4 and forms the London triangle with the c-pawn support when available. It also opens the route for the light-square bishop and castling.

- Plain hint: Close the London triangle while freeing the kingside bishop.

- Opening themes: London triangle, d4 support, king safety route

### Packet london-white.line-007.ply-07.g1f3

- Move: `Nf3` / `g1f3` at ply 7

- CoachCard: **Guard the London center with the kingside knight** — Nf3 develops behind the London center and helps White castle. The knight also supports the e5 and d4 squares that often decide when White can break.

- Plain hint: Develop the kingside knight to guard the queen-pawn center and prepare castling.

- Opening themes: kingside development, d4/e5 control, castling preparation

### Packet london-white.line-007.ply-09.f4g3

- Move: `Bg3` / `f4g3` at ply 9

- CoachCard: **Keep the London shell coherent** — Bg3 stays within the London plan by supporting the d-pawn shell and piece coordination rather than chasing early tactics.

- Plain hint: Keep the London structure compact: bishop outside the chain, pawns supporting the center, and safe kingside development.

- Opening themes: London shell, compact development, center support

### Packet london-white.line-007.ply-11.h2g3

- Move: `hxg3` / `h2g3` at ply 11

- CoachCard: **Keep the London shell coherent** — hxg3 stays within the London plan by supporting the d-pawn shell and piece coordination rather than chasing early tactics.

- Plain hint: Keep the London structure compact: bishop outside the chain, pawns supporting the center, and safe kingside development.

- Opening themes: London shell, compact development, center support


## london-white-line-008: 1. d4 d5 2. c4 c6 3. cxd5 cxd5 4. Nc3 Nc6 5. Bf4 a6 6. Nf3 Nf6

Runtime playKey: `d2d4,d7d5,c2c4,c7c6,c4d5,c6d5,b1c3,b8c6,c1f4,a7a6,g1f3,g8f6`  
Runtime totalGames field at line node: `377394`

### Packet london-white.line-008.ply-01.d2d4

- Move: `d4` / `d2d4` at ply 1

- CoachCard: **Anchor the London queen-pawn center** — d4 creates the d-pawn base the London System is built around. White can now develop the dark-square bishop before closing the pawn triangle.

- Plain hint: Anchor the queen-pawn center before building the London piece shell.

- Opening themes: London d-pawn base, compact setup, bishop outside chain

### Packet london-white.line-008.ply-03.c2c4

- Move: `c4` / `c2c4` at ply 3

- CoachCard: **Add Queen’s Gambit tension from a London move order** — c4 adds pressure against Black’s d-pawn while the London development remains intact. This line blends London setup logic with Queen’s Gambit-style central tension.

- Plain hint: Add queenside pawn tension without abandoning the compact London development scheme.

- Opening themes: c-pawn tension, London move order, d5 pressure

### Packet london-white.line-008.ply-05.c4d5

- Move: `cxd5` / `c4d5` at ply 5

- CoachCard: **Keep the London shell coherent** — cxd5 stays within the London plan by supporting the d-pawn shell and piece coordination rather than chasing early tactics.

- Plain hint: Keep the London structure compact: bishop outside the chain, pawns supporting the center, and safe kingside development.

- Opening themes: London shell, compact development, center support

### Packet london-white.line-008.ply-07.b1c3

- Move: `Nc3` / `b1c3` at ply 7

- CoachCard: **Keep the London shell coherent** — Nc3 stays within the London plan by supporting the d-pawn shell and piece coordination rather than chasing early tactics.

- Plain hint: Keep the London structure compact: bishop outside the chain, pawns supporting the center, and safe kingside development.

- Opening themes: London shell, compact development, center support

### Packet london-white.line-008.ply-09.c1f4

- Move: `Bf4` / `c1f4` at ply 9

- CoachCard: **Develop the London bishop before e3** — Bf4 is the key London move: the dark-square bishop comes out before the e-pawn closes the diagonal. That keeps White’s setup active instead of burying the bishop.

- Plain hint: Bring the dark-square bishop outside the pawn chain before closing the triangle.

- Opening themes: bishop outside chain, London identity, d4/e3/c3 shell

### Packet london-white.line-008.ply-11.g1f3

- Move: `Nf3` / `g1f3` at ply 11

- CoachCard: **Guard the London center with the kingside knight** — Nf3 develops behind the London center and helps White castle. The knight also supports the e5 and d4 squares that often decide when White can break.

- Plain hint: Develop the kingside knight to guard the queen-pawn center and prepare castling.

- Opening themes: kingside development, d4/e5 control, castling preparation


## london-white-line-009: 1. d4 d5 2. c4 c6 3. cxd5 cxd5 4. Nc3 Nc6 5. Bf4 a6 6. e3 Nf6

Runtime playKey: `d2d4,d7d5,c2c4,c7c6,c4d5,c6d5,b1c3,b8c6,c1f4,a7a6,e2e3,g8f6`  
Runtime totalGames field at line node: `333086`

### Packet london-white.line-009.ply-01.d2d4

- Move: `d4` / `d2d4` at ply 1

- CoachCard: **Anchor the London queen-pawn center** — d4 creates the d-pawn base the London System is built around. White can now develop the dark-square bishop before closing the pawn triangle.

- Plain hint: Anchor the queen-pawn center before building the London piece shell.

- Opening themes: London d-pawn base, compact setup, bishop outside chain

### Packet london-white.line-009.ply-03.c2c4

- Move: `c4` / `c2c4` at ply 3

- CoachCard: **Add Queen’s Gambit tension from a London move order** — c4 adds pressure against Black’s d-pawn while the London development remains intact. This line blends London setup logic with Queen’s Gambit-style central tension.

- Plain hint: Add queenside pawn tension without abandoning the compact London development scheme.

- Opening themes: c-pawn tension, London move order, d5 pressure

### Packet london-white.line-009.ply-05.c4d5

- Move: `cxd5` / `c4d5` at ply 5

- CoachCard: **Keep the London shell coherent** — cxd5 stays within the London plan by supporting the d-pawn shell and piece coordination rather than chasing early tactics.

- Plain hint: Keep the London structure compact: bishop outside the chain, pawns supporting the center, and safe kingside development.

- Opening themes: London shell, compact development, center support

### Packet london-white.line-009.ply-07.b1c3

- Move: `Nc3` / `b1c3` at ply 7

- CoachCard: **Keep the London shell coherent** — Nc3 stays within the London plan by supporting the d-pawn shell and piece coordination rather than chasing early tactics.

- Plain hint: Keep the London structure compact: bishop outside the chain, pawns supporting the center, and safe kingside development.

- Opening themes: London shell, compact development, center support

### Packet london-white.line-009.ply-09.c1f4

- Move: `Bf4` / `c1f4` at ply 9

- CoachCard: **Develop the London bishop before e3** — Bf4 is the key London move: the dark-square bishop comes out before the e-pawn closes the diagonal. That keeps White’s setup active instead of burying the bishop.

- Plain hint: Bring the dark-square bishop outside the pawn chain before closing the triangle.

- Opening themes: bishop outside chain, London identity, d4/e3/c3 shell

### Packet london-white.line-009.ply-11.e2e3

- Move: `e3` / `e2e3` at ply 11

- CoachCard: **Close the London triangle** — e3 supports d4 and forms the London triangle with the c-pawn support when available. It also opens the route for the light-square bishop and castling.

- Plain hint: Close the London triangle while freeing the kingside bishop.

- Opening themes: London triangle, d4 support, king safety route


## london-white-line-010: 1. d4 Nf6 2. Bf4 e6 3. e3 c5 4. c3 Nc6 5. Nd2 d5 6. Ngf3 Be7

Runtime playKey: `d2d4,g8f6,c1f4,e7e6,e2e3,c7c5,c2c3,b8c6,b1d2,d7d5,g1f3,f8e7`  
Runtime totalGames field at line node: `316430`

### Packet london-white.line-010.ply-01.d2d4

- Move: `d4` / `d2d4` at ply 1

- CoachCard: **Anchor the London queen-pawn center** — d4 creates the d-pawn base the London System is built around. White can now develop the dark-square bishop before closing the pawn triangle.

- Plain hint: Anchor the queen-pawn center before building the London piece shell.

- Opening themes: London d-pawn base, compact setup, bishop outside chain

### Packet london-white.line-010.ply-03.c1f4

- Move: `Bf4` / `c1f4` at ply 3

- CoachCard: **Develop the London bishop before e3** — Bf4 is the key London move: the dark-square bishop comes out before the e-pawn closes the diagonal. That keeps White’s setup active instead of burying the bishop.

- Plain hint: Bring the dark-square bishop outside the pawn chain before closing the triangle.

- Opening themes: bishop outside chain, London identity, d4/e3/c3 shell

### Packet london-white.line-010.ply-05.e2e3

- Move: `e3` / `e2e3` at ply 5

- CoachCard: **Close the London triangle** — e3 supports d4 and forms the London triangle with the c-pawn support when available. It also opens the route for the light-square bishop and castling.

- Plain hint: Close the London triangle while freeing the kingside bishop.

- Opening themes: London triangle, d4 support, king safety route

### Packet london-white.line-010.ply-07.c2c3

- Move: `c3` / `c2c3` at ply 7

- CoachCard: **Reinforce the London shell** — c3 reinforces d4 and completes the compact London pawn shell. This limits Black’s central breaks and prepares quiet development behind the structure.

- Plain hint: Reinforce the queen-pawn center and make the London shell harder to disturb.

- Opening themes: c3/e3/d4 triangle, d4 support, compact London

### Packet london-white.line-010.ply-09.b1d2

- Move: `Nd2` / `b1d2` at ply 9

- CoachCard: **Use the London Nbd2 route** — Nd2 is a typical London knight route: the knight supports the center from behind and keeps c-pawn structures flexible. It also helps prepare a future central push.

- Plain hint: Route the queenside knight behind the center to support future central breaks.

- Opening themes: Nbd2 route, central support, London flexibility

### Packet london-white.line-010.ply-11.g1f3

- Move: `Ngf3` / `g1f3` at ply 11

- CoachCard: **Guard the London center with the kingside knight** — Ngf3 develops behind the London center and helps White castle. The knight also supports the e5 and d4 squares that often decide when White can break.

- Plain hint: Develop the kingside knight to guard the queen-pawn center and prepare castling.

- Opening themes: kingside development, d4/e5 control, castling preparation


## london-white-line-011: 1. d4 d5 2. Nf3 e6 3. c4 c6 4. Nc3 f5 5. Bf4 Bd6 6. e3 Nf6

Runtime playKey: `d2d4,d7d5,g1f3,e7e6,c2c4,c7c6,b1c3,f7f5,c1f4,f8d6,e2e3,g8f6`  
Runtime totalGames field at line node: `291298`

### Packet london-white.line-011.ply-01.d2d4

- Move: `d4` / `d2d4` at ply 1

- CoachCard: **Anchor the London queen-pawn center** — d4 creates the d-pawn base the London System is built around. White can now develop the dark-square bishop before closing the pawn triangle.

- Plain hint: Anchor the queen-pawn center before building the London piece shell.

- Opening themes: London d-pawn base, compact setup, bishop outside chain

### Packet london-white.line-011.ply-03.g1f3

- Move: `Nf3` / `g1f3` at ply 3

- CoachCard: **Guard the London center with the kingside knight** — Nf3 develops behind the London center and helps White castle. The knight also supports the e5 and d4 squares that often decide when White can break.

- Plain hint: Develop the kingside knight to guard the queen-pawn center and prepare castling.

- Opening themes: kingside development, d4/e5 control, castling preparation

### Packet london-white.line-011.ply-05.c2c4

- Move: `c4` / `c2c4` at ply 5

- CoachCard: **Add Queen’s Gambit tension from a London move order** — c4 adds pressure against Black’s d-pawn while the London development remains intact. This line blends London setup logic with Queen’s Gambit-style central tension.

- Plain hint: Add queenside pawn tension without abandoning the compact London development scheme.

- Opening themes: c-pawn tension, London move order, d5 pressure

### Packet london-white.line-011.ply-07.b1c3

- Move: `Nc3` / `b1c3` at ply 7

- CoachCard: **Keep the London shell coherent** — Nc3 stays within the London plan by supporting the d-pawn shell and piece coordination rather than chasing early tactics.

- Plain hint: Keep the London structure compact: bishop outside the chain, pawns supporting the center, and safe kingside development.

- Opening themes: London shell, compact development, center support

### Packet london-white.line-011.ply-09.c1f4

- Move: `Bf4` / `c1f4` at ply 9

- CoachCard: **Develop the London bishop before e3** — Bf4 is the key London move: the dark-square bishop comes out before the e-pawn closes the diagonal. That keeps White’s setup active instead of burying the bishop.

- Plain hint: Bring the dark-square bishop outside the pawn chain before closing the triangle.

- Opening themes: bishop outside chain, London identity, d4/e3/c3 shell

### Packet london-white.line-011.ply-11.e2e3

- Move: `e3` / `e2e3` at ply 11

- CoachCard: **Close the London triangle** — e3 supports d4 and forms the London triangle with the c-pawn support when available. It also opens the route for the light-square bishop and castling.

- Plain hint: Close the London triangle while freeing the kingside bishop.

- Opening themes: London triangle, d4 support, king safety route


## london-white-line-012: 1. d4 Nf6 2. Bf4 d5 3. Nf3 Bf5 4. e3 e6 5. c4 c6 6. Nc3 Bb4

Runtime playKey: `d2d4,g8f6,c1f4,d7d5,g1f3,c8f5,e2e3,e7e6,c2c4,c7c6,b1c3,f8b4`  
Runtime totalGames field at line node: `272158`

### Packet london-white.line-012.ply-01.d2d4

- Move: `d4` / `d2d4` at ply 1

- CoachCard: **Anchor the London queen-pawn center** — d4 creates the d-pawn base the London System is built around. White can now develop the dark-square bishop before closing the pawn triangle.

- Plain hint: Anchor the queen-pawn center before building the London piece shell.

- Opening themes: London d-pawn base, compact setup, bishop outside chain

### Packet london-white.line-012.ply-03.c1f4

- Move: `Bf4` / `c1f4` at ply 3

- CoachCard: **Develop the London bishop before e3** — Bf4 is the key London move: the dark-square bishop comes out before the e-pawn closes the diagonal. That keeps White’s setup active instead of burying the bishop.

- Plain hint: Bring the dark-square bishop outside the pawn chain before closing the triangle.

- Opening themes: bishop outside chain, London identity, d4/e3/c3 shell

### Packet london-white.line-012.ply-05.g1f3

- Move: `Nf3` / `g1f3` at ply 5

- CoachCard: **Guard the London center with the kingside knight** — Nf3 develops behind the London center and helps White castle. The knight also supports the e5 and d4 squares that often decide when White can break.

- Plain hint: Develop the kingside knight to guard the queen-pawn center and prepare castling.

- Opening themes: kingside development, d4/e5 control, castling preparation

### Packet london-white.line-012.ply-07.e2e3

- Move: `e3` / `e2e3` at ply 7

- CoachCard: **Close the London triangle** — e3 supports d4 and forms the London triangle with the c-pawn support when available. It also opens the route for the light-square bishop and castling.

- Plain hint: Close the London triangle while freeing the kingside bishop.

- Opening themes: London triangle, d4 support, king safety route

### Packet london-white.line-012.ply-09.c2c4

- Move: `c4` / `c2c4` at ply 9

- CoachCard: **Add Queen’s Gambit tension from a London move order** — c4 adds pressure against Black’s d-pawn while the London development remains intact. This line blends London setup logic with Queen’s Gambit-style central tension.

- Plain hint: Add queenside pawn tension without abandoning the compact London development scheme.

- Opening themes: c-pawn tension, London move order, d5 pressure

### Packet london-white.line-012.ply-11.b1c3

- Move: `Nc3` / `b1c3` at ply 11

- CoachCard: **Keep the London shell coherent** — Nc3 stays within the London plan by supporting the d-pawn shell and piece coordination rather than chasing early tactics.

- Plain hint: Keep the London structure compact: bishop outside the chain, pawns supporting the center, and safe kingside development.

- Opening themes: London shell, compact development, center support


## london-white-line-013: 1. d4 d5 2. c4 c6 3. Nc3 e6 4. Bf4 Nf6 5. e3 Be7 6. Nf3 Nbd7

Runtime playKey: `d2d4,d7d5,c2c4,c7c6,b1c3,e7e6,c1f4,g8f6,e2e3,f8e7,g1f3,b8d7`  
Runtime totalGames field at line node: `259842`

### Packet london-white.line-013.ply-01.d2d4

- Move: `d4` / `d2d4` at ply 1

- CoachCard: **Anchor the London queen-pawn center** — d4 creates the d-pawn base the London System is built around. White can now develop the dark-square bishop before closing the pawn triangle.

- Plain hint: Anchor the queen-pawn center before building the London piece shell.

- Opening themes: London d-pawn base, compact setup, bishop outside chain

### Packet london-white.line-013.ply-03.c2c4

- Move: `c4` / `c2c4` at ply 3

- CoachCard: **Add Queen’s Gambit tension from a London move order** — c4 adds pressure against Black’s d-pawn while the London development remains intact. This line blends London setup logic with Queen’s Gambit-style central tension.

- Plain hint: Add queenside pawn tension without abandoning the compact London development scheme.

- Opening themes: c-pawn tension, London move order, d5 pressure

### Packet london-white.line-013.ply-05.b1c3

- Move: `Nc3` / `b1c3` at ply 5

- CoachCard: **Keep the London shell coherent** — Nc3 stays within the London plan by supporting the d-pawn shell and piece coordination rather than chasing early tactics.

- Plain hint: Keep the London structure compact: bishop outside the chain, pawns supporting the center, and safe kingside development.

- Opening themes: London shell, compact development, center support

### Packet london-white.line-013.ply-07.c1f4

- Move: `Bf4` / `c1f4` at ply 7

- CoachCard: **Develop the London bishop before e3** — Bf4 is the key London move: the dark-square bishop comes out before the e-pawn closes the diagonal. That keeps White’s setup active instead of burying the bishop.

- Plain hint: Bring the dark-square bishop outside the pawn chain before closing the triangle.

- Opening themes: bishop outside chain, London identity, d4/e3/c3 shell

### Packet london-white.line-013.ply-09.e2e3

- Move: `e3` / `e2e3` at ply 9

- CoachCard: **Close the London triangle** — e3 supports d4 and forms the London triangle with the c-pawn support when available. It also opens the route for the light-square bishop and castling.

- Plain hint: Close the London triangle while freeing the kingside bishop.

- Opening themes: London triangle, d4 support, king safety route

### Packet london-white.line-013.ply-11.g1f3

- Move: `Nf3` / `g1f3` at ply 11

- CoachCard: **Guard the London center with the kingside knight** — Nf3 develops behind the London center and helps White castle. The knight also supports the e5 and d4 squares that often decide when White can break.

- Plain hint: Develop the kingside knight to guard the queen-pawn center and prepare castling.

- Opening themes: kingside development, d4/e5 control, castling preparation


## london-white-line-014: 1. d4 d5 2. c4 c6 3. cxd5 cxd5 4. Nc3 Nc6 5. Bf4 Nf6 6. Nf3 Bf5

Runtime playKey: `d2d4,d7d5,c2c4,c7c6,c4d5,c6d5,b1c3,b8c6,c1f4,g8f6,g1f3,c8f5`  
Runtime totalGames field at line node: `248326`

### Packet london-white.line-014.ply-01.d2d4

- Move: `d4` / `d2d4` at ply 1

- CoachCard: **Anchor the London queen-pawn center** — d4 creates the d-pawn base the London System is built around. White can now develop the dark-square bishop before closing the pawn triangle.

- Plain hint: Anchor the queen-pawn center before building the London piece shell.

- Opening themes: London d-pawn base, compact setup, bishop outside chain

### Packet london-white.line-014.ply-03.c2c4

- Move: `c4` / `c2c4` at ply 3

- CoachCard: **Add Queen’s Gambit tension from a London move order** — c4 adds pressure against Black’s d-pawn while the London development remains intact. This line blends London setup logic with Queen’s Gambit-style central tension.

- Plain hint: Add queenside pawn tension without abandoning the compact London development scheme.

- Opening themes: c-pawn tension, London move order, d5 pressure

### Packet london-white.line-014.ply-05.c4d5

- Move: `cxd5` / `c4d5` at ply 5

- CoachCard: **Keep the London shell coherent** — cxd5 stays within the London plan by supporting the d-pawn shell and piece coordination rather than chasing early tactics.

- Plain hint: Keep the London structure compact: bishop outside the chain, pawns supporting the center, and safe kingside development.

- Opening themes: London shell, compact development, center support

### Packet london-white.line-014.ply-07.b1c3

- Move: `Nc3` / `b1c3` at ply 7

- CoachCard: **Keep the London shell coherent** — Nc3 stays within the London plan by supporting the d-pawn shell and piece coordination rather than chasing early tactics.

- Plain hint: Keep the London structure compact: bishop outside the chain, pawns supporting the center, and safe kingside development.

- Opening themes: London shell, compact development, center support

### Packet london-white.line-014.ply-09.c1f4

- Move: `Bf4` / `c1f4` at ply 9

- CoachCard: **Develop the London bishop before e3** — Bf4 is the key London move: the dark-square bishop comes out before the e-pawn closes the diagonal. That keeps White’s setup active instead of burying the bishop.

- Plain hint: Bring the dark-square bishop outside the pawn chain before closing the triangle.

- Opening themes: bishop outside chain, London identity, d4/e3/c3 shell

### Packet london-white.line-014.ply-11.g1f3

- Move: `Nf3` / `g1f3` at ply 11

- CoachCard: **Guard the London center with the kingside knight** — Nf3 develops behind the London center and helps White castle. The knight also supports the e5 and d4 squares that often decide when White can break.

- Plain hint: Develop the kingside knight to guard the queen-pawn center and prepare castling.

- Opening themes: kingside development, d4/e5 control, castling preparation


## london-white-line-015: 1. d4 Nf6 2. Bf4 e6 3. e3 d5 4. Nf3 Bd6 5. Bg3 Bxg3 6. hxg3 h6

Runtime playKey: `d2d4,g8f6,c1f4,e7e6,e2e3,d7d5,g1f3,f8d6,f4g3,d6g3,h2g3,h7h6`  
Runtime totalGames field at line node: `240142`

### Packet london-white.line-015.ply-01.d2d4

- Move: `d4` / `d2d4` at ply 1

- CoachCard: **Anchor the London queen-pawn center** — d4 creates the d-pawn base the London System is built around. White can now develop the dark-square bishop before closing the pawn triangle.

- Plain hint: Anchor the queen-pawn center before building the London piece shell.

- Opening themes: London d-pawn base, compact setup, bishop outside chain

### Packet london-white.line-015.ply-03.c1f4

- Move: `Bf4` / `c1f4` at ply 3

- CoachCard: **Develop the London bishop before e3** — Bf4 is the key London move: the dark-square bishop comes out before the e-pawn closes the diagonal. That keeps White’s setup active instead of burying the bishop.

- Plain hint: Bring the dark-square bishop outside the pawn chain before closing the triangle.

- Opening themes: bishop outside chain, London identity, d4/e3/c3 shell

### Packet london-white.line-015.ply-05.e2e3

- Move: `e3` / `e2e3` at ply 5

- CoachCard: **Close the London triangle** — e3 supports d4 and forms the London triangle with the c-pawn support when available. It also opens the route for the light-square bishop and castling.

- Plain hint: Close the London triangle while freeing the kingside bishop.

- Opening themes: London triangle, d4 support, king safety route

### Packet london-white.line-015.ply-07.g1f3

- Move: `Nf3` / `g1f3` at ply 7

- CoachCard: **Guard the London center with the kingside knight** — Nf3 develops behind the London center and helps White castle. The knight also supports the e5 and d4 squares that often decide when White can break.

- Plain hint: Develop the kingside knight to guard the queen-pawn center and prepare castling.

- Opening themes: kingside development, d4/e5 control, castling preparation

### Packet london-white.line-015.ply-09.f4g3

- Move: `Bg3` / `f4g3` at ply 9

- CoachCard: **Keep the London shell coherent** — Bg3 stays within the London plan by supporting the d-pawn shell and piece coordination rather than chasing early tactics.

- Plain hint: Keep the London structure compact: bishop outside the chain, pawns supporting the center, and safe kingside development.

- Opening themes: London shell, compact development, center support

### Packet london-white.line-015.ply-11.h2g3

- Move: `hxg3` / `h2g3` at ply 11

- CoachCard: **Keep the London shell coherent** — hxg3 stays within the London plan by supporting the d-pawn shell and piece coordination rather than chasing early tactics.

- Plain hint: Keep the London structure compact: bishop outside the chain, pawns supporting the center, and safe kingside development.

- Opening themes: London shell, compact development, center support


## london-white-line-016: 1. d4 Nf6 2. Bf4 e6 3. e3 c5 4. c3 Nc6 5. Nf3 d5 6. Bd3 Be7

Runtime playKey: `d2d4,g8f6,c1f4,e7e6,e2e3,c7c5,c2c3,b8c6,g1f3,d7d5,f1d3,f8e7`  
Runtime totalGames field at line node: `226034`

### Packet london-white.line-016.ply-01.d2d4

- Move: `d4` / `d2d4` at ply 1

- CoachCard: **Anchor the London queen-pawn center** — d4 creates the d-pawn base the London System is built around. White can now develop the dark-square bishop before closing the pawn triangle.

- Plain hint: Anchor the queen-pawn center before building the London piece shell.

- Opening themes: London d-pawn base, compact setup, bishop outside chain

### Packet london-white.line-016.ply-03.c1f4

- Move: `Bf4` / `c1f4` at ply 3

- CoachCard: **Develop the London bishop before e3** — Bf4 is the key London move: the dark-square bishop comes out before the e-pawn closes the diagonal. That keeps White’s setup active instead of burying the bishop.

- Plain hint: Bring the dark-square bishop outside the pawn chain before closing the triangle.

- Opening themes: bishop outside chain, London identity, d4/e3/c3 shell

### Packet london-white.line-016.ply-05.e2e3

- Move: `e3` / `e2e3` at ply 5

- CoachCard: **Close the London triangle** — e3 supports d4 and forms the London triangle with the c-pawn support when available. It also opens the route for the light-square bishop and castling.

- Plain hint: Close the London triangle while freeing the kingside bishop.

- Opening themes: London triangle, d4 support, king safety route

### Packet london-white.line-016.ply-07.c2c3

- Move: `c3` / `c2c3` at ply 7

- CoachCard: **Reinforce the London shell** — c3 reinforces d4 and completes the compact London pawn shell. This limits Black’s central breaks and prepares quiet development behind the structure.

- Plain hint: Reinforce the queen-pawn center and make the London shell harder to disturb.

- Opening themes: c3/e3/d4 triangle, d4 support, compact London

### Packet london-white.line-016.ply-09.g1f3

- Move: `Nf3` / `g1f3` at ply 9

- CoachCard: **Guard the London center with the kingside knight** — Nf3 develops behind the London center and helps White castle. The knight also supports the e5 and d4 squares that often decide when White can break.

- Plain hint: Develop the kingside knight to guard the queen-pawn center and prepare castling.

- Opening themes: kingside development, d4/e5 control, castling preparation

### Packet london-white.line-016.ply-11.f1d3

- Move: `Bd3` / `f1d3` at ply 11

- CoachCard: **Aim the light-square bishop at the kingside** — Bd3 develops the light-square bishop into the London attacking structure. It complements the bishop outside the chain and prepares castling or kingside pressure.

- Plain hint: Aim the light-square bishop toward the kingside after the London triangle is stable.

- Opening themes: light-square bishop, king safety, London coordination


## london-white-line-017: 1. d4 Nf6 2. Bf4 d5 3. Nf3 Nc6 4. e3 Bg4 5. Nbd2 e6 6. c3 Bd6

Runtime playKey: `d2d4,g8f6,c1f4,d7d5,g1f3,b8c6,e2e3,c8g4,b1d2,e7e6,c2c3,f8d6`  
Runtime totalGames field at line node: `223901`

### Packet london-white.line-017.ply-01.d2d4

- Move: `d4` / `d2d4` at ply 1

- CoachCard: **Anchor the London queen-pawn center** — d4 creates the d-pawn base the London System is built around. White can now develop the dark-square bishop before closing the pawn triangle.

- Plain hint: Anchor the queen-pawn center before building the London piece shell.

- Opening themes: London d-pawn base, compact setup, bishop outside chain

### Packet london-white.line-017.ply-03.c1f4

- Move: `Bf4` / `c1f4` at ply 3

- CoachCard: **Develop the London bishop before e3** — Bf4 is the key London move: the dark-square bishop comes out before the e-pawn closes the diagonal. That keeps White’s setup active instead of burying the bishop.

- Plain hint: Bring the dark-square bishop outside the pawn chain before closing the triangle.

- Opening themes: bishop outside chain, London identity, d4/e3/c3 shell

### Packet london-white.line-017.ply-05.g1f3

- Move: `Nf3` / `g1f3` at ply 5

- CoachCard: **Guard the London center with the kingside knight** — Nf3 develops behind the London center and helps White castle. The knight also supports the e5 and d4 squares that often decide when White can break.

- Plain hint: Develop the kingside knight to guard the queen-pawn center and prepare castling.

- Opening themes: kingside development, d4/e5 control, castling preparation

### Packet london-white.line-017.ply-07.e2e3

- Move: `e3` / `e2e3` at ply 7

- CoachCard: **Close the London triangle** — e3 supports d4 and forms the London triangle with the c-pawn support when available. It also opens the route for the light-square bishop and castling.

- Plain hint: Close the London triangle while freeing the kingside bishop.

- Opening themes: London triangle, d4 support, king safety route

### Packet london-white.line-017.ply-09.b1d2

- Move: `Nbd2` / `b1d2` at ply 9

- CoachCard: **Use the London Nbd2 route** — Nbd2 is a typical London knight route: the knight supports the center from behind and keeps c-pawn structures flexible. It also helps prepare a future central push.

- Plain hint: Route the queenside knight behind the center to support future central breaks.

- Opening themes: Nbd2 route, central support, London flexibility

### Packet london-white.line-017.ply-11.c2c3

- Move: `c3` / `c2c3` at ply 11

- CoachCard: **Reinforce the London shell** — c3 reinforces d4 and completes the compact London pawn shell. This limits Black’s central breaks and prepares quiet development behind the structure.

- Plain hint: Reinforce the queen-pawn center and make the London shell harder to disturb.

- Opening themes: c3/e3/d4 triangle, d4 support, compact London


## london-white-line-018: 1. d4 Nf6 2. Bf4 e6 3. e3 c5 4. c3 cxd4 5. exd4 Nc6 6. Bd3 d5

Runtime playKey: `d2d4,g8f6,c1f4,e7e6,e2e3,c7c5,c2c3,c5d4,e3d4,b8c6,f1d3,d7d5`  
Runtime totalGames field at line node: `211070`

### Packet london-white.line-018.ply-01.d2d4

- Move: `d4` / `d2d4` at ply 1

- CoachCard: **Anchor the London queen-pawn center** — d4 creates the d-pawn base the London System is built around. White can now develop the dark-square bishop before closing the pawn triangle.

- Plain hint: Anchor the queen-pawn center before building the London piece shell.

- Opening themes: London d-pawn base, compact setup, bishop outside chain

### Packet london-white.line-018.ply-03.c1f4

- Move: `Bf4` / `c1f4` at ply 3

- CoachCard: **Develop the London bishop before e3** — Bf4 is the key London move: the dark-square bishop comes out before the e-pawn closes the diagonal. That keeps White’s setup active instead of burying the bishop.

- Plain hint: Bring the dark-square bishop outside the pawn chain before closing the triangle.

- Opening themes: bishop outside chain, London identity, d4/e3/c3 shell

### Packet london-white.line-018.ply-05.e2e3

- Move: `e3` / `e2e3` at ply 5

- CoachCard: **Close the London triangle** — e3 supports d4 and forms the London triangle with the c-pawn support when available. It also opens the route for the light-square bishop and castling.

- Plain hint: Close the London triangle while freeing the kingside bishop.

- Opening themes: London triangle, d4 support, king safety route

### Packet london-white.line-018.ply-07.c2c3

- Move: `c3` / `c2c3` at ply 7

- CoachCard: **Reinforce the London shell** — c3 reinforces d4 and completes the compact London pawn shell. This limits Black’s central breaks and prepares quiet development behind the structure.

- Plain hint: Reinforce the queen-pawn center and make the London shell harder to disturb.

- Opening themes: c3/e3/d4 triangle, d4 support, compact London

### Packet london-white.line-018.ply-09.e3d4

- Move: `exd4` / `e3d4` at ply 9

- CoachCard: **Keep the London shell coherent** — exd4 stays within the London plan by supporting the d-pawn shell and piece coordination rather than chasing early tactics.

- Plain hint: Keep the London structure compact: bishop outside the chain, pawns supporting the center, and safe kingside development.

- Opening themes: London shell, compact development, center support

### Packet london-white.line-018.ply-11.f1d3

- Move: `Bd3` / `f1d3` at ply 11

- CoachCard: **Aim the light-square bishop at the kingside** — Bd3 develops the light-square bishop into the London attacking structure. It complements the bishop outside the chain and prepares castling or kingside pressure.

- Plain hint: Aim the light-square bishop toward the kingside after the London triangle is stable.

- Opening themes: light-square bishop, king safety, London coordination


## london-white-line-019: 1. d4 Nf6 2. Bf4 d5 3. Nf3 Bf5 4. e3 e6 5. Bd3 Bxd3 6. Qxd3 Bd6

Runtime playKey: `d2d4,g8f6,c1f4,d7d5,g1f3,c8f5,e2e3,e7e6,f1d3,f5d3,d1d3,f8d6`  
Runtime totalGames field at line node: `203537`

### Packet london-white.line-019.ply-01.d2d4

- Move: `d4` / `d2d4` at ply 1

- CoachCard: **Anchor the London queen-pawn center** — d4 creates the d-pawn base the London System is built around. White can now develop the dark-square bishop before closing the pawn triangle.

- Plain hint: Anchor the queen-pawn center before building the London piece shell.

- Opening themes: London d-pawn base, compact setup, bishop outside chain

### Packet london-white.line-019.ply-03.c1f4

- Move: `Bf4` / `c1f4` at ply 3

- CoachCard: **Develop the London bishop before e3** — Bf4 is the key London move: the dark-square bishop comes out before the e-pawn closes the diagonal. That keeps White’s setup active instead of burying the bishop.

- Plain hint: Bring the dark-square bishop outside the pawn chain before closing the triangle.

- Opening themes: bishop outside chain, London identity, d4/e3/c3 shell

### Packet london-white.line-019.ply-05.g1f3

- Move: `Nf3` / `g1f3` at ply 5

- CoachCard: **Guard the London center with the kingside knight** — Nf3 develops behind the London center and helps White castle. The knight also supports the e5 and d4 squares that often decide when White can break.

- Plain hint: Develop the kingside knight to guard the queen-pawn center and prepare castling.

- Opening themes: kingside development, d4/e5 control, castling preparation

### Packet london-white.line-019.ply-07.e2e3

- Move: `e3` / `e2e3` at ply 7

- CoachCard: **Close the London triangle** — e3 supports d4 and forms the London triangle with the c-pawn support when available. It also opens the route for the light-square bishop and castling.

- Plain hint: Close the London triangle while freeing the kingside bishop.

- Opening themes: London triangle, d4 support, king safety route

### Packet london-white.line-019.ply-09.f1d3

- Move: `Bd3` / `f1d3` at ply 9

- CoachCard: **Aim the light-square bishop at the kingside** — Bd3 develops the light-square bishop into the London attacking structure. It complements the bishop outside the chain and prepares castling or kingside pressure.

- Plain hint: Aim the light-square bishop toward the kingside after the London triangle is stable.

- Opening themes: light-square bishop, king safety, London coordination

### Packet london-white.line-019.ply-11.d1d3

- Move: `Qxd3` / `d1d3` at ply 11

- CoachCard: **Keep the London shell coherent** — Qxd3 stays within the London plan by supporting the d-pawn shell and piece coordination rather than chasing early tactics.

- Plain hint: Keep the London structure compact: bishop outside the chain, pawns supporting the center, and safe kingside development.

- Opening themes: London shell, compact development, center support


## london-white-line-020: 1. d4 Nf6 2. Bf4 d5 3. Nf3 Nc6 4. e3 e6 5. c3 Bd6 6. Bg3 Bxg3

Runtime playKey: `d2d4,g8f6,c1f4,d7d5,g1f3,b8c6,e2e3,e7e6,c2c3,f8d6,f4g3,d6g3`  
Runtime totalGames field at line node: `197220`

### Packet london-white.line-020.ply-01.d2d4

- Move: `d4` / `d2d4` at ply 1

- CoachCard: **Anchor the London queen-pawn center** — d4 creates the d-pawn base the London System is built around. White can now develop the dark-square bishop before closing the pawn triangle.

- Plain hint: Anchor the queen-pawn center before building the London piece shell.

- Opening themes: London d-pawn base, compact setup, bishop outside chain

### Packet london-white.line-020.ply-03.c1f4

- Move: `Bf4` / `c1f4` at ply 3

- CoachCard: **Develop the London bishop before e3** — Bf4 is the key London move: the dark-square bishop comes out before the e-pawn closes the diagonal. That keeps White’s setup active instead of burying the bishop.

- Plain hint: Bring the dark-square bishop outside the pawn chain before closing the triangle.

- Opening themes: bishop outside chain, London identity, d4/e3/c3 shell

### Packet london-white.line-020.ply-05.g1f3

- Move: `Nf3` / `g1f3` at ply 5

- CoachCard: **Guard the London center with the kingside knight** — Nf3 develops behind the London center and helps White castle. The knight also supports the e5 and d4 squares that often decide when White can break.

- Plain hint: Develop the kingside knight to guard the queen-pawn center and prepare castling.

- Opening themes: kingside development, d4/e5 control, castling preparation

### Packet london-white.line-020.ply-07.e2e3

- Move: `e3` / `e2e3` at ply 7

- CoachCard: **Close the London triangle** — e3 supports d4 and forms the London triangle with the c-pawn support when available. It also opens the route for the light-square bishop and castling.

- Plain hint: Close the London triangle while freeing the kingside bishop.

- Opening themes: London triangle, d4 support, king safety route

### Packet london-white.line-020.ply-09.c2c3

- Move: `c3` / `c2c3` at ply 9

- CoachCard: **Reinforce the London shell** — c3 reinforces d4 and completes the compact London pawn shell. This limits Black’s central breaks and prepares quiet development behind the structure.

- Plain hint: Reinforce the queen-pawn center and make the London shell harder to disturb.

- Opening themes: c3/e3/d4 triangle, d4 support, compact London

### Packet london-white.line-020.ply-11.f4g3

- Move: `Bg3` / `f4g3` at ply 11

- CoachCard: **Keep the London shell coherent** — Bg3 stays within the London plan by supporting the d-pawn shell and piece coordination rather than chasing early tactics.

- Plain hint: Keep the London structure compact: bishop outside the chain, pawns supporting the center, and safe kingside development.

- Opening themes: London shell, compact development, center support
