# Italian Game approved-content candidates

Opening ID: `italian-white`  
Status: approved candidates only; not app-activated.


## italian-white-line-001: 1. e4 e5 2. Nf3 Nc6 3. Bc4 Nf6 4. Ng5 d5 5. exd5 Na5 6. Bb5+ c6

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1c4,g8f6,f3g5,d7d5,e4d5,c6a5,c4b5,c7c6`  
Runtime totalGames field at line node: `4063553`

### Packet italian-white.line-001.ply-05.f1c4

- Move: `Bc4` / `f1c4` at ply 5

- CoachCard: **Put the bishop on the f7 diagonal** — Bc4 places the bishop on the classic Italian diagonal toward f7. That target shapes both quiet c3/d4 plans and sharper Two Knights ideas.

- Plain hint: Place the light-square bishop on the Italian diagonal where it eyes Black’s weakest kingside point.

- Opening themes: bishop on c4, f7 pressure, Italian diagonal

### Packet italian-white.line-001.ply-07.f3g5

- Move: `Ng5` / `f3g5` at ply 7

- CoachCard: **Add a second attacker to f7** — Ng5 is a Two Knights-style jump that combines with the c4 bishop against f7. White is choosing immediate pressure rather than a quiet d3 setup.

- Plain hint: Add a second attacker to Black’s vulnerable kingside point before Black finishes development.

- Opening themes: Two Knights pressure, f7 target, king-in-center pressure

### Packet italian-white.line-001.ply-09.e4d5

- Move: `exd5` / `e4d5` at ply 9

- CoachCard: **Open the Italian center at the right moment** — exd5 removes a central pawn and keeps the Italian line open for developed pieces. In these branches, White’s center decision is tied to the pressure already built by the bishop and knight.

- Plain hint: Remove Black’s central pawn while keeping the Italian pressure aimed at the kingside.

- Opening themes: central tension, open Italian center, piece activity

### Packet italian-white.line-001.ply-11.c4b5

- Move: `Bb5+` / `c4b5` at ply 11

- CoachCard: **Use the Italian bishop with tempo** — Bb5+ gives check with the bishop that began on the Italian diagonal. The move keeps White’s initiative connected to development rather than a loose queen sortie.

- Plain hint: Use the developed bishop to force Black to spend a tempo answering check.

- Opening themes: bishop tempo, king safety pressure, Italian initiative


## italian-white-line-002: 1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. c3 Nf6 5. d4 exd4 6. cxd4 Bb4+

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1c4,f8c5,c2c3,g8f6,d2d4,e5d4,c3d4,c5b4`  
Runtime totalGames field at line node: `3593728`

### Packet italian-white.line-002.ply-05.f1c4

- Move: `Bc4` / `f1c4` at ply 5

- CoachCard: **Put the bishop on the f7 diagonal** — Bc4 places the bishop on the classic Italian diagonal toward f7. That target shapes both quiet c3/d4 plans and sharper Two Knights ideas.

- Plain hint: Place the light-square bishop on the Italian diagonal where it eyes Black’s weakest kingside point.

- Opening themes: bishop on c4, f7 pressure, Italian diagonal

### Packet italian-white.line-002.ply-07.c2c3

- Move: `c3` / `c2c3` at ply 7

- CoachCard: **Prepare the c3/d4 Italian break** — c3 supports the d-pawn advance that is central to many Italian Game structures. It challenges Black’s e5 pawn without moving the c4 bishop off its attacking diagonal.

- Plain hint: Prepare the central pawn break that challenges Black’s e-pawn.

- Opening themes: c3/d4 break, e5 challenge, Italian center

### Packet italian-white.line-002.ply-09.d2d4

- Move: `d4` / `d2d4` at ply 9

- CoachCard: **Strike with the Italian d-pawn** — d4 is the prepared Italian central break. White uses development and bishop pressure to challenge Black’s e-pawn rather than sitting passively.

- Plain hint: Strike in the center once the Italian pieces are ready.

- Opening themes: d4 break, central challenge, Italian initiative

### Packet italian-white.line-002.ply-11.c3d4

- Move: `cxd4` / `c3d4` at ply 11

- CoachCard: **Open the Italian center at the right moment** — cxd4 removes a central pawn and keeps the Italian line open for developed pieces. In these branches, White’s center decision is tied to the pressure already built by the bishop and knight.

- Plain hint: Remove Black’s central pawn while keeping the Italian pressure aimed at the kingside.

- Opening themes: central tension, open Italian center, piece activity


## italian-white-line-003: 1. e4 e5 2. Nf3 Nc6 3. Bc4 Nf6 4. Ng5 d5 5. exd5 Nxd5 6. Nxf7 Kxf7

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1c4,g8f6,f3g5,d7d5,e4d5,f6d5,g5f7,e8f7`  
Runtime totalGames field at line node: `3051765`

### Packet italian-white.line-003.ply-05.f1c4

- Move: `Bc4` / `f1c4` at ply 5

- CoachCard: **Put the bishop on the f7 diagonal** — Bc4 places the bishop on the classic Italian diagonal toward f7. That target shapes both quiet c3/d4 plans and sharper Two Knights ideas.

- Plain hint: Place the light-square bishop on the Italian diagonal where it eyes Black’s weakest kingside point.

- Opening themes: bishop on c4, f7 pressure, Italian diagonal

### Packet italian-white.line-003.ply-07.f3g5

- Move: `Ng5` / `f3g5` at ply 7

- CoachCard: **Add a second attacker to f7** — Ng5 is a Two Knights-style jump that combines with the c4 bishop against f7. White is choosing immediate pressure rather than a quiet d3 setup.

- Plain hint: Add a second attacker to Black’s vulnerable kingside point before Black finishes development.

- Opening themes: Two Knights pressure, f7 target, king-in-center pressure

### Packet italian-white.line-003.ply-09.e4d5

- Move: `exd5` / `e4d5` at ply 9

- CoachCard: **Open the Italian center at the right moment** — exd5 removes a central pawn and keeps the Italian line open for developed pieces. In these branches, White’s center decision is tied to the pressure already built by the bishop and knight.

- Plain hint: Remove Black’s central pawn while keeping the Italian pressure aimed at the kingside.

- Opening themes: central tension, open Italian center, piece activity

### Packet italian-white.line-003.ply-11.g5f7

- Move: `Nxf7` / `g5f7` at ply 11

- CoachCard: **Coordinate the Italian pieces** — Nxf7 keeps the move tied to the Italian plan: central control, quick kingside safety, and pressure from developed minor pieces.

- Plain hint: Coordinate the Italian pieces around the center, kingside safety, and the pressure line toward Black’s king.

- Opening themes: Italian coordination, center, king safety


## italian-white-line-004: 1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. c3 d6 5. d4 exd4 6. cxd4 Bb6

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1c4,f8c5,c2c3,d7d6,d2d4,e5d4,c3d4,c5b6`  
Runtime totalGames field at line node: `1436145`

### Packet italian-white.line-004.ply-05.f1c4

- Move: `Bc4` / `f1c4` at ply 5

- CoachCard: **Put the bishop on the f7 diagonal** — Bc4 places the bishop on the classic Italian diagonal toward f7. That target shapes both quiet c3/d4 plans and sharper Two Knights ideas.

- Plain hint: Place the light-square bishop on the Italian diagonal where it eyes Black’s weakest kingside point.

- Opening themes: bishop on c4, f7 pressure, Italian diagonal

### Packet italian-white.line-004.ply-07.c2c3

- Move: `c3` / `c2c3` at ply 7

- CoachCard: **Prepare the c3/d4 Italian break** — c3 supports the d-pawn advance that is central to many Italian Game structures. It challenges Black’s e5 pawn without moving the c4 bishop off its attacking diagonal.

- Plain hint: Prepare the central pawn break that challenges Black’s e-pawn.

- Opening themes: c3/d4 break, e5 challenge, Italian center

### Packet italian-white.line-004.ply-09.d2d4

- Move: `d4` / `d2d4` at ply 9

- CoachCard: **Strike with the Italian d-pawn** — d4 is the prepared Italian central break. White uses development and bishop pressure to challenge Black’s e-pawn rather than sitting passively.

- Plain hint: Strike in the center once the Italian pieces are ready.

- Opening themes: d4 break, central challenge, Italian initiative

### Packet italian-white.line-004.ply-11.c3d4

- Move: `cxd4` / `c3d4` at ply 11

- CoachCard: **Open the Italian center at the right moment** — cxd4 removes a central pawn and keeps the Italian line open for developed pieces. In these branches, White’s center decision is tied to the pressure already built by the bishop and knight.

- Plain hint: Remove Black’s central pawn while keeping the Italian pressure aimed at the kingside.

- Opening themes: central tension, open Italian center, piece activity


## italian-white-line-005: 1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. c3 d6 5. d4 exd4 6. cxd4 Bb4+

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1c4,f8c5,c2c3,d7d6,d2d4,e5d4,c3d4,c5b4`  
Runtime totalGames field at line node: `1434702`

### Packet italian-white.line-005.ply-05.f1c4

- Move: `Bc4` / `f1c4` at ply 5

- CoachCard: **Put the bishop on the f7 diagonal** — Bc4 places the bishop on the classic Italian diagonal toward f7. That target shapes both quiet c3/d4 plans and sharper Two Knights ideas.

- Plain hint: Place the light-square bishop on the Italian diagonal where it eyes Black’s weakest kingside point.

- Opening themes: bishop on c4, f7 pressure, Italian diagonal

### Packet italian-white.line-005.ply-07.c2c3

- Move: `c3` / `c2c3` at ply 7

- CoachCard: **Prepare the c3/d4 Italian break** — c3 supports the d-pawn advance that is central to many Italian Game structures. It challenges Black’s e5 pawn without moving the c4 bishop off its attacking diagonal.

- Plain hint: Prepare the central pawn break that challenges Black’s e-pawn.

- Opening themes: c3/d4 break, e5 challenge, Italian center

### Packet italian-white.line-005.ply-09.d2d4

- Move: `d4` / `d2d4` at ply 9

- CoachCard: **Strike with the Italian d-pawn** — d4 is the prepared Italian central break. White uses development and bishop pressure to challenge Black’s e-pawn rather than sitting passively.

- Plain hint: Strike in the center once the Italian pieces are ready.

- Opening themes: d4 break, central challenge, Italian initiative

### Packet italian-white.line-005.ply-11.c3d4

- Move: `cxd4` / `c3d4` at ply 11

- CoachCard: **Open the Italian center at the right moment** — cxd4 removes a central pawn and keeps the Italian line open for developed pieces. In these branches, White’s center decision is tied to the pressure already built by the bishop and knight.

- Plain hint: Remove Black’s central pawn while keeping the Italian pressure aimed at the kingside.

- Opening themes: central tension, open Italian center, piece activity


## italian-white-line-006: 1. e4 e5 2. Nf3 Nc6 3. Bc4 Nf6 4. Ng5 d5 5. exd5 Na5 6. Bb5+ Bd7

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1c4,g8f6,f3g5,d7d5,e4d5,c6a5,c4b5,c8d7`  
Runtime totalGames field at line node: `841231`

### Packet italian-white.line-006.ply-05.f1c4

- Move: `Bc4` / `f1c4` at ply 5

- CoachCard: **Put the bishop on the f7 diagonal** — Bc4 places the bishop on the classic Italian diagonal toward f7. That target shapes both quiet c3/d4 plans and sharper Two Knights ideas.

- Plain hint: Place the light-square bishop on the Italian diagonal where it eyes Black’s weakest kingside point.

- Opening themes: bishop on c4, f7 pressure, Italian diagonal

### Packet italian-white.line-006.ply-07.f3g5

- Move: `Ng5` / `f3g5` at ply 7

- CoachCard: **Add a second attacker to f7** — Ng5 is a Two Knights-style jump that combines with the c4 bishop against f7. White is choosing immediate pressure rather than a quiet d3 setup.

- Plain hint: Add a second attacker to Black’s vulnerable kingside point before Black finishes development.

- Opening themes: Two Knights pressure, f7 target, king-in-center pressure

### Packet italian-white.line-006.ply-09.e4d5

- Move: `exd5` / `e4d5` at ply 9

- CoachCard: **Open the Italian center at the right moment** — exd5 removes a central pawn and keeps the Italian line open for developed pieces. In these branches, White’s center decision is tied to the pressure already built by the bishop and knight.

- Plain hint: Remove Black’s central pawn while keeping the Italian pressure aimed at the kingside.

- Opening themes: central tension, open Italian center, piece activity

### Packet italian-white.line-006.ply-11.c4b5

- Move: `Bb5+` / `c4b5` at ply 11

- CoachCard: **Use the Italian bishop with tempo** — Bb5+ gives check with the bishop that began on the Italian diagonal. The move keeps White’s initiative connected to development rather than a loose queen sortie.

- Plain hint: Use the developed bishop to force Black to spend a tempo answering check.

- Opening themes: bishop tempo, king safety pressure, Italian initiative


## italian-white-line-007: 1. e4 e5 2. Nf3 Nc6 3. Bc4 h6 4. d4 exd4 5. Nxd4 Nxd4 6. Qxd4 d6

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1c4,h7h6,d2d4,e5d4,f3d4,c6d4,d1d4,d7d6`  
Runtime totalGames field at line node: `836792`

### Packet italian-white.line-007.ply-05.f1c4

- Move: `Bc4` / `f1c4` at ply 5

- CoachCard: **Put the bishop on the f7 diagonal** — Bc4 places the bishop on the classic Italian diagonal toward f7. That target shapes both quiet c3/d4 plans and sharper Two Knights ideas.

- Plain hint: Place the light-square bishop on the Italian diagonal where it eyes Black’s weakest kingside point.

- Opening themes: bishop on c4, f7 pressure, Italian diagonal

### Packet italian-white.line-007.ply-07.d2d4

- Move: `d4` / `d2d4` at ply 7

- CoachCard: **Strike with the Italian d-pawn** — d4 is the prepared Italian central break. White uses development and bishop pressure to challenge Black’s e-pawn rather than sitting passively.

- Plain hint: Strike in the center once the Italian pieces are ready.

- Opening themes: d4 break, central challenge, Italian initiative

### Packet italian-white.line-007.ply-09.f3d4

- Move: `Nxd4` / `f3d4` at ply 9

- CoachCard: **Coordinate the Italian pieces** — Nxd4 keeps the move tied to the Italian plan: central control, quick kingside safety, and pressure from developed minor pieces.

- Plain hint: Coordinate the Italian pieces around the center, kingside safety, and the pressure line toward Black’s king.

- Opening themes: Italian coordination, center, king safety

### Packet italian-white.line-007.ply-11.d1d4

- Move: `Qxd4` / `d1d4` at ply 11

- CoachCard: **Coordinate the Italian pieces** — Qxd4 keeps the move tied to the Italian plan: central control, quick kingside safety, and pressure from developed minor pieces.

- Plain hint: Coordinate the Italian pieces around the center, kingside safety, and the pressure line toward Black’s king.

- Opening themes: Italian coordination, center, king safety


## italian-white-line-008: 1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. c3 Nf6 5. d4 exd4 6. cxd4 Bb6

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1c4,f8c5,c2c3,g8f6,d2d4,e5d4,c3d4,c5b6`  
Runtime totalGames field at line node: `698730`

### Packet italian-white.line-008.ply-05.f1c4

- Move: `Bc4` / `f1c4` at ply 5

- CoachCard: **Put the bishop on the f7 diagonal** — Bc4 places the bishop on the classic Italian diagonal toward f7. That target shapes both quiet c3/d4 plans and sharper Two Knights ideas.

- Plain hint: Place the light-square bishop on the Italian diagonal where it eyes Black’s weakest kingside point.

- Opening themes: bishop on c4, f7 pressure, Italian diagonal

### Packet italian-white.line-008.ply-07.c2c3

- Move: `c3` / `c2c3` at ply 7

- CoachCard: **Prepare the c3/d4 Italian break** — c3 supports the d-pawn advance that is central to many Italian Game structures. It challenges Black’s e5 pawn without moving the c4 bishop off its attacking diagonal.

- Plain hint: Prepare the central pawn break that challenges Black’s e-pawn.

- Opening themes: c3/d4 break, e5 challenge, Italian center

### Packet italian-white.line-008.ply-09.d2d4

- Move: `d4` / `d2d4` at ply 9

- CoachCard: **Strike with the Italian d-pawn** — d4 is the prepared Italian central break. White uses development and bishop pressure to challenge Black’s e-pawn rather than sitting passively.

- Plain hint: Strike in the center once the Italian pieces are ready.

- Opening themes: d4 break, central challenge, Italian initiative

### Packet italian-white.line-008.ply-11.c3d4

- Move: `cxd4` / `c3d4` at ply 11

- CoachCard: **Open the Italian center at the right moment** — cxd4 removes a central pawn and keeps the Italian line open for developed pieces. In these branches, White’s center decision is tied to the pressure already built by the bishop and knight.

- Plain hint: Remove Black’s central pawn while keeping the Italian pressure aimed at the kingside.

- Opening themes: central tension, open Italian center, piece activity


## italian-white-line-009: 1. e4 e5 2. Nf3 Nc6 3. Bc4 Nf6 4. Ng5 d5 5. exd5 Nxd5 6. Qf3 Qxg5

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1c4,g8f6,f3g5,d7d5,e4d5,f6d5,d1f3,d8g5`  
Runtime totalGames field at line node: `647443`

### Packet italian-white.line-009.ply-05.f1c4

- Move: `Bc4` / `f1c4` at ply 5

- CoachCard: **Put the bishop on the f7 diagonal** — Bc4 places the bishop on the classic Italian diagonal toward f7. That target shapes both quiet c3/d4 plans and sharper Two Knights ideas.

- Plain hint: Place the light-square bishop on the Italian diagonal where it eyes Black’s weakest kingside point.

- Opening themes: bishop on c4, f7 pressure, Italian diagonal

### Packet italian-white.line-009.ply-07.f3g5

- Move: `Ng5` / `f3g5` at ply 7

- CoachCard: **Add a second attacker to f7** — Ng5 is a Two Knights-style jump that combines with the c4 bishop against f7. White is choosing immediate pressure rather than a quiet d3 setup.

- Plain hint: Add a second attacker to Black’s vulnerable kingside point before Black finishes development.

- Opening themes: Two Knights pressure, f7 target, king-in-center pressure

### Packet italian-white.line-009.ply-09.e4d5

- Move: `exd5` / `e4d5` at ply 9

- CoachCard: **Open the Italian center at the right moment** — exd5 removes a central pawn and keeps the Italian line open for developed pieces. In these branches, White’s center decision is tied to the pressure already built by the bishop and knight.

- Plain hint: Remove Black’s central pawn while keeping the Italian pressure aimed at the kingside.

- Opening themes: central tension, open Italian center, piece activity

### Packet italian-white.line-009.ply-11.d1f3

- Move: `Qf3` / `d1f3` at ply 11

- CoachCard: **Coordinate the Italian pieces** — Qf3 keeps the move tied to the Italian plan: central control, quick kingside safety, and pressure from developed minor pieces.

- Plain hint: Coordinate the Italian pieces around the center, kingside safety, and the pressure line toward Black’s king.

- Opening themes: Italian coordination, center, king safety


## italian-white-line-010: 1. e4 e5 2. Nf3 Nc6 3. Bc4 Nf6 4. d3 h6 5. Nc3 Bc5 6. Be3 Bxe3

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1c4,g8f6,d2d3,h7h6,b1c3,f8c5,c1e3,c5e3`  
Runtime totalGames field at line node: `643093`

### Packet italian-white.line-010.ply-05.f1c4

- Move: `Bc4` / `f1c4` at ply 5

- CoachCard: **Put the bishop on the f7 diagonal** — Bc4 places the bishop on the classic Italian diagonal toward f7. That target shapes both quiet c3/d4 plans and sharper Two Knights ideas.

- Plain hint: Place the light-square bishop on the Italian diagonal where it eyes Black’s weakest kingside point.

- Opening themes: bishop on c4, f7 pressure, Italian diagonal

### Packet italian-white.line-010.ply-07.d2d3

- Move: `d3` / `d2d3` at ply 7

- CoachCard: **Build the quiet Italian base** — d3 supports the e-pawn and keeps the bishop on c4 useful without forcing immediate tactics. This is the quiet Italian route toward castling and later central play.

- Plain hint: Support the king pawn and keep the quiet Italian structure flexible.

- Opening themes: quiet Italian, e-pawn support, central timing

### Packet italian-white.line-010.ply-09.b1c3

- Move: `Nc3` / `b1c3` at ply 9

- CoachCard: **Coordinate the Italian pieces** — Nc3 keeps the move tied to the Italian plan: central control, quick kingside safety, and pressure from developed minor pieces.

- Plain hint: Coordinate the Italian pieces around the center, kingside safety, and the pressure line toward Black’s king.

- Opening themes: Italian coordination, center, king safety

### Packet italian-white.line-010.ply-11.c1e3

- Move: `Be3` / `c1e3` at ply 11

- CoachCard: **Coordinate the Italian pieces** — Be3 keeps the move tied to the Italian plan: central control, quick kingside safety, and pressure from developed minor pieces.

- Plain hint: Coordinate the Italian pieces around the center, kingside safety, and the pressure line toward Black’s king.

- Opening themes: Italian coordination, center, king safety


## italian-white-line-011: 1. e4 e5 2. Nf3 Nc6 3. Bc4 Nf6 4. Ng5 Bc5 5. Nxf7 Bxf2+ 6. Kxf2 Nxe4+

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1c4,g8f6,f3g5,f8c5,g5f7,c5f2,e1f2,f6e4`  
Runtime totalGames field at line node: `626693`

### Packet italian-white.line-011.ply-05.f1c4

- Move: `Bc4` / `f1c4` at ply 5

- CoachCard: **Put the bishop on the f7 diagonal** — Bc4 places the bishop on the classic Italian diagonal toward f7. That target shapes both quiet c3/d4 plans and sharper Two Knights ideas.

- Plain hint: Place the light-square bishop on the Italian diagonal where it eyes Black’s weakest kingside point.

- Opening themes: bishop on c4, f7 pressure, Italian diagonal

### Packet italian-white.line-011.ply-07.f3g5

- Move: `Ng5` / `f3g5` at ply 7

- CoachCard: **Add a second attacker to f7** — Ng5 is a Two Knights-style jump that combines with the c4 bishop against f7. White is choosing immediate pressure rather than a quiet d3 setup.

- Plain hint: Add a second attacker to Black’s vulnerable kingside point before Black finishes development.

- Opening themes: Two Knights pressure, f7 target, king-in-center pressure

### Packet italian-white.line-011.ply-09.g5f7

- Move: `Nxf7` / `g5f7` at ply 9

- CoachCard: **Coordinate the Italian pieces** — Nxf7 keeps the move tied to the Italian plan: central control, quick kingside safety, and pressure from developed minor pieces.

- Plain hint: Coordinate the Italian pieces around the center, kingside safety, and the pressure line toward Black’s king.

- Opening themes: Italian coordination, center, king safety

### Packet italian-white.line-011.ply-11.e1f2

- Move: `Kxf2` / `e1f2` at ply 11

- CoachCard: **Coordinate the Italian pieces** — Kxf2 keeps the move tied to the Italian plan: central control, quick kingside safety, and pressure from developed minor pieces.

- Plain hint: Coordinate the Italian pieces around the center, kingside safety, and the pressure line toward Black’s king.

- Opening themes: Italian coordination, center, king safety


## italian-white-line-012: 1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. c3 Nf6 5. d4 exd4 6. e5 d5

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1c4,f8c5,c2c3,g8f6,d2d4,e5d4,e4e5,d7d5`  
Runtime totalGames field at line node: `588357`

### Packet italian-white.line-012.ply-05.f1c4

- Move: `Bc4` / `f1c4` at ply 5

- CoachCard: **Put the bishop on the f7 diagonal** — Bc4 places the bishop on the classic Italian diagonal toward f7. That target shapes both quiet c3/d4 plans and sharper Two Knights ideas.

- Plain hint: Place the light-square bishop on the Italian diagonal where it eyes Black’s weakest kingside point.

- Opening themes: bishop on c4, f7 pressure, Italian diagonal

### Packet italian-white.line-012.ply-07.c2c3

- Move: `c3` / `c2c3` at ply 7

- CoachCard: **Prepare the c3/d4 Italian break** — c3 supports the d-pawn advance that is central to many Italian Game structures. It challenges Black’s e5 pawn without moving the c4 bishop off its attacking diagonal.

- Plain hint: Prepare the central pawn break that challenges Black’s e-pawn.

- Opening themes: c3/d4 break, e5 challenge, Italian center

### Packet italian-white.line-012.ply-09.d2d4

- Move: `d4` / `d2d4` at ply 9

- CoachCard: **Strike with the Italian d-pawn** — d4 is the prepared Italian central break. White uses development and bishop pressure to challenge Black’s e-pawn rather than sitting passively.

- Plain hint: Strike in the center once the Italian pieces are ready.

- Opening themes: d4 break, central challenge, Italian initiative

### Packet italian-white.line-012.ply-11.e4e5

- Move: `e5` / `e4e5` at ply 11

- CoachCard: **Coordinate the Italian pieces** — e5 keeps the move tied to the Italian plan: central control, quick kingside safety, and pressure from developed minor pieces.

- Plain hint: Coordinate the Italian pieces around the center, kingside safety, and the pressure line toward Black’s king.

- Opening themes: Italian coordination, center, king safety


## italian-white-line-013: 1. e4 e5 2. Nf3 Nc6 3. Bc4 Nf6 4. d3 h6 5. Nc3 Bc5 6. Be3 Bb6

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1c4,g8f6,d2d3,h7h6,b1c3,f8c5,c1e3,c5b6`  
Runtime totalGames field at line node: `560554`

### Packet italian-white.line-013.ply-05.f1c4

- Move: `Bc4` / `f1c4` at ply 5

- CoachCard: **Put the bishop on the f7 diagonal** — Bc4 places the bishop on the classic Italian diagonal toward f7. That target shapes both quiet c3/d4 plans and sharper Two Knights ideas.

- Plain hint: Place the light-square bishop on the Italian diagonal where it eyes Black’s weakest kingside point.

- Opening themes: bishop on c4, f7 pressure, Italian diagonal

### Packet italian-white.line-013.ply-07.d2d3

- Move: `d3` / `d2d3` at ply 7

- CoachCard: **Build the quiet Italian base** — d3 supports the e-pawn and keeps the bishop on c4 useful without forcing immediate tactics. This is the quiet Italian route toward castling and later central play.

- Plain hint: Support the king pawn and keep the quiet Italian structure flexible.

- Opening themes: quiet Italian, e-pawn support, central timing

### Packet italian-white.line-013.ply-09.b1c3

- Move: `Nc3` / `b1c3` at ply 9

- CoachCard: **Coordinate the Italian pieces** — Nc3 keeps the move tied to the Italian plan: central control, quick kingside safety, and pressure from developed minor pieces.

- Plain hint: Coordinate the Italian pieces around the center, kingside safety, and the pressure line toward Black’s king.

- Opening themes: Italian coordination, center, king safety

### Packet italian-white.line-013.ply-11.c1e3

- Move: `Be3` / `c1e3` at ply 11

- CoachCard: **Coordinate the Italian pieces** — Be3 keeps the move tied to the Italian plan: central control, quick kingside safety, and pressure from developed minor pieces.

- Plain hint: Coordinate the Italian pieces around the center, kingside safety, and the pressure line toward Black’s king.

- Opening themes: Italian coordination, center, king safety


## italian-white-line-014: 1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. c3 Nf6 5. d3 d6 6. h3 h6

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1c4,f8c5,c2c3,g8f6,d2d3,d7d6,h2h3,h7h6`  
Runtime totalGames field at line node: `513385`

### Packet italian-white.line-014.ply-05.f1c4

- Move: `Bc4` / `f1c4` at ply 5

- CoachCard: **Put the bishop on the f7 diagonal** — Bc4 places the bishop on the classic Italian diagonal toward f7. That target shapes both quiet c3/d4 plans and sharper Two Knights ideas.

- Plain hint: Place the light-square bishop on the Italian diagonal where it eyes Black’s weakest kingside point.

- Opening themes: bishop on c4, f7 pressure, Italian diagonal

### Packet italian-white.line-014.ply-07.c2c3

- Move: `c3` / `c2c3` at ply 7

- CoachCard: **Prepare the c3/d4 Italian break** — c3 supports the d-pawn advance that is central to many Italian Game structures. It challenges Black’s e5 pawn without moving the c4 bishop off its attacking diagonal.

- Plain hint: Prepare the central pawn break that challenges Black’s e-pawn.

- Opening themes: c3/d4 break, e5 challenge, Italian center

### Packet italian-white.line-014.ply-09.d2d3

- Move: `d3` / `d2d3` at ply 9

- CoachCard: **Build the quiet Italian base** — d3 supports the e-pawn and keeps the bishop on c4 useful without forcing immediate tactics. This is the quiet Italian route toward castling and later central play.

- Plain hint: Support the king pawn and keep the quiet Italian structure flexible.

- Opening themes: quiet Italian, e-pawn support, central timing

### Packet italian-white.line-014.ply-11.h2h3

- Move: `h3` / `h2h3` at ply 11

- CoachCard: **Coordinate the Italian pieces** — h3 keeps the move tied to the Italian plan: central control, quick kingside safety, and pressure from developed minor pieces.

- Plain hint: Coordinate the Italian pieces around the center, kingside safety, and the pressure line toward Black’s king.

- Opening themes: Italian coordination, center, king safety


## italian-white-line-015: 1. e4 e5 2. Nf3 Nc6 3. Bc4 h6 4. d4 exd4 5. Nxd4 Nxd4 6. Qxd4 Nf6

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1c4,h7h6,d2d4,e5d4,f3d4,c6d4,d1d4,g8f6`  
Runtime totalGames field at line node: `503109`

### Packet italian-white.line-015.ply-05.f1c4

- Move: `Bc4` / `f1c4` at ply 5

- CoachCard: **Put the bishop on the f7 diagonal** — Bc4 places the bishop on the classic Italian diagonal toward f7. That target shapes both quiet c3/d4 plans and sharper Two Knights ideas.

- Plain hint: Place the light-square bishop on the Italian diagonal where it eyes Black’s weakest kingside point.

- Opening themes: bishop on c4, f7 pressure, Italian diagonal

### Packet italian-white.line-015.ply-07.d2d4

- Move: `d4` / `d2d4` at ply 7

- CoachCard: **Strike with the Italian d-pawn** — d4 is the prepared Italian central break. White uses development and bishop pressure to challenge Black’s e-pawn rather than sitting passively.

- Plain hint: Strike in the center once the Italian pieces are ready.

- Opening themes: d4 break, central challenge, Italian initiative

### Packet italian-white.line-015.ply-09.f3d4

- Move: `Nxd4` / `f3d4` at ply 9

- CoachCard: **Coordinate the Italian pieces** — Nxd4 keeps the move tied to the Italian plan: central control, quick kingside safety, and pressure from developed minor pieces.

- Plain hint: Coordinate the Italian pieces around the center, kingside safety, and the pressure line toward Black’s king.

- Opening themes: Italian coordination, center, king safety

### Packet italian-white.line-015.ply-11.d1d4

- Move: `Qxd4` / `d1d4` at ply 11

- CoachCard: **Coordinate the Italian pieces** — Qxd4 keeps the move tied to the Italian plan: central control, quick kingside safety, and pressure from developed minor pieces.

- Plain hint: Coordinate the Italian pieces around the center, kingside safety, and the pressure line toward Black’s king.

- Opening themes: Italian coordination, center, king safety


## italian-white-line-016: 1. e4 e5 2. Nf3 Nc6 3. Bc4 Nf6 4. Ng5 Bc5 5. Nxf7 Bxf2+ 6. Kf1 Qe7

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1c4,g8f6,f3g5,f8c5,g5f7,c5f2,e1f1,d8e7`  
Runtime totalGames field at line node: `468268`

### Packet italian-white.line-016.ply-05.f1c4

- Move: `Bc4` / `f1c4` at ply 5

- CoachCard: **Put the bishop on the f7 diagonal** — Bc4 places the bishop on the classic Italian diagonal toward f7. That target shapes both quiet c3/d4 plans and sharper Two Knights ideas.

- Plain hint: Place the light-square bishop on the Italian diagonal where it eyes Black’s weakest kingside point.

- Opening themes: bishop on c4, f7 pressure, Italian diagonal

### Packet italian-white.line-016.ply-07.f3g5

- Move: `Ng5` / `f3g5` at ply 7

- CoachCard: **Add a second attacker to f7** — Ng5 is a Two Knights-style jump that combines with the c4 bishop against f7. White is choosing immediate pressure rather than a quiet d3 setup.

- Plain hint: Add a second attacker to Black’s vulnerable kingside point before Black finishes development.

- Opening themes: Two Knights pressure, f7 target, king-in-center pressure

### Packet italian-white.line-016.ply-09.g5f7

- Move: `Nxf7` / `g5f7` at ply 9

- CoachCard: **Coordinate the Italian pieces** — Nxf7 keeps the move tied to the Italian plan: central control, quick kingside safety, and pressure from developed minor pieces.

- Plain hint: Coordinate the Italian pieces around the center, kingside safety, and the pressure line toward Black’s king.

- Opening themes: Italian coordination, center, king safety

### Packet italian-white.line-016.ply-11.e1f1

- Move: `Kf1` / `e1f1` at ply 11

- CoachCard: **Coordinate the Italian pieces** — Kf1 keeps the move tied to the Italian plan: central control, quick kingside safety, and pressure from developed minor pieces.

- Plain hint: Coordinate the Italian pieces around the center, kingside safety, and the pressure line toward Black’s king.

- Opening themes: Italian coordination, center, king safety


## italian-white-line-017: 1. e4 e5 2. Nf3 Nc6 3. Bc4 Nf6 4. Ng5 d5 5. exd5 Nxd5 6. Qf3 Be6

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1c4,g8f6,f3g5,d7d5,e4d5,f6d5,d1f3,c8e6`  
Runtime totalGames field at line node: `313338`

### Packet italian-white.line-017.ply-05.f1c4

- Move: `Bc4` / `f1c4` at ply 5

- CoachCard: **Put the bishop on the f7 diagonal** — Bc4 places the bishop on the classic Italian diagonal toward f7. That target shapes both quiet c3/d4 plans and sharper Two Knights ideas.

- Plain hint: Place the light-square bishop on the Italian diagonal where it eyes Black’s weakest kingside point.

- Opening themes: bishop on c4, f7 pressure, Italian diagonal

### Packet italian-white.line-017.ply-07.f3g5

- Move: `Ng5` / `f3g5` at ply 7

- CoachCard: **Add a second attacker to f7** — Ng5 is a Two Knights-style jump that combines with the c4 bishop against f7. White is choosing immediate pressure rather than a quiet d3 setup.

- Plain hint: Add a second attacker to Black’s vulnerable kingside point before Black finishes development.

- Opening themes: Two Knights pressure, f7 target, king-in-center pressure

### Packet italian-white.line-017.ply-09.e4d5

- Move: `exd5` / `e4d5` at ply 9

- CoachCard: **Open the Italian center at the right moment** — exd5 removes a central pawn and keeps the Italian line open for developed pieces. In these branches, White’s center decision is tied to the pressure already built by the bishop and knight.

- Plain hint: Remove Black’s central pawn while keeping the Italian pressure aimed at the kingside.

- Opening themes: central tension, open Italian center, piece activity

### Packet italian-white.line-017.ply-11.d1f3

- Move: `Qf3` / `d1f3` at ply 11

- CoachCard: **Coordinate the Italian pieces** — Qf3 keeps the move tied to the Italian plan: central control, quick kingside safety, and pressure from developed minor pieces.

- Plain hint: Coordinate the Italian pieces around the center, kingside safety, and the pressure line toward Black’s king.

- Opening themes: Italian coordination, center, king safety


## italian-white-line-018: 1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. c3 Nf6 5. d4 exd4 6. e5 Ng4

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1c4,f8c5,c2c3,g8f6,d2d4,e5d4,e4e5,f6g4`  
Runtime totalGames field at line node: `308086`

### Packet italian-white.line-018.ply-05.f1c4

- Move: `Bc4` / `f1c4` at ply 5

- CoachCard: **Put the bishop on the f7 diagonal** — Bc4 places the bishop on the classic Italian diagonal toward f7. That target shapes both quiet c3/d4 plans and sharper Two Knights ideas.

- Plain hint: Place the light-square bishop on the Italian diagonal where it eyes Black’s weakest kingside point.

- Opening themes: bishop on c4, f7 pressure, Italian diagonal

### Packet italian-white.line-018.ply-07.c2c3

- Move: `c3` / `c2c3` at ply 7

- CoachCard: **Prepare the c3/d4 Italian break** — c3 supports the d-pawn advance that is central to many Italian Game structures. It challenges Black’s e5 pawn without moving the c4 bishop off its attacking diagonal.

- Plain hint: Prepare the central pawn break that challenges Black’s e-pawn.

- Opening themes: c3/d4 break, e5 challenge, Italian center

### Packet italian-white.line-018.ply-09.d2d4

- Move: `d4` / `d2d4` at ply 9

- CoachCard: **Strike with the Italian d-pawn** — d4 is the prepared Italian central break. White uses development and bishop pressure to challenge Black’s e-pawn rather than sitting passively.

- Plain hint: Strike in the center once the Italian pieces are ready.

- Opening themes: d4 break, central challenge, Italian initiative

### Packet italian-white.line-018.ply-11.e4e5

- Move: `e5` / `e4e5` at ply 11

- CoachCard: **Coordinate the Italian pieces** — e5 keeps the move tied to the Italian plan: central control, quick kingside safety, and pressure from developed minor pieces.

- Plain hint: Coordinate the Italian pieces around the center, kingside safety, and the pressure line toward Black’s king.

- Opening themes: Italian coordination, center, king safety


## italian-white-line-019: 1. e4 e5 2. Nf3 Nc6 3. Bc4 h6 4. d4 exd4 5. Nxd4 Bc5 6. Nxc6 bxc6

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1c4,h7h6,d2d4,e5d4,f3d4,f8c5,d4c6,b7c6`  
Runtime totalGames field at line node: `267019`

### Packet italian-white.line-019.ply-05.f1c4

- Move: `Bc4` / `f1c4` at ply 5

- CoachCard: **Put the bishop on the f7 diagonal** — Bc4 places the bishop on the classic Italian diagonal toward f7. That target shapes both quiet c3/d4 plans and sharper Two Knights ideas.

- Plain hint: Place the light-square bishop on the Italian diagonal where it eyes Black’s weakest kingside point.

- Opening themes: bishop on c4, f7 pressure, Italian diagonal

### Packet italian-white.line-019.ply-07.d2d4

- Move: `d4` / `d2d4` at ply 7

- CoachCard: **Strike with the Italian d-pawn** — d4 is the prepared Italian central break. White uses development and bishop pressure to challenge Black’s e-pawn rather than sitting passively.

- Plain hint: Strike in the center once the Italian pieces are ready.

- Opening themes: d4 break, central challenge, Italian initiative

### Packet italian-white.line-019.ply-09.f3d4

- Move: `Nxd4` / `f3d4` at ply 9

- CoachCard: **Coordinate the Italian pieces** — Nxd4 keeps the move tied to the Italian plan: central control, quick kingside safety, and pressure from developed minor pieces.

- Plain hint: Coordinate the Italian pieces around the center, kingside safety, and the pressure line toward Black’s king.

- Opening themes: Italian coordination, center, king safety

### Packet italian-white.line-019.ply-11.d4c6

- Move: `Nxc6` / `d4c6` at ply 11

- CoachCard: **Coordinate the Italian pieces** — Nxc6 keeps the move tied to the Italian plan: central control, quick kingside safety, and pressure from developed minor pieces.

- Plain hint: Coordinate the Italian pieces around the center, kingside safety, and the pressure line toward Black’s king.

- Opening themes: Italian coordination, center, king safety


## italian-white-line-020: 1. e4 e5 2. Nf3 Nc6 3. Bc4 Nf6 4. d3 h6 5. Nc3 Bb4 6. Bd2 d6

Runtime playKey: `e2e4,e7e5,g1f3,b8c6,f1c4,g8f6,d2d3,h7h6,b1c3,f8b4,c1d2,d7d6`  
Runtime totalGames field at line node: `266125`

### Packet italian-white.line-020.ply-05.f1c4

- Move: `Bc4` / `f1c4` at ply 5

- CoachCard: **Put the bishop on the f7 diagonal** — Bc4 places the bishop on the classic Italian diagonal toward f7. That target shapes both quiet c3/d4 plans and sharper Two Knights ideas.

- Plain hint: Place the light-square bishop on the Italian diagonal where it eyes Black’s weakest kingside point.

- Opening themes: bishop on c4, f7 pressure, Italian diagonal

### Packet italian-white.line-020.ply-07.d2d3

- Move: `d3` / `d2d3` at ply 7

- CoachCard: **Build the quiet Italian base** — d3 supports the e-pawn and keeps the bishop on c4 useful without forcing immediate tactics. This is the quiet Italian route toward castling and later central play.

- Plain hint: Support the king pawn and keep the quiet Italian structure flexible.

- Opening themes: quiet Italian, e-pawn support, central timing

### Packet italian-white.line-020.ply-09.b1c3

- Move: `Nc3` / `b1c3` at ply 9

- CoachCard: **Coordinate the Italian pieces** — Nc3 keeps the move tied to the Italian plan: central control, quick kingside safety, and pressure from developed minor pieces.

- Plain hint: Coordinate the Italian pieces around the center, kingside safety, and the pressure line toward Black’s king.

- Opening themes: Italian coordination, center, king safety

### Packet italian-white.line-020.ply-11.c1d2

- Move: `Bd2` / `c1d2` at ply 11

- CoachCard: **Coordinate the Italian pieces** — Bd2 keeps the move tied to the Italian plan: central control, quick kingside safety, and pressure from developed minor pieces.

- Plain hint: Coordinate the Italian pieces around the center, kingside safety, and the pressure line toward Black’s king.

- Opening themes: Italian coordination, center, king safety
