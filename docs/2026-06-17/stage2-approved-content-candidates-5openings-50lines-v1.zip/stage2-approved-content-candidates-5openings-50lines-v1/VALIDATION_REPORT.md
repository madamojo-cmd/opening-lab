# Validation Report

## Summary

- Total openings attempted: 5
- Openings completed: 5
- Total lines requested: 50 minimum
- Total lines produced: 100
- Total packets produced: 540
- 50-line target met: YES
- Additional round-robin iterations completed: YES (50 extra lines)

## Results

- Legal sequence validation result: PASS for all selected lines
- Runtime match result: PASS for all emitted packets
- Plain View no-leak result: PASS for all emitted packets
- Generic copy scan result: PASS; forbidden phrases not found in emitted packet copy
- Rejected line count: 741
- Rejected packet count: 0

## Opening coverage

- `italian-white`: 20 lines, 80 packets
- `london-white`: 20 lines, 120 packets
- `queens-gambit-white`: 20 lines, 100 packets
- `sicilian-black`: 20 lines, 120 packets
- `caro-kann-black`: 20 lines, 120 packets

## Rejection reasons

- Line rejections/skips were primarily near-duplicate transpositions with the same unordered move set.
- Packet rejections: none.

## Activation warning

This package is ready for app-side validation, but it is not final approved app content and must not flip `approvedContentAvailable`.
