# Manifest

## Source package

`stage2-21opening-crawled-filtered5to2-runtime-source-v1.zip`

## Runtime files used

- `runtime/opening-book.nodes.runtime.v1.jsonl`
- `runtime/opening-book.moves.runtime.v1.jsonl`

## Selected openings

- `italian-white` (Italian Game): 20 lines, 80 packets
- `london-white` (London System): 20 lines, 120 packets
- `queens-gambit-white` (Queen's Gambit): 20 lines, 100 packets
- `sicilian-black` (Sicilian Defense): 20 lines, 120 packets
- `caro-kann-black` (Caro-Kann Defense): 20 lines, 120 packets

## Substitutions

None. All five priority openings were present in the 21-opening runtime package and produced at least 10 safe validated lines.

## Totals

- Total lines: 100
- Total packets: 540
- Requested minimum: 50 total lines
- Extra round-robin lines added: 50

## Validation status

PASS

## Known limitations

- Candidate package only; not app-activated.
- Runtime-backed `totalGames` values are preserved in inventories and markdown for traceability, but packet copy does not make popularity or engine-evaluation claims.
- SAN was generated locally from legal UCI validation.
- Plain View hints were scanned for exact SAN/UCI leakage.

## Next step for app activation

Run a separate app-validation/activation agent to import through the Stage 2 resolver, verify UI surfaces, confirm no Plain View leaks in the app, and only then decide whether approved content availability can be activated.
