# Stage 2 Approved-Content Candidates: 5 Openings / 50+ Lines v1

This package contains **approved-content candidates** generated from the local crawled runtime source package only.

These candidates are **not app-activated**. They must be imported through the Stage 2 resolver only after a separate app-validation/activation agent validates runtime alignment, UI behavior, resolver wiring, and feature availability.

Runtime availability remains separate from approved content availability. Do **not** flip or set any `approvedContentAvailable` flag from this package alone.

## Source

- Source zip: `stage2-21opening-crawled-filtered5to2-runtime-source-v1.zip`
- Runtime nodes: `runtime/opening-book.nodes.runtime.v1.jsonl`
- Runtime moves: `runtime/opening-book.moves.runtime.v1.jsonl`
- Live Lichess calls: none
- App code changes: none

## Selected openings

- `italian-white`: 20 lines, 80 packets
- `london-white`: 20 lines, 120 packets
- `queens-gambit-white`: 20 lines, 100 packets
- `sicilian-black`: 20 lines, 120 packets
- `caro-kann-black`: 20 lines, 120 packets

## Integration note

Each JSONL packet has status `approved_candidate` and approvalReadiness `ready_for_app_validation`. The next agent should validate and wire these through the Stage 2 resolver without mutating the runtime files or changing move authority.
