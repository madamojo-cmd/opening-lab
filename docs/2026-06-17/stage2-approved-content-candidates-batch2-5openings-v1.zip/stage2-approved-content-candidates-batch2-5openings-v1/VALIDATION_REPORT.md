# Validation Report

## Summary

- Openings attempted: 5
- Openings completed: 5
- Target line count: 20 per opening preferred; 10 per opening minimum
- Actual line count: 125
- Packet count: 725
- Rejected line count: 790
- Rejected packet count: 0

## Results

- Legal sequence validation result: PASS for all selected lines
- Runtime match result: PASS for all emitted packets
- Plain View no-leak result: PASS for all emitted packets
- Generic copy scan result: PASS; forbidden phrases not found in emitted packet copy

## Coverage

- `english-white`: 10-line minimum=YES; 20-line target=YES; lines=25; packets=150
- `scandinavian-black`: 10-line minimum=YES; 20-line target=YES; lines=25; packets=150
- `colle-white`: 10-line minimum=YES; 20-line target=YES; lines=25; packets=150
- `slav-black`: 10-line minimum=YES; 20-line target=YES; lines=25; packets=125
- `french-black`: 10-line minimum=YES; 20-line target=YES; lines=25; packets=150

## Extra round-robin lines

- Extra round-robin lines added: YES
- Extra lines beyond 20/opening: 25

## Activation warning

This package is ready for app-side validation, but it is not final approved app content and must not flip `approvedContentAvailable`.
