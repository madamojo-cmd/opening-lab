# Stage 2 Approved-Content Candidates Batch 2: 5 Openings v1

This package contains **Batch 2 approved-content candidates** generated from the local crawled runtime source package only.

These candidates are **not app-activated** and are **not final approved content**. App-side validation must run before activation.

Runtime availability remains separate from approved content availability. Do **not** flip or set any `approvedContentAvailable` flag from this package alone.

## Source

- Source zip: `stage2-21opening-crawled-filtered5to2-runtime-source-v1.zip`
- Runtime nodes: `runtime/opening-book.nodes.runtime.v1.jsonl`
- Runtime moves: `runtime/opening-book.moves.runtime.v1.jsonl`
- Live Lichess calls: none
- App code changes: none

## Selected openings

- `english-white`: 25 lines, 150 packets
- `scandinavian-black`: 25 lines, 150 packets
- `colle-white`: 25 lines, 150 packets
- `slav-black`: 25 lines, 125 packets
- `french-black`: 25 lines, 150 packets

## Integration note

Each JSONL packet has status `approved_candidate` and approvalReadiness `ready_for_app_validation`. The app-validation/activation agent should validate resolver wiring, UI surfaces, no-leak behavior, and runtime alignment before any app promotion.
