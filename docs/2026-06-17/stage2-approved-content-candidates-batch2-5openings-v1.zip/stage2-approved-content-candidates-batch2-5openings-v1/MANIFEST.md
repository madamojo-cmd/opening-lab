# Manifest

## Source runtime package

`stage2-21opening-crawled-filtered5to2-runtime-source-v1.zip`

## Selected openings

- `english-white` (English Opening): 25 lines, 150 packets
- `scandinavian-black` (Scandinavian Defense): 25 lines, 150 packets
- `colle-white` (Colle System): 25 lines, 150 packets
- `slav-black` (Slav Defense): 25 lines, 125 packets
- `french-black` (French Defense): 25 lines, 150 packets

## Totals

- Total line count: 125
- Total packet count: 725
- 10-line minimum met for every opening: YES
- 20-line target met for every opening: YES
- Extra round-robin lines added: YES (25 extra beyond 20/opening)

## Validation status

PASS

## Known limitations

- Candidate content only; not app-activated.
- Runtime `totalGames` fields are preserved for traceability, but packet copy does not claim popularity or engine evaluation.
- Some early learner moves are not packetized when the opening-specific runtime node begins after the move; emitted packets preserve `runtimeMatched: true`.

## Next step for app validation

Run app-side validation/activation through the Stage 2 resolver before any approved-content availability flag or app-approved status is changed.
