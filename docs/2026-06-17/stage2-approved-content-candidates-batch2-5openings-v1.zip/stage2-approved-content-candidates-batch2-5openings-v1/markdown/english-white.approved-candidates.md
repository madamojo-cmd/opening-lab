# English Opening approved-content candidates — Batch 2

Opening ID: `english-white`  
Status: approved candidates only; not app-activated.


## english-white-line-001: 1. c4 Nf6 2. d4 g6 3. Nc3 d5 4. cxd5 Nxd5 5. e4 Nxc3 6. bxc3 Bg7

Runtime playKey: `c2c4,g8f6,d2d4,g7g6,b1c3,d7d5,c4d5,f6d5,e2e4,d5c3,b2c3,f8g7`  
Runtime totalGames field at line node: `1700417`

### Packet english-white.line-001.ply-01.c2c4

- Move: `c4` / `c2c4` at ply 1

- CoachCard: **Use the English flank pawn** — c4 is the English Opening’s defining flank claim: White’s c-pawn controls d5 without committing the e-pawn or d-pawn immediately.

- Plain hint: Use the flank pawn to challenge the center from the side while keeping the central pawns flexible.

- Opening themes: c4 controls d5, flank control, delayed central commitment

### Packet english-white.line-001.ply-03.d2d4

- Move: `d4` / `d2d4` at ply 3

- CoachCard: **Transpose into direct central pressure** — d4 changes the English from pure flank control into direct d-pawn central pressure. White uses the earlier c-pawn setup to contest Black’s center.

- Plain hint: Commit the queen pawn only when the flank pressure already supports the center.

- Opening themes: d4 transposition, central pressure, c-pawn support

### Packet english-white.line-001.ply-05.b1c3

- Move: `Nc3` / `b1c3` at ply 5

- CoachCard: **Increase English pressure on d5** — Nc3 adds a knight to the English fight over d5 and e4. It supports flexible setups where White may transpose into queen-pawn or reversed Sicilian structures.

- Plain hint: Develop the queenside knight toward the dark-square center behind the flank pawn.

- Opening themes: d5 pressure, dark-square control, transposition flexibility

### Packet english-white.line-001.ply-07.c4d5

- Move: `cxd5` / `c4d5` at ply 7

- CoachCard: **Resolve the d5 tension from the flank** — cxd5 uses the English c-pawn to remove Black’s central pawn. The capture converts flank pressure into a concrete central decision.

- Plain hint: Use the flank pawn to clarify the central tension when it helps White’s structure.

- Opening themes: d5 capture, flank-to-center pressure, structure decision

### Packet english-white.line-001.ply-09.e2e4

- Move: `e4` / `e2e4` at ply 9

- CoachCard: **Take broad central space from the English** — e4 expands from an English move order into a broad pawn center. This is strongest when White’s c-pawn and knights already support the dark squares.

- Plain hint: Claim more central space once the queenside and dark-square support are ready.

- Opening themes: delayed e-pawn, broad center, dark-square support

### Packet english-white.line-001.ply-11.b2c3

- Move: `bxc3` / `b2c3` at ply 11

- CoachCard: **Keep the English flexibility intact** — bxc3 stays connected to the English plan: c-pawn pressure on d5, flexible central commitment, and smooth development.

- Plain hint: Preserve flank control, central flexibility, and safe development.

- Opening themes: English flexibility, flank control, development


## english-white-line-002: 1. c4 e6 2. d4 d5 3. Nf3 c6 4. Nc3 Nf6 5. Bg5 Nbd7 6. e3 Be7

Runtime playKey: `c2c4,e7e6,d2d4,d7d5,g1f3,c7c6,b1c3,g8f6,c1g5,b8d7,e2e3,f8e7`  
Runtime totalGames field at line node: `1388506`

### Packet english-white.line-002.ply-01.c2c4

- Move: `c4` / `c2c4` at ply 1

- CoachCard: **Use the English flank pawn** — c4 is the English Opening’s defining flank claim: White’s c-pawn controls d5 without committing the e-pawn or d-pawn immediately.

- Plain hint: Use the flank pawn to challenge the center from the side while keeping the central pawns flexible.

- Opening themes: c4 controls d5, flank control, delayed central commitment

### Packet english-white.line-002.ply-03.d2d4

- Move: `d4` / `d2d4` at ply 3

- CoachCard: **Transpose into direct central pressure** — d4 changes the English from pure flank control into direct d-pawn central pressure. White uses the earlier c-pawn setup to contest Black’s center.

- Plain hint: Commit the queen pawn only when the flank pressure already supports the center.

- Opening themes: d4 transposition, central pressure, c-pawn support

### Packet english-white.line-002.ply-05.g1f3

- Move: `Nf3` / `g1f3` at ply 5

- CoachCard: **Prepare flexible English development** — Nf3 develops the kingside knight without forcing the center. In English lines, this keeps White ready for d4, e4, g3, or quiet kingside castling.

- Plain hint: Bring the kingside knight out while keeping central pawn choices open.

- Opening themes: flexible development, delayed center, kingside safety

### Packet english-white.line-002.ply-07.b1c3

- Move: `Nc3` / `b1c3` at ply 7

- CoachCard: **Increase English pressure on d5** — Nc3 adds a knight to the English fight over d5 and e4. It supports flexible setups where White may transpose into queen-pawn or reversed Sicilian structures.

- Plain hint: Develop the queenside knight toward the dark-square center behind the flank pawn.

- Opening themes: d5 pressure, dark-square control, transposition flexibility

### Packet english-white.line-002.ply-09.c1g5

- Move: `Bg5` / `c1g5` at ply 9

- CoachCard: **Keep the English flexibility intact** — Bg5 stays connected to the English plan: c-pawn pressure on d5, flexible central commitment, and smooth development.

- Plain hint: Preserve flank control, central flexibility, and safe development.

- Opening themes: English flexibility, flank control, development

### Packet english-white.line-002.ply-11.e2e3

- Move: `e3` / `e2e3` at ply 11

- CoachCard: **Keep the English flexibility intact** — e3 stays connected to the English plan: c-pawn pressure on d5, flexible central commitment, and smooth development.

- Plain hint: Preserve flank control, central flexibility, and safe development.

- Opening themes: English flexibility, flank control, development


## english-white-line-003: 1. c4 e6 2. d4 c5 3. d5 Nf6 4. Nc3 d6 5. e4 exd5 6. cxd5 g6

Runtime playKey: `c2c4,e7e6,d2d4,c7c5,d4d5,g8f6,b1c3,d7d6,e2e4,e6d5,c4d5,g7g6`  
Runtime totalGames field at line node: `1052183`

### Packet english-white.line-003.ply-01.c2c4

- Move: `c4` / `c2c4` at ply 1

- CoachCard: **Use the English flank pawn** — c4 is the English Opening’s defining flank claim: White’s c-pawn controls d5 without committing the e-pawn or d-pawn immediately.

- Plain hint: Use the flank pawn to challenge the center from the side while keeping the central pawns flexible.

- Opening themes: c4 controls d5, flank control, delayed central commitment

### Packet english-white.line-003.ply-03.d2d4

- Move: `d4` / `d2d4` at ply 3

- CoachCard: **Transpose into direct central pressure** — d4 changes the English from pure flank control into direct d-pawn central pressure. White uses the earlier c-pawn setup to contest Black’s center.

- Plain hint: Commit the queen pawn only when the flank pressure already supports the center.

- Opening themes: d4 transposition, central pressure, c-pawn support

### Packet english-white.line-003.ply-05.d4d5

- Move: `d5` / `d4d5` at ply 5

- CoachCard: **Keep the English flexibility intact** — d5 stays connected to the English plan: c-pawn pressure on d5, flexible central commitment, and smooth development.

- Plain hint: Preserve flank control, central flexibility, and safe development.

- Opening themes: English flexibility, flank control, development

### Packet english-white.line-003.ply-07.b1c3

- Move: `Nc3` / `b1c3` at ply 7

- CoachCard: **Increase English pressure on d5** — Nc3 adds a knight to the English fight over d5 and e4. It supports flexible setups where White may transpose into queen-pawn or reversed Sicilian structures.

- Plain hint: Develop the queenside knight toward the dark-square center behind the flank pawn.

- Opening themes: d5 pressure, dark-square control, transposition flexibility

### Packet english-white.line-003.ply-09.e2e4

- Move: `e4` / `e2e4` at ply 9

- CoachCard: **Take broad central space from the English** — e4 expands from an English move order into a broad pawn center. This is strongest when White’s c-pawn and knights already support the dark squares.

- Plain hint: Claim more central space once the queenside and dark-square support are ready.

- Opening themes: delayed e-pawn, broad center, dark-square support

### Packet english-white.line-003.ply-11.c4d5

- Move: `cxd5` / `c4d5` at ply 11

- CoachCard: **Resolve the d5 tension from the flank** — cxd5 uses the English c-pawn to remove Black’s central pawn. The capture converts flank pressure into a concrete central decision.

- Plain hint: Use the flank pawn to clarify the central tension when it helps White’s structure.

- Opening themes: d5 capture, flank-to-center pressure, structure decision


## english-white-line-004: 1. c4 e6 2. d4 d5 3. Nf3 c5 4. Nc3 Nc6 5. e3 cxd4 6. exd4 Nf6

Runtime playKey: `c2c4,e7e6,d2d4,d7d5,g1f3,c7c5,b1c3,b8c6,e2e3,c5d4,e3d4,g8f6`  
Runtime totalGames field at line node: `794231`

### Packet english-white.line-004.ply-01.c2c4

- Move: `c4` / `c2c4` at ply 1

- CoachCard: **Use the English flank pawn** — c4 is the English Opening’s defining flank claim: White’s c-pawn controls d5 without committing the e-pawn or d-pawn immediately.

- Plain hint: Use the flank pawn to challenge the center from the side while keeping the central pawns flexible.

- Opening themes: c4 controls d5, flank control, delayed central commitment

### Packet english-white.line-004.ply-03.d2d4

- Move: `d4` / `d2d4` at ply 3

- CoachCard: **Transpose into direct central pressure** — d4 changes the English from pure flank control into direct d-pawn central pressure. White uses the earlier c-pawn setup to contest Black’s center.

- Plain hint: Commit the queen pawn only when the flank pressure already supports the center.

- Opening themes: d4 transposition, central pressure, c-pawn support

### Packet english-white.line-004.ply-05.g1f3

- Move: `Nf3` / `g1f3` at ply 5

- CoachCard: **Prepare flexible English development** — Nf3 develops the kingside knight without forcing the center. In English lines, this keeps White ready for d4, e4, g3, or quiet kingside castling.

- Plain hint: Bring the kingside knight out while keeping central pawn choices open.

- Opening themes: flexible development, delayed center, kingside safety

### Packet english-white.line-004.ply-07.b1c3

- Move: `Nc3` / `b1c3` at ply 7

- CoachCard: **Increase English pressure on d5** — Nc3 adds a knight to the English fight over d5 and e4. It supports flexible setups where White may transpose into queen-pawn or reversed Sicilian structures.

- Plain hint: Develop the queenside knight toward the dark-square center behind the flank pawn.

- Opening themes: d5 pressure, dark-square control, transposition flexibility

### Packet english-white.line-004.ply-09.e2e3

- Move: `e3` / `e2e3` at ply 9

- CoachCard: **Keep the English flexibility intact** — e3 stays connected to the English plan: c-pawn pressure on d5, flexible central commitment, and smooth development.

- Plain hint: Preserve flank control, central flexibility, and safe development.

- Opening themes: English flexibility, flank control, development

### Packet english-white.line-004.ply-11.e3d4

- Move: `exd4` / `e3d4` at ply 11

- CoachCard: **Keep the English flexibility intact** — exd4 stays connected to the English plan: c-pawn pressure on d5, flexible central commitment, and smooth development.

- Plain hint: Preserve flank control, central flexibility, and safe development.

- Opening themes: English flexibility, flank control, development


## english-white-line-005: 1. c4 c5 2. Nc3 Nc6 3. e3 Nf6 4. d4 cxd4 5. exd4 d5 6. Nf3 Bg4

Runtime playKey: `c2c4,c7c5,b1c3,b8c6,e2e3,g8f6,d2d4,c5d4,e3d4,d7d5,g1f3,c8g4`  
Runtime totalGames field at line node: `781637`

### Packet english-white.line-005.ply-01.c2c4

- Move: `c4` / `c2c4` at ply 1

- CoachCard: **Use the English flank pawn** — c4 is the English Opening’s defining flank claim: White’s c-pawn controls d5 without committing the e-pawn or d-pawn immediately.

- Plain hint: Use the flank pawn to challenge the center from the side while keeping the central pawns flexible.

- Opening themes: c4 controls d5, flank control, delayed central commitment

### Packet english-white.line-005.ply-03.b1c3

- Move: `Nc3` / `b1c3` at ply 3

- CoachCard: **Increase English pressure on d5** — Nc3 adds a knight to the English fight over d5 and e4. It supports flexible setups where White may transpose into queen-pawn or reversed Sicilian structures.

- Plain hint: Develop the queenside knight toward the dark-square center behind the flank pawn.

- Opening themes: d5 pressure, dark-square control, transposition flexibility

### Packet english-white.line-005.ply-05.e2e3

- Move: `e3` / `e2e3` at ply 5

- CoachCard: **Keep the English flexibility intact** — e3 stays connected to the English plan: c-pawn pressure on d5, flexible central commitment, and smooth development.

- Plain hint: Preserve flank control, central flexibility, and safe development.

- Opening themes: English flexibility, flank control, development

### Packet english-white.line-005.ply-07.d2d4

- Move: `d4` / `d2d4` at ply 7

- CoachCard: **Transpose into direct central pressure** — d4 changes the English from pure flank control into direct d-pawn central pressure. White uses the earlier c-pawn setup to contest Black’s center.

- Plain hint: Commit the queen pawn only when the flank pressure already supports the center.

- Opening themes: d4 transposition, central pressure, c-pawn support

### Packet english-white.line-005.ply-09.e3d4

- Move: `exd4` / `e3d4` at ply 9

- CoachCard: **Keep the English flexibility intact** — exd4 stays connected to the English plan: c-pawn pressure on d5, flexible central commitment, and smooth development.

- Plain hint: Preserve flank control, central flexibility, and safe development.

- Opening themes: English flexibility, flank control, development

### Packet english-white.line-005.ply-11.g1f3

- Move: `Nf3` / `g1f3` at ply 11

- CoachCard: **Prepare flexible English development** — Nf3 develops the kingside knight without forcing the center. In English lines, this keeps White ready for d4, e4, g3, or quiet kingside castling.

- Plain hint: Bring the kingside knight out while keeping central pawn choices open.

- Opening themes: flexible development, delayed center, kingside safety


## english-white-line-006: 1. c4 e6 2. Nc3 d5 3. cxd5 exd5 4. d4 Nf6 5. Bg5 c6 6. e3 Be7

Runtime playKey: `c2c4,e7e6,b1c3,d7d5,c4d5,e6d5,d2d4,g8f6,c1g5,c7c6,e2e3,f8e7`  
Runtime totalGames field at line node: `696201`

### Packet english-white.line-006.ply-01.c2c4

- Move: `c4` / `c2c4` at ply 1

- CoachCard: **Use the English flank pawn** — c4 is the English Opening’s defining flank claim: White’s c-pawn controls d5 without committing the e-pawn or d-pawn immediately.

- Plain hint: Use the flank pawn to challenge the center from the side while keeping the central pawns flexible.

- Opening themes: c4 controls d5, flank control, delayed central commitment

### Packet english-white.line-006.ply-03.b1c3

- Move: `Nc3` / `b1c3` at ply 3

- CoachCard: **Increase English pressure on d5** — Nc3 adds a knight to the English fight over d5 and e4. It supports flexible setups where White may transpose into queen-pawn or reversed Sicilian structures.

- Plain hint: Develop the queenside knight toward the dark-square center behind the flank pawn.

- Opening themes: d5 pressure, dark-square control, transposition flexibility

### Packet english-white.line-006.ply-05.c4d5

- Move: `cxd5` / `c4d5` at ply 5

- CoachCard: **Resolve the d5 tension from the flank** — cxd5 uses the English c-pawn to remove Black’s central pawn. The capture converts flank pressure into a concrete central decision.

- Plain hint: Use the flank pawn to clarify the central tension when it helps White’s structure.

- Opening themes: d5 capture, flank-to-center pressure, structure decision

### Packet english-white.line-006.ply-07.d2d4

- Move: `d4` / `d2d4` at ply 7

- CoachCard: **Transpose into direct central pressure** — d4 changes the English from pure flank control into direct d-pawn central pressure. White uses the earlier c-pawn setup to contest Black’s center.

- Plain hint: Commit the queen pawn only when the flank pressure already supports the center.

- Opening themes: d4 transposition, central pressure, c-pawn support

### Packet english-white.line-006.ply-09.c1g5

- Move: `Bg5` / `c1g5` at ply 9

- CoachCard: **Keep the English flexibility intact** — Bg5 stays connected to the English plan: c-pawn pressure on d5, flexible central commitment, and smooth development.

- Plain hint: Preserve flank control, central flexibility, and safe development.

- Opening themes: English flexibility, flank control, development

### Packet english-white.line-006.ply-11.e2e3

- Move: `e3` / `e2e3` at ply 11

- CoachCard: **Keep the English flexibility intact** — e3 stays connected to the English plan: c-pawn pressure on d5, flexible central commitment, and smooth development.

- Plain hint: Preserve flank control, central flexibility, and safe development.

- Opening themes: English flexibility, flank control, development


## english-white-line-007: 1. c4 e6 2. Nc3 d5 3. cxd5 exd5 4. d4 c6 5. Nf3 Nf6 6. Bg5 Be7

Runtime playKey: `c2c4,e7e6,b1c3,d7d5,c4d5,e6d5,d2d4,c7c6,g1f3,g8f6,c1g5,f8e7`  
Runtime totalGames field at line node: `690464`

### Packet english-white.line-007.ply-01.c2c4

- Move: `c4` / `c2c4` at ply 1

- CoachCard: **Use the English flank pawn** — c4 is the English Opening’s defining flank claim: White’s c-pawn controls d5 without committing the e-pawn or d-pawn immediately.

- Plain hint: Use the flank pawn to challenge the center from the side while keeping the central pawns flexible.

- Opening themes: c4 controls d5, flank control, delayed central commitment

### Packet english-white.line-007.ply-03.b1c3

- Move: `Nc3` / `b1c3` at ply 3

- CoachCard: **Increase English pressure on d5** — Nc3 adds a knight to the English fight over d5 and e4. It supports flexible setups where White may transpose into queen-pawn or reversed Sicilian structures.

- Plain hint: Develop the queenside knight toward the dark-square center behind the flank pawn.

- Opening themes: d5 pressure, dark-square control, transposition flexibility

### Packet english-white.line-007.ply-05.c4d5

- Move: `cxd5` / `c4d5` at ply 5

- CoachCard: **Resolve the d5 tension from the flank** — cxd5 uses the English c-pawn to remove Black’s central pawn. The capture converts flank pressure into a concrete central decision.

- Plain hint: Use the flank pawn to clarify the central tension when it helps White’s structure.

- Opening themes: d5 capture, flank-to-center pressure, structure decision

### Packet english-white.line-007.ply-07.d2d4

- Move: `d4` / `d2d4` at ply 7

- CoachCard: **Transpose into direct central pressure** — d4 changes the English from pure flank control into direct d-pawn central pressure. White uses the earlier c-pawn setup to contest Black’s center.

- Plain hint: Commit the queen pawn only when the flank pressure already supports the center.

- Opening themes: d4 transposition, central pressure, c-pawn support

### Packet english-white.line-007.ply-09.g1f3

- Move: `Nf3` / `g1f3` at ply 9

- CoachCard: **Prepare flexible English development** — Nf3 develops the kingside knight without forcing the center. In English lines, this keeps White ready for d4, e4, g3, or quiet kingside castling.

- Plain hint: Bring the kingside knight out while keeping central pawn choices open.

- Opening themes: flexible development, delayed center, kingside safety

### Packet english-white.line-007.ply-11.c1g5

- Move: `Bg5` / `c1g5` at ply 11

- CoachCard: **Keep the English flexibility intact** — Bg5 stays connected to the English plan: c-pawn pressure on d5, flexible central commitment, and smooth development.

- Plain hint: Preserve flank control, central flexibility, and safe development.

- Opening themes: English flexibility, flank control, development


## english-white-line-008: 1. c4 e6 2. d4 d5 3. Nf3 c5 4. Nc3 Nc6 5. cxd5 exd5 6. e3 Nf6

Runtime playKey: `c2c4,e7e6,d2d4,d7d5,g1f3,c7c5,b1c3,b8c6,c4d5,e6d5,e2e3,g8f6`  
Runtime totalGames field at line node: `588220`

### Packet english-white.line-008.ply-01.c2c4

- Move: `c4` / `c2c4` at ply 1

- CoachCard: **Use the English flank pawn** — c4 is the English Opening’s defining flank claim: White’s c-pawn controls d5 without committing the e-pawn or d-pawn immediately.

- Plain hint: Use the flank pawn to challenge the center from the side while keeping the central pawns flexible.

- Opening themes: c4 controls d5, flank control, delayed central commitment

### Packet english-white.line-008.ply-03.d2d4

- Move: `d4` / `d2d4` at ply 3

- CoachCard: **Transpose into direct central pressure** — d4 changes the English from pure flank control into direct d-pawn central pressure. White uses the earlier c-pawn setup to contest Black’s center.

- Plain hint: Commit the queen pawn only when the flank pressure already supports the center.

- Opening themes: d4 transposition, central pressure, c-pawn support

### Packet english-white.line-008.ply-05.g1f3

- Move: `Nf3` / `g1f3` at ply 5

- CoachCard: **Prepare flexible English development** — Nf3 develops the kingside knight without forcing the center. In English lines, this keeps White ready for d4, e4, g3, or quiet kingside castling.

- Plain hint: Bring the kingside knight out while keeping central pawn choices open.

- Opening themes: flexible development, delayed center, kingside safety

### Packet english-white.line-008.ply-07.b1c3

- Move: `Nc3` / `b1c3` at ply 7

- CoachCard: **Increase English pressure on d5** — Nc3 adds a knight to the English fight over d5 and e4. It supports flexible setups where White may transpose into queen-pawn or reversed Sicilian structures.

- Plain hint: Develop the queenside knight toward the dark-square center behind the flank pawn.

- Opening themes: d5 pressure, dark-square control, transposition flexibility

### Packet english-white.line-008.ply-09.c4d5

- Move: `cxd5` / `c4d5` at ply 9

- CoachCard: **Resolve the d5 tension from the flank** — cxd5 uses the English c-pawn to remove Black’s central pawn. The capture converts flank pressure into a concrete central decision.

- Plain hint: Use the flank pawn to clarify the central tension when it helps White’s structure.

- Opening themes: d5 capture, flank-to-center pressure, structure decision

### Packet english-white.line-008.ply-11.e2e3

- Move: `e3` / `e2e3` at ply 11

- CoachCard: **Keep the English flexibility intact** — e3 stays connected to the English plan: c-pawn pressure on d5, flexible central commitment, and smooth development.

- Plain hint: Preserve flank control, central flexibility, and safe development.

- Opening themes: English flexibility, flank control, development


## english-white-line-009: 1. c4 e6 2. d4 d5 3. Nf3 c6 4. Nc3 Nf6 5. Bg5 Nbd7 6. e3 Qa5

Runtime playKey: `c2c4,e7e6,d2d4,d7d5,g1f3,c7c6,b1c3,g8f6,c1g5,b8d7,e2e3,d8a5`  
Runtime totalGames field at line node: `545509`

### Packet english-white.line-009.ply-01.c2c4

- Move: `c4` / `c2c4` at ply 1

- CoachCard: **Use the English flank pawn** — c4 is the English Opening’s defining flank claim: White’s c-pawn controls d5 without committing the e-pawn or d-pawn immediately.

- Plain hint: Use the flank pawn to challenge the center from the side while keeping the central pawns flexible.

- Opening themes: c4 controls d5, flank control, delayed central commitment

### Packet english-white.line-009.ply-03.d2d4

- Move: `d4` / `d2d4` at ply 3

- CoachCard: **Transpose into direct central pressure** — d4 changes the English from pure flank control into direct d-pawn central pressure. White uses the earlier c-pawn setup to contest Black’s center.

- Plain hint: Commit the queen pawn only when the flank pressure already supports the center.

- Opening themes: d4 transposition, central pressure, c-pawn support

### Packet english-white.line-009.ply-05.g1f3

- Move: `Nf3` / `g1f3` at ply 5

- CoachCard: **Prepare flexible English development** — Nf3 develops the kingside knight without forcing the center. In English lines, this keeps White ready for d4, e4, g3, or quiet kingside castling.

- Plain hint: Bring the kingside knight out while keeping central pawn choices open.

- Opening themes: flexible development, delayed center, kingside safety

### Packet english-white.line-009.ply-07.b1c3

- Move: `Nc3` / `b1c3` at ply 7

- CoachCard: **Increase English pressure on d5** — Nc3 adds a knight to the English fight over d5 and e4. It supports flexible setups where White may transpose into queen-pawn or reversed Sicilian structures.

- Plain hint: Develop the queenside knight toward the dark-square center behind the flank pawn.

- Opening themes: d5 pressure, dark-square control, transposition flexibility

### Packet english-white.line-009.ply-09.c1g5

- Move: `Bg5` / `c1g5` at ply 9

- CoachCard: **Keep the English flexibility intact** — Bg5 stays connected to the English plan: c-pawn pressure on d5, flexible central commitment, and smooth development.

- Plain hint: Preserve flank control, central flexibility, and safe development.

- Opening themes: English flexibility, flank control, development

### Packet english-white.line-009.ply-11.e2e3

- Move: `e3` / `e2e3` at ply 11

- CoachCard: **Keep the English flexibility intact** — e3 stays connected to the English plan: c-pawn pressure on d5, flexible central commitment, and smooth development.

- Plain hint: Preserve flank control, central flexibility, and safe development.

- Opening themes: English flexibility, flank control, development


## english-white-line-010: 1. c4 e6 2. d4 c5 3. Nf3 Nf6 4. d5 d6 5. Nc3 exd5 6. cxd5 g6

Runtime playKey: `c2c4,e7e6,d2d4,c7c5,g1f3,g8f6,d4d5,d7d6,b1c3,e6d5,c4d5,g7g6`  
Runtime totalGames field at line node: `513005`

### Packet english-white.line-010.ply-01.c2c4

- Move: `c4` / `c2c4` at ply 1

- CoachCard: **Use the English flank pawn** — c4 is the English Opening’s defining flank claim: White’s c-pawn controls d5 without committing the e-pawn or d-pawn immediately.

- Plain hint: Use the flank pawn to challenge the center from the side while keeping the central pawns flexible.

- Opening themes: c4 controls d5, flank control, delayed central commitment

### Packet english-white.line-010.ply-03.d2d4

- Move: `d4` / `d2d4` at ply 3

- CoachCard: **Transpose into direct central pressure** — d4 changes the English from pure flank control into direct d-pawn central pressure. White uses the earlier c-pawn setup to contest Black’s center.

- Plain hint: Commit the queen pawn only when the flank pressure already supports the center.

- Opening themes: d4 transposition, central pressure, c-pawn support

### Packet english-white.line-010.ply-05.g1f3

- Move: `Nf3` / `g1f3` at ply 5

- CoachCard: **Prepare flexible English development** — Nf3 develops the kingside knight without forcing the center. In English lines, this keeps White ready for d4, e4, g3, or quiet kingside castling.

- Plain hint: Bring the kingside knight out while keeping central pawn choices open.

- Opening themes: flexible development, delayed center, kingside safety

### Packet english-white.line-010.ply-07.d4d5

- Move: `d5` / `d4d5` at ply 7

- CoachCard: **Keep the English flexibility intact** — d5 stays connected to the English plan: c-pawn pressure on d5, flexible central commitment, and smooth development.

- Plain hint: Preserve flank control, central flexibility, and safe development.

- Opening themes: English flexibility, flank control, development

### Packet english-white.line-010.ply-09.b1c3

- Move: `Nc3` / `b1c3` at ply 9

- CoachCard: **Increase English pressure on d5** — Nc3 adds a knight to the English fight over d5 and e4. It supports flexible setups where White may transpose into queen-pawn or reversed Sicilian structures.

- Plain hint: Develop the queenside knight toward the dark-square center behind the flank pawn.

- Opening themes: d5 pressure, dark-square control, transposition flexibility

### Packet english-white.line-010.ply-11.c4d5

- Move: `cxd5` / `c4d5` at ply 11

- CoachCard: **Resolve the d5 tension from the flank** — cxd5 uses the English c-pawn to remove Black’s central pawn. The capture converts flank pressure into a concrete central decision.

- Plain hint: Use the flank pawn to clarify the central tension when it helps White’s structure.

- Opening themes: d5 capture, flank-to-center pressure, structure decision


## english-white-line-011: 1. c4 e6 2. Nc3 d5 3. e3 c5 4. d4 Nf6 5. Nf3 cxd4 6. exd4 Bb4

Runtime playKey: `c2c4,e7e6,b1c3,d7d5,e2e3,c7c5,d2d4,g8f6,g1f3,c5d4,e3d4,f8b4`  
Runtime totalGames field at line node: `486873`

### Packet english-white.line-011.ply-01.c2c4

- Move: `c4` / `c2c4` at ply 1

- CoachCard: **Use the English flank pawn** — c4 is the English Opening’s defining flank claim: White’s c-pawn controls d5 without committing the e-pawn or d-pawn immediately.

- Plain hint: Use the flank pawn to challenge the center from the side while keeping the central pawns flexible.

- Opening themes: c4 controls d5, flank control, delayed central commitment

### Packet english-white.line-011.ply-03.b1c3

- Move: `Nc3` / `b1c3` at ply 3

- CoachCard: **Increase English pressure on d5** — Nc3 adds a knight to the English fight over d5 and e4. It supports flexible setups where White may transpose into queen-pawn or reversed Sicilian structures.

- Plain hint: Develop the queenside knight toward the dark-square center behind the flank pawn.

- Opening themes: d5 pressure, dark-square control, transposition flexibility

### Packet english-white.line-011.ply-05.e2e3

- Move: `e3` / `e2e3` at ply 5

- CoachCard: **Keep the English flexibility intact** — e3 stays connected to the English plan: c-pawn pressure on d5, flexible central commitment, and smooth development.

- Plain hint: Preserve flank control, central flexibility, and safe development.

- Opening themes: English flexibility, flank control, development

### Packet english-white.line-011.ply-07.d2d4

- Move: `d4` / `d2d4` at ply 7

- CoachCard: **Transpose into direct central pressure** — d4 changes the English from pure flank control into direct d-pawn central pressure. White uses the earlier c-pawn setup to contest Black’s center.

- Plain hint: Commit the queen pawn only when the flank pressure already supports the center.

- Opening themes: d4 transposition, central pressure, c-pawn support

### Packet english-white.line-011.ply-09.g1f3

- Move: `Nf3` / `g1f3` at ply 9

- CoachCard: **Prepare flexible English development** — Nf3 develops the kingside knight without forcing the center. In English lines, this keeps White ready for d4, e4, g3, or quiet kingside castling.

- Plain hint: Bring the kingside knight out while keeping central pawn choices open.

- Opening themes: flexible development, delayed center, kingside safety

### Packet english-white.line-011.ply-11.e3d4

- Move: `exd4` / `e3d4` at ply 11

- CoachCard: **Keep the English flexibility intact** — exd4 stays connected to the English plan: c-pawn pressure on d5, flexible central commitment, and smooth development.

- Plain hint: Preserve flank control, central flexibility, and safe development.

- Opening themes: English flexibility, flank control, development


## english-white-line-012: 1. c4 Nf6 2. Nc3 g6 3. d4 d5 4. Nf3 Bg7 5. cxd5 Nxd5 6. e4 Nxc3

Runtime playKey: `c2c4,g8f6,b1c3,g7g6,d2d4,d7d5,g1f3,f8g7,c4d5,f6d5,e2e4,d5c3`  
Runtime totalGames field at line node: `455570`

### Packet english-white.line-012.ply-01.c2c4

- Move: `c4` / `c2c4` at ply 1

- CoachCard: **Use the English flank pawn** — c4 is the English Opening’s defining flank claim: White’s c-pawn controls d5 without committing the e-pawn or d-pawn immediately.

- Plain hint: Use the flank pawn to challenge the center from the side while keeping the central pawns flexible.

- Opening themes: c4 controls d5, flank control, delayed central commitment

### Packet english-white.line-012.ply-03.b1c3

- Move: `Nc3` / `b1c3` at ply 3

- CoachCard: **Increase English pressure on d5** — Nc3 adds a knight to the English fight over d5 and e4. It supports flexible setups where White may transpose into queen-pawn or reversed Sicilian structures.

- Plain hint: Develop the queenside knight toward the dark-square center behind the flank pawn.

- Opening themes: d5 pressure, dark-square control, transposition flexibility

### Packet english-white.line-012.ply-05.d2d4

- Move: `d4` / `d2d4` at ply 5

- CoachCard: **Transpose into direct central pressure** — d4 changes the English from pure flank control into direct d-pawn central pressure. White uses the earlier c-pawn setup to contest Black’s center.

- Plain hint: Commit the queen pawn only when the flank pressure already supports the center.

- Opening themes: d4 transposition, central pressure, c-pawn support

### Packet english-white.line-012.ply-07.g1f3

- Move: `Nf3` / `g1f3` at ply 7

- CoachCard: **Prepare flexible English development** — Nf3 develops the kingside knight without forcing the center. In English lines, this keeps White ready for d4, e4, g3, or quiet kingside castling.

- Plain hint: Bring the kingside knight out while keeping central pawn choices open.

- Opening themes: flexible development, delayed center, kingside safety

### Packet english-white.line-012.ply-09.c4d5

- Move: `cxd5` / `c4d5` at ply 9

- CoachCard: **Resolve the d5 tension from the flank** — cxd5 uses the English c-pawn to remove Black’s central pawn. The capture converts flank pressure into a concrete central decision.

- Plain hint: Use the flank pawn to clarify the central tension when it helps White’s structure.

- Opening themes: d5 capture, flank-to-center pressure, structure decision

### Packet english-white.line-012.ply-11.e2e4

- Move: `e4` / `e2e4` at ply 11

- CoachCard: **Take broad central space from the English** — e4 expands from an English move order into a broad pawn center. This is strongest when White’s c-pawn and knights already support the dark squares.

- Plain hint: Claim more central space once the queenside and dark-square support are ready.

- Opening themes: delayed e-pawn, broad center, dark-square support


## english-white-line-013: 1. c4 e6 2. d4 c5 3. d5 Nf6 4. Nc3 d6 5. e4 exd5 6. cxd5 Be7

Runtime playKey: `c2c4,e7e6,d2d4,c7c5,d4d5,g8f6,b1c3,d7d6,e2e4,e6d5,c4d5,f8e7`  
Runtime totalGames field at line node: `417296`

### Packet english-white.line-013.ply-01.c2c4

- Move: `c4` / `c2c4` at ply 1

- CoachCard: **Use the English flank pawn** — c4 is the English Opening’s defining flank claim: White’s c-pawn controls d5 without committing the e-pawn or d-pawn immediately.

- Plain hint: Use the flank pawn to challenge the center from the side while keeping the central pawns flexible.

- Opening themes: c4 controls d5, flank control, delayed central commitment

### Packet english-white.line-013.ply-03.d2d4

- Move: `d4` / `d2d4` at ply 3

- CoachCard: **Transpose into direct central pressure** — d4 changes the English from pure flank control into direct d-pawn central pressure. White uses the earlier c-pawn setup to contest Black’s center.

- Plain hint: Commit the queen pawn only when the flank pressure already supports the center.

- Opening themes: d4 transposition, central pressure, c-pawn support

### Packet english-white.line-013.ply-05.d4d5

- Move: `d5` / `d4d5` at ply 5

- CoachCard: **Keep the English flexibility intact** — d5 stays connected to the English plan: c-pawn pressure on d5, flexible central commitment, and smooth development.

- Plain hint: Preserve flank control, central flexibility, and safe development.

- Opening themes: English flexibility, flank control, development

### Packet english-white.line-013.ply-07.b1c3

- Move: `Nc3` / `b1c3` at ply 7

- CoachCard: **Increase English pressure on d5** — Nc3 adds a knight to the English fight over d5 and e4. It supports flexible setups where White may transpose into queen-pawn or reversed Sicilian structures.

- Plain hint: Develop the queenside knight toward the dark-square center behind the flank pawn.

- Opening themes: d5 pressure, dark-square control, transposition flexibility

### Packet english-white.line-013.ply-09.e2e4

- Move: `e4` / `e2e4` at ply 9

- CoachCard: **Take broad central space from the English** — e4 expands from an English move order into a broad pawn center. This is strongest when White’s c-pawn and knights already support the dark squares.

- Plain hint: Claim more central space once the queenside and dark-square support are ready.

- Opening themes: delayed e-pawn, broad center, dark-square support

### Packet english-white.line-013.ply-11.c4d5

- Move: `cxd5` / `c4d5` at ply 11

- CoachCard: **Resolve the d5 tension from the flank** — cxd5 uses the English c-pawn to remove Black’s central pawn. The capture converts flank pressure into a concrete central decision.

- Plain hint: Use the flank pawn to clarify the central tension when it helps White’s structure.

- Opening themes: d5 capture, flank-to-center pressure, structure decision


## english-white-line-014: 1. c4 e6 2. Nc3 d5 3. e3 c5 4. d4 Nf6 5. Nf3 cxd4 6. exd4 Be7

Runtime playKey: `c2c4,e7e6,b1c3,d7d5,e2e3,c7c5,d2d4,g8f6,g1f3,c5d4,e3d4,f8e7`  
Runtime totalGames field at line node: `378455`

### Packet english-white.line-014.ply-01.c2c4

- Move: `c4` / `c2c4` at ply 1

- CoachCard: **Use the English flank pawn** — c4 is the English Opening’s defining flank claim: White’s c-pawn controls d5 without committing the e-pawn or d-pawn immediately.

- Plain hint: Use the flank pawn to challenge the center from the side while keeping the central pawns flexible.

- Opening themes: c4 controls d5, flank control, delayed central commitment

### Packet english-white.line-014.ply-03.b1c3

- Move: `Nc3` / `b1c3` at ply 3

- CoachCard: **Increase English pressure on d5** — Nc3 adds a knight to the English fight over d5 and e4. It supports flexible setups where White may transpose into queen-pawn or reversed Sicilian structures.

- Plain hint: Develop the queenside knight toward the dark-square center behind the flank pawn.

- Opening themes: d5 pressure, dark-square control, transposition flexibility

### Packet english-white.line-014.ply-05.e2e3

- Move: `e3` / `e2e3` at ply 5

- CoachCard: **Keep the English flexibility intact** — e3 stays connected to the English plan: c-pawn pressure on d5, flexible central commitment, and smooth development.

- Plain hint: Preserve flank control, central flexibility, and safe development.

- Opening themes: English flexibility, flank control, development

### Packet english-white.line-014.ply-07.d2d4

- Move: `d4` / `d2d4` at ply 7

- CoachCard: **Transpose into direct central pressure** — d4 changes the English from pure flank control into direct d-pawn central pressure. White uses the earlier c-pawn setup to contest Black’s center.

- Plain hint: Commit the queen pawn only when the flank pressure already supports the center.

- Opening themes: d4 transposition, central pressure, c-pawn support

### Packet english-white.line-014.ply-09.g1f3

- Move: `Nf3` / `g1f3` at ply 9

- CoachCard: **Prepare flexible English development** — Nf3 develops the kingside knight without forcing the center. In English lines, this keeps White ready for d4, e4, g3, or quiet kingside castling.

- Plain hint: Bring the kingside knight out while keeping central pawn choices open.

- Opening themes: flexible development, delayed center, kingside safety

### Packet english-white.line-014.ply-11.e3d4

- Move: `exd4` / `e3d4` at ply 11

- CoachCard: **Keep the English flexibility intact** — exd4 stays connected to the English plan: c-pawn pressure on d5, flexible central commitment, and smooth development.

- Plain hint: Preserve flank control, central flexibility, and safe development.

- Opening themes: English flexibility, flank control, development


## english-white-line-015: 1. c4 e6 2. d4 c5 3. Nf3 Nf6 4. Nc3 cxd4 5. Nxd4 a6 6. e4 Qc7

Runtime playKey: `c2c4,e7e6,d2d4,c7c5,g1f3,g8f6,b1c3,c5d4,f3d4,a7a6,e2e4,d8c7`  
Runtime totalGames field at line node: `361488`

### Packet english-white.line-015.ply-01.c2c4

- Move: `c4` / `c2c4` at ply 1

- CoachCard: **Use the English flank pawn** — c4 is the English Opening’s defining flank claim: White’s c-pawn controls d5 without committing the e-pawn or d-pawn immediately.

- Plain hint: Use the flank pawn to challenge the center from the side while keeping the central pawns flexible.

- Opening themes: c4 controls d5, flank control, delayed central commitment

### Packet english-white.line-015.ply-03.d2d4

- Move: `d4` / `d2d4` at ply 3

- CoachCard: **Transpose into direct central pressure** — d4 changes the English from pure flank control into direct d-pawn central pressure. White uses the earlier c-pawn setup to contest Black’s center.

- Plain hint: Commit the queen pawn only when the flank pressure already supports the center.

- Opening themes: d4 transposition, central pressure, c-pawn support

### Packet english-white.line-015.ply-05.g1f3

- Move: `Nf3` / `g1f3` at ply 5

- CoachCard: **Prepare flexible English development** — Nf3 develops the kingside knight without forcing the center. In English lines, this keeps White ready for d4, e4, g3, or quiet kingside castling.

- Plain hint: Bring the kingside knight out while keeping central pawn choices open.

- Opening themes: flexible development, delayed center, kingside safety

### Packet english-white.line-015.ply-07.b1c3

- Move: `Nc3` / `b1c3` at ply 7

- CoachCard: **Increase English pressure on d5** — Nc3 adds a knight to the English fight over d5 and e4. It supports flexible setups where White may transpose into queen-pawn or reversed Sicilian structures.

- Plain hint: Develop the queenside knight toward the dark-square center behind the flank pawn.

- Opening themes: d5 pressure, dark-square control, transposition flexibility

### Packet english-white.line-015.ply-09.f3d4

- Move: `Nxd4` / `f3d4` at ply 9

- CoachCard: **Keep the English flexibility intact** — Nxd4 stays connected to the English plan: c-pawn pressure on d5, flexible central commitment, and smooth development.

- Plain hint: Preserve flank control, central flexibility, and safe development.

- Opening themes: English flexibility, flank control, development

### Packet english-white.line-015.ply-11.e2e4

- Move: `e4` / `e2e4` at ply 11

- CoachCard: **Take broad central space from the English** — e4 expands from an English move order into a broad pawn center. This is strongest when White’s c-pawn and knights already support the dark squares.

- Plain hint: Claim more central space once the queenside and dark-square support are ready.

- Opening themes: delayed e-pawn, broad center, dark-square support


## english-white-line-016: 1. c4 Nf6 2. d4 c5 3. d5 b5 4. cxb5 a6 5. bxa6 Bxa6 6. Nc3 d6

Runtime playKey: `c2c4,g8f6,d2d4,c7c5,d4d5,b7b5,c4b5,a7a6,b5a6,c8a6,b1c3,d7d6`  
Runtime totalGames field at line node: `344270`

### Packet english-white.line-016.ply-01.c2c4

- Move: `c4` / `c2c4` at ply 1

- CoachCard: **Use the English flank pawn** — c4 is the English Opening’s defining flank claim: White’s c-pawn controls d5 without committing the e-pawn or d-pawn immediately.

- Plain hint: Use the flank pawn to challenge the center from the side while keeping the central pawns flexible.

- Opening themes: c4 controls d5, flank control, delayed central commitment

### Packet english-white.line-016.ply-03.d2d4

- Move: `d4` / `d2d4` at ply 3

- CoachCard: **Transpose into direct central pressure** — d4 changes the English from pure flank control into direct d-pawn central pressure. White uses the earlier c-pawn setup to contest Black’s center.

- Plain hint: Commit the queen pawn only when the flank pressure already supports the center.

- Opening themes: d4 transposition, central pressure, c-pawn support

### Packet english-white.line-016.ply-05.d4d5

- Move: `d5` / `d4d5` at ply 5

- CoachCard: **Keep the English flexibility intact** — d5 stays connected to the English plan: c-pawn pressure on d5, flexible central commitment, and smooth development.

- Plain hint: Preserve flank control, central flexibility, and safe development.

- Opening themes: English flexibility, flank control, development

### Packet english-white.line-016.ply-07.c4b5

- Move: `cxb5` / `c4b5` at ply 7

- CoachCard: **Keep the English flexibility intact** — cxb5 stays connected to the English plan: c-pawn pressure on d5, flexible central commitment, and smooth development.

- Plain hint: Preserve flank control, central flexibility, and safe development.

- Opening themes: English flexibility, flank control, development

### Packet english-white.line-016.ply-09.b5a6

- Move: `bxa6` / `b5a6` at ply 9

- CoachCard: **Keep the English flexibility intact** — bxa6 stays connected to the English plan: c-pawn pressure on d5, flexible central commitment, and smooth development.

- Plain hint: Preserve flank control, central flexibility, and safe development.

- Opening themes: English flexibility, flank control, development

### Packet english-white.line-016.ply-11.b1c3

- Move: `Nc3` / `b1c3` at ply 11

- CoachCard: **Increase English pressure on d5** — Nc3 adds a knight to the English fight over d5 and e4. It supports flexible setups where White may transpose into queen-pawn or reversed Sicilian structures.

- Plain hint: Develop the queenside knight toward the dark-square center behind the flank pawn.

- Opening themes: d5 pressure, dark-square control, transposition flexibility


## english-white-line-017: 1. c4 c5 2. Nc3 Nf6 3. e4 d6 4. Nf3 Nc6 5. d4 cxd4 6. Nxd4 g6

Runtime playKey: `c2c4,c7c5,b1c3,g8f6,e2e4,d7d6,g1f3,b8c6,d2d4,c5d4,f3d4,g7g6`  
Runtime totalGames field at line node: `343801`

### Packet english-white.line-017.ply-01.c2c4

- Move: `c4` / `c2c4` at ply 1

- CoachCard: **Use the English flank pawn** — c4 is the English Opening’s defining flank claim: White’s c-pawn controls d5 without committing the e-pawn or d-pawn immediately.

- Plain hint: Use the flank pawn to challenge the center from the side while keeping the central pawns flexible.

- Opening themes: c4 controls d5, flank control, delayed central commitment

### Packet english-white.line-017.ply-03.b1c3

- Move: `Nc3` / `b1c3` at ply 3

- CoachCard: **Increase English pressure on d5** — Nc3 adds a knight to the English fight over d5 and e4. It supports flexible setups where White may transpose into queen-pawn or reversed Sicilian structures.

- Plain hint: Develop the queenside knight toward the dark-square center behind the flank pawn.

- Opening themes: d5 pressure, dark-square control, transposition flexibility

### Packet english-white.line-017.ply-05.e2e4

- Move: `e4` / `e2e4` at ply 5

- CoachCard: **Take broad central space from the English** — e4 expands from an English move order into a broad pawn center. This is strongest when White’s c-pawn and knights already support the dark squares.

- Plain hint: Claim more central space once the queenside and dark-square support are ready.

- Opening themes: delayed e-pawn, broad center, dark-square support

### Packet english-white.line-017.ply-07.g1f3

- Move: `Nf3` / `g1f3` at ply 7

- CoachCard: **Prepare flexible English development** — Nf3 develops the kingside knight without forcing the center. In English lines, this keeps White ready for d4, e4, g3, or quiet kingside castling.

- Plain hint: Bring the kingside knight out while keeping central pawn choices open.

- Opening themes: flexible development, delayed center, kingside safety

### Packet english-white.line-017.ply-09.d2d4

- Move: `d4` / `d2d4` at ply 9

- CoachCard: **Transpose into direct central pressure** — d4 changes the English from pure flank control into direct d-pawn central pressure. White uses the earlier c-pawn setup to contest Black’s center.

- Plain hint: Commit the queen pawn only when the flank pressure already supports the center.

- Opening themes: d4 transposition, central pressure, c-pawn support

### Packet english-white.line-017.ply-11.f3d4

- Move: `Nxd4` / `f3d4` at ply 11

- CoachCard: **Keep the English flexibility intact** — Nxd4 stays connected to the English plan: c-pawn pressure on d5, flexible central commitment, and smooth development.

- Plain hint: Preserve flank control, central flexibility, and safe development.

- Opening themes: English flexibility, flank control, development


## english-white-line-018: 1. c4 Nf6 2. d4 c5 3. d5 b5 4. cxb5 a6 5. bxa6 g6 6. Nc3 Bxa6

Runtime playKey: `c2c4,g8f6,d2d4,c7c5,d4d5,b7b5,c4b5,a7a6,b5a6,g7g6,b1c3,c8a6`  
Runtime totalGames field at line node: `314858`

### Packet english-white.line-018.ply-01.c2c4

- Move: `c4` / `c2c4` at ply 1

- CoachCard: **Use the English flank pawn** — c4 is the English Opening’s defining flank claim: White’s c-pawn controls d5 without committing the e-pawn or d-pawn immediately.

- Plain hint: Use the flank pawn to challenge the center from the side while keeping the central pawns flexible.

- Opening themes: c4 controls d5, flank control, delayed central commitment

### Packet english-white.line-018.ply-03.d2d4

- Move: `d4` / `d2d4` at ply 3

- CoachCard: **Transpose into direct central pressure** — d4 changes the English from pure flank control into direct d-pawn central pressure. White uses the earlier c-pawn setup to contest Black’s center.

- Plain hint: Commit the queen pawn only when the flank pressure already supports the center.

- Opening themes: d4 transposition, central pressure, c-pawn support

### Packet english-white.line-018.ply-05.d4d5

- Move: `d5` / `d4d5` at ply 5

- CoachCard: **Keep the English flexibility intact** — d5 stays connected to the English plan: c-pawn pressure on d5, flexible central commitment, and smooth development.

- Plain hint: Preserve flank control, central flexibility, and safe development.

- Opening themes: English flexibility, flank control, development

### Packet english-white.line-018.ply-07.c4b5

- Move: `cxb5` / `c4b5` at ply 7

- CoachCard: **Keep the English flexibility intact** — cxb5 stays connected to the English plan: c-pawn pressure on d5, flexible central commitment, and smooth development.

- Plain hint: Preserve flank control, central flexibility, and safe development.

- Opening themes: English flexibility, flank control, development

### Packet english-white.line-018.ply-09.b5a6

- Move: `bxa6` / `b5a6` at ply 9

- CoachCard: **Keep the English flexibility intact** — bxa6 stays connected to the English plan: c-pawn pressure on d5, flexible central commitment, and smooth development.

- Plain hint: Preserve flank control, central flexibility, and safe development.

- Opening themes: English flexibility, flank control, development

### Packet english-white.line-018.ply-11.b1c3

- Move: `Nc3` / `b1c3` at ply 11

- CoachCard: **Increase English pressure on d5** — Nc3 adds a knight to the English fight over d5 and e4. It supports flexible setups where White may transpose into queen-pawn or reversed Sicilian structures.

- Plain hint: Develop the queenside knight toward the dark-square center behind the flank pawn.

- Opening themes: d5 pressure, dark-square control, transposition flexibility


## english-white-line-019: 1. c4 e6 2. d4 d5 3. Nc3 c6 4. Nf3 f5 5. Bf4 Bd6 6. e3 Nf6

Runtime playKey: `c2c4,e7e6,d2d4,d7d5,b1c3,c7c6,g1f3,f7f5,c1f4,f8d6,e2e3,g8f6`  
Runtime totalGames field at line node: `290965`

### Packet english-white.line-019.ply-01.c2c4

- Move: `c4` / `c2c4` at ply 1

- CoachCard: **Use the English flank pawn** — c4 is the English Opening’s defining flank claim: White’s c-pawn controls d5 without committing the e-pawn or d-pawn immediately.

- Plain hint: Use the flank pawn to challenge the center from the side while keeping the central pawns flexible.

- Opening themes: c4 controls d5, flank control, delayed central commitment

### Packet english-white.line-019.ply-03.d2d4

- Move: `d4` / `d2d4` at ply 3

- CoachCard: **Transpose into direct central pressure** — d4 changes the English from pure flank control into direct d-pawn central pressure. White uses the earlier c-pawn setup to contest Black’s center.

- Plain hint: Commit the queen pawn only when the flank pressure already supports the center.

- Opening themes: d4 transposition, central pressure, c-pawn support

### Packet english-white.line-019.ply-05.b1c3

- Move: `Nc3` / `b1c3` at ply 5

- CoachCard: **Increase English pressure on d5** — Nc3 adds a knight to the English fight over d5 and e4. It supports flexible setups where White may transpose into queen-pawn or reversed Sicilian structures.

- Plain hint: Develop the queenside knight toward the dark-square center behind the flank pawn.

- Opening themes: d5 pressure, dark-square control, transposition flexibility

### Packet english-white.line-019.ply-07.g1f3

- Move: `Nf3` / `g1f3` at ply 7

- CoachCard: **Prepare flexible English development** — Nf3 develops the kingside knight without forcing the center. In English lines, this keeps White ready for d4, e4, g3, or quiet kingside castling.

- Plain hint: Bring the kingside knight out while keeping central pawn choices open.

- Opening themes: flexible development, delayed center, kingside safety

### Packet english-white.line-019.ply-09.c1f4

- Move: `Bf4` / `c1f4` at ply 9

- CoachCard: **Keep the English flexibility intact** — Bf4 stays connected to the English plan: c-pawn pressure on d5, flexible central commitment, and smooth development.

- Plain hint: Preserve flank control, central flexibility, and safe development.

- Opening themes: English flexibility, flank control, development

### Packet english-white.line-019.ply-11.e2e3

- Move: `e3` / `e2e3` at ply 11

- CoachCard: **Keep the English flexibility intact** — e3 stays connected to the English plan: c-pawn pressure on d5, flexible central commitment, and smooth development.

- Plain hint: Preserve flank control, central flexibility, and safe development.

- Opening themes: English flexibility, flank control, development


## english-white-line-020: 1. c4 e6 2. d4 c5 3. Nf3 cxd4 4. Nxd4 Nc6 5. Nc3 Nf6 6. e4 Bb4

Runtime playKey: `c2c4,e7e6,d2d4,c7c5,g1f3,c5d4,f3d4,b8c6,b1c3,g8f6,e2e4,f8b4`  
Runtime totalGames field at line node: `270026`

### Packet english-white.line-020.ply-01.c2c4

- Move: `c4` / `c2c4` at ply 1

- CoachCard: **Use the English flank pawn** — c4 is the English Opening’s defining flank claim: White’s c-pawn controls d5 without committing the e-pawn or d-pawn immediately.

- Plain hint: Use the flank pawn to challenge the center from the side while keeping the central pawns flexible.

- Opening themes: c4 controls d5, flank control, delayed central commitment

### Packet english-white.line-020.ply-03.d2d4

- Move: `d4` / `d2d4` at ply 3

- CoachCard: **Transpose into direct central pressure** — d4 changes the English from pure flank control into direct d-pawn central pressure. White uses the earlier c-pawn setup to contest Black’s center.

- Plain hint: Commit the queen pawn only when the flank pressure already supports the center.

- Opening themes: d4 transposition, central pressure, c-pawn support

### Packet english-white.line-020.ply-05.g1f3

- Move: `Nf3` / `g1f3` at ply 5

- CoachCard: **Prepare flexible English development** — Nf3 develops the kingside knight without forcing the center. In English lines, this keeps White ready for d4, e4, g3, or quiet kingside castling.

- Plain hint: Bring the kingside knight out while keeping central pawn choices open.

- Opening themes: flexible development, delayed center, kingside safety

### Packet english-white.line-020.ply-07.f3d4

- Move: `Nxd4` / `f3d4` at ply 7

- CoachCard: **Keep the English flexibility intact** — Nxd4 stays connected to the English plan: c-pawn pressure on d5, flexible central commitment, and smooth development.

- Plain hint: Preserve flank control, central flexibility, and safe development.

- Opening themes: English flexibility, flank control, development

### Packet english-white.line-020.ply-09.b1c3

- Move: `Nc3` / `b1c3` at ply 9

- CoachCard: **Increase English pressure on d5** — Nc3 adds a knight to the English fight over d5 and e4. It supports flexible setups where White may transpose into queen-pawn or reversed Sicilian structures.

- Plain hint: Develop the queenside knight toward the dark-square center behind the flank pawn.

- Opening themes: d5 pressure, dark-square control, transposition flexibility

### Packet english-white.line-020.ply-11.e2e4

- Move: `e4` / `e2e4` at ply 11

- CoachCard: **Take broad central space from the English** — e4 expands from an English move order into a broad pawn center. This is strongest when White’s c-pawn and knights already support the dark squares.

- Plain hint: Claim more central space once the queenside and dark-square support are ready.

- Opening themes: delayed e-pawn, broad center, dark-square support


## english-white-line-021: 1. c4 e6 2. d4 d5 3. Nf3 c6 4. Nc3 Nf6 5. e3 Nbd7 6. Bd3 dxc4

Runtime playKey: `c2c4,e7e6,d2d4,d7d5,g1f3,c7c6,b1c3,g8f6,e2e3,b8d7,f1d3,d5c4`  
Runtime totalGames field at line node: `264798`

### Packet english-white.line-021.ply-01.c2c4

- Move: `c4` / `c2c4` at ply 1

- CoachCard: **Use the English flank pawn** — c4 is the English Opening’s defining flank claim: White’s c-pawn controls d5 without committing the e-pawn or d-pawn immediately.

- Plain hint: Use the flank pawn to challenge the center from the side while keeping the central pawns flexible.

- Opening themes: c4 controls d5, flank control, delayed central commitment

### Packet english-white.line-021.ply-03.d2d4

- Move: `d4` / `d2d4` at ply 3

- CoachCard: **Transpose into direct central pressure** — d4 changes the English from pure flank control into direct d-pawn central pressure. White uses the earlier c-pawn setup to contest Black’s center.

- Plain hint: Commit the queen pawn only when the flank pressure already supports the center.

- Opening themes: d4 transposition, central pressure, c-pawn support

### Packet english-white.line-021.ply-05.g1f3

- Move: `Nf3` / `g1f3` at ply 5

- CoachCard: **Prepare flexible English development** — Nf3 develops the kingside knight without forcing the center. In English lines, this keeps White ready for d4, e4, g3, or quiet kingside castling.

- Plain hint: Bring the kingside knight out while keeping central pawn choices open.

- Opening themes: flexible development, delayed center, kingside safety

### Packet english-white.line-021.ply-07.b1c3

- Move: `Nc3` / `b1c3` at ply 7

- CoachCard: **Increase English pressure on d5** — Nc3 adds a knight to the English fight over d5 and e4. It supports flexible setups where White may transpose into queen-pawn or reversed Sicilian structures.

- Plain hint: Develop the queenside knight toward the dark-square center behind the flank pawn.

- Opening themes: d5 pressure, dark-square control, transposition flexibility

### Packet english-white.line-021.ply-09.e2e3

- Move: `e3` / `e2e3` at ply 9

- CoachCard: **Keep the English flexibility intact** — e3 stays connected to the English plan: c-pawn pressure on d5, flexible central commitment, and smooth development.

- Plain hint: Preserve flank control, central flexibility, and safe development.

- Opening themes: English flexibility, flank control, development

### Packet english-white.line-021.ply-11.f1d3

- Move: `Bd3` / `f1d3` at ply 11

- CoachCard: **Keep the English flexibility intact** — Bd3 stays connected to the English plan: c-pawn pressure on d5, flexible central commitment, and smooth development.

- Plain hint: Preserve flank control, central flexibility, and safe development.

- Opening themes: English flexibility, flank control, development


## english-white-line-022: 1. c4 e6 2. d4 d5 3. Nf3 c5 4. cxd5 exd5 5. g3 Nc6 6. Bg2 Nf6

Runtime playKey: `c2c4,e7e6,d2d4,d7d5,g1f3,c7c5,c4d5,e6d5,g2g3,b8c6,f1g2,g8f6`  
Runtime totalGames field at line node: `263697`

### Packet english-white.line-022.ply-01.c2c4

- Move: `c4` / `c2c4` at ply 1

- CoachCard: **Use the English flank pawn** — c4 is the English Opening’s defining flank claim: White’s c-pawn controls d5 without committing the e-pawn or d-pawn immediately.

- Plain hint: Use the flank pawn to challenge the center from the side while keeping the central pawns flexible.

- Opening themes: c4 controls d5, flank control, delayed central commitment

### Packet english-white.line-022.ply-03.d2d4

- Move: `d4` / `d2d4` at ply 3

- CoachCard: **Transpose into direct central pressure** — d4 changes the English from pure flank control into direct d-pawn central pressure. White uses the earlier c-pawn setup to contest Black’s center.

- Plain hint: Commit the queen pawn only when the flank pressure already supports the center.

- Opening themes: d4 transposition, central pressure, c-pawn support

### Packet english-white.line-022.ply-05.g1f3

- Move: `Nf3` / `g1f3` at ply 5

- CoachCard: **Prepare flexible English development** — Nf3 develops the kingside knight without forcing the center. In English lines, this keeps White ready for d4, e4, g3, or quiet kingside castling.

- Plain hint: Bring the kingside knight out while keeping central pawn choices open.

- Opening themes: flexible development, delayed center, kingside safety

### Packet english-white.line-022.ply-07.c4d5

- Move: `cxd5` / `c4d5` at ply 7

- CoachCard: **Resolve the d5 tension from the flank** — cxd5 uses the English c-pawn to remove Black’s central pawn. The capture converts flank pressure into a concrete central decision.

- Plain hint: Use the flank pawn to clarify the central tension when it helps White’s structure.

- Opening themes: d5 capture, flank-to-center pressure, structure decision

### Packet english-white.line-022.ply-09.g2g3

- Move: `g3` / `g2g3` at ply 9

- CoachCard: **Choose the English kingside fianchetto** — g3 signals an English fianchetto setup. White keeps central choices flexible while preparing long-diagonal pressure.

- Plain hint: Prepare a kingside fianchetto to pressure the long diagonal while the center stays flexible.

- Opening themes: English fianchetto, long diagonal, central flexibility

### Packet english-white.line-022.ply-11.f1g2

- Move: `Bg2` / `f1g2` at ply 11

- CoachCard: **Finish the English long diagonal** — Bg2 completes the English fianchetto. The bishop supports pressure on the long diagonal while White decides how to use the center.

- Plain hint: Place the bishop on the long diagonal to support central and queenside pressure.

- Opening themes: g2 bishop, long diagonal, flank control


## english-white-line-023: 1. c4 e6 2. d4 d5 3. Nc3 c6 4. Bf4 Nf6 5. e3 Be7 6. Nf3 Nbd7

Runtime playKey: `c2c4,e7e6,d2d4,d7d5,b1c3,c7c6,c1f4,g8f6,e2e3,f8e7,g1f3,b8d7`  
Runtime totalGames field at line node: `260188`

### Packet english-white.line-023.ply-01.c2c4

- Move: `c4` / `c2c4` at ply 1

- CoachCard: **Use the English flank pawn** — c4 is the English Opening’s defining flank claim: White’s c-pawn controls d5 without committing the e-pawn or d-pawn immediately.

- Plain hint: Use the flank pawn to challenge the center from the side while keeping the central pawns flexible.

- Opening themes: c4 controls d5, flank control, delayed central commitment

### Packet english-white.line-023.ply-03.d2d4

- Move: `d4` / `d2d4` at ply 3

- CoachCard: **Transpose into direct central pressure** — d4 changes the English from pure flank control into direct d-pawn central pressure. White uses the earlier c-pawn setup to contest Black’s center.

- Plain hint: Commit the queen pawn only when the flank pressure already supports the center.

- Opening themes: d4 transposition, central pressure, c-pawn support

### Packet english-white.line-023.ply-05.b1c3

- Move: `Nc3` / `b1c3` at ply 5

- CoachCard: **Increase English pressure on d5** — Nc3 adds a knight to the English fight over d5 and e4. It supports flexible setups where White may transpose into queen-pawn or reversed Sicilian structures.

- Plain hint: Develop the queenside knight toward the dark-square center behind the flank pawn.

- Opening themes: d5 pressure, dark-square control, transposition flexibility

### Packet english-white.line-023.ply-07.c1f4

- Move: `Bf4` / `c1f4` at ply 7

- CoachCard: **Keep the English flexibility intact** — Bf4 stays connected to the English plan: c-pawn pressure on d5, flexible central commitment, and smooth development.

- Plain hint: Preserve flank control, central flexibility, and safe development.

- Opening themes: English flexibility, flank control, development

### Packet english-white.line-023.ply-09.e2e3

- Move: `e3` / `e2e3` at ply 9

- CoachCard: **Keep the English flexibility intact** — e3 stays connected to the English plan: c-pawn pressure on d5, flexible central commitment, and smooth development.

- Plain hint: Preserve flank control, central flexibility, and safe development.

- Opening themes: English flexibility, flank control, development

### Packet english-white.line-023.ply-11.g1f3

- Move: `Nf3` / `g1f3` at ply 11

- CoachCard: **Prepare flexible English development** — Nf3 develops the kingside knight without forcing the center. In English lines, this keeps White ready for d4, e4, g3, or quiet kingside castling.

- Plain hint: Bring the kingside knight out while keeping central pawn choices open.

- Opening themes: flexible development, delayed center, kingside safety


## english-white-line-024: 1. c4 e6 2. d4 d5 3. Nc3 c6 4. Nf3 Nf6 5. e3 Nbd7 6. Bd3 Bd6

Runtime playKey: `c2c4,e7e6,d2d4,d7d5,b1c3,c7c6,g1f3,g8f6,e2e3,b8d7,f1d3,f8d6`  
Runtime totalGames field at line node: `255466`

### Packet english-white.line-024.ply-01.c2c4

- Move: `c4` / `c2c4` at ply 1

- CoachCard: **Use the English flank pawn** — c4 is the English Opening’s defining flank claim: White’s c-pawn controls d5 without committing the e-pawn or d-pawn immediately.

- Plain hint: Use the flank pawn to challenge the center from the side while keeping the central pawns flexible.

- Opening themes: c4 controls d5, flank control, delayed central commitment

### Packet english-white.line-024.ply-03.d2d4

- Move: `d4` / `d2d4` at ply 3

- CoachCard: **Transpose into direct central pressure** — d4 changes the English from pure flank control into direct d-pawn central pressure. White uses the earlier c-pawn setup to contest Black’s center.

- Plain hint: Commit the queen pawn only when the flank pressure already supports the center.

- Opening themes: d4 transposition, central pressure, c-pawn support

### Packet english-white.line-024.ply-05.b1c3

- Move: `Nc3` / `b1c3` at ply 5

- CoachCard: **Increase English pressure on d5** — Nc3 adds a knight to the English fight over d5 and e4. It supports flexible setups where White may transpose into queen-pawn or reversed Sicilian structures.

- Plain hint: Develop the queenside knight toward the dark-square center behind the flank pawn.

- Opening themes: d5 pressure, dark-square control, transposition flexibility

### Packet english-white.line-024.ply-07.g1f3

- Move: `Nf3` / `g1f3` at ply 7

- CoachCard: **Prepare flexible English development** — Nf3 develops the kingside knight without forcing the center. In English lines, this keeps White ready for d4, e4, g3, or quiet kingside castling.

- Plain hint: Bring the kingside knight out while keeping central pawn choices open.

- Opening themes: flexible development, delayed center, kingside safety

### Packet english-white.line-024.ply-09.e2e3

- Move: `e3` / `e2e3` at ply 9

- CoachCard: **Keep the English flexibility intact** — e3 stays connected to the English plan: c-pawn pressure on d5, flexible central commitment, and smooth development.

- Plain hint: Preserve flank control, central flexibility, and safe development.

- Opening themes: English flexibility, flank control, development

### Packet english-white.line-024.ply-11.f1d3

- Move: `Bd3` / `f1d3` at ply 11

- CoachCard: **Keep the English flexibility intact** — Bd3 stays connected to the English plan: c-pawn pressure on d5, flexible central commitment, and smooth development.

- Plain hint: Preserve flank control, central flexibility, and safe development.

- Opening themes: English flexibility, flank control, development


## english-white-line-025: 1. c4 e6 2. d4 Nf6 3. Nc3 d5 4. Bg5 Bb4 5. Nf3 h6 6. Bxf6 Qxf6

Runtime playKey: `c2c4,e7e6,d2d4,g8f6,b1c3,d7d5,c1g5,f8b4,g1f3,h7h6,g5f6,d8f6`  
Runtime totalGames field at line node: `240000`

### Packet english-white.line-025.ply-01.c2c4

- Move: `c4` / `c2c4` at ply 1

- CoachCard: **Use the English flank pawn** — c4 is the English Opening’s defining flank claim: White’s c-pawn controls d5 without committing the e-pawn or d-pawn immediately.

- Plain hint: Use the flank pawn to challenge the center from the side while keeping the central pawns flexible.

- Opening themes: c4 controls d5, flank control, delayed central commitment

### Packet english-white.line-025.ply-03.d2d4

- Move: `d4` / `d2d4` at ply 3

- CoachCard: **Transpose into direct central pressure** — d4 changes the English from pure flank control into direct d-pawn central pressure. White uses the earlier c-pawn setup to contest Black’s center.

- Plain hint: Commit the queen pawn only when the flank pressure already supports the center.

- Opening themes: d4 transposition, central pressure, c-pawn support

### Packet english-white.line-025.ply-05.b1c3

- Move: `Nc3` / `b1c3` at ply 5

- CoachCard: **Increase English pressure on d5** — Nc3 adds a knight to the English fight over d5 and e4. It supports flexible setups where White may transpose into queen-pawn or reversed Sicilian structures.

- Plain hint: Develop the queenside knight toward the dark-square center behind the flank pawn.

- Opening themes: d5 pressure, dark-square control, transposition flexibility

### Packet english-white.line-025.ply-07.c1g5

- Move: `Bg5` / `c1g5` at ply 7

- CoachCard: **Keep the English flexibility intact** — Bg5 stays connected to the English plan: c-pawn pressure on d5, flexible central commitment, and smooth development.

- Plain hint: Preserve flank control, central flexibility, and safe development.

- Opening themes: English flexibility, flank control, development

### Packet english-white.line-025.ply-09.g1f3

- Move: `Nf3` / `g1f3` at ply 9

- CoachCard: **Prepare flexible English development** — Nf3 develops the kingside knight without forcing the center. In English lines, this keeps White ready for d4, e4, g3, or quiet kingside castling.

- Plain hint: Bring the kingside knight out while keeping central pawn choices open.

- Opening themes: flexible development, delayed center, kingside safety

### Packet english-white.line-025.ply-11.g5f6

- Move: `Bxf6` / `g5f6` at ply 11

- CoachCard: **Keep the English flexibility intact** — Bxf6 stays connected to the English plan: c-pawn pressure on d5, flexible central commitment, and smooth development.

- Plain hint: Preserve flank control, central flexibility, and safe development.

- Opening themes: English flexibility, flank control, development
