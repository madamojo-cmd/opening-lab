# Colle System approved-content candidates — Batch 2

Opening ID: `colle-white`  
Status: approved candidates only; not app-activated.


## colle-white-line-001: 1. d4 Nf6 2. Nf3 e6 3. e3 c5 4. Bd3 cxd4 5. exd4 Nc6 6. c3 d5

Runtime playKey: `d2d4,g8f6,g1f3,e7e6,e2e3,c7c5,f1d3,c5d4,e3d4,b8c6,c2c3,d7d5`  
Runtime totalGames field at line node: `240822`

### Packet colle-white.line-001.ply-01.d2d4

- Move: `d4` / `d2d4` at ply 1

- CoachCard: **Start the Colle queen-pawn shell** — d4 establishes the d-pawn base of the Colle System. White plans a compact Nf3/e3/c3 structure before choosing the central break.

- Plain hint: Build the queen-pawn base that the compact Colle structure rests on.

- Opening themes: d4 base, Colle shell, e4 break timing

### Packet colle-white.line-001.ply-03.g1f3

- Move: `Nf3` / `g1f3` at ply 3

- CoachCard: **Develop behind the Colle center** — Nf3 supports d4 and prepares kingside castling in the Colle structure. The knight helps White build before the e-pawn break.

- Plain hint: Place the kingside knight behind the queen-pawn center and prepare castling.

- Opening themes: Nf3 support, safe development, castling

### Packet colle-white.line-001.ply-05.e2e3

- Move: `e3` / `e2e3` at ply 5

- CoachCard: **Lock in the Colle structure** — e3 supports d4 and forms the Colle pawn shell with c3 when available. It also opens the light-square bishop for Bd3.

- Plain hint: Support the queen pawn and open the bishop route while keeping the setup compact.

- Opening themes: e3 support, Bd3 route, Colle shell

### Packet colle-white.line-001.ply-07.f1d3

- Move: `Bd3` / `f1d3` at ply 7

- CoachCard: **Aim the Colle bishop at the kingside** — Bd3 develops the bishop to the classic Colle diagonal toward the kingside. It supports castling and later attacking chances if the center opens.

- Plain hint: Place the light-square bishop on the attacking diagonal after the pawn shell is stable.

- Opening themes: Bd3 placement, kingside aim, Colle attacking setup

### Packet colle-white.line-001.ply-09.e3d4

- Move: `exd4` / `e3d4` at ply 9

- CoachCard: **Recapture and preserve the Colle center** — exd4 restores White’s central pawn presence after Black trades into the Colle structure. The recapture keeps the d-pawn base alive.

- Plain hint: Restore the central pawn base when Black exchanges into the shell.

- Opening themes: central recapture, d-pawn base, structure preservation

### Packet colle-white.line-001.ply-11.c2c3

- Move: `c3` / `c2c3` at ply 11

- CoachCard: **Complete the Colle d4/e3/c3 shell** — c3 completes the d4/e3/c3 Colle structure. White reinforces d4 and prepares to choose the right moment for e4.

- Plain hint: Reinforce the queen-pawn center so the later central break has a base.

- Opening themes: d4/e3/c3 structure, e4 preparation, center support


## colle-white-line-002: 1. d4 Nf6 2. Nf3 d5 3. e3 e6 4. Bd3 c5 5. c3 Nc6 6. Nbd2 Bd6

Runtime playKey: `d2d4,g8f6,g1f3,d7d5,e2e3,e7e6,f1d3,c7c5,c2c3,b8c6,b1d2,f8d6`  
Runtime totalGames field at line node: `203749`

### Packet colle-white.line-002.ply-01.d2d4

- Move: `d4` / `d2d4` at ply 1

- CoachCard: **Start the Colle queen-pawn shell** — d4 establishes the d-pawn base of the Colle System. White plans a compact Nf3/e3/c3 structure before choosing the central break.

- Plain hint: Build the queen-pawn base that the compact Colle structure rests on.

- Opening themes: d4 base, Colle shell, e4 break timing

### Packet colle-white.line-002.ply-03.g1f3

- Move: `Nf3` / `g1f3` at ply 3

- CoachCard: **Develop behind the Colle center** — Nf3 supports d4 and prepares kingside castling in the Colle structure. The knight helps White build before the e-pawn break.

- Plain hint: Place the kingside knight behind the queen-pawn center and prepare castling.

- Opening themes: Nf3 support, safe development, castling

### Packet colle-white.line-002.ply-05.e2e3

- Move: `e3` / `e2e3` at ply 5

- CoachCard: **Lock in the Colle structure** — e3 supports d4 and forms the Colle pawn shell with c3 when available. It also opens the light-square bishop for Bd3.

- Plain hint: Support the queen pawn and open the bishop route while keeping the setup compact.

- Opening themes: e3 support, Bd3 route, Colle shell

### Packet colle-white.line-002.ply-07.f1d3

- Move: `Bd3` / `f1d3` at ply 7

- CoachCard: **Aim the Colle bishop at the kingside** — Bd3 develops the bishop to the classic Colle diagonal toward the kingside. It supports castling and later attacking chances if the center opens.

- Plain hint: Place the light-square bishop on the attacking diagonal after the pawn shell is stable.

- Opening themes: Bd3 placement, kingside aim, Colle attacking setup

### Packet colle-white.line-002.ply-09.c2c3

- Move: `c3` / `c2c3` at ply 9

- CoachCard: **Complete the Colle d4/e3/c3 shell** — c3 completes the d4/e3/c3 Colle structure. White reinforces d4 and prepares to choose the right moment for e4.

- Plain hint: Reinforce the queen-pawn center so the later central break has a base.

- Opening themes: d4/e3/c3 structure, e4 preparation, center support

### Packet colle-white.line-002.ply-11.b1d2

- Move: `Nbd2` / `b1d2` at ply 11

- CoachCard: **Use the Colle Nbd2 support route** — Nbd2 supports the Colle center from behind and helps prepare e4. The knight route keeps c-pawn support intact.

- Plain hint: Route the queenside knight behind the pawn shell to reinforce the central break.

- Opening themes: Nbd2 route, e4 support, compact structure


## colle-white-line-003: 1. d4 Nf6 2. Nf3 d5 3. e3 e6 4. Bd3 c5 5. c3 Nc6 6. Nbd2 Be7

Runtime playKey: `d2d4,g8f6,g1f3,d7d5,e2e3,e7e6,f1d3,c7c5,c2c3,b8c6,b1d2,f8e7`  
Runtime totalGames field at line node: `122015`

### Packet colle-white.line-003.ply-01.d2d4

- Move: `d4` / `d2d4` at ply 1

- CoachCard: **Start the Colle queen-pawn shell** — d4 establishes the d-pawn base of the Colle System. White plans a compact Nf3/e3/c3 structure before choosing the central break.

- Plain hint: Build the queen-pawn base that the compact Colle structure rests on.

- Opening themes: d4 base, Colle shell, e4 break timing

### Packet colle-white.line-003.ply-03.g1f3

- Move: `Nf3` / `g1f3` at ply 3

- CoachCard: **Develop behind the Colle center** — Nf3 supports d4 and prepares kingside castling in the Colle structure. The knight helps White build before the e-pawn break.

- Plain hint: Place the kingside knight behind the queen-pawn center and prepare castling.

- Opening themes: Nf3 support, safe development, castling

### Packet colle-white.line-003.ply-05.e2e3

- Move: `e3` / `e2e3` at ply 5

- CoachCard: **Lock in the Colle structure** — e3 supports d4 and forms the Colle pawn shell with c3 when available. It also opens the light-square bishop for Bd3.

- Plain hint: Support the queen pawn and open the bishop route while keeping the setup compact.

- Opening themes: e3 support, Bd3 route, Colle shell

### Packet colle-white.line-003.ply-07.f1d3

- Move: `Bd3` / `f1d3` at ply 7

- CoachCard: **Aim the Colle bishop at the kingside** — Bd3 develops the bishop to the classic Colle diagonal toward the kingside. It supports castling and later attacking chances if the center opens.

- Plain hint: Place the light-square bishop on the attacking diagonal after the pawn shell is stable.

- Opening themes: Bd3 placement, kingside aim, Colle attacking setup

### Packet colle-white.line-003.ply-09.c2c3

- Move: `c3` / `c2c3` at ply 9

- CoachCard: **Complete the Colle d4/e3/c3 shell** — c3 completes the d4/e3/c3 Colle structure. White reinforces d4 and prepares to choose the right moment for e4.

- Plain hint: Reinforce the queen-pawn center so the later central break has a base.

- Opening themes: d4/e3/c3 structure, e4 preparation, center support

### Packet colle-white.line-003.ply-11.b1d2

- Move: `Nbd2` / `b1d2` at ply 11

- CoachCard: **Use the Colle Nbd2 support route** — Nbd2 supports the Colle center from behind and helps prepare e4. The knight route keeps c-pawn support intact.

- Plain hint: Route the queenside knight behind the pawn shell to reinforce the central break.

- Opening themes: Nbd2 route, e4 support, compact structure


## colle-white-line-004: 1. d4 d5 2. Nf3 Nc6 3. e3 Nf6 4. Bd3 Bg4 5. Nbd2 e6 6. c3 Bd6

Runtime playKey: `d2d4,d7d5,g1f3,b8c6,e2e3,g8f6,f1d3,c8g4,b1d2,e7e6,c2c3,f8d6`  
Runtime totalGames field at line node: `102155`

### Packet colle-white.line-004.ply-01.d2d4

- Move: `d4` / `d2d4` at ply 1

- CoachCard: **Start the Colle queen-pawn shell** — d4 establishes the d-pawn base of the Colle System. White plans a compact Nf3/e3/c3 structure before choosing the central break.

- Plain hint: Build the queen-pawn base that the compact Colle structure rests on.

- Opening themes: d4 base, Colle shell, e4 break timing

### Packet colle-white.line-004.ply-03.g1f3

- Move: `Nf3` / `g1f3` at ply 3

- CoachCard: **Develop behind the Colle center** — Nf3 supports d4 and prepares kingside castling in the Colle structure. The knight helps White build before the e-pawn break.

- Plain hint: Place the kingside knight behind the queen-pawn center and prepare castling.

- Opening themes: Nf3 support, safe development, castling

### Packet colle-white.line-004.ply-05.e2e3

- Move: `e3` / `e2e3` at ply 5

- CoachCard: **Lock in the Colle structure** — e3 supports d4 and forms the Colle pawn shell with c3 when available. It also opens the light-square bishop for Bd3.

- Plain hint: Support the queen pawn and open the bishop route while keeping the setup compact.

- Opening themes: e3 support, Bd3 route, Colle shell

### Packet colle-white.line-004.ply-07.f1d3

- Move: `Bd3` / `f1d3` at ply 7

- CoachCard: **Aim the Colle bishop at the kingside** — Bd3 develops the bishop to the classic Colle diagonal toward the kingside. It supports castling and later attacking chances if the center opens.

- Plain hint: Place the light-square bishop on the attacking diagonal after the pawn shell is stable.

- Opening themes: Bd3 placement, kingside aim, Colle attacking setup

### Packet colle-white.line-004.ply-09.b1d2

- Move: `Nbd2` / `b1d2` at ply 9

- CoachCard: **Use the Colle Nbd2 support route** — Nbd2 supports the Colle center from behind and helps prepare e4. The knight route keeps c-pawn support intact.

- Plain hint: Route the queenside knight behind the pawn shell to reinforce the central break.

- Opening themes: Nbd2 route, e4 support, compact structure

### Packet colle-white.line-004.ply-11.c2c3

- Move: `c3` / `c2c3` at ply 11

- CoachCard: **Complete the Colle d4/e3/c3 shell** — c3 completes the d4/e3/c3 Colle structure. White reinforces d4 and prepares to choose the right moment for e4.

- Plain hint: Reinforce the queen-pawn center so the later central break has a base.

- Opening themes: d4/e3/c3 structure, e4 preparation, center support


## colle-white-line-005: 1. d4 Nf6 2. Nf3 d5 3. e3 e6 4. Bd3 c5 5. c3 c4 6. Bc2 Nc6

Runtime playKey: `d2d4,g8f6,g1f3,d7d5,e2e3,e7e6,f1d3,c7c5,c2c3,c5c4,d3c2,b8c6`  
Runtime totalGames field at line node: `91691`

### Packet colle-white.line-005.ply-01.d2d4

- Move: `d4` / `d2d4` at ply 1

- CoachCard: **Start the Colle queen-pawn shell** — d4 establishes the d-pawn base of the Colle System. White plans a compact Nf3/e3/c3 structure before choosing the central break.

- Plain hint: Build the queen-pawn base that the compact Colle structure rests on.

- Opening themes: d4 base, Colle shell, e4 break timing

### Packet colle-white.line-005.ply-03.g1f3

- Move: `Nf3` / `g1f3` at ply 3

- CoachCard: **Develop behind the Colle center** — Nf3 supports d4 and prepares kingside castling in the Colle structure. The knight helps White build before the e-pawn break.

- Plain hint: Place the kingside knight behind the queen-pawn center and prepare castling.

- Opening themes: Nf3 support, safe development, castling

### Packet colle-white.line-005.ply-05.e2e3

- Move: `e3` / `e2e3` at ply 5

- CoachCard: **Lock in the Colle structure** — e3 supports d4 and forms the Colle pawn shell with c3 when available. It also opens the light-square bishop for Bd3.

- Plain hint: Support the queen pawn and open the bishop route while keeping the setup compact.

- Opening themes: e3 support, Bd3 route, Colle shell

### Packet colle-white.line-005.ply-07.f1d3

- Move: `Bd3` / `f1d3` at ply 7

- CoachCard: **Aim the Colle bishop at the kingside** — Bd3 develops the bishop to the classic Colle diagonal toward the kingside. It supports castling and later attacking chances if the center opens.

- Plain hint: Place the light-square bishop on the attacking diagonal after the pawn shell is stable.

- Opening themes: Bd3 placement, kingside aim, Colle attacking setup

### Packet colle-white.line-005.ply-09.c2c3

- Move: `c3` / `c2c3` at ply 9

- CoachCard: **Complete the Colle d4/e3/c3 shell** — c3 completes the d4/e3/c3 Colle structure. White reinforces d4 and prepares to choose the right moment for e4.

- Plain hint: Reinforce the queen-pawn center so the later central break has a base.

- Opening themes: d4/e3/c3 structure, e4 preparation, center support

### Packet colle-white.line-005.ply-11.d3c2

- Move: `Bc2` / `d3c2` at ply 11

- CoachCard: **Keep the Colle plan compact** — Bc2 stays connected to the Colle plan: compact development, d4 support, bishop coordination, and a timed central break.

- Plain hint: Keep the d-pawn shell stable, castle safely, and prepare the central break.

- Opening themes: Colle structure, safe development, central timing


## colle-white-line-006: 1. d4 Nf6 2. Nf3 d5 3. e3 Bf5 4. Bd3 Bxd3 5. Qxd3 Nc6 6. c3 e6

Runtime playKey: `d2d4,g8f6,g1f3,d7d5,e2e3,c8f5,f1d3,f5d3,d1d3,b8c6,c2c3,e7e6`  
Runtime totalGames field at line node: `82295`

### Packet colle-white.line-006.ply-01.d2d4

- Move: `d4` / `d2d4` at ply 1

- CoachCard: **Start the Colle queen-pawn shell** — d4 establishes the d-pawn base of the Colle System. White plans a compact Nf3/e3/c3 structure before choosing the central break.

- Plain hint: Build the queen-pawn base that the compact Colle structure rests on.

- Opening themes: d4 base, Colle shell, e4 break timing

### Packet colle-white.line-006.ply-03.g1f3

- Move: `Nf3` / `g1f3` at ply 3

- CoachCard: **Develop behind the Colle center** — Nf3 supports d4 and prepares kingside castling in the Colle structure. The knight helps White build before the e-pawn break.

- Plain hint: Place the kingside knight behind the queen-pawn center and prepare castling.

- Opening themes: Nf3 support, safe development, castling

### Packet colle-white.line-006.ply-05.e2e3

- Move: `e3` / `e2e3` at ply 5

- CoachCard: **Lock in the Colle structure** — e3 supports d4 and forms the Colle pawn shell with c3 when available. It also opens the light-square bishop for Bd3.

- Plain hint: Support the queen pawn and open the bishop route while keeping the setup compact.

- Opening themes: e3 support, Bd3 route, Colle shell

### Packet colle-white.line-006.ply-07.f1d3

- Move: `Bd3` / `f1d3` at ply 7

- CoachCard: **Aim the Colle bishop at the kingside** — Bd3 develops the bishop to the classic Colle diagonal toward the kingside. It supports castling and later attacking chances if the center opens.

- Plain hint: Place the light-square bishop on the attacking diagonal after the pawn shell is stable.

- Opening themes: Bd3 placement, kingside aim, Colle attacking setup

### Packet colle-white.line-006.ply-09.d1d3

- Move: `Qxd3` / `d1d3` at ply 9

- CoachCard: **Keep the Colle plan compact** — Qxd3 stays connected to the Colle plan: compact development, d4 support, bishop coordination, and a timed central break.

- Plain hint: Keep the d-pawn shell stable, castle safely, and prepare the central break.

- Opening themes: Colle structure, safe development, central timing

### Packet colle-white.line-006.ply-11.c2c3

- Move: `c3` / `c2c3` at ply 11

- CoachCard: **Complete the Colle d4/e3/c3 shell** — c3 completes the d4/e3/c3 Colle structure. White reinforces d4 and prepares to choose the right moment for e4.

- Plain hint: Reinforce the queen-pawn center so the later central break has a base.

- Opening themes: d4/e3/c3 structure, e4 preparation, center support


## colle-white-line-007: 1. d4 Nf6 2. Nf3 e6 3. e3 c5 4. Bd3 cxd4 5. exd4 d5 6. c3 Bd6

Runtime playKey: `d2d4,g8f6,g1f3,e7e6,e2e3,c7c5,f1d3,c5d4,e3d4,d7d5,c2c3,f8d6`  
Runtime totalGames field at line node: `78699`

### Packet colle-white.line-007.ply-01.d2d4

- Move: `d4` / `d2d4` at ply 1

- CoachCard: **Start the Colle queen-pawn shell** — d4 establishes the d-pawn base of the Colle System. White plans a compact Nf3/e3/c3 structure before choosing the central break.

- Plain hint: Build the queen-pawn base that the compact Colle structure rests on.

- Opening themes: d4 base, Colle shell, e4 break timing

### Packet colle-white.line-007.ply-03.g1f3

- Move: `Nf3` / `g1f3` at ply 3

- CoachCard: **Develop behind the Colle center** — Nf3 supports d4 and prepares kingside castling in the Colle structure. The knight helps White build before the e-pawn break.

- Plain hint: Place the kingside knight behind the queen-pawn center and prepare castling.

- Opening themes: Nf3 support, safe development, castling

### Packet colle-white.line-007.ply-05.e2e3

- Move: `e3` / `e2e3` at ply 5

- CoachCard: **Lock in the Colle structure** — e3 supports d4 and forms the Colle pawn shell with c3 when available. It also opens the light-square bishop for Bd3.

- Plain hint: Support the queen pawn and open the bishop route while keeping the setup compact.

- Opening themes: e3 support, Bd3 route, Colle shell

### Packet colle-white.line-007.ply-07.f1d3

- Move: `Bd3` / `f1d3` at ply 7

- CoachCard: **Aim the Colle bishop at the kingside** — Bd3 develops the bishop to the classic Colle diagonal toward the kingside. It supports castling and later attacking chances if the center opens.

- Plain hint: Place the light-square bishop on the attacking diagonal after the pawn shell is stable.

- Opening themes: Bd3 placement, kingside aim, Colle attacking setup

### Packet colle-white.line-007.ply-09.e3d4

- Move: `exd4` / `e3d4` at ply 9

- CoachCard: **Recapture and preserve the Colle center** — exd4 restores White’s central pawn presence after Black trades into the Colle structure. The recapture keeps the d-pawn base alive.

- Plain hint: Restore the central pawn base when Black exchanges into the shell.

- Opening themes: central recapture, d-pawn base, structure preservation

### Packet colle-white.line-007.ply-11.c2c3

- Move: `c3` / `c2c3` at ply 11

- CoachCard: **Complete the Colle d4/e3/c3 shell** — c3 completes the d4/e3/c3 Colle structure. White reinforces d4 and prepares to choose the right moment for e4.

- Plain hint: Reinforce the queen-pawn center so the later central break has a base.

- Opening themes: d4/e3/c3 structure, e4 preparation, center support


## colle-white-line-008: 1. d4 d5 2. Nf3 Nc6 3. e3 Nf6 4. Bd3 e6 5. c3 Bd6 6. Nbd2 Bd7

Runtime playKey: `d2d4,d7d5,g1f3,b8c6,e2e3,g8f6,f1d3,e7e6,c2c3,f8d6,b1d2,c8d7`  
Runtime totalGames field at line node: `67817`

### Packet colle-white.line-008.ply-01.d2d4

- Move: `d4` / `d2d4` at ply 1

- CoachCard: **Start the Colle queen-pawn shell** — d4 establishes the d-pawn base of the Colle System. White plans a compact Nf3/e3/c3 structure before choosing the central break.

- Plain hint: Build the queen-pawn base that the compact Colle structure rests on.

- Opening themes: d4 base, Colle shell, e4 break timing

### Packet colle-white.line-008.ply-03.g1f3

- Move: `Nf3` / `g1f3` at ply 3

- CoachCard: **Develop behind the Colle center** — Nf3 supports d4 and prepares kingside castling in the Colle structure. The knight helps White build before the e-pawn break.

- Plain hint: Place the kingside knight behind the queen-pawn center and prepare castling.

- Opening themes: Nf3 support, safe development, castling

### Packet colle-white.line-008.ply-05.e2e3

- Move: `e3` / `e2e3` at ply 5

- CoachCard: **Lock in the Colle structure** — e3 supports d4 and forms the Colle pawn shell with c3 when available. It also opens the light-square bishop for Bd3.

- Plain hint: Support the queen pawn and open the bishop route while keeping the setup compact.

- Opening themes: e3 support, Bd3 route, Colle shell

### Packet colle-white.line-008.ply-07.f1d3

- Move: `Bd3` / `f1d3` at ply 7

- CoachCard: **Aim the Colle bishop at the kingside** — Bd3 develops the bishop to the classic Colle diagonal toward the kingside. It supports castling and later attacking chances if the center opens.

- Plain hint: Place the light-square bishop on the attacking diagonal after the pawn shell is stable.

- Opening themes: Bd3 placement, kingside aim, Colle attacking setup

### Packet colle-white.line-008.ply-09.c2c3

- Move: `c3` / `c2c3` at ply 9

- CoachCard: **Complete the Colle d4/e3/c3 shell** — c3 completes the d4/e3/c3 Colle structure. White reinforces d4 and prepares to choose the right moment for e4.

- Plain hint: Reinforce the queen-pawn center so the later central break has a base.

- Opening themes: d4/e3/c3 structure, e4 preparation, center support

### Packet colle-white.line-008.ply-11.b1d2

- Move: `Nbd2` / `b1d2` at ply 11

- CoachCard: **Use the Colle Nbd2 support route** — Nbd2 supports the Colle center from behind and helps prepare e4. The knight route keeps c-pawn support intact.

- Plain hint: Route the queenside knight behind the pawn shell to reinforce the central break.

- Opening themes: Nbd2 route, e4 support, compact structure


## colle-white-line-009: 1. d4 Nf6 2. Nf3 d5 3. e3 e6 4. Bd3 c5 5. c3 c4 6. Bc2 b5

Runtime playKey: `d2d4,g8f6,g1f3,d7d5,e2e3,e7e6,f1d3,c7c5,c2c3,c5c4,d3c2,b7b5`  
Runtime totalGames field at line node: `56333`

### Packet colle-white.line-009.ply-01.d2d4

- Move: `d4` / `d2d4` at ply 1

- CoachCard: **Start the Colle queen-pawn shell** — d4 establishes the d-pawn base of the Colle System. White plans a compact Nf3/e3/c3 structure before choosing the central break.

- Plain hint: Build the queen-pawn base that the compact Colle structure rests on.

- Opening themes: d4 base, Colle shell, e4 break timing

### Packet colle-white.line-009.ply-03.g1f3

- Move: `Nf3` / `g1f3` at ply 3

- CoachCard: **Develop behind the Colle center** — Nf3 supports d4 and prepares kingside castling in the Colle structure. The knight helps White build before the e-pawn break.

- Plain hint: Place the kingside knight behind the queen-pawn center and prepare castling.

- Opening themes: Nf3 support, safe development, castling

### Packet colle-white.line-009.ply-05.e2e3

- Move: `e3` / `e2e3` at ply 5

- CoachCard: **Lock in the Colle structure** — e3 supports d4 and forms the Colle pawn shell with c3 when available. It also opens the light-square bishop for Bd3.

- Plain hint: Support the queen pawn and open the bishop route while keeping the setup compact.

- Opening themes: e3 support, Bd3 route, Colle shell

### Packet colle-white.line-009.ply-07.f1d3

- Move: `Bd3` / `f1d3` at ply 7

- CoachCard: **Aim the Colle bishop at the kingside** — Bd3 develops the bishop to the classic Colle diagonal toward the kingside. It supports castling and later attacking chances if the center opens.

- Plain hint: Place the light-square bishop on the attacking diagonal after the pawn shell is stable.

- Opening themes: Bd3 placement, kingside aim, Colle attacking setup

### Packet colle-white.line-009.ply-09.c2c3

- Move: `c3` / `c2c3` at ply 9

- CoachCard: **Complete the Colle d4/e3/c3 shell** — c3 completes the d4/e3/c3 Colle structure. White reinforces d4 and prepares to choose the right moment for e4.

- Plain hint: Reinforce the queen-pawn center so the later central break has a base.

- Opening themes: d4/e3/c3 structure, e4 preparation, center support

### Packet colle-white.line-009.ply-11.d3c2

- Move: `Bc2` / `d3c2` at ply 11

- CoachCard: **Keep the Colle plan compact** — Bc2 stays connected to the Colle plan: compact development, d4 support, bishop coordination, and a timed central break.

- Plain hint: Keep the d-pawn shell stable, castle safely, and prepare the central break.

- Opening themes: Colle structure, safe development, central timing


## colle-white-line-010: 1. d4 d5 2. Nf3 e6 3. e3 c5 4. c3 Nc6 5. Bd3 Qb6 6. Nbd2 Nf6

Runtime playKey: `d2d4,d7d5,g1f3,e7e6,e2e3,c7c5,c2c3,b8c6,f1d3,d8b6,b1d2,g8f6`  
Runtime totalGames field at line node: `39153`

### Packet colle-white.line-010.ply-01.d2d4

- Move: `d4` / `d2d4` at ply 1

- CoachCard: **Start the Colle queen-pawn shell** — d4 establishes the d-pawn base of the Colle System. White plans a compact Nf3/e3/c3 structure before choosing the central break.

- Plain hint: Build the queen-pawn base that the compact Colle structure rests on.

- Opening themes: d4 base, Colle shell, e4 break timing

### Packet colle-white.line-010.ply-03.g1f3

- Move: `Nf3` / `g1f3` at ply 3

- CoachCard: **Develop behind the Colle center** — Nf3 supports d4 and prepares kingside castling in the Colle structure. The knight helps White build before the e-pawn break.

- Plain hint: Place the kingside knight behind the queen-pawn center and prepare castling.

- Opening themes: Nf3 support, safe development, castling

### Packet colle-white.line-010.ply-05.e2e3

- Move: `e3` / `e2e3` at ply 5

- CoachCard: **Lock in the Colle structure** — e3 supports d4 and forms the Colle pawn shell with c3 when available. It also opens the light-square bishop for Bd3.

- Plain hint: Support the queen pawn and open the bishop route while keeping the setup compact.

- Opening themes: e3 support, Bd3 route, Colle shell

### Packet colle-white.line-010.ply-07.c2c3

- Move: `c3` / `c2c3` at ply 7

- CoachCard: **Complete the Colle d4/e3/c3 shell** — c3 completes the d4/e3/c3 Colle structure. White reinforces d4 and prepares to choose the right moment for e4.

- Plain hint: Reinforce the queen-pawn center so the later central break has a base.

- Opening themes: d4/e3/c3 structure, e4 preparation, center support

### Packet colle-white.line-010.ply-09.f1d3

- Move: `Bd3` / `f1d3` at ply 9

- CoachCard: **Aim the Colle bishop at the kingside** — Bd3 develops the bishop to the classic Colle diagonal toward the kingside. It supports castling and later attacking chances if the center opens.

- Plain hint: Place the light-square bishop on the attacking diagonal after the pawn shell is stable.

- Opening themes: Bd3 placement, kingside aim, Colle attacking setup

### Packet colle-white.line-010.ply-11.b1d2

- Move: `Nbd2` / `b1d2` at ply 11

- CoachCard: **Use the Colle Nbd2 support route** — Nbd2 supports the Colle center from behind and helps prepare e4. The knight route keeps c-pawn support intact.

- Plain hint: Route the queenside knight behind the pawn shell to reinforce the central break.

- Opening themes: Nbd2 route, e4 support, compact structure


## colle-white-line-011: 1. d4 d5 2. Nf3 Nc6 3. e3 Nf6 4. Bd3 e6 5. c3 Be7 6. Nbd2 Bd7

Runtime playKey: `d2d4,d7d5,g1f3,b8c6,e2e3,g8f6,f1d3,e7e6,c2c3,f8e7,b1d2,c8d7`  
Runtime totalGames field at line node: `26551`

### Packet colle-white.line-011.ply-01.d2d4

- Move: `d4` / `d2d4` at ply 1

- CoachCard: **Start the Colle queen-pawn shell** — d4 establishes the d-pawn base of the Colle System. White plans a compact Nf3/e3/c3 structure before choosing the central break.

- Plain hint: Build the queen-pawn base that the compact Colle structure rests on.

- Opening themes: d4 base, Colle shell, e4 break timing

### Packet colle-white.line-011.ply-03.g1f3

- Move: `Nf3` / `g1f3` at ply 3

- CoachCard: **Develop behind the Colle center** — Nf3 supports d4 and prepares kingside castling in the Colle structure. The knight helps White build before the e-pawn break.

- Plain hint: Place the kingside knight behind the queen-pawn center and prepare castling.

- Opening themes: Nf3 support, safe development, castling

### Packet colle-white.line-011.ply-05.e2e3

- Move: `e3` / `e2e3` at ply 5

- CoachCard: **Lock in the Colle structure** — e3 supports d4 and forms the Colle pawn shell with c3 when available. It also opens the light-square bishop for Bd3.

- Plain hint: Support the queen pawn and open the bishop route while keeping the setup compact.

- Opening themes: e3 support, Bd3 route, Colle shell

### Packet colle-white.line-011.ply-07.f1d3

- Move: `Bd3` / `f1d3` at ply 7

- CoachCard: **Aim the Colle bishop at the kingside** — Bd3 develops the bishop to the classic Colle diagonal toward the kingside. It supports castling and later attacking chances if the center opens.

- Plain hint: Place the light-square bishop on the attacking diagonal after the pawn shell is stable.

- Opening themes: Bd3 placement, kingside aim, Colle attacking setup

### Packet colle-white.line-011.ply-09.c2c3

- Move: `c3` / `c2c3` at ply 9

- CoachCard: **Complete the Colle d4/e3/c3 shell** — c3 completes the d4/e3/c3 Colle structure. White reinforces d4 and prepares to choose the right moment for e4.

- Plain hint: Reinforce the queen-pawn center so the later central break has a base.

- Opening themes: d4/e3/c3 structure, e4 preparation, center support

### Packet colle-white.line-011.ply-11.b1d2

- Move: `Nbd2` / `b1d2` at ply 11

- CoachCard: **Use the Colle Nbd2 support route** — Nbd2 supports the Colle center from behind and helps prepare e4. The knight route keeps c-pawn support intact.

- Plain hint: Route the queenside knight behind the pawn shell to reinforce the central break.

- Opening themes: Nbd2 route, e4 support, compact structure


## colle-white-line-012: 1. d4 Nf6 2. Nf3 e6 3. e3 c5 4. Bd3 cxd4 5. exd4 Nc6 6. c3 Be7

Runtime playKey: `d2d4,g8f6,g1f3,e7e6,e2e3,c7c5,f1d3,c5d4,e3d4,b8c6,c2c3,f8e7`  
Runtime totalGames field at line node: `14289`

### Packet colle-white.line-012.ply-01.d2d4

- Move: `d4` / `d2d4` at ply 1

- CoachCard: **Start the Colle queen-pawn shell** — d4 establishes the d-pawn base of the Colle System. White plans a compact Nf3/e3/c3 structure before choosing the central break.

- Plain hint: Build the queen-pawn base that the compact Colle structure rests on.

- Opening themes: d4 base, Colle shell, e4 break timing

### Packet colle-white.line-012.ply-03.g1f3

- Move: `Nf3` / `g1f3` at ply 3

- CoachCard: **Develop behind the Colle center** — Nf3 supports d4 and prepares kingside castling in the Colle structure. The knight helps White build before the e-pawn break.

- Plain hint: Place the kingside knight behind the queen-pawn center and prepare castling.

- Opening themes: Nf3 support, safe development, castling

### Packet colle-white.line-012.ply-05.e2e3

- Move: `e3` / `e2e3` at ply 5

- CoachCard: **Lock in the Colle structure** — e3 supports d4 and forms the Colle pawn shell with c3 when available. It also opens the light-square bishop for Bd3.

- Plain hint: Support the queen pawn and open the bishop route while keeping the setup compact.

- Opening themes: e3 support, Bd3 route, Colle shell

### Packet colle-white.line-012.ply-07.f1d3

- Move: `Bd3` / `f1d3` at ply 7

- CoachCard: **Aim the Colle bishop at the kingside** — Bd3 develops the bishop to the classic Colle diagonal toward the kingside. It supports castling and later attacking chances if the center opens.

- Plain hint: Place the light-square bishop on the attacking diagonal after the pawn shell is stable.

- Opening themes: Bd3 placement, kingside aim, Colle attacking setup

### Packet colle-white.line-012.ply-09.e3d4

- Move: `exd4` / `e3d4` at ply 9

- CoachCard: **Recapture and preserve the Colle center** — exd4 restores White’s central pawn presence after Black trades into the Colle structure. The recapture keeps the d-pawn base alive.

- Plain hint: Restore the central pawn base when Black exchanges into the shell.

- Opening themes: central recapture, d-pawn base, structure preservation

### Packet colle-white.line-012.ply-11.c2c3

- Move: `c3` / `c2c3` at ply 11

- CoachCard: **Complete the Colle d4/e3/c3 shell** — c3 completes the d4/e3/c3 Colle structure. White reinforces d4 and prepares to choose the right moment for e4.

- Plain hint: Reinforce the queen-pawn center so the later central break has a base.

- Opening themes: d4/e3/c3 structure, e4 preparation, center support


## colle-white-line-013: 1. d4 d5 2. Nf3 Nc6 3. e3 Nf6 4. Bd3 Bg4 5. Nbd2 e6 6. c3 Be7

Runtime playKey: `d2d4,d7d5,g1f3,b8c6,e2e3,g8f6,f1d3,c8g4,b1d2,e7e6,c2c3,f8e7`  
Runtime totalGames field at line node: `14017`

### Packet colle-white.line-013.ply-01.d2d4

- Move: `d4` / `d2d4` at ply 1

- CoachCard: **Start the Colle queen-pawn shell** — d4 establishes the d-pawn base of the Colle System. White plans a compact Nf3/e3/c3 structure before choosing the central break.

- Plain hint: Build the queen-pawn base that the compact Colle structure rests on.

- Opening themes: d4 base, Colle shell, e4 break timing

### Packet colle-white.line-013.ply-03.g1f3

- Move: `Nf3` / `g1f3` at ply 3

- CoachCard: **Develop behind the Colle center** — Nf3 supports d4 and prepares kingside castling in the Colle structure. The knight helps White build before the e-pawn break.

- Plain hint: Place the kingside knight behind the queen-pawn center and prepare castling.

- Opening themes: Nf3 support, safe development, castling

### Packet colle-white.line-013.ply-05.e2e3

- Move: `e3` / `e2e3` at ply 5

- CoachCard: **Lock in the Colle structure** — e3 supports d4 and forms the Colle pawn shell with c3 when available. It also opens the light-square bishop for Bd3.

- Plain hint: Support the queen pawn and open the bishop route while keeping the setup compact.

- Opening themes: e3 support, Bd3 route, Colle shell

### Packet colle-white.line-013.ply-07.f1d3

- Move: `Bd3` / `f1d3` at ply 7

- CoachCard: **Aim the Colle bishop at the kingside** — Bd3 develops the bishop to the classic Colle diagonal toward the kingside. It supports castling and later attacking chances if the center opens.

- Plain hint: Place the light-square bishop on the attacking diagonal after the pawn shell is stable.

- Opening themes: Bd3 placement, kingside aim, Colle attacking setup

### Packet colle-white.line-013.ply-09.b1d2

- Move: `Nbd2` / `b1d2` at ply 9

- CoachCard: **Use the Colle Nbd2 support route** — Nbd2 supports the Colle center from behind and helps prepare e4. The knight route keeps c-pawn support intact.

- Plain hint: Route the queenside knight behind the pawn shell to reinforce the central break.

- Opening themes: Nbd2 route, e4 support, compact structure

### Packet colle-white.line-013.ply-11.c2c3

- Move: `c3` / `c2c3` at ply 11

- CoachCard: **Complete the Colle d4/e3/c3 shell** — c3 completes the d4/e3/c3 Colle structure. White reinforces d4 and prepares to choose the right moment for e4.

- Plain hint: Reinforce the queen-pawn center so the later central break has a base.

- Opening themes: d4/e3/c3 structure, e4 preparation, center support


## colle-white-line-014: 1. d4 d5 2. Nf3 e6 3. e3 c5 4. c3 Nc6 5. Bd3 Qb6 6. Nbd2 Bd7

Runtime playKey: `d2d4,d7d5,g1f3,e7e6,e2e3,c7c5,c2c3,b8c6,f1d3,d8b6,b1d2,c8d7`  
Runtime totalGames field at line node: `13567`

### Packet colle-white.line-014.ply-01.d2d4

- Move: `d4` / `d2d4` at ply 1

- CoachCard: **Start the Colle queen-pawn shell** — d4 establishes the d-pawn base of the Colle System. White plans a compact Nf3/e3/c3 structure before choosing the central break.

- Plain hint: Build the queen-pawn base that the compact Colle structure rests on.

- Opening themes: d4 base, Colle shell, e4 break timing

### Packet colle-white.line-014.ply-03.g1f3

- Move: `Nf3` / `g1f3` at ply 3

- CoachCard: **Develop behind the Colle center** — Nf3 supports d4 and prepares kingside castling in the Colle structure. The knight helps White build before the e-pawn break.

- Plain hint: Place the kingside knight behind the queen-pawn center and prepare castling.

- Opening themes: Nf3 support, safe development, castling

### Packet colle-white.line-014.ply-05.e2e3

- Move: `e3` / `e2e3` at ply 5

- CoachCard: **Lock in the Colle structure** — e3 supports d4 and forms the Colle pawn shell with c3 when available. It also opens the light-square bishop for Bd3.

- Plain hint: Support the queen pawn and open the bishop route while keeping the setup compact.

- Opening themes: e3 support, Bd3 route, Colle shell

### Packet colle-white.line-014.ply-07.c2c3

- Move: `c3` / `c2c3` at ply 7

- CoachCard: **Complete the Colle d4/e3/c3 shell** — c3 completes the d4/e3/c3 Colle structure. White reinforces d4 and prepares to choose the right moment for e4.

- Plain hint: Reinforce the queen-pawn center so the later central break has a base.

- Opening themes: d4/e3/c3 structure, e4 preparation, center support

### Packet colle-white.line-014.ply-09.f1d3

- Move: `Bd3` / `f1d3` at ply 9

- CoachCard: **Aim the Colle bishop at the kingside** — Bd3 develops the bishop to the classic Colle diagonal toward the kingside. It supports castling and later attacking chances if the center opens.

- Plain hint: Place the light-square bishop on the attacking diagonal after the pawn shell is stable.

- Opening themes: Bd3 placement, kingside aim, Colle attacking setup

### Packet colle-white.line-014.ply-11.b1d2

- Move: `Nbd2` / `b1d2` at ply 11

- CoachCard: **Use the Colle Nbd2 support route** — Nbd2 supports the Colle center from behind and helps prepare e4. The knight route keeps c-pawn support intact.

- Plain hint: Route the queenside knight behind the pawn shell to reinforce the central break.

- Opening themes: Nbd2 route, e4 support, compact structure


## colle-white-line-015: 1. d4 d5 2. Nf3 Nc6 3. e3 Bf5 4. Bd3 Bxd3 5. Qxd3 e6 6. c3 Bd6

Runtime playKey: `d2d4,d7d5,g1f3,b8c6,e2e3,c8f5,f1d3,f5d3,d1d3,e7e6,c2c3,f8d6`  
Runtime totalGames field at line node: `9309`

### Packet colle-white.line-015.ply-01.d2d4

- Move: `d4` / `d2d4` at ply 1

- CoachCard: **Start the Colle queen-pawn shell** — d4 establishes the d-pawn base of the Colle System. White plans a compact Nf3/e3/c3 structure before choosing the central break.

- Plain hint: Build the queen-pawn base that the compact Colle structure rests on.

- Opening themes: d4 base, Colle shell, e4 break timing

### Packet colle-white.line-015.ply-03.g1f3

- Move: `Nf3` / `g1f3` at ply 3

- CoachCard: **Develop behind the Colle center** — Nf3 supports d4 and prepares kingside castling in the Colle structure. The knight helps White build before the e-pawn break.

- Plain hint: Place the kingside knight behind the queen-pawn center and prepare castling.

- Opening themes: Nf3 support, safe development, castling

### Packet colle-white.line-015.ply-05.e2e3

- Move: `e3` / `e2e3` at ply 5

- CoachCard: **Lock in the Colle structure** — e3 supports d4 and forms the Colle pawn shell with c3 when available. It also opens the light-square bishop for Bd3.

- Plain hint: Support the queen pawn and open the bishop route while keeping the setup compact.

- Opening themes: e3 support, Bd3 route, Colle shell

### Packet colle-white.line-015.ply-07.f1d3

- Move: `Bd3` / `f1d3` at ply 7

- CoachCard: **Aim the Colle bishop at the kingside** — Bd3 develops the bishop to the classic Colle diagonal toward the kingside. It supports castling and later attacking chances if the center opens.

- Plain hint: Place the light-square bishop on the attacking diagonal after the pawn shell is stable.

- Opening themes: Bd3 placement, kingside aim, Colle attacking setup

### Packet colle-white.line-015.ply-09.d1d3

- Move: `Qxd3` / `d1d3` at ply 9

- CoachCard: **Keep the Colle plan compact** — Qxd3 stays connected to the Colle plan: compact development, d4 support, bishop coordination, and a timed central break.

- Plain hint: Keep the d-pawn shell stable, castle safely, and prepare the central break.

- Opening themes: Colle structure, safe development, central timing

### Packet colle-white.line-015.ply-11.c2c3

- Move: `c3` / `c2c3` at ply 11

- CoachCard: **Complete the Colle d4/e3/c3 shell** — c3 completes the d4/e3/c3 Colle structure. White reinforces d4 and prepares to choose the right moment for e4.

- Plain hint: Reinforce the queen-pawn center so the later central break has a base.

- Opening themes: d4/e3/c3 structure, e4 preparation, center support


## colle-white-line-016: 1. d4 Nf6 2. Nf3 e6 3. e3 c5 4. Bd3 cxd4 5. Nxd4 d5 6. c3 Nc6

Runtime playKey: `d2d4,g8f6,g1f3,e7e6,e2e3,c7c5,f1d3,c5d4,f3d4,d7d5,c2c3,b8c6`  
Runtime totalGames field at line node: `4200`

### Packet colle-white.line-016.ply-01.d2d4

- Move: `d4` / `d2d4` at ply 1

- CoachCard: **Start the Colle queen-pawn shell** — d4 establishes the d-pawn base of the Colle System. White plans a compact Nf3/e3/c3 structure before choosing the central break.

- Plain hint: Build the queen-pawn base that the compact Colle structure rests on.

- Opening themes: d4 base, Colle shell, e4 break timing

### Packet colle-white.line-016.ply-03.g1f3

- Move: `Nf3` / `g1f3` at ply 3

- CoachCard: **Develop behind the Colle center** — Nf3 supports d4 and prepares kingside castling in the Colle structure. The knight helps White build before the e-pawn break.

- Plain hint: Place the kingside knight behind the queen-pawn center and prepare castling.

- Opening themes: Nf3 support, safe development, castling

### Packet colle-white.line-016.ply-05.e2e3

- Move: `e3` / `e2e3` at ply 5

- CoachCard: **Lock in the Colle structure** — e3 supports d4 and forms the Colle pawn shell with c3 when available. It also opens the light-square bishop for Bd3.

- Plain hint: Support the queen pawn and open the bishop route while keeping the setup compact.

- Opening themes: e3 support, Bd3 route, Colle shell

### Packet colle-white.line-016.ply-07.f1d3

- Move: `Bd3` / `f1d3` at ply 7

- CoachCard: **Aim the Colle bishop at the kingside** — Bd3 develops the bishop to the classic Colle diagonal toward the kingside. It supports castling and later attacking chances if the center opens.

- Plain hint: Place the light-square bishop on the attacking diagonal after the pawn shell is stable.

- Opening themes: Bd3 placement, kingside aim, Colle attacking setup

### Packet colle-white.line-016.ply-09.f3d4

- Move: `Nxd4` / `f3d4` at ply 9

- CoachCard: **Keep the Colle plan compact** — Nxd4 stays connected to the Colle plan: compact development, d4 support, bishop coordination, and a timed central break.

- Plain hint: Keep the d-pawn shell stable, castle safely, and prepare the central break.

- Opening themes: Colle structure, safe development, central timing

### Packet colle-white.line-016.ply-11.c2c3

- Move: `c3` / `c2c3` at ply 11

- CoachCard: **Complete the Colle d4/e3/c3 shell** — c3 completes the d4/e3/c3 Colle structure. White reinforces d4 and prepares to choose the right moment for e4.

- Plain hint: Reinforce the queen-pawn center so the later central break has a base.

- Opening themes: d4/e3/c3 structure, e4 preparation, center support


## colle-white-line-017: 1. d4 Nf6 2. Nf3 e6 3. e3 c5 4. Bd3 cxd4 5. exd4 d5 6. c3 Nc6

Runtime playKey: `d2d4,g8f6,g1f3,e7e6,e2e3,c7c5,f1d3,c5d4,e3d4,d7d5,c2c3,b8c6`  
Runtime totalGames field at line node: `240822`

### Packet colle-white.line-017.ply-01.d2d4

- Move: `d4` / `d2d4` at ply 1

- CoachCard: **Start the Colle queen-pawn shell** — d4 establishes the d-pawn base of the Colle System. White plans a compact Nf3/e3/c3 structure before choosing the central break.

- Plain hint: Build the queen-pawn base that the compact Colle structure rests on.

- Opening themes: d4 base, Colle shell, e4 break timing

### Packet colle-white.line-017.ply-03.g1f3

- Move: `Nf3` / `g1f3` at ply 3

- CoachCard: **Develop behind the Colle center** — Nf3 supports d4 and prepares kingside castling in the Colle structure. The knight helps White build before the e-pawn break.

- Plain hint: Place the kingside knight behind the queen-pawn center and prepare castling.

- Opening themes: Nf3 support, safe development, castling

### Packet colle-white.line-017.ply-05.e2e3

- Move: `e3` / `e2e3` at ply 5

- CoachCard: **Lock in the Colle structure** — e3 supports d4 and forms the Colle pawn shell with c3 when available. It also opens the light-square bishop for Bd3.

- Plain hint: Support the queen pawn and open the bishop route while keeping the setup compact.

- Opening themes: e3 support, Bd3 route, Colle shell

### Packet colle-white.line-017.ply-07.f1d3

- Move: `Bd3` / `f1d3` at ply 7

- CoachCard: **Aim the Colle bishop at the kingside** — Bd3 develops the bishop to the classic Colle diagonal toward the kingside. It supports castling and later attacking chances if the center opens.

- Plain hint: Place the light-square bishop on the attacking diagonal after the pawn shell is stable.

- Opening themes: Bd3 placement, kingside aim, Colle attacking setup

### Packet colle-white.line-017.ply-09.e3d4

- Move: `exd4` / `e3d4` at ply 9

- CoachCard: **Recapture and preserve the Colle center** — exd4 restores White’s central pawn presence after Black trades into the Colle structure. The recapture keeps the d-pawn base alive.

- Plain hint: Restore the central pawn base when Black exchanges into the shell.

- Opening themes: central recapture, d-pawn base, structure preservation

### Packet colle-white.line-017.ply-11.c2c3

- Move: `c3` / `c2c3` at ply 11

- CoachCard: **Complete the Colle d4/e3/c3 shell** — c3 completes the d4/e3/c3 Colle structure. White reinforces d4 and prepares to choose the right moment for e4.

- Plain hint: Reinforce the queen-pawn center so the later central break has a base.

- Opening themes: d4/e3/c3 structure, e4 preparation, center support


## colle-white-line-018: 1. d4 Nf6 2. Nf3 e6 3. e3 c5 4. c3 Nc6 5. Nbd2 d5 6. Bd3 Bd6

Runtime playKey: `d2d4,g8f6,g1f3,e7e6,e2e3,c7c5,c2c3,b8c6,b1d2,d7d5,f1d3,f8d6`  
Runtime totalGames field at line node: `203748`

### Packet colle-white.line-018.ply-01.d2d4

- Move: `d4` / `d2d4` at ply 1

- CoachCard: **Start the Colle queen-pawn shell** — d4 establishes the d-pawn base of the Colle System. White plans a compact Nf3/e3/c3 structure before choosing the central break.

- Plain hint: Build the queen-pawn base that the compact Colle structure rests on.

- Opening themes: d4 base, Colle shell, e4 break timing

### Packet colle-white.line-018.ply-03.g1f3

- Move: `Nf3` / `g1f3` at ply 3

- CoachCard: **Develop behind the Colle center** — Nf3 supports d4 and prepares kingside castling in the Colle structure. The knight helps White build before the e-pawn break.

- Plain hint: Place the kingside knight behind the queen-pawn center and prepare castling.

- Opening themes: Nf3 support, safe development, castling

### Packet colle-white.line-018.ply-05.e2e3

- Move: `e3` / `e2e3` at ply 5

- CoachCard: **Lock in the Colle structure** — e3 supports d4 and forms the Colle pawn shell with c3 when available. It also opens the light-square bishop for Bd3.

- Plain hint: Support the queen pawn and open the bishop route while keeping the setup compact.

- Opening themes: e3 support, Bd3 route, Colle shell

### Packet colle-white.line-018.ply-07.c2c3

- Move: `c3` / `c2c3` at ply 7

- CoachCard: **Complete the Colle d4/e3/c3 shell** — c3 completes the d4/e3/c3 Colle structure. White reinforces d4 and prepares to choose the right moment for e4.

- Plain hint: Reinforce the queen-pawn center so the later central break has a base.

- Opening themes: d4/e3/c3 structure, e4 preparation, center support

### Packet colle-white.line-018.ply-09.b1d2

- Move: `Nbd2` / `b1d2` at ply 9

- CoachCard: **Use the Colle Nbd2 support route** — Nbd2 supports the Colle center from behind and helps prepare e4. The knight route keeps c-pawn support intact.

- Plain hint: Route the queenside knight behind the pawn shell to reinforce the central break.

- Opening themes: Nbd2 route, e4 support, compact structure

### Packet colle-white.line-018.ply-11.f1d3

- Move: `Bd3` / `f1d3` at ply 11

- CoachCard: **Aim the Colle bishop at the kingside** — Bd3 develops the bishop to the classic Colle diagonal toward the kingside. It supports castling and later attacking chances if the center opens.

- Plain hint: Place the light-square bishop on the attacking diagonal after the pawn shell is stable.

- Opening themes: Bd3 placement, kingside aim, Colle attacking setup


## colle-white-line-019: 1. d4 Nf6 2. Nf3 e6 3. e3 c5 4. c3 Nc6 5. Bd3 d5 6. Nbd2 Bd6

Runtime playKey: `d2d4,g8f6,g1f3,e7e6,e2e3,c7c5,c2c3,b8c6,f1d3,d7d5,b1d2,f8d6`  
Runtime totalGames field at line node: `203748`

### Packet colle-white.line-019.ply-01.d2d4

- Move: `d4` / `d2d4` at ply 1

- CoachCard: **Start the Colle queen-pawn shell** — d4 establishes the d-pawn base of the Colle System. White plans a compact Nf3/e3/c3 structure before choosing the central break.

- Plain hint: Build the queen-pawn base that the compact Colle structure rests on.

- Opening themes: d4 base, Colle shell, e4 break timing

### Packet colle-white.line-019.ply-03.g1f3

- Move: `Nf3` / `g1f3` at ply 3

- CoachCard: **Develop behind the Colle center** — Nf3 supports d4 and prepares kingside castling in the Colle structure. The knight helps White build before the e-pawn break.

- Plain hint: Place the kingside knight behind the queen-pawn center and prepare castling.

- Opening themes: Nf3 support, safe development, castling

### Packet colle-white.line-019.ply-05.e2e3

- Move: `e3` / `e2e3` at ply 5

- CoachCard: **Lock in the Colle structure** — e3 supports d4 and forms the Colle pawn shell with c3 when available. It also opens the light-square bishop for Bd3.

- Plain hint: Support the queen pawn and open the bishop route while keeping the setup compact.

- Opening themes: e3 support, Bd3 route, Colle shell

### Packet colle-white.line-019.ply-07.c2c3

- Move: `c3` / `c2c3` at ply 7

- CoachCard: **Complete the Colle d4/e3/c3 shell** — c3 completes the d4/e3/c3 Colle structure. White reinforces d4 and prepares to choose the right moment for e4.

- Plain hint: Reinforce the queen-pawn center so the later central break has a base.

- Opening themes: d4/e3/c3 structure, e4 preparation, center support

### Packet colle-white.line-019.ply-09.f1d3

- Move: `Bd3` / `f1d3` at ply 9

- CoachCard: **Aim the Colle bishop at the kingside** — Bd3 develops the bishop to the classic Colle diagonal toward the kingside. It supports castling and later attacking chances if the center opens.

- Plain hint: Place the light-square bishop on the attacking diagonal after the pawn shell is stable.

- Opening themes: Bd3 placement, kingside aim, Colle attacking setup

### Packet colle-white.line-019.ply-11.b1d2

- Move: `Nbd2` / `b1d2` at ply 11

- CoachCard: **Use the Colle Nbd2 support route** — Nbd2 supports the Colle center from behind and helps prepare e4. The knight route keeps c-pawn support intact.

- Plain hint: Route the queenside knight behind the pawn shell to reinforce the central break.

- Opening themes: Nbd2 route, e4 support, compact structure


## colle-white-line-020: 1. d4 Nf6 2. Nf3 e6 3. e3 c5 4. c3 d5 5. Nbd2 Nc6 6. Bd3 Bd6

Runtime playKey: `d2d4,g8f6,g1f3,e7e6,e2e3,c7c5,c2c3,d7d5,b1d2,b8c6,f1d3,f8d6`  
Runtime totalGames field at line node: `203748`

### Packet colle-white.line-020.ply-01.d2d4

- Move: `d4` / `d2d4` at ply 1

- CoachCard: **Start the Colle queen-pawn shell** — d4 establishes the d-pawn base of the Colle System. White plans a compact Nf3/e3/c3 structure before choosing the central break.

- Plain hint: Build the queen-pawn base that the compact Colle structure rests on.

- Opening themes: d4 base, Colle shell, e4 break timing

### Packet colle-white.line-020.ply-03.g1f3

- Move: `Nf3` / `g1f3` at ply 3

- CoachCard: **Develop behind the Colle center** — Nf3 supports d4 and prepares kingside castling in the Colle structure. The knight helps White build before the e-pawn break.

- Plain hint: Place the kingside knight behind the queen-pawn center and prepare castling.

- Opening themes: Nf3 support, safe development, castling

### Packet colle-white.line-020.ply-05.e2e3

- Move: `e3` / `e2e3` at ply 5

- CoachCard: **Lock in the Colle structure** — e3 supports d4 and forms the Colle pawn shell with c3 when available. It also opens the light-square bishop for Bd3.

- Plain hint: Support the queen pawn and open the bishop route while keeping the setup compact.

- Opening themes: e3 support, Bd3 route, Colle shell

### Packet colle-white.line-020.ply-07.c2c3

- Move: `c3` / `c2c3` at ply 7

- CoachCard: **Complete the Colle d4/e3/c3 shell** — c3 completes the d4/e3/c3 Colle structure. White reinforces d4 and prepares to choose the right moment for e4.

- Plain hint: Reinforce the queen-pawn center so the later central break has a base.

- Opening themes: d4/e3/c3 structure, e4 preparation, center support

### Packet colle-white.line-020.ply-09.b1d2

- Move: `Nbd2` / `b1d2` at ply 9

- CoachCard: **Use the Colle Nbd2 support route** — Nbd2 supports the Colle center from behind and helps prepare e4. The knight route keeps c-pawn support intact.

- Plain hint: Route the queenside knight behind the pawn shell to reinforce the central break.

- Opening themes: Nbd2 route, e4 support, compact structure

### Packet colle-white.line-020.ply-11.f1d3

- Move: `Bd3` / `f1d3` at ply 11

- CoachCard: **Aim the Colle bishop at the kingside** — Bd3 develops the bishop to the classic Colle diagonal toward the kingside. It supports castling and later attacking chances if the center opens.

- Plain hint: Place the light-square bishop on the attacking diagonal after the pawn shell is stable.

- Opening themes: Bd3 placement, kingside aim, Colle attacking setup


## colle-white-line-021: 1. d4 Nf6 2. Nf3 e6 3. e3 c5 4. c3 d5 5. Bd3 Nc6 6. Nbd2 Bd6

Runtime playKey: `d2d4,g8f6,g1f3,e7e6,e2e3,c7c5,c2c3,d7d5,f1d3,b8c6,b1d2,f8d6`  
Runtime totalGames field at line node: `203748`

### Packet colle-white.line-021.ply-01.d2d4

- Move: `d4` / `d2d4` at ply 1

- CoachCard: **Start the Colle queen-pawn shell** — d4 establishes the d-pawn base of the Colle System. White plans a compact Nf3/e3/c3 structure before choosing the central break.

- Plain hint: Build the queen-pawn base that the compact Colle structure rests on.

- Opening themes: d4 base, Colle shell, e4 break timing

### Packet colle-white.line-021.ply-03.g1f3

- Move: `Nf3` / `g1f3` at ply 3

- CoachCard: **Develop behind the Colle center** — Nf3 supports d4 and prepares kingside castling in the Colle structure. The knight helps White build before the e-pawn break.

- Plain hint: Place the kingside knight behind the queen-pawn center and prepare castling.

- Opening themes: Nf3 support, safe development, castling

### Packet colle-white.line-021.ply-05.e2e3

- Move: `e3` / `e2e3` at ply 5

- CoachCard: **Lock in the Colle structure** — e3 supports d4 and forms the Colle pawn shell with c3 when available. It also opens the light-square bishop for Bd3.

- Plain hint: Support the queen pawn and open the bishop route while keeping the setup compact.

- Opening themes: e3 support, Bd3 route, Colle shell

### Packet colle-white.line-021.ply-07.c2c3

- Move: `c3` / `c2c3` at ply 7

- CoachCard: **Complete the Colle d4/e3/c3 shell** — c3 completes the d4/e3/c3 Colle structure. White reinforces d4 and prepares to choose the right moment for e4.

- Plain hint: Reinforce the queen-pawn center so the later central break has a base.

- Opening themes: d4/e3/c3 structure, e4 preparation, center support

### Packet colle-white.line-021.ply-09.f1d3

- Move: `Bd3` / `f1d3` at ply 9

- CoachCard: **Aim the Colle bishop at the kingside** — Bd3 develops the bishop to the classic Colle diagonal toward the kingside. It supports castling and later attacking chances if the center opens.

- Plain hint: Place the light-square bishop on the attacking diagonal after the pawn shell is stable.

- Opening themes: Bd3 placement, kingside aim, Colle attacking setup

### Packet colle-white.line-021.ply-11.b1d2

- Move: `Nbd2` / `b1d2` at ply 11

- CoachCard: **Use the Colle Nbd2 support route** — Nbd2 supports the Colle center from behind and helps prepare e4. The knight route keeps c-pawn support intact.

- Plain hint: Route the queenside knight behind the pawn shell to reinforce the central break.

- Opening themes: Nbd2 route, e4 support, compact structure


## colle-white-line-022: 1. d4 Nf6 2. Nf3 e6 3. e3 c5 4. Bd3 d5 5. c3 Nc6 6. Nbd2 Bd6

Runtime playKey: `d2d4,g8f6,g1f3,e7e6,e2e3,c7c5,f1d3,d7d5,c2c3,b8c6,b1d2,f8d6`  
Runtime totalGames field at line node: `203747`

### Packet colle-white.line-022.ply-01.d2d4

- Move: `d4` / `d2d4` at ply 1

- CoachCard: **Start the Colle queen-pawn shell** — d4 establishes the d-pawn base of the Colle System. White plans a compact Nf3/e3/c3 structure before choosing the central break.

- Plain hint: Build the queen-pawn base that the compact Colle structure rests on.

- Opening themes: d4 base, Colle shell, e4 break timing

### Packet colle-white.line-022.ply-03.g1f3

- Move: `Nf3` / `g1f3` at ply 3

- CoachCard: **Develop behind the Colle center** — Nf3 supports d4 and prepares kingside castling in the Colle structure. The knight helps White build before the e-pawn break.

- Plain hint: Place the kingside knight behind the queen-pawn center and prepare castling.

- Opening themes: Nf3 support, safe development, castling

### Packet colle-white.line-022.ply-05.e2e3

- Move: `e3` / `e2e3` at ply 5

- CoachCard: **Lock in the Colle structure** — e3 supports d4 and forms the Colle pawn shell with c3 when available. It also opens the light-square bishop for Bd3.

- Plain hint: Support the queen pawn and open the bishop route while keeping the setup compact.

- Opening themes: e3 support, Bd3 route, Colle shell

### Packet colle-white.line-022.ply-07.f1d3

- Move: `Bd3` / `f1d3` at ply 7

- CoachCard: **Aim the Colle bishop at the kingside** — Bd3 develops the bishop to the classic Colle diagonal toward the kingside. It supports castling and later attacking chances if the center opens.

- Plain hint: Place the light-square bishop on the attacking diagonal after the pawn shell is stable.

- Opening themes: Bd3 placement, kingside aim, Colle attacking setup

### Packet colle-white.line-022.ply-09.c2c3

- Move: `c3` / `c2c3` at ply 9

- CoachCard: **Complete the Colle d4/e3/c3 shell** — c3 completes the d4/e3/c3 Colle structure. White reinforces d4 and prepares to choose the right moment for e4.

- Plain hint: Reinforce the queen-pawn center so the later central break has a base.

- Opening themes: d4/e3/c3 structure, e4 preparation, center support

### Packet colle-white.line-022.ply-11.b1d2

- Move: `Nbd2` / `b1d2` at ply 11

- CoachCard: **Use the Colle Nbd2 support route** — Nbd2 supports the Colle center from behind and helps prepare e4. The knight route keeps c-pawn support intact.

- Plain hint: Route the queenside knight behind the pawn shell to reinforce the central break.

- Opening themes: Nbd2 route, e4 support, compact structure


## colle-white-line-023: 1. d4 Nf6 2. Nf3 e6 3. e3 d5 4. Bd3 c5 5. c3 Nc6 6. Nbd2 Bd6

Runtime playKey: `d2d4,g8f6,g1f3,e7e6,e2e3,d7d5,f1d3,c7c5,c2c3,b8c6,b1d2,f8d6`  
Runtime totalGames field at line node: `203747`

### Packet colle-white.line-023.ply-01.d2d4

- Move: `d4` / `d2d4` at ply 1

- CoachCard: **Start the Colle queen-pawn shell** — d4 establishes the d-pawn base of the Colle System. White plans a compact Nf3/e3/c3 structure before choosing the central break.

- Plain hint: Build the queen-pawn base that the compact Colle structure rests on.

- Opening themes: d4 base, Colle shell, e4 break timing

### Packet colle-white.line-023.ply-03.g1f3

- Move: `Nf3` / `g1f3` at ply 3

- CoachCard: **Develop behind the Colle center** — Nf3 supports d4 and prepares kingside castling in the Colle structure. The knight helps White build before the e-pawn break.

- Plain hint: Place the kingside knight behind the queen-pawn center and prepare castling.

- Opening themes: Nf3 support, safe development, castling

### Packet colle-white.line-023.ply-05.e2e3

- Move: `e3` / `e2e3` at ply 5

- CoachCard: **Lock in the Colle structure** — e3 supports d4 and forms the Colle pawn shell with c3 when available. It also opens the light-square bishop for Bd3.

- Plain hint: Support the queen pawn and open the bishop route while keeping the setup compact.

- Opening themes: e3 support, Bd3 route, Colle shell

### Packet colle-white.line-023.ply-07.f1d3

- Move: `Bd3` / `f1d3` at ply 7

- CoachCard: **Aim the Colle bishop at the kingside** — Bd3 develops the bishop to the classic Colle diagonal toward the kingside. It supports castling and later attacking chances if the center opens.

- Plain hint: Place the light-square bishop on the attacking diagonal after the pawn shell is stable.

- Opening themes: Bd3 placement, kingside aim, Colle attacking setup

### Packet colle-white.line-023.ply-09.c2c3

- Move: `c3` / `c2c3` at ply 9

- CoachCard: **Complete the Colle d4/e3/c3 shell** — c3 completes the d4/e3/c3 Colle structure. White reinforces d4 and prepares to choose the right moment for e4.

- Plain hint: Reinforce the queen-pawn center so the later central break has a base.

- Opening themes: d4/e3/c3 structure, e4 preparation, center support

### Packet colle-white.line-023.ply-11.b1d2

- Move: `Nbd2` / `b1d2` at ply 11

- CoachCard: **Use the Colle Nbd2 support route** — Nbd2 supports the Colle center from behind and helps prepare e4. The knight route keeps c-pawn support intact.

- Plain hint: Route the queenside knight behind the pawn shell to reinforce the central break.

- Opening themes: Nbd2 route, e4 support, compact structure


## colle-white-line-024: 1. d4 d5 2. Nf3 e6 3. e3 c5 4. c3 Nc6 5. Bd3 Nf6 6. Nbd2 Bd6

Runtime playKey: `d2d4,d7d5,g1f3,e7e6,e2e3,c7c5,c2c3,b8c6,f1d3,g8f6,b1d2,f8d6`  
Runtime totalGames field at line node: `203727`

### Packet colle-white.line-024.ply-01.d2d4

- Move: `d4` / `d2d4` at ply 1

- CoachCard: **Start the Colle queen-pawn shell** — d4 establishes the d-pawn base of the Colle System. White plans a compact Nf3/e3/c3 structure before choosing the central break.

- Plain hint: Build the queen-pawn base that the compact Colle structure rests on.

- Opening themes: d4 base, Colle shell, e4 break timing

### Packet colle-white.line-024.ply-03.g1f3

- Move: `Nf3` / `g1f3` at ply 3

- CoachCard: **Develop behind the Colle center** — Nf3 supports d4 and prepares kingside castling in the Colle structure. The knight helps White build before the e-pawn break.

- Plain hint: Place the kingside knight behind the queen-pawn center and prepare castling.

- Opening themes: Nf3 support, safe development, castling

### Packet colle-white.line-024.ply-05.e2e3

- Move: `e3` / `e2e3` at ply 5

- CoachCard: **Lock in the Colle structure** — e3 supports d4 and forms the Colle pawn shell with c3 when available. It also opens the light-square bishop for Bd3.

- Plain hint: Support the queen pawn and open the bishop route while keeping the setup compact.

- Opening themes: e3 support, Bd3 route, Colle shell

### Packet colle-white.line-024.ply-07.c2c3

- Move: `c3` / `c2c3` at ply 7

- CoachCard: **Complete the Colle d4/e3/c3 shell** — c3 completes the d4/e3/c3 Colle structure. White reinforces d4 and prepares to choose the right moment for e4.

- Plain hint: Reinforce the queen-pawn center so the later central break has a base.

- Opening themes: d4/e3/c3 structure, e4 preparation, center support

### Packet colle-white.line-024.ply-09.f1d3

- Move: `Bd3` / `f1d3` at ply 9

- CoachCard: **Aim the Colle bishop at the kingside** — Bd3 develops the bishop to the classic Colle diagonal toward the kingside. It supports castling and later attacking chances if the center opens.

- Plain hint: Place the light-square bishop on the attacking diagonal after the pawn shell is stable.

- Opening themes: Bd3 placement, kingside aim, Colle attacking setup

### Packet colle-white.line-024.ply-11.b1d2

- Move: `Nbd2` / `b1d2` at ply 11

- CoachCard: **Use the Colle Nbd2 support route** — Nbd2 supports the Colle center from behind and helps prepare e4. The knight route keeps c-pawn support intact.

- Plain hint: Route the queenside knight behind the pawn shell to reinforce the central break.

- Opening themes: Nbd2 route, e4 support, compact structure


## colle-white-line-025: 1. d4 d5 2. Nf3 e6 3. e3 c5 4. c3 Nf6 5. Nbd2 Nc6 6. Bd3 Bd6

Runtime playKey: `d2d4,d7d5,g1f3,e7e6,e2e3,c7c5,c2c3,g8f6,b1d2,b8c6,f1d3,f8d6`  
Runtime totalGames field at line node: `203727`

### Packet colle-white.line-025.ply-01.d2d4

- Move: `d4` / `d2d4` at ply 1

- CoachCard: **Start the Colle queen-pawn shell** — d4 establishes the d-pawn base of the Colle System. White plans a compact Nf3/e3/c3 structure before choosing the central break.

- Plain hint: Build the queen-pawn base that the compact Colle structure rests on.

- Opening themes: d4 base, Colle shell, e4 break timing

### Packet colle-white.line-025.ply-03.g1f3

- Move: `Nf3` / `g1f3` at ply 3

- CoachCard: **Develop behind the Colle center** — Nf3 supports d4 and prepares kingside castling in the Colle structure. The knight helps White build before the e-pawn break.

- Plain hint: Place the kingside knight behind the queen-pawn center and prepare castling.

- Opening themes: Nf3 support, safe development, castling

### Packet colle-white.line-025.ply-05.e2e3

- Move: `e3` / `e2e3` at ply 5

- CoachCard: **Lock in the Colle structure** — e3 supports d4 and forms the Colle pawn shell with c3 when available. It also opens the light-square bishop for Bd3.

- Plain hint: Support the queen pawn and open the bishop route while keeping the setup compact.

- Opening themes: e3 support, Bd3 route, Colle shell

### Packet colle-white.line-025.ply-07.c2c3

- Move: `c3` / `c2c3` at ply 7

- CoachCard: **Complete the Colle d4/e3/c3 shell** — c3 completes the d4/e3/c3 Colle structure. White reinforces d4 and prepares to choose the right moment for e4.

- Plain hint: Reinforce the queen-pawn center so the later central break has a base.

- Opening themes: d4/e3/c3 structure, e4 preparation, center support

### Packet colle-white.line-025.ply-09.b1d2

- Move: `Nbd2` / `b1d2` at ply 9

- CoachCard: **Use the Colle Nbd2 support route** — Nbd2 supports the Colle center from behind and helps prepare e4. The knight route keeps c-pawn support intact.

- Plain hint: Route the queenside knight behind the pawn shell to reinforce the central break.

- Opening themes: Nbd2 route, e4 support, compact structure

### Packet colle-white.line-025.ply-11.f1d3

- Move: `Bd3` / `f1d3` at ply 11

- CoachCard: **Aim the Colle bishop at the kingside** — Bd3 develops the bishop to the classic Colle diagonal toward the kingside. It supports castling and later attacking chances if the center opens.

- Plain hint: Place the light-square bishop on the attacking diagonal after the pawn shell is stable.

- Opening themes: Bd3 placement, kingside aim, Colle attacking setup
