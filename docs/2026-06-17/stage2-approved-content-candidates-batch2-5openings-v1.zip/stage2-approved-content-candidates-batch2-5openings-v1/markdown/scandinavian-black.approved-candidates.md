# Scandinavian Defense approved-content candidates — Batch 2

Opening ID: `scandinavian-black`  
Status: approved candidates only; not app-activated.


## scandinavian-black-line-001: 1. e4 d5 2. e5 c5 3. d4 e6 4. c3 Nc6 5. Nf3 Bd7 6. Bd3 Qb6

Runtime playKey: `e2e4,d7d5,e4e5,c7c5,d2d4,e7e6,c2c3,b8c6,g1f3,c8d7,f1d3,d8b6`  
Runtime totalGames field at line node: `1400211`

### Packet scandinavian-black.line-001.ply-02.d7d5

- Move: `d5` / `d7d5` at ply 2

- CoachCard: **Challenge e4 immediately** — d5 is the Scandinavian’s signature central challenge. Black attacks White’s e-pawn immediately and asks White to resolve the center.

- Plain hint: Challenge the king pawn at once instead of building a slower pawn shell.

- Opening themes: immediate ...d5, e4 challenge, central tension

### Packet scandinavian-black.line-001.ply-04.c7c5

- Move: `c5` / `c7c5` at ply 4

- CoachCard: **Attack White’s advanced center from the side** — c5 challenges White’s advanced center from the side. In these Scandinavian Advance structures, Black pressures d4 instead of passively accepting White’s space.

- Plain hint: Use the c-pawn to pressure White’s central chain after the king pawn advances.

- Opening themes: Advance structure, ...c5 counterpressure, d4 target

### Packet scandinavian-black.line-001.ply-06.e7e6

- Move: `e6` / `e7e6` at ply 6

- CoachCard: **Support the Scandinavian central fight** — e6 supports Black’s central structure after the Scandinavian challenge. It helps Black pressure White’s advanced or exchanged center without overextending.

- Plain hint: Build a solid support pawn behind the central challenge.

- Opening themes: central support, Scandinavian-French structure, solid development

### Packet scandinavian-black.line-001.ply-08.b8c6

- Move: `Nc6` / `b8c6` at ply 8

- CoachCard: **Develop toward the central tension** — Nc6 develops into the Scandinavian central fight, adding pressure on d4 and e5 structures. Black develops behind the early ...d5 challenge.

- Plain hint: Bring the queenside knight into the fight over the central dark squares.

- Opening themes: central development, d4 pressure, Scandinavian tension

### Packet scandinavian-black.line-001.ply-10.c8d7

- Move: `Bd7` / `c8d7` at ply 10

- CoachCard: **Develop the bishop behind the central challenge** — Bd7 develops the bishop and connects Black’s queenside pieces in a Scandinavian Advance structure. It also prepares smoother rook and queen coordination.

- Plain hint: Place the bishop where it supports development without weakening the central setup.

- Opening themes: bishop development, central stability, piece coordination

### Packet scandinavian-black.line-001.ply-12.d8b6

- Move: `Qb6` / `d8b6` at ply 12

- CoachCard: **Pressure the b2/d4 complex** — Qb6 targets b2 and d4 from an active Scandinavian queen square. The point is pressure on White’s center, not a loose queen adventure.

- Plain hint: Use the queen to pressure the queenside and central pawns only when the center supports it.

- Opening themes: queen pressure, d4 target, queenside pressure


## scandinavian-black-line-002: 1. e4 d5 2. e5 c5 3. d4 Nc6 4. c3 cxd4 5. cxd4 e6 6. Nf3 Nge7

Runtime playKey: `e2e4,d7d5,e4e5,c7c5,d2d4,b8c6,c2c3,c5d4,c3d4,e7e6,g1f3,g8e7`  
Runtime totalGames field at line node: `1052350`

### Packet scandinavian-black.line-002.ply-02.d7d5

- Move: `d5` / `d7d5` at ply 2

- CoachCard: **Challenge e4 immediately** — d5 is the Scandinavian’s signature central challenge. Black attacks White’s e-pawn immediately and asks White to resolve the center.

- Plain hint: Challenge the king pawn at once instead of building a slower pawn shell.

- Opening themes: immediate ...d5, e4 challenge, central tension

### Packet scandinavian-black.line-002.ply-04.c7c5

- Move: `c5` / `c7c5` at ply 4

- CoachCard: **Attack White’s advanced center from the side** — c5 challenges White’s advanced center from the side. In these Scandinavian Advance structures, Black pressures d4 instead of passively accepting White’s space.

- Plain hint: Use the c-pawn to pressure White’s central chain after the king pawn advances.

- Opening themes: Advance structure, ...c5 counterpressure, d4 target

### Packet scandinavian-black.line-002.ply-06.b8c6

- Move: `Nc6` / `b8c6` at ply 6

- CoachCard: **Develop toward the central tension** — Nc6 develops into the Scandinavian central fight, adding pressure on d4 and e5 structures. Black develops behind the early ...d5 challenge.

- Plain hint: Bring the queenside knight into the fight over the central dark squares.

- Opening themes: central development, d4 pressure, Scandinavian tension

### Packet scandinavian-black.line-002.ply-08.c5d4

- Move: `cxd4` / `c5d4` at ply 8

- CoachCard: **Keep Scandinavian development connected to the center** — cxd4 supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure

### Packet scandinavian-black.line-002.ply-10.e7e6

- Move: `e6` / `e7e6` at ply 10

- CoachCard: **Support the Scandinavian central fight** — e6 supports Black’s central structure after the Scandinavian challenge. It helps Black pressure White’s advanced or exchanged center without overextending.

- Plain hint: Build a solid support pawn behind the central challenge.

- Opening themes: central support, Scandinavian-French structure, solid development

### Packet scandinavian-black.line-002.ply-12.g8e7

- Move: `Nge7` / `g8e7` at ply 12

- CoachCard: **Keep Scandinavian development connected to the center** — Nge7 supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure


## scandinavian-black-line-003: 1. e4 d5 2. exd5 Nf6 3. Nc3 Nxd5 4. Nxd5 Qxd5 5. Nf3 Nc6 6. Be2 Bg4

Runtime playKey: `e2e4,d7d5,e4d5,g8f6,b1c3,f6d5,c3d5,d8d5,g1f3,b8c6,f1e2,c8g4`  
Runtime totalGames field at line node: `987666`

### Packet scandinavian-black.line-003.ply-02.d7d5

- Move: `d5` / `d7d5` at ply 2

- CoachCard: **Challenge e4 immediately** — d5 is the Scandinavian’s signature central challenge. Black attacks White’s e-pawn immediately and asks White to resolve the center.

- Plain hint: Challenge the king pawn at once instead of building a slower pawn shell.

- Opening themes: immediate ...d5, e4 challenge, central tension

### Packet scandinavian-black.line-003.ply-04.g8f6

- Move: `Nf6` / `g8f6` at ply 4

- CoachCard: **Add a kingside knight to the center** — Nf6 develops a knight toward the center and helps Black catch up after the early central challenge. It also brings castling closer.

- Plain hint: Use the kingside knight to pressure the center while preparing castling.

- Opening themes: kingside development, central pressure, castling preparation

### Packet scandinavian-black.line-003.ply-06.f6d5

- Move: `Nxd5` / `f6d5` at ply 6

- CoachCard: **Keep Scandinavian development connected to the center** — Nxd5 supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure

### Packet scandinavian-black.line-003.ply-08.d8d5

- Move: `Qxd5` / `d8d5` at ply 8

- CoachCard: **Recapture with the queen only when the line allows it** — Qxd5 is the classic Scandinavian queen recapture. Black regains the pawn but must develop efficiently because the queen may become a target.

- Plain hint: Recover the central pawn with the queen and then plan development around the queen’s exposure.

- Opening themes: queen recapture, Scandinavian structure, development catch-up

### Packet scandinavian-black.line-003.ply-10.b8c6

- Move: `Nc6` / `b8c6` at ply 10

- CoachCard: **Develop toward the central tension** — Nc6 develops into the Scandinavian central fight, adding pressure on d4 and e5 structures. Black develops behind the early ...d5 challenge.

- Plain hint: Bring the queenside knight into the fight over the central dark squares.

- Opening themes: central development, d4 pressure, Scandinavian tension

### Packet scandinavian-black.line-003.ply-12.c8g4

- Move: `Bg4` / `c8g4` at ply 12

- CoachCard: **Keep Scandinavian development connected to the center** — Bg4 supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure


## scandinavian-black-line-004: 1. e4 d5 2. e5 c5 3. d4 Nc6 4. c3 cxd4 5. cxd4 e6 6. Nf3 Bb4+

Runtime playKey: `e2e4,d7d5,e4e5,c7c5,d2d4,b8c6,c2c3,c5d4,c3d4,e7e6,g1f3,f8b4`  
Runtime totalGames field at line node: `955949`

### Packet scandinavian-black.line-004.ply-02.d7d5

- Move: `d5` / `d7d5` at ply 2

- CoachCard: **Challenge e4 immediately** — d5 is the Scandinavian’s signature central challenge. Black attacks White’s e-pawn immediately and asks White to resolve the center.

- Plain hint: Challenge the king pawn at once instead of building a slower pawn shell.

- Opening themes: immediate ...d5, e4 challenge, central tension

### Packet scandinavian-black.line-004.ply-04.c7c5

- Move: `c5` / `c7c5` at ply 4

- CoachCard: **Attack White’s advanced center from the side** — c5 challenges White’s advanced center from the side. In these Scandinavian Advance structures, Black pressures d4 instead of passively accepting White’s space.

- Plain hint: Use the c-pawn to pressure White’s central chain after the king pawn advances.

- Opening themes: Advance structure, ...c5 counterpressure, d4 target

### Packet scandinavian-black.line-004.ply-06.b8c6

- Move: `Nc6` / `b8c6` at ply 6

- CoachCard: **Develop toward the central tension** — Nc6 develops into the Scandinavian central fight, adding pressure on d4 and e5 structures. Black develops behind the early ...d5 challenge.

- Plain hint: Bring the queenside knight into the fight over the central dark squares.

- Opening themes: central development, d4 pressure, Scandinavian tension

### Packet scandinavian-black.line-004.ply-08.c5d4

- Move: `cxd4` / `c5d4` at ply 8

- CoachCard: **Keep Scandinavian development connected to the center** — cxd4 supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure

### Packet scandinavian-black.line-004.ply-10.e7e6

- Move: `e6` / `e7e6` at ply 10

- CoachCard: **Support the Scandinavian central fight** — e6 supports Black’s central structure after the Scandinavian challenge. It helps Black pressure White’s advanced or exchanged center without overextending.

- Plain hint: Build a solid support pawn behind the central challenge.

- Opening themes: central support, Scandinavian-French structure, solid development

### Packet scandinavian-black.line-004.ply-12.f8b4

- Move: `Bb4+` / `f8b4` at ply 12

- CoachCard: **Keep Scandinavian development connected to the center** — Bb4+ supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure


## scandinavian-black-line-005: 1. e4 d5 2. exd5 Nf6 3. c4 c6 4. Nc3 cxd5 5. d4 Nc6 6. Nf3 e6

Runtime playKey: `e2e4,d7d5,e4d5,g8f6,c2c4,c7c6,b1c3,c6d5,d2d4,b8c6,g1f3,e7e6`  
Runtime totalGames field at line node: `794103`

### Packet scandinavian-black.line-005.ply-02.d7d5

- Move: `d5` / `d7d5` at ply 2

- CoachCard: **Challenge e4 immediately** — d5 is the Scandinavian’s signature central challenge. Black attacks White’s e-pawn immediately and asks White to resolve the center.

- Plain hint: Challenge the king pawn at once instead of building a slower pawn shell.

- Opening themes: immediate ...d5, e4 challenge, central tension

### Packet scandinavian-black.line-005.ply-04.g8f6

- Move: `Nf6` / `g8f6` at ply 4

- CoachCard: **Add a kingside knight to the center** — Nf6 develops a knight toward the center and helps Black catch up after the early central challenge. It also brings castling closer.

- Plain hint: Use the kingside knight to pressure the center while preparing castling.

- Opening themes: kingside development, central pressure, castling preparation

### Packet scandinavian-black.line-005.ply-06.c7c6

- Move: `c6` / `c7c6` at ply 6

- CoachCard: **Keep Scandinavian development connected to the center** — c6 supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure

### Packet scandinavian-black.line-005.ply-08.c6d5

- Move: `cxd5` / `c6d5` at ply 8

- CoachCard: **Keep Scandinavian development connected to the center** — cxd5 supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure

### Packet scandinavian-black.line-005.ply-10.b8c6

- Move: `Nc6` / `b8c6` at ply 10

- CoachCard: **Develop toward the central tension** — Nc6 develops into the Scandinavian central fight, adding pressure on d4 and e5 structures. Black develops behind the early ...d5 challenge.

- Plain hint: Bring the queenside knight into the fight over the central dark squares.

- Opening themes: central development, d4 pressure, Scandinavian tension

### Packet scandinavian-black.line-005.ply-12.e7e6

- Move: `e6` / `e7e6` at ply 12

- CoachCard: **Support the Scandinavian central fight** — e6 supports Black’s central structure after the Scandinavian challenge. It helps Black pressure White’s advanced or exchanged center without overextending.

- Plain hint: Build a solid support pawn behind the central challenge.

- Opening themes: central support, Scandinavian-French structure, solid development


## scandinavian-black-line-006: 1. e4 d5 2. exd5 Nf6 3. c4 c6 4. Nc3 cxd5 5. d4 Nc6 6. Nf3 Bg4

Runtime playKey: `e2e4,d7d5,e4d5,g8f6,c2c4,c7c6,b1c3,c6d5,d2d4,b8c6,g1f3,c8g4`  
Runtime totalGames field at line node: `782868`

### Packet scandinavian-black.line-006.ply-02.d7d5

- Move: `d5` / `d7d5` at ply 2

- CoachCard: **Challenge e4 immediately** — d5 is the Scandinavian’s signature central challenge. Black attacks White’s e-pawn immediately and asks White to resolve the center.

- Plain hint: Challenge the king pawn at once instead of building a slower pawn shell.

- Opening themes: immediate ...d5, e4 challenge, central tension

### Packet scandinavian-black.line-006.ply-04.g8f6

- Move: `Nf6` / `g8f6` at ply 4

- CoachCard: **Add a kingside knight to the center** — Nf6 develops a knight toward the center and helps Black catch up after the early central challenge. It also brings castling closer.

- Plain hint: Use the kingside knight to pressure the center while preparing castling.

- Opening themes: kingside development, central pressure, castling preparation

### Packet scandinavian-black.line-006.ply-06.c7c6

- Move: `c6` / `c7c6` at ply 6

- CoachCard: **Keep Scandinavian development connected to the center** — c6 supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure

### Packet scandinavian-black.line-006.ply-08.c6d5

- Move: `cxd5` / `c6d5` at ply 8

- CoachCard: **Keep Scandinavian development connected to the center** — cxd5 supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure

### Packet scandinavian-black.line-006.ply-10.b8c6

- Move: `Nc6` / `b8c6` at ply 10

- CoachCard: **Develop toward the central tension** — Nc6 develops into the Scandinavian central fight, adding pressure on d4 and e5 structures. Black develops behind the early ...d5 challenge.

- Plain hint: Bring the queenside knight into the fight over the central dark squares.

- Opening themes: central development, d4 pressure, Scandinavian tension

### Packet scandinavian-black.line-006.ply-12.c8g4

- Move: `Bg4` / `c8g4` at ply 12

- CoachCard: **Keep Scandinavian development connected to the center** — Bg4 supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure


## scandinavian-black-line-007: 1. e4 d5 2. e5 c5 3. d4 e6 4. c3 Nc6 5. Nf3 Qb6 6. Bd3 cxd4

Runtime playKey: `e2e4,d7d5,e4e5,c7c5,d2d4,e7e6,c2c3,b8c6,g1f3,d8b6,f1d3,c5d4`  
Runtime totalGames field at line node: `765752`

### Packet scandinavian-black.line-007.ply-02.d7d5

- Move: `d5` / `d7d5` at ply 2

- CoachCard: **Challenge e4 immediately** — d5 is the Scandinavian’s signature central challenge. Black attacks White’s e-pawn immediately and asks White to resolve the center.

- Plain hint: Challenge the king pawn at once instead of building a slower pawn shell.

- Opening themes: immediate ...d5, e4 challenge, central tension

### Packet scandinavian-black.line-007.ply-04.c7c5

- Move: `c5` / `c7c5` at ply 4

- CoachCard: **Attack White’s advanced center from the side** — c5 challenges White’s advanced center from the side. In these Scandinavian Advance structures, Black pressures d4 instead of passively accepting White’s space.

- Plain hint: Use the c-pawn to pressure White’s central chain after the king pawn advances.

- Opening themes: Advance structure, ...c5 counterpressure, d4 target

### Packet scandinavian-black.line-007.ply-06.e7e6

- Move: `e6` / `e7e6` at ply 6

- CoachCard: **Support the Scandinavian central fight** — e6 supports Black’s central structure after the Scandinavian challenge. It helps Black pressure White’s advanced or exchanged center without overextending.

- Plain hint: Build a solid support pawn behind the central challenge.

- Opening themes: central support, Scandinavian-French structure, solid development

### Packet scandinavian-black.line-007.ply-08.b8c6

- Move: `Nc6` / `b8c6` at ply 8

- CoachCard: **Develop toward the central tension** — Nc6 develops into the Scandinavian central fight, adding pressure on d4 and e5 structures. Black develops behind the early ...d5 challenge.

- Plain hint: Bring the queenside knight into the fight over the central dark squares.

- Opening themes: central development, d4 pressure, Scandinavian tension

### Packet scandinavian-black.line-007.ply-10.d8b6

- Move: `Qb6` / `d8b6` at ply 10

- CoachCard: **Pressure the b2/d4 complex** — Qb6 targets b2 and d4 from an active Scandinavian queen square. The point is pressure on White’s center, not a loose queen adventure.

- Plain hint: Use the queen to pressure the queenside and central pawns only when the center supports it.

- Opening themes: queen pressure, d4 target, queenside pressure

### Packet scandinavian-black.line-007.ply-12.c5d4

- Move: `cxd4` / `c5d4` at ply 12

- CoachCard: **Keep Scandinavian development connected to the center** — cxd4 supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure


## scandinavian-black-line-008: 1. e4 d5 2. exd5 Qxd5 3. Nf3 Qd8 4. Nc3 e6 5. d4 Nf6 6. Bg5 Be7

Runtime playKey: `e2e4,d7d5,e4d5,d8d5,g1f3,d5d8,b1c3,e7e6,d2d4,g8f6,c1g5,f8e7`  
Runtime totalGames field at line node: `614343`

### Packet scandinavian-black.line-008.ply-02.d7d5

- Move: `d5` / `d7d5` at ply 2

- CoachCard: **Challenge e4 immediately** — d5 is the Scandinavian’s signature central challenge. Black attacks White’s e-pawn immediately and asks White to resolve the center.

- Plain hint: Challenge the king pawn at once instead of building a slower pawn shell.

- Opening themes: immediate ...d5, e4 challenge, central tension

### Packet scandinavian-black.line-008.ply-04.d8d5

- Move: `Qxd5` / `d8d5` at ply 4

- CoachCard: **Recapture with the queen only when the line allows it** — Qxd5 is the classic Scandinavian queen recapture. Black regains the pawn but must develop efficiently because the queen may become a target.

- Plain hint: Recover the central pawn with the queen and then plan development around the queen’s exposure.

- Opening themes: queen recapture, Scandinavian structure, development catch-up

### Packet scandinavian-black.line-008.ply-06.d5d8

- Move: `Qd8` / `d5d8` at ply 6

- CoachCard: **Keep Scandinavian development connected to the center** — Qd8 supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure

### Packet scandinavian-black.line-008.ply-08.e7e6

- Move: `e6` / `e7e6` at ply 8

- CoachCard: **Support the Scandinavian central fight** — e6 supports Black’s central structure after the Scandinavian challenge. It helps Black pressure White’s advanced or exchanged center without overextending.

- Plain hint: Build a solid support pawn behind the central challenge.

- Opening themes: central support, Scandinavian-French structure, solid development

### Packet scandinavian-black.line-008.ply-10.g8f6

- Move: `Nf6` / `g8f6` at ply 10

- CoachCard: **Add a kingside knight to the center** — Nf6 develops a knight toward the center and helps Black catch up after the early central challenge. It also brings castling closer.

- Plain hint: Use the kingside knight to pressure the center while preparing castling.

- Opening themes: kingside development, central pressure, castling preparation

### Packet scandinavian-black.line-008.ply-12.f8e7

- Move: `Be7` / `f8e7` at ply 12

- CoachCard: **Keep Scandinavian development connected to the center** — Be7 supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure


## scandinavian-black-line-009: 1. e4 d5 2. exd5 Nf6 3. Nc3 Nxd5 4. Nxd5 Qxd5 5. Nf3 Nc6 6. d4 Bg4

Runtime playKey: `e2e4,d7d5,e4d5,g8f6,b1c3,f6d5,c3d5,d8d5,g1f3,b8c6,d2d4,c8g4`  
Runtime totalGames field at line node: `607879`

### Packet scandinavian-black.line-009.ply-02.d7d5

- Move: `d5` / `d7d5` at ply 2

- CoachCard: **Challenge e4 immediately** — d5 is the Scandinavian’s signature central challenge. Black attacks White’s e-pawn immediately and asks White to resolve the center.

- Plain hint: Challenge the king pawn at once instead of building a slower pawn shell.

- Opening themes: immediate ...d5, e4 challenge, central tension

### Packet scandinavian-black.line-009.ply-04.g8f6

- Move: `Nf6` / `g8f6` at ply 4

- CoachCard: **Add a kingside knight to the center** — Nf6 develops a knight toward the center and helps Black catch up after the early central challenge. It also brings castling closer.

- Plain hint: Use the kingside knight to pressure the center while preparing castling.

- Opening themes: kingside development, central pressure, castling preparation

### Packet scandinavian-black.line-009.ply-06.f6d5

- Move: `Nxd5` / `f6d5` at ply 6

- CoachCard: **Keep Scandinavian development connected to the center** — Nxd5 supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure

### Packet scandinavian-black.line-009.ply-08.d8d5

- Move: `Qxd5` / `d8d5` at ply 8

- CoachCard: **Recapture with the queen only when the line allows it** — Qxd5 is the classic Scandinavian queen recapture. Black regains the pawn but must develop efficiently because the queen may become a target.

- Plain hint: Recover the central pawn with the queen and then plan development around the queen’s exposure.

- Opening themes: queen recapture, Scandinavian structure, development catch-up

### Packet scandinavian-black.line-009.ply-10.b8c6

- Move: `Nc6` / `b8c6` at ply 10

- CoachCard: **Develop toward the central tension** — Nc6 develops into the Scandinavian central fight, adding pressure on d4 and e5 structures. Black develops behind the early ...d5 challenge.

- Plain hint: Bring the queenside knight into the fight over the central dark squares.

- Opening themes: central development, d4 pressure, Scandinavian tension

### Packet scandinavian-black.line-009.ply-12.c8g4

- Move: `Bg4` / `c8g4` at ply 12

- CoachCard: **Keep Scandinavian development connected to the center** — Bg4 supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure


## scandinavian-black-line-010: 1. e4 d5 2. e5 c5 3. d4 e6 4. c3 Nc6 5. Nf3 Qb6 6. Be2 cxd4

Runtime playKey: `e2e4,d7d5,e4e5,c7c5,d2d4,e7e6,c2c3,b8c6,g1f3,d8b6,f1e2,c5d4`  
Runtime totalGames field at line node: `565955`

### Packet scandinavian-black.line-010.ply-02.d7d5

- Move: `d5` / `d7d5` at ply 2

- CoachCard: **Challenge e4 immediately** — d5 is the Scandinavian’s signature central challenge. Black attacks White’s e-pawn immediately and asks White to resolve the center.

- Plain hint: Challenge the king pawn at once instead of building a slower pawn shell.

- Opening themes: immediate ...d5, e4 challenge, central tension

### Packet scandinavian-black.line-010.ply-04.c7c5

- Move: `c5` / `c7c5` at ply 4

- CoachCard: **Attack White’s advanced center from the side** — c5 challenges White’s advanced center from the side. In these Scandinavian Advance structures, Black pressures d4 instead of passively accepting White’s space.

- Plain hint: Use the c-pawn to pressure White’s central chain after the king pawn advances.

- Opening themes: Advance structure, ...c5 counterpressure, d4 target

### Packet scandinavian-black.line-010.ply-06.e7e6

- Move: `e6` / `e7e6` at ply 6

- CoachCard: **Support the Scandinavian central fight** — e6 supports Black’s central structure after the Scandinavian challenge. It helps Black pressure White’s advanced or exchanged center without overextending.

- Plain hint: Build a solid support pawn behind the central challenge.

- Opening themes: central support, Scandinavian-French structure, solid development

### Packet scandinavian-black.line-010.ply-08.b8c6

- Move: `Nc6` / `b8c6` at ply 8

- CoachCard: **Develop toward the central tension** — Nc6 develops into the Scandinavian central fight, adding pressure on d4 and e5 structures. Black develops behind the early ...d5 challenge.

- Plain hint: Bring the queenside knight into the fight over the central dark squares.

- Opening themes: central development, d4 pressure, Scandinavian tension

### Packet scandinavian-black.line-010.ply-10.d8b6

- Move: `Qb6` / `d8b6` at ply 10

- CoachCard: **Pressure the b2/d4 complex** — Qb6 targets b2 and d4 from an active Scandinavian queen square. The point is pressure on White’s center, not a loose queen adventure.

- Plain hint: Use the queen to pressure the queenside and central pawns only when the center supports it.

- Opening themes: queen pressure, d4 target, queenside pressure

### Packet scandinavian-black.line-010.ply-12.c5d4

- Move: `cxd4` / `c5d4` at ply 12

- CoachCard: **Keep Scandinavian development connected to the center** — cxd4 supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure


## scandinavian-black-line-011: 1. e4 d5 2. e5 c5 3. d4 e6 4. c3 Nc6 5. Nf3 Bd7 6. Be2 Qb6

Runtime playKey: `e2e4,d7d5,e4e5,c7c5,d2d4,e7e6,c2c3,b8c6,g1f3,c8d7,f1e2,d8b6`  
Runtime totalGames field at line node: `545996`

### Packet scandinavian-black.line-011.ply-02.d7d5

- Move: `d5` / `d7d5` at ply 2

- CoachCard: **Challenge e4 immediately** — d5 is the Scandinavian’s signature central challenge. Black attacks White’s e-pawn immediately and asks White to resolve the center.

- Plain hint: Challenge the king pawn at once instead of building a slower pawn shell.

- Opening themes: immediate ...d5, e4 challenge, central tension

### Packet scandinavian-black.line-011.ply-04.c7c5

- Move: `c5` / `c7c5` at ply 4

- CoachCard: **Attack White’s advanced center from the side** — c5 challenges White’s advanced center from the side. In these Scandinavian Advance structures, Black pressures d4 instead of passively accepting White’s space.

- Plain hint: Use the c-pawn to pressure White’s central chain after the king pawn advances.

- Opening themes: Advance structure, ...c5 counterpressure, d4 target

### Packet scandinavian-black.line-011.ply-06.e7e6

- Move: `e6` / `e7e6` at ply 6

- CoachCard: **Support the Scandinavian central fight** — e6 supports Black’s central structure after the Scandinavian challenge. It helps Black pressure White’s advanced or exchanged center without overextending.

- Plain hint: Build a solid support pawn behind the central challenge.

- Opening themes: central support, Scandinavian-French structure, solid development

### Packet scandinavian-black.line-011.ply-08.b8c6

- Move: `Nc6` / `b8c6` at ply 8

- CoachCard: **Develop toward the central tension** — Nc6 develops into the Scandinavian central fight, adding pressure on d4 and e5 structures. Black develops behind the early ...d5 challenge.

- Plain hint: Bring the queenside knight into the fight over the central dark squares.

- Opening themes: central development, d4 pressure, Scandinavian tension

### Packet scandinavian-black.line-011.ply-10.c8d7

- Move: `Bd7` / `c8d7` at ply 10

- CoachCard: **Develop the bishop behind the central challenge** — Bd7 develops the bishop and connects Black’s queenside pieces in a Scandinavian Advance structure. It also prepares smoother rook and queen coordination.

- Plain hint: Place the bishop where it supports development without weakening the central setup.

- Opening themes: bishop development, central stability, piece coordination

### Packet scandinavian-black.line-011.ply-12.d8b6

- Move: `Qb6` / `d8b6` at ply 12

- CoachCard: **Pressure the b2/d4 complex** — Qb6 targets b2 and d4 from an active Scandinavian queen square. The point is pressure on White’s center, not a loose queen adventure.

- Plain hint: Use the queen to pressure the queenside and central pawns only when the center supports it.

- Opening themes: queen pressure, d4 target, queenside pressure


## scandinavian-black-line-012: 1. e4 d5 2. exd5 Nf6 3. c4 c6 4. Nc3 cxd5 5. d4 e6 6. Nf3 Bb4

Runtime playKey: `e2e4,d7d5,e4d5,g8f6,c2c4,c7c6,b1c3,c6d5,d2d4,e7e6,g1f3,f8b4`  
Runtime totalGames field at line node: `486843`

### Packet scandinavian-black.line-012.ply-02.d7d5

- Move: `d5` / `d7d5` at ply 2

- CoachCard: **Challenge e4 immediately** — d5 is the Scandinavian’s signature central challenge. Black attacks White’s e-pawn immediately and asks White to resolve the center.

- Plain hint: Challenge the king pawn at once instead of building a slower pawn shell.

- Opening themes: immediate ...d5, e4 challenge, central tension

### Packet scandinavian-black.line-012.ply-04.g8f6

- Move: `Nf6` / `g8f6` at ply 4

- CoachCard: **Add a kingside knight to the center** — Nf6 develops a knight toward the center and helps Black catch up after the early central challenge. It also brings castling closer.

- Plain hint: Use the kingside knight to pressure the center while preparing castling.

- Opening themes: kingside development, central pressure, castling preparation

### Packet scandinavian-black.line-012.ply-06.c7c6

- Move: `c6` / `c7c6` at ply 6

- CoachCard: **Keep Scandinavian development connected to the center** — c6 supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure

### Packet scandinavian-black.line-012.ply-08.c6d5

- Move: `cxd5` / `c6d5` at ply 8

- CoachCard: **Keep Scandinavian development connected to the center** — cxd5 supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure

### Packet scandinavian-black.line-012.ply-10.e7e6

- Move: `e6` / `e7e6` at ply 10

- CoachCard: **Support the Scandinavian central fight** — e6 supports Black’s central structure after the Scandinavian challenge. It helps Black pressure White’s advanced or exchanged center without overextending.

- Plain hint: Build a solid support pawn behind the central challenge.

- Opening themes: central support, Scandinavian-French structure, solid development

### Packet scandinavian-black.line-012.ply-12.f8b4

- Move: `Bb4` / `f8b4` at ply 12

- CoachCard: **Keep Scandinavian development connected to the center** — Bb4 supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure


## scandinavian-black-line-013: 1. e4 d5 2. exd5 Qxd5 3. Nf3 Nf6 4. Nc3 Qa5 5. d4 c6 6. Bd2 Bg4

Runtime playKey: `e2e4,d7d5,e4d5,d8d5,g1f3,g8f6,b1c3,d5a5,d2d4,c7c6,c1d2,c8g4`  
Runtime totalGames field at line node: `478626`

### Packet scandinavian-black.line-013.ply-02.d7d5

- Move: `d5` / `d7d5` at ply 2

- CoachCard: **Challenge e4 immediately** — d5 is the Scandinavian’s signature central challenge. Black attacks White’s e-pawn immediately and asks White to resolve the center.

- Plain hint: Challenge the king pawn at once instead of building a slower pawn shell.

- Opening themes: immediate ...d5, e4 challenge, central tension

### Packet scandinavian-black.line-013.ply-04.d8d5

- Move: `Qxd5` / `d8d5` at ply 4

- CoachCard: **Recapture with the queen only when the line allows it** — Qxd5 is the classic Scandinavian queen recapture. Black regains the pawn but must develop efficiently because the queen may become a target.

- Plain hint: Recover the central pawn with the queen and then plan development around the queen’s exposure.

- Opening themes: queen recapture, Scandinavian structure, development catch-up

### Packet scandinavian-black.line-013.ply-06.g8f6

- Move: `Nf6` / `g8f6` at ply 6

- CoachCard: **Add a kingside knight to the center** — Nf6 develops a knight toward the center and helps Black catch up after the early central challenge. It also brings castling closer.

- Plain hint: Use the kingside knight to pressure the center while preparing castling.

- Opening themes: kingside development, central pressure, castling preparation

### Packet scandinavian-black.line-013.ply-08.d5a5

- Move: `Qa5` / `d5a5` at ply 8

- CoachCard: **Keep Scandinavian development connected to the center** — Qa5 supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure

### Packet scandinavian-black.line-013.ply-10.c7c6

- Move: `c6` / `c7c6` at ply 10

- CoachCard: **Keep Scandinavian development connected to the center** — c6 supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure

### Packet scandinavian-black.line-013.ply-12.c8g4

- Move: `Bg4` / `c8g4` at ply 12

- CoachCard: **Keep Scandinavian development connected to the center** — Bg4 supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure


## scandinavian-black-line-014: 1. e4 d5 2. exd5 Qxd5 3. Nf3 Nf6 4. Nc3 Qa5 5. d4 c6 6. Bd2 Qc7

Runtime playKey: `e2e4,d7d5,e4d5,d8d5,g1f3,g8f6,b1c3,d5a5,d2d4,c7c6,c1d2,a5c7`  
Runtime totalGames field at line node: `424739`

### Packet scandinavian-black.line-014.ply-02.d7d5

- Move: `d5` / `d7d5` at ply 2

- CoachCard: **Challenge e4 immediately** — d5 is the Scandinavian’s signature central challenge. Black attacks White’s e-pawn immediately and asks White to resolve the center.

- Plain hint: Challenge the king pawn at once instead of building a slower pawn shell.

- Opening themes: immediate ...d5, e4 challenge, central tension

### Packet scandinavian-black.line-014.ply-04.d8d5

- Move: `Qxd5` / `d8d5` at ply 4

- CoachCard: **Recapture with the queen only when the line allows it** — Qxd5 is the classic Scandinavian queen recapture. Black regains the pawn but must develop efficiently because the queen may become a target.

- Plain hint: Recover the central pawn with the queen and then plan development around the queen’s exposure.

- Opening themes: queen recapture, Scandinavian structure, development catch-up

### Packet scandinavian-black.line-014.ply-06.g8f6

- Move: `Nf6` / `g8f6` at ply 6

- CoachCard: **Add a kingside knight to the center** — Nf6 develops a knight toward the center and helps Black catch up after the early central challenge. It also brings castling closer.

- Plain hint: Use the kingside knight to pressure the center while preparing castling.

- Opening themes: kingside development, central pressure, castling preparation

### Packet scandinavian-black.line-014.ply-08.d5a5

- Move: `Qa5` / `d5a5` at ply 8

- CoachCard: **Keep Scandinavian development connected to the center** — Qa5 supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure

### Packet scandinavian-black.line-014.ply-10.c7c6

- Move: `c6` / `c7c6` at ply 10

- CoachCard: **Keep Scandinavian development connected to the center** — c6 supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure

### Packet scandinavian-black.line-014.ply-12.a5c7

- Move: `Qc7` / `a5c7` at ply 12

- CoachCard: **Keep Scandinavian development connected to the center** — Qc7 supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure


## scandinavian-black-line-015: 1. e4 d5 2. e5 c5 3. d4 e6 4. c3 Nc6 5. Bb5 Qb6 6. Bxc6+ bxc6

Runtime playKey: `e2e4,d7d5,e4e5,c7c5,d2d4,e7e6,c2c3,b8c6,f1b5,d8b6,b5c6,b7c6`  
Runtime totalGames field at line node: `418934`

### Packet scandinavian-black.line-015.ply-02.d7d5

- Move: `d5` / `d7d5` at ply 2

- CoachCard: **Challenge e4 immediately** — d5 is the Scandinavian’s signature central challenge. Black attacks White’s e-pawn immediately and asks White to resolve the center.

- Plain hint: Challenge the king pawn at once instead of building a slower pawn shell.

- Opening themes: immediate ...d5, e4 challenge, central tension

### Packet scandinavian-black.line-015.ply-04.c7c5

- Move: `c5` / `c7c5` at ply 4

- CoachCard: **Attack White’s advanced center from the side** — c5 challenges White’s advanced center from the side. In these Scandinavian Advance structures, Black pressures d4 instead of passively accepting White’s space.

- Plain hint: Use the c-pawn to pressure White’s central chain after the king pawn advances.

- Opening themes: Advance structure, ...c5 counterpressure, d4 target

### Packet scandinavian-black.line-015.ply-06.e7e6

- Move: `e6` / `e7e6` at ply 6

- CoachCard: **Support the Scandinavian central fight** — e6 supports Black’s central structure after the Scandinavian challenge. It helps Black pressure White’s advanced or exchanged center without overextending.

- Plain hint: Build a solid support pawn behind the central challenge.

- Opening themes: central support, Scandinavian-French structure, solid development

### Packet scandinavian-black.line-015.ply-08.b8c6

- Move: `Nc6` / `b8c6` at ply 8

- CoachCard: **Develop toward the central tension** — Nc6 develops into the Scandinavian central fight, adding pressure on d4 and e5 structures. Black develops behind the early ...d5 challenge.

- Plain hint: Bring the queenside knight into the fight over the central dark squares.

- Opening themes: central development, d4 pressure, Scandinavian tension

### Packet scandinavian-black.line-015.ply-10.d8b6

- Move: `Qb6` / `d8b6` at ply 10

- CoachCard: **Pressure the b2/d4 complex** — Qb6 targets b2 and d4 from an active Scandinavian queen square. The point is pressure on White’s center, not a loose queen adventure.

- Plain hint: Use the queen to pressure the queenside and central pawns only when the center supports it.

- Opening themes: queen pressure, d4 target, queenside pressure

### Packet scandinavian-black.line-015.ply-12.b7c6

- Move: `bxc6` / `b7c6` at ply 12

- CoachCard: **Keep Scandinavian development connected to the center** — bxc6 supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure


## scandinavian-black-line-016: 1. e4 d5 2. exd5 Qxd5 3. Nc3 Qa5 4. d4 c6 5. Nf3 Bg4 6. Be2 Nf6

Runtime playKey: `e2e4,d7d5,e4d5,d8d5,b1c3,d5a5,d2d4,c7c6,g1f3,c8g4,f1e2,g8f6`  
Runtime totalGames field at line node: `410561`

### Packet scandinavian-black.line-016.ply-02.d7d5

- Move: `d5` / `d7d5` at ply 2

- CoachCard: **Challenge e4 immediately** — d5 is the Scandinavian’s signature central challenge. Black attacks White’s e-pawn immediately and asks White to resolve the center.

- Plain hint: Challenge the king pawn at once instead of building a slower pawn shell.

- Opening themes: immediate ...d5, e4 challenge, central tension

### Packet scandinavian-black.line-016.ply-04.d8d5

- Move: `Qxd5` / `d8d5` at ply 4

- CoachCard: **Recapture with the queen only when the line allows it** — Qxd5 is the classic Scandinavian queen recapture. Black regains the pawn but must develop efficiently because the queen may become a target.

- Plain hint: Recover the central pawn with the queen and then plan development around the queen’s exposure.

- Opening themes: queen recapture, Scandinavian structure, development catch-up

### Packet scandinavian-black.line-016.ply-06.d5a5

- Move: `Qa5` / `d5a5` at ply 6

- CoachCard: **Keep Scandinavian development connected to the center** — Qa5 supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure

### Packet scandinavian-black.line-016.ply-08.c7c6

- Move: `c6` / `c7c6` at ply 8

- CoachCard: **Keep Scandinavian development connected to the center** — c6 supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure

### Packet scandinavian-black.line-016.ply-10.c8g4

- Move: `Bg4` / `c8g4` at ply 10

- CoachCard: **Keep Scandinavian development connected to the center** — Bg4 supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure

### Packet scandinavian-black.line-016.ply-12.g8f6

- Move: `Nf6` / `g8f6` at ply 12

- CoachCard: **Add a kingside knight to the center** — Nf6 develops a knight toward the center and helps Black catch up after the early central challenge. It also brings castling closer.

- Plain hint: Use the kingside knight to pressure the center while preparing castling.

- Opening themes: kingside development, central pressure, castling preparation


## scandinavian-black-line-017: 1. e4 d5 2. exd5 Qxd5 3. Nf3 Qd8 4. Nc3 Nf6 5. d4 Bg4 6. Be2 e6

Runtime playKey: `e2e4,d7d5,e4d5,d8d5,g1f3,d5d8,b1c3,g8f6,d2d4,c8g4,f1e2,e7e6`  
Runtime totalGames field at line node: `402389`

### Packet scandinavian-black.line-017.ply-02.d7d5

- Move: `d5` / `d7d5` at ply 2

- CoachCard: **Challenge e4 immediately** — d5 is the Scandinavian’s signature central challenge. Black attacks White’s e-pawn immediately and asks White to resolve the center.

- Plain hint: Challenge the king pawn at once instead of building a slower pawn shell.

- Opening themes: immediate ...d5, e4 challenge, central tension

### Packet scandinavian-black.line-017.ply-04.d8d5

- Move: `Qxd5` / `d8d5` at ply 4

- CoachCard: **Recapture with the queen only when the line allows it** — Qxd5 is the classic Scandinavian queen recapture. Black regains the pawn but must develop efficiently because the queen may become a target.

- Plain hint: Recover the central pawn with the queen and then plan development around the queen’s exposure.

- Opening themes: queen recapture, Scandinavian structure, development catch-up

### Packet scandinavian-black.line-017.ply-06.d5d8

- Move: `Qd8` / `d5d8` at ply 6

- CoachCard: **Keep Scandinavian development connected to the center** — Qd8 supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure

### Packet scandinavian-black.line-017.ply-08.g8f6

- Move: `Nf6` / `g8f6` at ply 8

- CoachCard: **Add a kingside knight to the center** — Nf6 develops a knight toward the center and helps Black catch up after the early central challenge. It also brings castling closer.

- Plain hint: Use the kingside knight to pressure the center while preparing castling.

- Opening themes: kingside development, central pressure, castling preparation

### Packet scandinavian-black.line-017.ply-10.c8g4

- Move: `Bg4` / `c8g4` at ply 10

- CoachCard: **Keep Scandinavian development connected to the center** — Bg4 supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure

### Packet scandinavian-black.line-017.ply-12.e7e6

- Move: `e6` / `e7e6` at ply 12

- CoachCard: **Support the Scandinavian central fight** — e6 supports Black’s central structure after the Scandinavian challenge. It helps Black pressure White’s advanced or exchanged center without overextending.

- Plain hint: Build a solid support pawn behind the central challenge.

- Opening themes: central support, Scandinavian-French structure, solid development


## scandinavian-black-line-018: 1. e4 d5 2. exd5 Qxd5 3. Nf3 Qd8 4. Nc3 e6 5. d4 Nf6 6. Bc4 Be7

Runtime playKey: `e2e4,d7d5,e4d5,d8d5,g1f3,d5d8,b1c3,e7e6,d2d4,g8f6,f1c4,f8e7`  
Runtime totalGames field at line node: `381139`

### Packet scandinavian-black.line-018.ply-02.d7d5

- Move: `d5` / `d7d5` at ply 2

- CoachCard: **Challenge e4 immediately** — d5 is the Scandinavian’s signature central challenge. Black attacks White’s e-pawn immediately and asks White to resolve the center.

- Plain hint: Challenge the king pawn at once instead of building a slower pawn shell.

- Opening themes: immediate ...d5, e4 challenge, central tension

### Packet scandinavian-black.line-018.ply-04.d8d5

- Move: `Qxd5` / `d8d5` at ply 4

- CoachCard: **Recapture with the queen only when the line allows it** — Qxd5 is the classic Scandinavian queen recapture. Black regains the pawn but must develop efficiently because the queen may become a target.

- Plain hint: Recover the central pawn with the queen and then plan development around the queen’s exposure.

- Opening themes: queen recapture, Scandinavian structure, development catch-up

### Packet scandinavian-black.line-018.ply-06.d5d8

- Move: `Qd8` / `d5d8` at ply 6

- CoachCard: **Keep Scandinavian development connected to the center** — Qd8 supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure

### Packet scandinavian-black.line-018.ply-08.e7e6

- Move: `e6` / `e7e6` at ply 8

- CoachCard: **Support the Scandinavian central fight** — e6 supports Black’s central structure after the Scandinavian challenge. It helps Black pressure White’s advanced or exchanged center without overextending.

- Plain hint: Build a solid support pawn behind the central challenge.

- Opening themes: central support, Scandinavian-French structure, solid development

### Packet scandinavian-black.line-018.ply-10.g8f6

- Move: `Nf6` / `g8f6` at ply 10

- CoachCard: **Add a kingside knight to the center** — Nf6 develops a knight toward the center and helps Black catch up after the early central challenge. It also brings castling closer.

- Plain hint: Use the kingside knight to pressure the center while preparing castling.

- Opening themes: kingside development, central pressure, castling preparation

### Packet scandinavian-black.line-018.ply-12.f8e7

- Move: `Be7` / `f8e7` at ply 12

- CoachCard: **Keep Scandinavian development connected to the center** — Be7 supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure


## scandinavian-black-line-019: 1. e4 d5 2. exd5 Nf6 3. c4 c6 4. Nc3 cxd5 5. d4 e6 6. Nf3 Be7

Runtime playKey: `e2e4,d7d5,e4d5,g8f6,c2c4,c7c6,b1c3,c6d5,d2d4,e7e6,g1f3,f8e7`  
Runtime totalGames field at line node: `378424`

### Packet scandinavian-black.line-019.ply-02.d7d5

- Move: `d5` / `d7d5` at ply 2

- CoachCard: **Challenge e4 immediately** — d5 is the Scandinavian’s signature central challenge. Black attacks White’s e-pawn immediately and asks White to resolve the center.

- Plain hint: Challenge the king pawn at once instead of building a slower pawn shell.

- Opening themes: immediate ...d5, e4 challenge, central tension

### Packet scandinavian-black.line-019.ply-04.g8f6

- Move: `Nf6` / `g8f6` at ply 4

- CoachCard: **Add a kingside knight to the center** — Nf6 develops a knight toward the center and helps Black catch up after the early central challenge. It also brings castling closer.

- Plain hint: Use the kingside knight to pressure the center while preparing castling.

- Opening themes: kingside development, central pressure, castling preparation

### Packet scandinavian-black.line-019.ply-06.c7c6

- Move: `c6` / `c7c6` at ply 6

- CoachCard: **Keep Scandinavian development connected to the center** — c6 supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure

### Packet scandinavian-black.line-019.ply-08.c6d5

- Move: `cxd5` / `c6d5` at ply 8

- CoachCard: **Keep Scandinavian development connected to the center** — cxd5 supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure

### Packet scandinavian-black.line-019.ply-10.e7e6

- Move: `e6` / `e7e6` at ply 10

- CoachCard: **Support the Scandinavian central fight** — e6 supports Black’s central structure after the Scandinavian challenge. It helps Black pressure White’s advanced or exchanged center without overextending.

- Plain hint: Build a solid support pawn behind the central challenge.

- Opening themes: central support, Scandinavian-French structure, solid development

### Packet scandinavian-black.line-019.ply-12.f8e7

- Move: `Be7` / `f8e7` at ply 12

- CoachCard: **Keep Scandinavian development connected to the center** — Be7 supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure


## scandinavian-black-line-020: 1. e4 d5 2. exd5 Qxd5 3. Nf3 Nf6 4. Nc3 Qa5 5. d4 c6 6. Bc4 Bg4

Runtime playKey: `e2e4,d7d5,e4d5,d8d5,g1f3,g8f6,b1c3,d5a5,d2d4,c7c6,f1c4,c8g4`  
Runtime totalGames field at line node: `346088`

### Packet scandinavian-black.line-020.ply-02.d7d5

- Move: `d5` / `d7d5` at ply 2

- CoachCard: **Challenge e4 immediately** — d5 is the Scandinavian’s signature central challenge. Black attacks White’s e-pawn immediately and asks White to resolve the center.

- Plain hint: Challenge the king pawn at once instead of building a slower pawn shell.

- Opening themes: immediate ...d5, e4 challenge, central tension

### Packet scandinavian-black.line-020.ply-04.d8d5

- Move: `Qxd5` / `d8d5` at ply 4

- CoachCard: **Recapture with the queen only when the line allows it** — Qxd5 is the classic Scandinavian queen recapture. Black regains the pawn but must develop efficiently because the queen may become a target.

- Plain hint: Recover the central pawn with the queen and then plan development around the queen’s exposure.

- Opening themes: queen recapture, Scandinavian structure, development catch-up

### Packet scandinavian-black.line-020.ply-06.g8f6

- Move: `Nf6` / `g8f6` at ply 6

- CoachCard: **Add a kingside knight to the center** — Nf6 develops a knight toward the center and helps Black catch up after the early central challenge. It also brings castling closer.

- Plain hint: Use the kingside knight to pressure the center while preparing castling.

- Opening themes: kingside development, central pressure, castling preparation

### Packet scandinavian-black.line-020.ply-08.d5a5

- Move: `Qa5` / `d5a5` at ply 8

- CoachCard: **Keep Scandinavian development connected to the center** — Qa5 supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure

### Packet scandinavian-black.line-020.ply-10.c7c6

- Move: `c6` / `c7c6` at ply 10

- CoachCard: **Keep Scandinavian development connected to the center** — c6 supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure

### Packet scandinavian-black.line-020.ply-12.c8g4

- Move: `Bg4` / `c8g4` at ply 12

- CoachCard: **Keep Scandinavian development connected to the center** — Bg4 supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure


## scandinavian-black-line-021: 1. e4 d5 2. exd5 Nf6 3. d4 Qxd5 4. Nf3 Nc6 5. Nc3 Qa5 6. Bd2 Bg4

Runtime playKey: `e2e4,d7d5,e4d5,g8f6,d2d4,d8d5,g1f3,b8c6,b1c3,d5a5,c1d2,c8g4`  
Runtime totalGames field at line node: `331914`

### Packet scandinavian-black.line-021.ply-02.d7d5

- Move: `d5` / `d7d5` at ply 2

- CoachCard: **Challenge e4 immediately** — d5 is the Scandinavian’s signature central challenge. Black attacks White’s e-pawn immediately and asks White to resolve the center.

- Plain hint: Challenge the king pawn at once instead of building a slower pawn shell.

- Opening themes: immediate ...d5, e4 challenge, central tension

### Packet scandinavian-black.line-021.ply-04.g8f6

- Move: `Nf6` / `g8f6` at ply 4

- CoachCard: **Add a kingside knight to the center** — Nf6 develops a knight toward the center and helps Black catch up after the early central challenge. It also brings castling closer.

- Plain hint: Use the kingside knight to pressure the center while preparing castling.

- Opening themes: kingside development, central pressure, castling preparation

### Packet scandinavian-black.line-021.ply-06.d8d5

- Move: `Qxd5` / `d8d5` at ply 6

- CoachCard: **Recapture with the queen only when the line allows it** — Qxd5 is the classic Scandinavian queen recapture. Black regains the pawn but must develop efficiently because the queen may become a target.

- Plain hint: Recover the central pawn with the queen and then plan development around the queen’s exposure.

- Opening themes: queen recapture, Scandinavian structure, development catch-up

### Packet scandinavian-black.line-021.ply-08.b8c6

- Move: `Nc6` / `b8c6` at ply 8

- CoachCard: **Develop toward the central tension** — Nc6 develops into the Scandinavian central fight, adding pressure on d4 and e5 structures. Black develops behind the early ...d5 challenge.

- Plain hint: Bring the queenside knight into the fight over the central dark squares.

- Opening themes: central development, d4 pressure, Scandinavian tension

### Packet scandinavian-black.line-021.ply-10.d5a5

- Move: `Qa5` / `d5a5` at ply 10

- CoachCard: **Keep Scandinavian development connected to the center** — Qa5 supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure

### Packet scandinavian-black.line-021.ply-12.c8g4

- Move: `Bg4` / `c8g4` at ply 12

- CoachCard: **Keep Scandinavian development connected to the center** — Bg4 supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure


## scandinavian-black-line-022: 1. e4 d5 2. exd5 Nf6 3. d4 Qxd5 4. Nc3 Qa5 5. Nf3 Bg4 6. Be2 Nc6

Runtime playKey: `e2e4,d7d5,e4d5,g8f6,d2d4,d8d5,b1c3,d5a5,g1f3,c8g4,f1e2,b8c6`  
Runtime totalGames field at line node: `328200`

### Packet scandinavian-black.line-022.ply-02.d7d5

- Move: `d5` / `d7d5` at ply 2

- CoachCard: **Challenge e4 immediately** — d5 is the Scandinavian’s signature central challenge. Black attacks White’s e-pawn immediately and asks White to resolve the center.

- Plain hint: Challenge the king pawn at once instead of building a slower pawn shell.

- Opening themes: immediate ...d5, e4 challenge, central tension

### Packet scandinavian-black.line-022.ply-04.g8f6

- Move: `Nf6` / `g8f6` at ply 4

- CoachCard: **Add a kingside knight to the center** — Nf6 develops a knight toward the center and helps Black catch up after the early central challenge. It also brings castling closer.

- Plain hint: Use the kingside knight to pressure the center while preparing castling.

- Opening themes: kingside development, central pressure, castling preparation

### Packet scandinavian-black.line-022.ply-06.d8d5

- Move: `Qxd5` / `d8d5` at ply 6

- CoachCard: **Recapture with the queen only when the line allows it** — Qxd5 is the classic Scandinavian queen recapture. Black regains the pawn but must develop efficiently because the queen may become a target.

- Plain hint: Recover the central pawn with the queen and then plan development around the queen’s exposure.

- Opening themes: queen recapture, Scandinavian structure, development catch-up

### Packet scandinavian-black.line-022.ply-08.d5a5

- Move: `Qa5` / `d5a5` at ply 8

- CoachCard: **Keep Scandinavian development connected to the center** — Qa5 supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure

### Packet scandinavian-black.line-022.ply-10.c8g4

- Move: `Bg4` / `c8g4` at ply 10

- CoachCard: **Keep Scandinavian development connected to the center** — Bg4 supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure

### Packet scandinavian-black.line-022.ply-12.b8c6

- Move: `Nc6` / `b8c6` at ply 12

- CoachCard: **Develop toward the central tension** — Nc6 develops into the Scandinavian central fight, adding pressure on d4 and e5 structures. Black develops behind the early ...d5 challenge.

- Plain hint: Bring the queenside knight into the fight over the central dark squares.

- Opening themes: central development, d4 pressure, Scandinavian tension


## scandinavian-black-line-023: 1. e4 d5 2. e5 c5 3. d4 e6 4. Nf3 Nc6 5. Bb5 Qb6 6. Bxc6+ bxc6

Runtime playKey: `e2e4,d7d5,e4e5,c7c5,d2d4,e7e6,g1f3,b8c6,f1b5,d8b6,b5c6,b7c6`  
Runtime totalGames field at line node: `304918`

### Packet scandinavian-black.line-023.ply-02.d7d5

- Move: `d5` / `d7d5` at ply 2

- CoachCard: **Challenge e4 immediately** — d5 is the Scandinavian’s signature central challenge. Black attacks White’s e-pawn immediately and asks White to resolve the center.

- Plain hint: Challenge the king pawn at once instead of building a slower pawn shell.

- Opening themes: immediate ...d5, e4 challenge, central tension

### Packet scandinavian-black.line-023.ply-04.c7c5

- Move: `c5` / `c7c5` at ply 4

- CoachCard: **Attack White’s advanced center from the side** — c5 challenges White’s advanced center from the side. In these Scandinavian Advance structures, Black pressures d4 instead of passively accepting White’s space.

- Plain hint: Use the c-pawn to pressure White’s central chain after the king pawn advances.

- Opening themes: Advance structure, ...c5 counterpressure, d4 target

### Packet scandinavian-black.line-023.ply-06.e7e6

- Move: `e6` / `e7e6` at ply 6

- CoachCard: **Support the Scandinavian central fight** — e6 supports Black’s central structure after the Scandinavian challenge. It helps Black pressure White’s advanced or exchanged center without overextending.

- Plain hint: Build a solid support pawn behind the central challenge.

- Opening themes: central support, Scandinavian-French structure, solid development

### Packet scandinavian-black.line-023.ply-08.b8c6

- Move: `Nc6` / `b8c6` at ply 8

- CoachCard: **Develop toward the central tension** — Nc6 develops into the Scandinavian central fight, adding pressure on d4 and e5 structures. Black develops behind the early ...d5 challenge.

- Plain hint: Bring the queenside knight into the fight over the central dark squares.

- Opening themes: central development, d4 pressure, Scandinavian tension

### Packet scandinavian-black.line-023.ply-10.d8b6

- Move: `Qb6` / `d8b6` at ply 10

- CoachCard: **Pressure the b2/d4 complex** — Qb6 targets b2 and d4 from an active Scandinavian queen square. The point is pressure on White’s center, not a loose queen adventure.

- Plain hint: Use the queen to pressure the queenside and central pawns only when the center supports it.

- Opening themes: queen pressure, d4 target, queenside pressure

### Packet scandinavian-black.line-023.ply-12.b7c6

- Move: `bxc6` / `b7c6` at ply 12

- CoachCard: **Keep Scandinavian development connected to the center** — bxc6 supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure


## scandinavian-black-line-024: 1. e4 d5 2. e5 c5 3. d4 Nc6 4. c3 cxd4 5. cxd4 Bf5 6. Nf3 e6

Runtime playKey: `e2e4,d7d5,e4e5,c7c5,d2d4,b8c6,c2c3,c5d4,c3d4,c8f5,g1f3,e7e6`  
Runtime totalGames field at line node: `294293`

### Packet scandinavian-black.line-024.ply-02.d7d5

- Move: `d5` / `d7d5` at ply 2

- CoachCard: **Challenge e4 immediately** — d5 is the Scandinavian’s signature central challenge. Black attacks White’s e-pawn immediately and asks White to resolve the center.

- Plain hint: Challenge the king pawn at once instead of building a slower pawn shell.

- Opening themes: immediate ...d5, e4 challenge, central tension

### Packet scandinavian-black.line-024.ply-04.c7c5

- Move: `c5` / `c7c5` at ply 4

- CoachCard: **Attack White’s advanced center from the side** — c5 challenges White’s advanced center from the side. In these Scandinavian Advance structures, Black pressures d4 instead of passively accepting White’s space.

- Plain hint: Use the c-pawn to pressure White’s central chain after the king pawn advances.

- Opening themes: Advance structure, ...c5 counterpressure, d4 target

### Packet scandinavian-black.line-024.ply-06.b8c6

- Move: `Nc6` / `b8c6` at ply 6

- CoachCard: **Develop toward the central tension** — Nc6 develops into the Scandinavian central fight, adding pressure on d4 and e5 structures. Black develops behind the early ...d5 challenge.

- Plain hint: Bring the queenside knight into the fight over the central dark squares.

- Opening themes: central development, d4 pressure, Scandinavian tension

### Packet scandinavian-black.line-024.ply-08.c5d4

- Move: `cxd4` / `c5d4` at ply 8

- CoachCard: **Keep Scandinavian development connected to the center** — cxd4 supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure

### Packet scandinavian-black.line-024.ply-10.c8f5

- Move: `Bf5` / `c8f5` at ply 10

- CoachCard: **Develop the bishop before the structure closes** — Bf5 develops the light-square bishop before Black’s pawn structure restricts it. This supports Scandinavian development after the early central challenge.

- Plain hint: Bring the bishop out while it can still influence the central fight.

- Opening themes: bishop activity, central support, Scandinavian development

### Packet scandinavian-black.line-024.ply-12.e7e6

- Move: `e6` / `e7e6` at ply 12

- CoachCard: **Support the Scandinavian central fight** — e6 supports Black’s central structure after the Scandinavian challenge. It helps Black pressure White’s advanced or exchanged center without overextending.

- Plain hint: Build a solid support pawn behind the central challenge.

- Opening themes: central support, Scandinavian-French structure, solid development


## scandinavian-black-line-025: 1. e4 d5 2. e5 c5 3. d4 e6 4. c3 Nc6 5. Bb5 Bd7 6. Bxc6 Bxc6

Runtime playKey: `e2e4,d7d5,e4e5,c7c5,d2d4,e7e6,c2c3,b8c6,f1b5,c8d7,b5c6,d7c6`  
Runtime totalGames field at line node: `283706`

### Packet scandinavian-black.line-025.ply-02.d7d5

- Move: `d5` / `d7d5` at ply 2

- CoachCard: **Challenge e4 immediately** — d5 is the Scandinavian’s signature central challenge. Black attacks White’s e-pawn immediately and asks White to resolve the center.

- Plain hint: Challenge the king pawn at once instead of building a slower pawn shell.

- Opening themes: immediate ...d5, e4 challenge, central tension

### Packet scandinavian-black.line-025.ply-04.c7c5

- Move: `c5` / `c7c5` at ply 4

- CoachCard: **Attack White’s advanced center from the side** — c5 challenges White’s advanced center from the side. In these Scandinavian Advance structures, Black pressures d4 instead of passively accepting White’s space.

- Plain hint: Use the c-pawn to pressure White’s central chain after the king pawn advances.

- Opening themes: Advance structure, ...c5 counterpressure, d4 target

### Packet scandinavian-black.line-025.ply-06.e7e6

- Move: `e6` / `e7e6` at ply 6

- CoachCard: **Support the Scandinavian central fight** — e6 supports Black’s central structure after the Scandinavian challenge. It helps Black pressure White’s advanced or exchanged center without overextending.

- Plain hint: Build a solid support pawn behind the central challenge.

- Opening themes: central support, Scandinavian-French structure, solid development

### Packet scandinavian-black.line-025.ply-08.b8c6

- Move: `Nc6` / `b8c6` at ply 8

- CoachCard: **Develop toward the central tension** — Nc6 develops into the Scandinavian central fight, adding pressure on d4 and e5 structures. Black develops behind the early ...d5 challenge.

- Plain hint: Bring the queenside knight into the fight over the central dark squares.

- Opening themes: central development, d4 pressure, Scandinavian tension

### Packet scandinavian-black.line-025.ply-10.c8d7

- Move: `Bd7` / `c8d7` at ply 10

- CoachCard: **Develop the bishop behind the central challenge** — Bd7 develops the bishop and connects Black’s queenside pieces in a Scandinavian Advance structure. It also prepares smoother rook and queen coordination.

- Plain hint: Place the bishop where it supports development without weakening the central setup.

- Opening themes: bishop development, central stability, piece coordination

### Packet scandinavian-black.line-025.ply-12.d7c6

- Move: `Bxc6` / `d7c6` at ply 12

- CoachCard: **Keep Scandinavian development connected to the center** — Bxc6 supports the Scandinavian plan of challenging e4 first and then developing coherently behind that central contact.

- Plain hint: Develop behind the early central challenge and keep pressure on White’s pawns.

- Opening themes: Scandinavian center, development, pawn pressure
