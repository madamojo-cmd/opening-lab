# French Defense approved-content candidates — Batch 2

Opening ID: `french-black`  
Status: approved candidates only; not app-activated.


## french-black-line-001: 1. e4 e6 2. Nf3 d5 3. e5 c5 4. c3 Nc6 5. d4 Bd7 6. Bd3 Qb6

Runtime playKey: `e2e4,e7e6,g1f3,d7d5,e4e5,c7c5,c2c3,b8c6,d2d4,c8d7,f1d3,d8b6`  
Runtime totalGames field at line node: `1398417`

### Packet french-black.line-001.ply-02.e7e6

- Move: `e6` / `e7e6` at ply 2

- CoachCard: **Prepare the French central challenge** — e6 is the French Defense foundation: Black prepares ...d5 against White’s e-pawn. The move creates a solid center but can make the light-square bishop harder to activate.

- Plain hint: Prepare a central pawn challenge while accepting a more compact light-square bishop.

- Opening themes: ...e6 foundation, ...d5 preparation, bishop problem

### Packet french-black.line-001.ply-04.d7d5

- Move: `d5` / `d7d5` at ply 4

- CoachCard: **Challenge e4 with the French center** — d5 completes the basic French plan by attacking White’s e-pawn. Black creates central tension that may become an exchange, advance, or locked pawn chain.

- Plain hint: Challenge White’s king pawn with the prepared queen-pawn strike.

- Opening themes: ...d5 challenge, e4 tension, French center

### Packet french-black.line-001.ply-06.c7c5

- Move: `c5` / `c7c5` at ply 6

- CoachCard: **Strike at White’s pawn chain** — c5 is the French counterattack against White’s center, especially when White advances the e-pawn. Black pressures d4 and challenges the pawn chain.

- Plain hint: Attack White’s central chain from the side instead of passively accepting space.

- Opening themes: ...c5 counterplay, pawn-chain pressure, d4 target

### Packet french-black.line-001.ply-08.b8c6

- Move: `Nc6` / `b8c6` at ply 8

- CoachCard: **Add pressure to the French center** — Nc6 develops into the French central fight and adds pressure on d4/e5 structures. Black supports counterplay rather than defending passively.

- Plain hint: Develop the queenside knight to increase pressure on White’s central pawns.

- Opening themes: central pressure, French development, pawn-chain pressure

### Packet french-black.line-001.ply-10.c8d7

- Move: `Bd7` / `c8d7` at ply 10

- CoachCard: **Develop while supporting the French center** — Bd7 develops the bishop behind the French center and connects queenside coordination. It is useful in Advance-style structures where Black pressures d4.

- Plain hint: Place the bishop where it helps coordination behind the central pawn chain.

- Opening themes: bishop development, Advance French structure, d4 pressure

### Packet french-black.line-001.ply-12.d8b6

- Move: `Qb6` / `d8b6` at ply 12

- CoachCard: **Pressure d4 and b2** — Qb6 attacks b2 and d4 in French Advance-type structures. The queen move is justified by concrete pressure on White’s pawn chain.

- Plain hint: Use the queen to pressure real targets created by the French pawn chain.

- Opening themes: Qb6 pressure, d4 target, pawn-chain attack


## french-black-line-002: 1. e4 e6 2. d4 d5 3. Nc3 Nf6 4. e5 Nfd7 5. f4 c5 6. Nf3 Nc6

Runtime playKey: `e2e4,e7e6,d2d4,d7d5,b1c3,g8f6,e4e5,f6d7,f2f4,c7c5,g1f3,b8c6`  
Runtime totalGames field at line node: `1228698`

### Packet french-black.line-002.ply-02.e7e6

- Move: `e6` / `e7e6` at ply 2

- CoachCard: **Prepare the French central challenge** — e6 is the French Defense foundation: Black prepares ...d5 against White’s e-pawn. The move creates a solid center but can make the light-square bishop harder to activate.

- Plain hint: Prepare a central pawn challenge while accepting a more compact light-square bishop.

- Opening themes: ...e6 foundation, ...d5 preparation, bishop problem

### Packet french-black.line-002.ply-04.d7d5

- Move: `d5` / `d7d5` at ply 4

- CoachCard: **Challenge e4 with the French center** — d5 completes the basic French plan by attacking White’s e-pawn. Black creates central tension that may become an exchange, advance, or locked pawn chain.

- Plain hint: Challenge White’s king pawn with the prepared queen-pawn strike.

- Opening themes: ...d5 challenge, e4 tension, French center

### Packet french-black.line-002.ply-06.g8f6

- Move: `Nf6` / `g8f6` at ply 6

- CoachCard: **Pressure the advanced center** — Nf6 develops a knight to pressure White’s central structure and brings Black closer to castling. In French lines, piece pressure must support the pawn breaks.

- Plain hint: Bring the kingside knight into the central fight and prepare castling.

- Opening themes: ...Nf6 pressure, king safety, central support

### Packet french-black.line-002.ply-08.f6d7

- Move: `Nfd7` / `f6d7` at ply 8

- CoachCard: **Keep French counterplay aimed at the center** — Nfd7 supports the French plan of ...e6/...d5 central tension and counterplay against White’s center. It stays tied to structure rather than generic development.

- Plain hint: Build the e-pawn and queen-pawn center, then pressure White’s pawn chain.

- Opening themes: French structure, central tension, counterplay

### Packet french-black.line-002.ply-10.c7c5

- Move: `c5` / `c7c5` at ply 10

- CoachCard: **Strike at White’s pawn chain** — c5 is the French counterattack against White’s center, especially when White advances the e-pawn. Black pressures d4 and challenges the pawn chain.

- Plain hint: Attack White’s central chain from the side instead of passively accepting space.

- Opening themes: ...c5 counterplay, pawn-chain pressure, d4 target

### Packet french-black.line-002.ply-12.b8c6

- Move: `Nc6` / `b8c6` at ply 12

- CoachCard: **Add pressure to the French center** — Nc6 develops into the French central fight and adds pressure on d4/e5 structures. Black supports counterplay rather than defending passively.

- Plain hint: Develop the queenside knight to increase pressure on White’s central pawns.

- Opening themes: central pressure, French development, pawn-chain pressure


## french-black-line-003: 1. e4 e6 2. Nf3 d5 3. e5 c5 4. c3 Nc6 5. d4 Qb6 6. Bd3 cxd4

Runtime playKey: `e2e4,e7e6,g1f3,d7d5,e4e5,c7c5,c2c3,b8c6,d2d4,d8b6,f1d3,c5d4`  
Runtime totalGames field at line node: `764680`

### Packet french-black.line-003.ply-02.e7e6

- Move: `e6` / `e7e6` at ply 2

- CoachCard: **Prepare the French central challenge** — e6 is the French Defense foundation: Black prepares ...d5 against White’s e-pawn. The move creates a solid center but can make the light-square bishop harder to activate.

- Plain hint: Prepare a central pawn challenge while accepting a more compact light-square bishop.

- Opening themes: ...e6 foundation, ...d5 preparation, bishop problem

### Packet french-black.line-003.ply-04.d7d5

- Move: `d5` / `d7d5` at ply 4

- CoachCard: **Challenge e4 with the French center** — d5 completes the basic French plan by attacking White’s e-pawn. Black creates central tension that may become an exchange, advance, or locked pawn chain.

- Plain hint: Challenge White’s king pawn with the prepared queen-pawn strike.

- Opening themes: ...d5 challenge, e4 tension, French center

### Packet french-black.line-003.ply-06.c7c5

- Move: `c5` / `c7c5` at ply 6

- CoachCard: **Strike at White’s pawn chain** — c5 is the French counterattack against White’s center, especially when White advances the e-pawn. Black pressures d4 and challenges the pawn chain.

- Plain hint: Attack White’s central chain from the side instead of passively accepting space.

- Opening themes: ...c5 counterplay, pawn-chain pressure, d4 target

### Packet french-black.line-003.ply-08.b8c6

- Move: `Nc6` / `b8c6` at ply 8

- CoachCard: **Add pressure to the French center** — Nc6 develops into the French central fight and adds pressure on d4/e5 structures. Black supports counterplay rather than defending passively.

- Plain hint: Develop the queenside knight to increase pressure on White’s central pawns.

- Opening themes: central pressure, French development, pawn-chain pressure

### Packet french-black.line-003.ply-10.d8b6

- Move: `Qb6` / `d8b6` at ply 10

- CoachCard: **Pressure d4 and b2** — Qb6 attacks b2 and d4 in French Advance-type structures. The queen move is justified by concrete pressure on White’s pawn chain.

- Plain hint: Use the queen to pressure real targets created by the French pawn chain.

- Opening themes: Qb6 pressure, d4 target, pawn-chain attack

### Packet french-black.line-003.ply-12.c5d4

- Move: `cxd4` / `c5d4` at ply 12

- CoachCard: **Keep French counterplay aimed at the center** — cxd4 supports the French plan of ...e6/...d5 central tension and counterplay against White’s center. It stays tied to structure rather than generic development.

- Plain hint: Build the e-pawn and queen-pawn center, then pressure White’s pawn chain.

- Opening themes: French structure, central tension, counterplay


## french-black-line-004: 1. e4 e6 2. Nf3 d5 3. exd5 exd5 4. d4 Nf6 5. Nc3 Bd6 6. Bg5 c6

Runtime playKey: `e2e4,e7e6,g1f3,d7d5,e4d5,e6d5,d2d4,g8f6,b1c3,f8d6,c1g5,c7c6`  
Runtime totalGames field at line node: `748721`

### Packet french-black.line-004.ply-02.e7e6

- Move: `e6` / `e7e6` at ply 2

- CoachCard: **Prepare the French central challenge** — e6 is the French Defense foundation: Black prepares ...d5 against White’s e-pawn. The move creates a solid center but can make the light-square bishop harder to activate.

- Plain hint: Prepare a central pawn challenge while accepting a more compact light-square bishop.

- Opening themes: ...e6 foundation, ...d5 preparation, bishop problem

### Packet french-black.line-004.ply-04.d7d5

- Move: `d5` / `d7d5` at ply 4

- CoachCard: **Challenge e4 with the French center** — d5 completes the basic French plan by attacking White’s e-pawn. Black creates central tension that may become an exchange, advance, or locked pawn chain.

- Plain hint: Challenge White’s king pawn with the prepared queen-pawn strike.

- Opening themes: ...d5 challenge, e4 tension, French center

### Packet french-black.line-004.ply-06.e6d5

- Move: `exd5` / `e6d5` at ply 6

- CoachCard: **Accept the Exchange French structure** — exd5 recaptures in the Exchange French structure. Black keeps a solid center and shifts the game toward development and piece activity.

- Plain hint: Recapture in the center and settle into a symmetrical but solid pawn structure.

- Opening themes: Exchange French, central recapture, solid structure

### Packet french-black.line-004.ply-08.g8f6

- Move: `Nf6` / `g8f6` at ply 8

- CoachCard: **Pressure the advanced center** — Nf6 develops a knight to pressure White’s central structure and brings Black closer to castling. In French lines, piece pressure must support the pawn breaks.

- Plain hint: Bring the kingside knight into the central fight and prepare castling.

- Opening themes: ...Nf6 pressure, king safety, central support

### Packet french-black.line-004.ply-10.f8d6

- Move: `Bd6` / `f8d6` at ply 10

- CoachCard: **Place the bishop on an active French diagonal** — Bd6 develops the bishop to an active diagonal in the French structure. It supports castling and can pressure the kingside once the center is stable.

- Plain hint: Use the dark-square bishop to support development and kingside coordination.

- Opening themes: dark-square bishop, king safety, French piece activity

### Packet french-black.line-004.ply-12.c7c6

- Move: `c6` / `c7c6` at ply 12

- CoachCard: **Keep French counterplay aimed at the center** — c6 supports the French plan of ...e6/...d5 central tension and counterplay against White’s center. It stays tied to structure rather than generic development.

- Plain hint: Build the e-pawn and queen-pawn center, then pressure White’s pawn chain.

- Opening themes: French structure, central tension, counterplay


## french-black-line-005: 1. e4 e6 2. d4 d5 3. Nc3 Nf6 4. Bg5 Be7 5. e5 Nfd7 6. Bxe7 Qxe7

Runtime playKey: `e2e4,e7e6,d2d4,d7d5,b1c3,g8f6,c1g5,f8e7,e4e5,f6d7,g5e7,d8e7`  
Runtime totalGames field at line node: `676714`

### Packet french-black.line-005.ply-02.e7e6

- Move: `e6` / `e7e6` at ply 2

- CoachCard: **Prepare the French central challenge** — e6 is the French Defense foundation: Black prepares ...d5 against White’s e-pawn. The move creates a solid center but can make the light-square bishop harder to activate.

- Plain hint: Prepare a central pawn challenge while accepting a more compact light-square bishop.

- Opening themes: ...e6 foundation, ...d5 preparation, bishop problem

### Packet french-black.line-005.ply-04.d7d5

- Move: `d5` / `d7d5` at ply 4

- CoachCard: **Challenge e4 with the French center** — d5 completes the basic French plan by attacking White’s e-pawn. Black creates central tension that may become an exchange, advance, or locked pawn chain.

- Plain hint: Challenge White’s king pawn with the prepared queen-pawn strike.

- Opening themes: ...d5 challenge, e4 tension, French center

### Packet french-black.line-005.ply-06.g8f6

- Move: `Nf6` / `g8f6` at ply 6

- CoachCard: **Pressure the advanced center** — Nf6 develops a knight to pressure White’s central structure and brings Black closer to castling. In French lines, piece pressure must support the pawn breaks.

- Plain hint: Bring the kingside knight into the central fight and prepare castling.

- Opening themes: ...Nf6 pressure, king safety, central support

### Packet french-black.line-005.ply-08.f8e7

- Move: `Be7` / `f8e7` at ply 8

- CoachCard: **Keep French counterplay aimed at the center** — Be7 supports the French plan of ...e6/...d5 central tension and counterplay against White’s center. It stays tied to structure rather than generic development.

- Plain hint: Build the e-pawn and queen-pawn center, then pressure White’s pawn chain.

- Opening themes: French structure, central tension, counterplay

### Packet french-black.line-005.ply-10.f6d7

- Move: `Nfd7` / `f6d7` at ply 10

- CoachCard: **Keep French counterplay aimed at the center** — Nfd7 supports the French plan of ...e6/...d5 central tension and counterplay against White’s center. It stays tied to structure rather than generic development.

- Plain hint: Build the e-pawn and queen-pawn center, then pressure White’s pawn chain.

- Opening themes: French structure, central tension, counterplay

### Packet french-black.line-005.ply-12.d8e7

- Move: `Qxe7` / `d8e7` at ply 12

- CoachCard: **Keep French counterplay aimed at the center** — Qxe7 supports the French plan of ...e6/...d5 central tension and counterplay against White’s center. It stays tied to structure rather than generic development.

- Plain hint: Build the e-pawn and queen-pawn center, then pressure White’s pawn chain.

- Opening themes: French structure, central tension, counterplay


## french-black-line-006: 1. e4 e6 2. Nf3 d5 3. e5 c5 4. c3 Nc6 5. d4 Qb6 6. Be2 cxd4

Runtime playKey: `e2e4,e7e6,g1f3,d7d5,e4e5,c7c5,c2c3,b8c6,d2d4,d8b6,f1e2,c5d4`  
Runtime totalGames field at line node: `565199`

### Packet french-black.line-006.ply-02.e7e6

- Move: `e6` / `e7e6` at ply 2

- CoachCard: **Prepare the French central challenge** — e6 is the French Defense foundation: Black prepares ...d5 against White’s e-pawn. The move creates a solid center but can make the light-square bishop harder to activate.

- Plain hint: Prepare a central pawn challenge while accepting a more compact light-square bishop.

- Opening themes: ...e6 foundation, ...d5 preparation, bishop problem

### Packet french-black.line-006.ply-04.d7d5

- Move: `d5` / `d7d5` at ply 4

- CoachCard: **Challenge e4 with the French center** — d5 completes the basic French plan by attacking White’s e-pawn. Black creates central tension that may become an exchange, advance, or locked pawn chain.

- Plain hint: Challenge White’s king pawn with the prepared queen-pawn strike.

- Opening themes: ...d5 challenge, e4 tension, French center

### Packet french-black.line-006.ply-06.c7c5

- Move: `c5` / `c7c5` at ply 6

- CoachCard: **Strike at White’s pawn chain** — c5 is the French counterattack against White’s center, especially when White advances the e-pawn. Black pressures d4 and challenges the pawn chain.

- Plain hint: Attack White’s central chain from the side instead of passively accepting space.

- Opening themes: ...c5 counterplay, pawn-chain pressure, d4 target

### Packet french-black.line-006.ply-08.b8c6

- Move: `Nc6` / `b8c6` at ply 8

- CoachCard: **Add pressure to the French center** — Nc6 develops into the French central fight and adds pressure on d4/e5 structures. Black supports counterplay rather than defending passively.

- Plain hint: Develop the queenside knight to increase pressure on White’s central pawns.

- Opening themes: central pressure, French development, pawn-chain pressure

### Packet french-black.line-006.ply-10.d8b6

- Move: `Qb6` / `d8b6` at ply 10

- CoachCard: **Pressure d4 and b2** — Qb6 attacks b2 and d4 in French Advance-type structures. The queen move is justified by concrete pressure on White’s pawn chain.

- Plain hint: Use the queen to pressure real targets created by the French pawn chain.

- Opening themes: Qb6 pressure, d4 target, pawn-chain attack

### Packet french-black.line-006.ply-12.c5d4

- Move: `cxd4` / `c5d4` at ply 12

- CoachCard: **Keep French counterplay aimed at the center** — cxd4 supports the French plan of ...e6/...d5 central tension and counterplay against White’s center. It stays tied to structure rather than generic development.

- Plain hint: Build the e-pawn and queen-pawn center, then pressure White’s pawn chain.

- Opening themes: French structure, central tension, counterplay


## french-black-line-007: 1. e4 e6 2. Nf3 d5 3. e5 c5 4. c3 Nc6 5. d4 Bd7 6. Be2 Qb6

Runtime playKey: `e2e4,e7e6,g1f3,d7d5,e4e5,c7c5,c2c3,b8c6,d2d4,c8d7,f1e2,d8b6`  
Runtime totalGames field at line node: `545338`

### Packet french-black.line-007.ply-02.e7e6

- Move: `e6` / `e7e6` at ply 2

- CoachCard: **Prepare the French central challenge** — e6 is the French Defense foundation: Black prepares ...d5 against White’s e-pawn. The move creates a solid center but can make the light-square bishop harder to activate.

- Plain hint: Prepare a central pawn challenge while accepting a more compact light-square bishop.

- Opening themes: ...e6 foundation, ...d5 preparation, bishop problem

### Packet french-black.line-007.ply-04.d7d5

- Move: `d5` / `d7d5` at ply 4

- CoachCard: **Challenge e4 with the French center** — d5 completes the basic French plan by attacking White’s e-pawn. Black creates central tension that may become an exchange, advance, or locked pawn chain.

- Plain hint: Challenge White’s king pawn with the prepared queen-pawn strike.

- Opening themes: ...d5 challenge, e4 tension, French center

### Packet french-black.line-007.ply-06.c7c5

- Move: `c5` / `c7c5` at ply 6

- CoachCard: **Strike at White’s pawn chain** — c5 is the French counterattack against White’s center, especially when White advances the e-pawn. Black pressures d4 and challenges the pawn chain.

- Plain hint: Attack White’s central chain from the side instead of passively accepting space.

- Opening themes: ...c5 counterplay, pawn-chain pressure, d4 target

### Packet french-black.line-007.ply-08.b8c6

- Move: `Nc6` / `b8c6` at ply 8

- CoachCard: **Add pressure to the French center** — Nc6 develops into the French central fight and adds pressure on d4/e5 structures. Black supports counterplay rather than defending passively.

- Plain hint: Develop the queenside knight to increase pressure on White’s central pawns.

- Opening themes: central pressure, French development, pawn-chain pressure

### Packet french-black.line-007.ply-10.c8d7

- Move: `Bd7` / `c8d7` at ply 10

- CoachCard: **Develop while supporting the French center** — Bd7 develops the bishop behind the French center and connects queenside coordination. It is useful in Advance-style structures where Black pressures d4.

- Plain hint: Place the bishop where it helps coordination behind the central pawn chain.

- Opening themes: bishop development, Advance French structure, d4 pressure

### Packet french-black.line-007.ply-12.d8b6

- Move: `Qb6` / `d8b6` at ply 12

- CoachCard: **Pressure d4 and b2** — Qb6 attacks b2 and d4 in French Advance-type structures. The queen move is justified by concrete pressure on White’s pawn chain.

- Plain hint: Use the queen to pressure real targets created by the French pawn chain.

- Opening themes: Qb6 pressure, d4 target, pawn-chain attack


## french-black-line-008: 1. e4 e6 2. d4 d5 3. Nc3 dxe4 4. Nxe4 Nf6 5. Bg5 Be7 6. Bxf6 Bxf6

Runtime playKey: `e2e4,e7e6,d2d4,d7d5,b1c3,d5e4,c3e4,g8f6,c1g5,f8e7,g5f6,e7f6`  
Runtime totalGames field at line node: `528585`

### Packet french-black.line-008.ply-02.e7e6

- Move: `e6` / `e7e6` at ply 2

- CoachCard: **Prepare the French central challenge** — e6 is the French Defense foundation: Black prepares ...d5 against White’s e-pawn. The move creates a solid center but can make the light-square bishop harder to activate.

- Plain hint: Prepare a central pawn challenge while accepting a more compact light-square bishop.

- Opening themes: ...e6 foundation, ...d5 preparation, bishop problem

### Packet french-black.line-008.ply-04.d7d5

- Move: `d5` / `d7d5` at ply 4

- CoachCard: **Challenge e4 with the French center** — d5 completes the basic French plan by attacking White’s e-pawn. Black creates central tension that may become an exchange, advance, or locked pawn chain.

- Plain hint: Challenge White’s king pawn with the prepared queen-pawn strike.

- Opening themes: ...d5 challenge, e4 tension, French center

### Packet french-black.line-008.ply-06.d5e4

- Move: `dxe4` / `d5e4` at ply 6

- CoachCard: **Keep French counterplay aimed at the center** — dxe4 supports the French plan of ...e6/...d5 central tension and counterplay against White’s center. It stays tied to structure rather than generic development.

- Plain hint: Build the e-pawn and queen-pawn center, then pressure White’s pawn chain.

- Opening themes: French structure, central tension, counterplay

### Packet french-black.line-008.ply-08.g8f6

- Move: `Nf6` / `g8f6` at ply 8

- CoachCard: **Pressure the advanced center** — Nf6 develops a knight to pressure White’s central structure and brings Black closer to castling. In French lines, piece pressure must support the pawn breaks.

- Plain hint: Bring the kingside knight into the central fight and prepare castling.

- Opening themes: ...Nf6 pressure, king safety, central support

### Packet french-black.line-008.ply-10.f8e7

- Move: `Be7` / `f8e7` at ply 10

- CoachCard: **Keep French counterplay aimed at the center** — Be7 supports the French plan of ...e6/...d5 central tension and counterplay against White’s center. It stays tied to structure rather than generic development.

- Plain hint: Build the e-pawn and queen-pawn center, then pressure White’s pawn chain.

- Opening themes: French structure, central tension, counterplay

### Packet french-black.line-008.ply-12.e7f6

- Move: `Bxf6` / `e7f6` at ply 12

- CoachCard: **Keep French counterplay aimed at the center** — Bxf6 supports the French plan of ...e6/...d5 central tension and counterplay against White’s center. It stays tied to structure rather than generic development.

- Plain hint: Build the e-pawn and queen-pawn center, then pressure White’s pawn chain.

- Opening themes: French structure, central tension, counterplay


## french-black-line-009: 1. e4 e6 2. d4 d5 3. Nc3 Bb4 4. e5 Ne7 5. a3 Bxc3+ 6. bxc3 c5

Runtime playKey: `e2e4,e7e6,d2d4,d7d5,b1c3,f8b4,e4e5,g8e7,a2a3,b4c3,b2c3,c7c5`  
Runtime totalGames field at line node: `513690`

### Packet french-black.line-009.ply-02.e7e6

- Move: `e6` / `e7e6` at ply 2

- CoachCard: **Prepare the French central challenge** — e6 is the French Defense foundation: Black prepares ...d5 against White’s e-pawn. The move creates a solid center but can make the light-square bishop harder to activate.

- Plain hint: Prepare a central pawn challenge while accepting a more compact light-square bishop.

- Opening themes: ...e6 foundation, ...d5 preparation, bishop problem

### Packet french-black.line-009.ply-04.d7d5

- Move: `d5` / `d7d5` at ply 4

- CoachCard: **Challenge e4 with the French center** — d5 completes the basic French plan by attacking White’s e-pawn. Black creates central tension that may become an exchange, advance, or locked pawn chain.

- Plain hint: Challenge White’s king pawn with the prepared queen-pawn strike.

- Opening themes: ...d5 challenge, e4 tension, French center

### Packet french-black.line-009.ply-06.f8b4

- Move: `Bb4` / `f8b4` at ply 6

- CoachCard: **Keep French counterplay aimed at the center** — Bb4 supports the French plan of ...e6/...d5 central tension and counterplay against White’s center. It stays tied to structure rather than generic development.

- Plain hint: Build the e-pawn and queen-pawn center, then pressure White’s pawn chain.

- Opening themes: French structure, central tension, counterplay

### Packet french-black.line-009.ply-08.g8e7

- Move: `Ne7` / `g8e7` at ply 8

- CoachCard: **Keep French counterplay aimed at the center** — Ne7 supports the French plan of ...e6/...d5 central tension and counterplay against White’s center. It stays tied to structure rather than generic development.

- Plain hint: Build the e-pawn and queen-pawn center, then pressure White’s pawn chain.

- Opening themes: French structure, central tension, counterplay

### Packet french-black.line-009.ply-10.b4c3

- Move: `Bxc3+` / `b4c3` at ply 10

- CoachCard: **Keep French counterplay aimed at the center** — Bxc3+ supports the French plan of ...e6/...d5 central tension and counterplay against White’s center. It stays tied to structure rather than generic development.

- Plain hint: Build the e-pawn and queen-pawn center, then pressure White’s pawn chain.

- Opening themes: French structure, central tension, counterplay

### Packet french-black.line-009.ply-12.c7c5

- Move: `c5` / `c7c5` at ply 12

- CoachCard: **Strike at White’s pawn chain** — c5 is the French counterattack against White’s center, especially when White advances the e-pawn. Black pressures d4 and challenges the pawn chain.

- Plain hint: Attack White’s central chain from the side instead of passively accepting space.

- Opening themes: ...c5 counterplay, pawn-chain pressure, d4 target


## french-black-line-010: 1. e4 e6 2. d4 d5 3. e5 c5 4. c3 Nc6 5. Bb5 Qb6 6. Bxc6+ bxc6

Runtime playKey: `e2e4,e7e6,d2d4,d7d5,e4e5,c7c5,c2c3,b8c6,f1b5,d8b6,b5c6,b7c6`  
Runtime totalGames field at line node: `418345`

### Packet french-black.line-010.ply-02.e7e6

- Move: `e6` / `e7e6` at ply 2

- CoachCard: **Prepare the French central challenge** — e6 is the French Defense foundation: Black prepares ...d5 against White’s e-pawn. The move creates a solid center but can make the light-square bishop harder to activate.

- Plain hint: Prepare a central pawn challenge while accepting a more compact light-square bishop.

- Opening themes: ...e6 foundation, ...d5 preparation, bishop problem

### Packet french-black.line-010.ply-04.d7d5

- Move: `d5` / `d7d5` at ply 4

- CoachCard: **Challenge e4 with the French center** — d5 completes the basic French plan by attacking White’s e-pawn. Black creates central tension that may become an exchange, advance, or locked pawn chain.

- Plain hint: Challenge White’s king pawn with the prepared queen-pawn strike.

- Opening themes: ...d5 challenge, e4 tension, French center

### Packet french-black.line-010.ply-06.c7c5

- Move: `c5` / `c7c5` at ply 6

- CoachCard: **Strike at White’s pawn chain** — c5 is the French counterattack against White’s center, especially when White advances the e-pawn. Black pressures d4 and challenges the pawn chain.

- Plain hint: Attack White’s central chain from the side instead of passively accepting space.

- Opening themes: ...c5 counterplay, pawn-chain pressure, d4 target

### Packet french-black.line-010.ply-08.b8c6

- Move: `Nc6` / `b8c6` at ply 8

- CoachCard: **Add pressure to the French center** — Nc6 develops into the French central fight and adds pressure on d4/e5 structures. Black supports counterplay rather than defending passively.

- Plain hint: Develop the queenside knight to increase pressure on White’s central pawns.

- Opening themes: central pressure, French development, pawn-chain pressure

### Packet french-black.line-010.ply-10.d8b6

- Move: `Qb6` / `d8b6` at ply 10

- CoachCard: **Pressure d4 and b2** — Qb6 attacks b2 and d4 in French Advance-type structures. The queen move is justified by concrete pressure on White’s pawn chain.

- Plain hint: Use the queen to pressure real targets created by the French pawn chain.

- Opening themes: Qb6 pressure, d4 target, pawn-chain attack

### Packet french-black.line-010.ply-12.b7c6

- Move: `bxc6` / `b7c6` at ply 12

- CoachCard: **Keep French counterplay aimed at the center** — bxc6 supports the French plan of ...e6/...d5 central tension and counterplay against White’s center. It stays tied to structure rather than generic development.

- Plain hint: Build the e-pawn and queen-pawn center, then pressure White’s pawn chain.

- Opening themes: French structure, central tension, counterplay


## french-black-line-011: 1. e4 e6 2. d4 d5 3. Nc3 dxe4 4. Nxe4 Nf6 5. Bg5 Be7 6. Nxf6+ Bxf6

Runtime playKey: `e2e4,e7e6,d2d4,d7d5,b1c3,d5e4,c3e4,g8f6,c1g5,f8e7,e4f6,e7f6`  
Runtime totalGames field at line node: `348830`

### Packet french-black.line-011.ply-02.e7e6

- Move: `e6` / `e7e6` at ply 2

- CoachCard: **Prepare the French central challenge** — e6 is the French Defense foundation: Black prepares ...d5 against White’s e-pawn. The move creates a solid center but can make the light-square bishop harder to activate.

- Plain hint: Prepare a central pawn challenge while accepting a more compact light-square bishop.

- Opening themes: ...e6 foundation, ...d5 preparation, bishop problem

### Packet french-black.line-011.ply-04.d7d5

- Move: `d5` / `d7d5` at ply 4

- CoachCard: **Challenge e4 with the French center** — d5 completes the basic French plan by attacking White’s e-pawn. Black creates central tension that may become an exchange, advance, or locked pawn chain.

- Plain hint: Challenge White’s king pawn with the prepared queen-pawn strike.

- Opening themes: ...d5 challenge, e4 tension, French center

### Packet french-black.line-011.ply-06.d5e4

- Move: `dxe4` / `d5e4` at ply 6

- CoachCard: **Keep French counterplay aimed at the center** — dxe4 supports the French plan of ...e6/...d5 central tension and counterplay against White’s center. It stays tied to structure rather than generic development.

- Plain hint: Build the e-pawn and queen-pawn center, then pressure White’s pawn chain.

- Opening themes: French structure, central tension, counterplay

### Packet french-black.line-011.ply-08.g8f6

- Move: `Nf6` / `g8f6` at ply 8

- CoachCard: **Pressure the advanced center** — Nf6 develops a knight to pressure White’s central structure and brings Black closer to castling. In French lines, piece pressure must support the pawn breaks.

- Plain hint: Bring the kingside knight into the central fight and prepare castling.

- Opening themes: ...Nf6 pressure, king safety, central support

### Packet french-black.line-011.ply-10.f8e7

- Move: `Be7` / `f8e7` at ply 10

- CoachCard: **Keep French counterplay aimed at the center** — Be7 supports the French plan of ...e6/...d5 central tension and counterplay against White’s center. It stays tied to structure rather than generic development.

- Plain hint: Build the e-pawn and queen-pawn center, then pressure White’s pawn chain.

- Opening themes: French structure, central tension, counterplay

### Packet french-black.line-011.ply-12.e7f6

- Move: `Bxf6` / `e7f6` at ply 12

- CoachCard: **Keep French counterplay aimed at the center** — Bxf6 supports the French plan of ...e6/...d5 central tension and counterplay against White’s center. It stays tied to structure rather than generic development.

- Plain hint: Build the e-pawn and queen-pawn center, then pressure White’s pawn chain.

- Opening themes: French structure, central tension, counterplay


## french-black-line-012: 1. e4 e6 2. d4 d5 3. exd5 exd5 4. Nc3 c6 5. Nf3 Nf6 6. Bg5 Be7

Runtime playKey: `e2e4,e7e6,d2d4,d7d5,e4d5,e6d5,b1c3,c7c6,g1f3,g8f6,c1g5,f8e7`  
Runtime totalGames field at line node: `342927`

### Packet french-black.line-012.ply-02.e7e6

- Move: `e6` / `e7e6` at ply 2

- CoachCard: **Prepare the French central challenge** — e6 is the French Defense foundation: Black prepares ...d5 against White’s e-pawn. The move creates a solid center but can make the light-square bishop harder to activate.

- Plain hint: Prepare a central pawn challenge while accepting a more compact light-square bishop.

- Opening themes: ...e6 foundation, ...d5 preparation, bishop problem

### Packet french-black.line-012.ply-04.d7d5

- Move: `d5` / `d7d5` at ply 4

- CoachCard: **Challenge e4 with the French center** — d5 completes the basic French plan by attacking White’s e-pawn. Black creates central tension that may become an exchange, advance, or locked pawn chain.

- Plain hint: Challenge White’s king pawn with the prepared queen-pawn strike.

- Opening themes: ...d5 challenge, e4 tension, French center

### Packet french-black.line-012.ply-06.e6d5

- Move: `exd5` / `e6d5` at ply 6

- CoachCard: **Accept the Exchange French structure** — exd5 recaptures in the Exchange French structure. Black keeps a solid center and shifts the game toward development and piece activity.

- Plain hint: Recapture in the center and settle into a symmetrical but solid pawn structure.

- Opening themes: Exchange French, central recapture, solid structure

### Packet french-black.line-012.ply-08.c7c6

- Move: `c6` / `c7c6` at ply 8

- CoachCard: **Keep French counterplay aimed at the center** — c6 supports the French plan of ...e6/...d5 central tension and counterplay against White’s center. It stays tied to structure rather than generic development.

- Plain hint: Build the e-pawn and queen-pawn center, then pressure White’s pawn chain.

- Opening themes: French structure, central tension, counterplay

### Packet french-black.line-012.ply-10.g8f6

- Move: `Nf6` / `g8f6` at ply 10

- CoachCard: **Pressure the advanced center** — Nf6 develops a knight to pressure White’s central structure and brings Black closer to castling. In French lines, piece pressure must support the pawn breaks.

- Plain hint: Bring the kingside knight into the central fight and prepare castling.

- Opening themes: ...Nf6 pressure, king safety, central support

### Packet french-black.line-012.ply-12.f8e7

- Move: `Be7` / `f8e7` at ply 12

- CoachCard: **Keep French counterplay aimed at the center** — Be7 supports the French plan of ...e6/...d5 central tension and counterplay against White’s center. It stays tied to structure rather than generic development.

- Plain hint: Build the e-pawn and queen-pawn center, then pressure White’s pawn chain.

- Opening themes: French structure, central tension, counterplay


## french-black-line-013: 1. e4 e6 2. d4 d5 3. Nc3 dxe4 4. Nxe4 Nd7 5. Nf3 Ngf6 6. Nxf6+ Nxf6

Runtime playKey: `e2e4,e7e6,d2d4,d7d5,b1c3,d5e4,c3e4,b8d7,g1f3,g8f6,e4f6,d7f6`  
Runtime totalGames field at line node: `323065`

### Packet french-black.line-013.ply-02.e7e6

- Move: `e6` / `e7e6` at ply 2

- CoachCard: **Prepare the French central challenge** — e6 is the French Defense foundation: Black prepares ...d5 against White’s e-pawn. The move creates a solid center but can make the light-square bishop harder to activate.

- Plain hint: Prepare a central pawn challenge while accepting a more compact light-square bishop.

- Opening themes: ...e6 foundation, ...d5 preparation, bishop problem

### Packet french-black.line-013.ply-04.d7d5

- Move: `d5` / `d7d5` at ply 4

- CoachCard: **Challenge e4 with the French center** — d5 completes the basic French plan by attacking White’s e-pawn. Black creates central tension that may become an exchange, advance, or locked pawn chain.

- Plain hint: Challenge White’s king pawn with the prepared queen-pawn strike.

- Opening themes: ...d5 challenge, e4 tension, French center

### Packet french-black.line-013.ply-06.d5e4

- Move: `dxe4` / `d5e4` at ply 6

- CoachCard: **Keep French counterplay aimed at the center** — dxe4 supports the French plan of ...e6/...d5 central tension and counterplay against White’s center. It stays tied to structure rather than generic development.

- Plain hint: Build the e-pawn and queen-pawn center, then pressure White’s pawn chain.

- Opening themes: French structure, central tension, counterplay

### Packet french-black.line-013.ply-08.b8d7

- Move: `Nd7` / `b8d7` at ply 8

- CoachCard: **Keep French counterplay aimed at the center** — Nd7 supports the French plan of ...e6/...d5 central tension and counterplay against White’s center. It stays tied to structure rather than generic development.

- Plain hint: Build the e-pawn and queen-pawn center, then pressure White’s pawn chain.

- Opening themes: French structure, central tension, counterplay

### Packet french-black.line-013.ply-10.g8f6

- Move: `Ngf6` / `g8f6` at ply 10

- CoachCard: **Pressure the advanced center** — Ngf6 develops a knight to pressure White’s central structure and brings Black closer to castling. In French lines, piece pressure must support the pawn breaks.

- Plain hint: Bring the kingside knight into the central fight and prepare castling.

- Opening themes: ...Nf6 pressure, king safety, central support

### Packet french-black.line-013.ply-12.d7f6

- Move: `Nxf6` / `d7f6` at ply 12

- CoachCard: **Keep French counterplay aimed at the center** — Nxf6 supports the French plan of ...e6/...d5 central tension and counterplay against White’s center. It stays tied to structure rather than generic development.

- Plain hint: Build the e-pawn and queen-pawn center, then pressure White’s pawn chain.

- Opening themes: French structure, central tension, counterplay


## french-black-line-014: 1. e4 e6 2. d4 d5 3. Nc3 dxe4 4. Nxe4 Nf6 5. Nxf6+ Qxf6 6. Nf3 h6

Runtime playKey: `e2e4,e7e6,d2d4,d7d5,b1c3,d5e4,c3e4,g8f6,e4f6,d8f6,g1f3,h7h6`  
Runtime totalGames field at line node: `316730`

### Packet french-black.line-014.ply-02.e7e6

- Move: `e6` / `e7e6` at ply 2

- CoachCard: **Prepare the French central challenge** — e6 is the French Defense foundation: Black prepares ...d5 against White’s e-pawn. The move creates a solid center but can make the light-square bishop harder to activate.

- Plain hint: Prepare a central pawn challenge while accepting a more compact light-square bishop.

- Opening themes: ...e6 foundation, ...d5 preparation, bishop problem

### Packet french-black.line-014.ply-04.d7d5

- Move: `d5` / `d7d5` at ply 4

- CoachCard: **Challenge e4 with the French center** — d5 completes the basic French plan by attacking White’s e-pawn. Black creates central tension that may become an exchange, advance, or locked pawn chain.

- Plain hint: Challenge White’s king pawn with the prepared queen-pawn strike.

- Opening themes: ...d5 challenge, e4 tension, French center

### Packet french-black.line-014.ply-06.d5e4

- Move: `dxe4` / `d5e4` at ply 6

- CoachCard: **Keep French counterplay aimed at the center** — dxe4 supports the French plan of ...e6/...d5 central tension and counterplay against White’s center. It stays tied to structure rather than generic development.

- Plain hint: Build the e-pawn and queen-pawn center, then pressure White’s pawn chain.

- Opening themes: French structure, central tension, counterplay

### Packet french-black.line-014.ply-08.g8f6

- Move: `Nf6` / `g8f6` at ply 8

- CoachCard: **Pressure the advanced center** — Nf6 develops a knight to pressure White’s central structure and brings Black closer to castling. In French lines, piece pressure must support the pawn breaks.

- Plain hint: Bring the kingside knight into the central fight and prepare castling.

- Opening themes: ...Nf6 pressure, king safety, central support

### Packet french-black.line-014.ply-10.d8f6

- Move: `Qxf6` / `d8f6` at ply 10

- CoachCard: **Keep French counterplay aimed at the center** — Qxf6 supports the French plan of ...e6/...d5 central tension and counterplay against White’s center. It stays tied to structure rather than generic development.

- Plain hint: Build the e-pawn and queen-pawn center, then pressure White’s pawn chain.

- Opening themes: French structure, central tension, counterplay

### Packet french-black.line-014.ply-12.h7h6

- Move: `h6` / `h7h6` at ply 12

- CoachCard: **Keep French counterplay aimed at the center** — h6 supports the French plan of ...e6/...d5 central tension and counterplay against White’s center. It stays tied to structure rather than generic development.

- Plain hint: Build the e-pawn and queen-pawn center, then pressure White’s pawn chain.

- Opening themes: French structure, central tension, counterplay


## french-black-line-015: 1. e4 e6 2. Nf3 d5 3. e5 c5 4. d4 Nc6 5. Bb5 Qb6 6. Bxc6+ bxc6

Runtime playKey: `e2e4,e7e6,g1f3,d7d5,e4e5,c7c5,d2d4,b8c6,f1b5,d8b6,b5c6,b7c6`  
Runtime totalGames field at line node: `304509`

### Packet french-black.line-015.ply-02.e7e6

- Move: `e6` / `e7e6` at ply 2

- CoachCard: **Prepare the French central challenge** — e6 is the French Defense foundation: Black prepares ...d5 against White’s e-pawn. The move creates a solid center but can make the light-square bishop harder to activate.

- Plain hint: Prepare a central pawn challenge while accepting a more compact light-square bishop.

- Opening themes: ...e6 foundation, ...d5 preparation, bishop problem

### Packet french-black.line-015.ply-04.d7d5

- Move: `d5` / `d7d5` at ply 4

- CoachCard: **Challenge e4 with the French center** — d5 completes the basic French plan by attacking White’s e-pawn. Black creates central tension that may become an exchange, advance, or locked pawn chain.

- Plain hint: Challenge White’s king pawn with the prepared queen-pawn strike.

- Opening themes: ...d5 challenge, e4 tension, French center

### Packet french-black.line-015.ply-06.c7c5

- Move: `c5` / `c7c5` at ply 6

- CoachCard: **Strike at White’s pawn chain** — c5 is the French counterattack against White’s center, especially when White advances the e-pawn. Black pressures d4 and challenges the pawn chain.

- Plain hint: Attack White’s central chain from the side instead of passively accepting space.

- Opening themes: ...c5 counterplay, pawn-chain pressure, d4 target

### Packet french-black.line-015.ply-08.b8c6

- Move: `Nc6` / `b8c6` at ply 8

- CoachCard: **Add pressure to the French center** — Nc6 develops into the French central fight and adds pressure on d4/e5 structures. Black supports counterplay rather than defending passively.

- Plain hint: Develop the queenside knight to increase pressure on White’s central pawns.

- Opening themes: central pressure, French development, pawn-chain pressure

### Packet french-black.line-015.ply-10.d8b6

- Move: `Qb6` / `d8b6` at ply 10

- CoachCard: **Pressure d4 and b2** — Qb6 attacks b2 and d4 in French Advance-type structures. The queen move is justified by concrete pressure on White’s pawn chain.

- Plain hint: Use the queen to pressure real targets created by the French pawn chain.

- Opening themes: Qb6 pressure, d4 target, pawn-chain attack

### Packet french-black.line-015.ply-12.b7c6

- Move: `bxc6` / `b7c6` at ply 12

- CoachCard: **Keep French counterplay aimed at the center** — bxc6 supports the French plan of ...e6/...d5 central tension and counterplay against White’s center. It stays tied to structure rather than generic development.

- Plain hint: Build the e-pawn and queen-pawn center, then pressure White’s pawn chain.

- Opening themes: French structure, central tension, counterplay


## french-black-line-016: 1. e4 e6 2. d4 d5 3. Nc3 dxe4 4. Nxe4 Nd7 5. Bd3 Ngf6 6. Nf3 Be7

Runtime playKey: `e2e4,e7e6,d2d4,d7d5,b1c3,d5e4,c3e4,b8d7,f1d3,g8f6,g1f3,f8e7`  
Runtime totalGames field at line node: `301013`

### Packet french-black.line-016.ply-02.e7e6

- Move: `e6` / `e7e6` at ply 2

- CoachCard: **Prepare the French central challenge** — e6 is the French Defense foundation: Black prepares ...d5 against White’s e-pawn. The move creates a solid center but can make the light-square bishop harder to activate.

- Plain hint: Prepare a central pawn challenge while accepting a more compact light-square bishop.

- Opening themes: ...e6 foundation, ...d5 preparation, bishop problem

### Packet french-black.line-016.ply-04.d7d5

- Move: `d5` / `d7d5` at ply 4

- CoachCard: **Challenge e4 with the French center** — d5 completes the basic French plan by attacking White’s e-pawn. Black creates central tension that may become an exchange, advance, or locked pawn chain.

- Plain hint: Challenge White’s king pawn with the prepared queen-pawn strike.

- Opening themes: ...d5 challenge, e4 tension, French center

### Packet french-black.line-016.ply-06.d5e4

- Move: `dxe4` / `d5e4` at ply 6

- CoachCard: **Keep French counterplay aimed at the center** — dxe4 supports the French plan of ...e6/...d5 central tension and counterplay against White’s center. It stays tied to structure rather than generic development.

- Plain hint: Build the e-pawn and queen-pawn center, then pressure White’s pawn chain.

- Opening themes: French structure, central tension, counterplay

### Packet french-black.line-016.ply-08.b8d7

- Move: `Nd7` / `b8d7` at ply 8

- CoachCard: **Keep French counterplay aimed at the center** — Nd7 supports the French plan of ...e6/...d5 central tension and counterplay against White’s center. It stays tied to structure rather than generic development.

- Plain hint: Build the e-pawn and queen-pawn center, then pressure White’s pawn chain.

- Opening themes: French structure, central tension, counterplay

### Packet french-black.line-016.ply-10.g8f6

- Move: `Ngf6` / `g8f6` at ply 10

- CoachCard: **Pressure the advanced center** — Ngf6 develops a knight to pressure White’s central structure and brings Black closer to castling. In French lines, piece pressure must support the pawn breaks.

- Plain hint: Bring the kingside knight into the central fight and prepare castling.

- Opening themes: ...Nf6 pressure, king safety, central support

### Packet french-black.line-016.ply-12.f8e7

- Move: `Be7` / `f8e7` at ply 12

- CoachCard: **Keep French counterplay aimed at the center** — Be7 supports the French plan of ...e6/...d5 central tension and counterplay against White’s center. It stays tied to structure rather than generic development.

- Plain hint: Build the e-pawn and queen-pawn center, then pressure White’s pawn chain.

- Opening themes: French structure, central tension, counterplay


## french-black-line-017: 1. e4 e6 2. d4 d5 3. exd5 exd5 4. Nc3 c6 5. Bd3 Bd6 6. Nf3 Nf6

Runtime playKey: `e2e4,e7e6,d2d4,d7d5,e4d5,e6d5,b1c3,c7c6,f1d3,f8d6,g1f3,g8f6`  
Runtime totalGames field at line node: `285770`

### Packet french-black.line-017.ply-02.e7e6

- Move: `e6` / `e7e6` at ply 2

- CoachCard: **Prepare the French central challenge** — e6 is the French Defense foundation: Black prepares ...d5 against White’s e-pawn. The move creates a solid center but can make the light-square bishop harder to activate.

- Plain hint: Prepare a central pawn challenge while accepting a more compact light-square bishop.

- Opening themes: ...e6 foundation, ...d5 preparation, bishop problem

### Packet french-black.line-017.ply-04.d7d5

- Move: `d5` / `d7d5` at ply 4

- CoachCard: **Challenge e4 with the French center** — d5 completes the basic French plan by attacking White’s e-pawn. Black creates central tension that may become an exchange, advance, or locked pawn chain.

- Plain hint: Challenge White’s king pawn with the prepared queen-pawn strike.

- Opening themes: ...d5 challenge, e4 tension, French center

### Packet french-black.line-017.ply-06.e6d5

- Move: `exd5` / `e6d5` at ply 6

- CoachCard: **Accept the Exchange French structure** — exd5 recaptures in the Exchange French structure. Black keeps a solid center and shifts the game toward development and piece activity.

- Plain hint: Recapture in the center and settle into a symmetrical but solid pawn structure.

- Opening themes: Exchange French, central recapture, solid structure

### Packet french-black.line-017.ply-08.c7c6

- Move: `c6` / `c7c6` at ply 8

- CoachCard: **Keep French counterplay aimed at the center** — c6 supports the French plan of ...e6/...d5 central tension and counterplay against White’s center. It stays tied to structure rather than generic development.

- Plain hint: Build the e-pawn and queen-pawn center, then pressure White’s pawn chain.

- Opening themes: French structure, central tension, counterplay

### Packet french-black.line-017.ply-10.f8d6

- Move: `Bd6` / `f8d6` at ply 10

- CoachCard: **Place the bishop on an active French diagonal** — Bd6 develops the bishop to an active diagonal in the French structure. It supports castling and can pressure the kingside once the center is stable.

- Plain hint: Use the dark-square bishop to support development and kingside coordination.

- Opening themes: dark-square bishop, king safety, French piece activity

### Packet french-black.line-017.ply-12.g8f6

- Move: `Nf6` / `g8f6` at ply 12

- CoachCard: **Pressure the advanced center** — Nf6 develops a knight to pressure White’s central structure and brings Black closer to castling. In French lines, piece pressure must support the pawn breaks.

- Plain hint: Bring the kingside knight into the central fight and prepare castling.

- Opening themes: ...Nf6 pressure, king safety, central support


## french-black-line-018: 1. e4 e6 2. d4 d5 3. e5 c5 4. c3 Nc6 5. Bb5 Bd7 6. Bxc6 Bxc6

Runtime playKey: `e2e4,e7e6,d2d4,d7d5,e4e5,c7c5,c2c3,b8c6,f1b5,c8d7,b5c6,d7c6`  
Runtime totalGames field at line node: `283277`

### Packet french-black.line-018.ply-02.e7e6

- Move: `e6` / `e7e6` at ply 2

- CoachCard: **Prepare the French central challenge** — e6 is the French Defense foundation: Black prepares ...d5 against White’s e-pawn. The move creates a solid center but can make the light-square bishop harder to activate.

- Plain hint: Prepare a central pawn challenge while accepting a more compact light-square bishop.

- Opening themes: ...e6 foundation, ...d5 preparation, bishop problem

### Packet french-black.line-018.ply-04.d7d5

- Move: `d5` / `d7d5` at ply 4

- CoachCard: **Challenge e4 with the French center** — d5 completes the basic French plan by attacking White’s e-pawn. Black creates central tension that may become an exchange, advance, or locked pawn chain.

- Plain hint: Challenge White’s king pawn with the prepared queen-pawn strike.

- Opening themes: ...d5 challenge, e4 tension, French center

### Packet french-black.line-018.ply-06.c7c5

- Move: `c5` / `c7c5` at ply 6

- CoachCard: **Strike at White’s pawn chain** — c5 is the French counterattack against White’s center, especially when White advances the e-pawn. Black pressures d4 and challenges the pawn chain.

- Plain hint: Attack White’s central chain from the side instead of passively accepting space.

- Opening themes: ...c5 counterplay, pawn-chain pressure, d4 target

### Packet french-black.line-018.ply-08.b8c6

- Move: `Nc6` / `b8c6` at ply 8

- CoachCard: **Add pressure to the French center** — Nc6 develops into the French central fight and adds pressure on d4/e5 structures. Black supports counterplay rather than defending passively.

- Plain hint: Develop the queenside knight to increase pressure on White’s central pawns.

- Opening themes: central pressure, French development, pawn-chain pressure

### Packet french-black.line-018.ply-10.c8d7

- Move: `Bd7` / `c8d7` at ply 10

- CoachCard: **Develop while supporting the French center** — Bd7 develops the bishop behind the French center and connects queenside coordination. It is useful in Advance-style structures where Black pressures d4.

- Plain hint: Place the bishop where it helps coordination behind the central pawn chain.

- Opening themes: bishop development, Advance French structure, d4 pressure

### Packet french-black.line-018.ply-12.d7c6

- Move: `Bxc6` / `d7c6` at ply 12

- CoachCard: **Keep French counterplay aimed at the center** — Bxc6 supports the French plan of ...e6/...d5 central tension and counterplay against White’s center. It stays tied to structure rather than generic development.

- Plain hint: Build the e-pawn and queen-pawn center, then pressure White’s pawn chain.

- Opening themes: French structure, central tension, counterplay


## french-black-line-019: 1. e4 e6 2. Nf3 d5 3. e5 c5 4. d4 cxd4 5. Nxd4 Nc6 6. Nxc6 bxc6

Runtime playKey: `e2e4,e7e6,g1f3,d7d5,e4e5,c7c5,d2d4,c5d4,f3d4,b8c6,d4c6,b7c6`  
Runtime totalGames field at line node: `280182`

### Packet french-black.line-019.ply-02.e7e6

- Move: `e6` / `e7e6` at ply 2

- CoachCard: **Prepare the French central challenge** — e6 is the French Defense foundation: Black prepares ...d5 against White’s e-pawn. The move creates a solid center but can make the light-square bishop harder to activate.

- Plain hint: Prepare a central pawn challenge while accepting a more compact light-square bishop.

- Opening themes: ...e6 foundation, ...d5 preparation, bishop problem

### Packet french-black.line-019.ply-04.d7d5

- Move: `d5` / `d7d5` at ply 4

- CoachCard: **Challenge e4 with the French center** — d5 completes the basic French plan by attacking White’s e-pawn. Black creates central tension that may become an exchange, advance, or locked pawn chain.

- Plain hint: Challenge White’s king pawn with the prepared queen-pawn strike.

- Opening themes: ...d5 challenge, e4 tension, French center

### Packet french-black.line-019.ply-06.c7c5

- Move: `c5` / `c7c5` at ply 6

- CoachCard: **Strike at White’s pawn chain** — c5 is the French counterattack against White’s center, especially when White advances the e-pawn. Black pressures d4 and challenges the pawn chain.

- Plain hint: Attack White’s central chain from the side instead of passively accepting space.

- Opening themes: ...c5 counterplay, pawn-chain pressure, d4 target

### Packet french-black.line-019.ply-08.c5d4

- Move: `cxd4` / `c5d4` at ply 8

- CoachCard: **Keep French counterplay aimed at the center** — cxd4 supports the French plan of ...e6/...d5 central tension and counterplay against White’s center. It stays tied to structure rather than generic development.

- Plain hint: Build the e-pawn and queen-pawn center, then pressure White’s pawn chain.

- Opening themes: French structure, central tension, counterplay

### Packet french-black.line-019.ply-10.b8c6

- Move: `Nc6` / `b8c6` at ply 10

- CoachCard: **Add pressure to the French center** — Nc6 develops into the French central fight and adds pressure on d4/e5 structures. Black supports counterplay rather than defending passively.

- Plain hint: Develop the queenside knight to increase pressure on White’s central pawns.

- Opening themes: central pressure, French development, pawn-chain pressure

### Packet french-black.line-019.ply-12.b7c6

- Move: `bxc6` / `b7c6` at ply 12

- CoachCard: **Keep French counterplay aimed at the center** — bxc6 supports the French plan of ...e6/...d5 central tension and counterplay against White’s center. It stays tied to structure rather than generic development.

- Plain hint: Build the e-pawn and queen-pawn center, then pressure White’s pawn chain.

- Opening themes: French structure, central tension, counterplay


## french-black-line-020: 1. e4 e6 2. Nf3 d5 3. e5 c5 4. c3 Nc6 5. Bb5 Bd7 6. d4 Nxe5

Runtime playKey: `e2e4,e7e6,g1f3,d7d5,e4e5,c7c5,c2c3,b8c6,f1b5,c8d7,d2d4,c6e5`  
Runtime totalGames field at line node: `277703`

### Packet french-black.line-020.ply-02.e7e6

- Move: `e6` / `e7e6` at ply 2

- CoachCard: **Prepare the French central challenge** — e6 is the French Defense foundation: Black prepares ...d5 against White’s e-pawn. The move creates a solid center but can make the light-square bishop harder to activate.

- Plain hint: Prepare a central pawn challenge while accepting a more compact light-square bishop.

- Opening themes: ...e6 foundation, ...d5 preparation, bishop problem

### Packet french-black.line-020.ply-04.d7d5

- Move: `d5` / `d7d5` at ply 4

- CoachCard: **Challenge e4 with the French center** — d5 completes the basic French plan by attacking White’s e-pawn. Black creates central tension that may become an exchange, advance, or locked pawn chain.

- Plain hint: Challenge White’s king pawn with the prepared queen-pawn strike.

- Opening themes: ...d5 challenge, e4 tension, French center

### Packet french-black.line-020.ply-06.c7c5

- Move: `c5` / `c7c5` at ply 6

- CoachCard: **Strike at White’s pawn chain** — c5 is the French counterattack against White’s center, especially when White advances the e-pawn. Black pressures d4 and challenges the pawn chain.

- Plain hint: Attack White’s central chain from the side instead of passively accepting space.

- Opening themes: ...c5 counterplay, pawn-chain pressure, d4 target

### Packet french-black.line-020.ply-08.b8c6

- Move: `Nc6` / `b8c6` at ply 8

- CoachCard: **Add pressure to the French center** — Nc6 develops into the French central fight and adds pressure on d4/e5 structures. Black supports counterplay rather than defending passively.

- Plain hint: Develop the queenside knight to increase pressure on White’s central pawns.

- Opening themes: central pressure, French development, pawn-chain pressure

### Packet french-black.line-020.ply-10.c8d7

- Move: `Bd7` / `c8d7` at ply 10

- CoachCard: **Develop while supporting the French center** — Bd7 develops the bishop behind the French center and connects queenside coordination. It is useful in Advance-style structures where Black pressures d4.

- Plain hint: Place the bishop where it helps coordination behind the central pawn chain.

- Opening themes: bishop development, Advance French structure, d4 pressure

### Packet french-black.line-020.ply-12.c6e5

- Move: `Nxe5` / `c6e5` at ply 12

- CoachCard: **Keep French counterplay aimed at the center** — Nxe5 supports the French plan of ...e6/...d5 central tension and counterplay against White’s center. It stays tied to structure rather than generic development.

- Plain hint: Build the e-pawn and queen-pawn center, then pressure White’s pawn chain.

- Opening themes: French structure, central tension, counterplay


## french-black-line-021: 1. e4 e6 2. Nf3 d5 3. e5 c5 4. d4 Nc6 5. Bb5 Bd7 6. Bxc6 Bxc6

Runtime playKey: `e2e4,e7e6,g1f3,d7d5,e4e5,c7c5,d2d4,b8c6,f1b5,c8d7,b5c6,d7c6`  
Runtime totalGames field at line node: `253168`

### Packet french-black.line-021.ply-02.e7e6

- Move: `e6` / `e7e6` at ply 2

- CoachCard: **Prepare the French central challenge** — e6 is the French Defense foundation: Black prepares ...d5 against White’s e-pawn. The move creates a solid center but can make the light-square bishop harder to activate.

- Plain hint: Prepare a central pawn challenge while accepting a more compact light-square bishop.

- Opening themes: ...e6 foundation, ...d5 preparation, bishop problem

### Packet french-black.line-021.ply-04.d7d5

- Move: `d5` / `d7d5` at ply 4

- CoachCard: **Challenge e4 with the French center** — d5 completes the basic French plan by attacking White’s e-pawn. Black creates central tension that may become an exchange, advance, or locked pawn chain.

- Plain hint: Challenge White’s king pawn with the prepared queen-pawn strike.

- Opening themes: ...d5 challenge, e4 tension, French center

### Packet french-black.line-021.ply-06.c7c5

- Move: `c5` / `c7c5` at ply 6

- CoachCard: **Strike at White’s pawn chain** — c5 is the French counterattack against White’s center, especially when White advances the e-pawn. Black pressures d4 and challenges the pawn chain.

- Plain hint: Attack White’s central chain from the side instead of passively accepting space.

- Opening themes: ...c5 counterplay, pawn-chain pressure, d4 target

### Packet french-black.line-021.ply-08.b8c6

- Move: `Nc6` / `b8c6` at ply 8

- CoachCard: **Add pressure to the French center** — Nc6 develops into the French central fight and adds pressure on d4/e5 structures. Black supports counterplay rather than defending passively.

- Plain hint: Develop the queenside knight to increase pressure on White’s central pawns.

- Opening themes: central pressure, French development, pawn-chain pressure

### Packet french-black.line-021.ply-10.c8d7

- Move: `Bd7` / `c8d7` at ply 10

- CoachCard: **Develop while supporting the French center** — Bd7 develops the bishop behind the French center and connects queenside coordination. It is useful in Advance-style structures where Black pressures d4.

- Plain hint: Place the bishop where it helps coordination behind the central pawn chain.

- Opening themes: bishop development, Advance French structure, d4 pressure

### Packet french-black.line-021.ply-12.d7c6

- Move: `Bxc6` / `d7c6` at ply 12

- CoachCard: **Keep French counterplay aimed at the center** — Bxc6 supports the French plan of ...e6/...d5 central tension and counterplay against White’s center. It stays tied to structure rather than generic development.

- Plain hint: Build the e-pawn and queen-pawn center, then pressure White’s pawn chain.

- Opening themes: French structure, central tension, counterplay


## french-black-line-022: 1. e4 e6 2. Nf3 d5 3. exd5 exd5 4. d4 Bd6 5. Nc3 c6 6. Bd3 Ne7

Runtime playKey: `e2e4,e7e6,g1f3,d7d5,e4d5,e6d5,d2d4,f8d6,b1c3,c7c6,f1d3,g8e7`  
Runtime totalGames field at line node: `247987`

### Packet french-black.line-022.ply-02.e7e6

- Move: `e6` / `e7e6` at ply 2

- CoachCard: **Prepare the French central challenge** — e6 is the French Defense foundation: Black prepares ...d5 against White’s e-pawn. The move creates a solid center but can make the light-square bishop harder to activate.

- Plain hint: Prepare a central pawn challenge while accepting a more compact light-square bishop.

- Opening themes: ...e6 foundation, ...d5 preparation, bishop problem

### Packet french-black.line-022.ply-04.d7d5

- Move: `d5` / `d7d5` at ply 4

- CoachCard: **Challenge e4 with the French center** — d5 completes the basic French plan by attacking White’s e-pawn. Black creates central tension that may become an exchange, advance, or locked pawn chain.

- Plain hint: Challenge White’s king pawn with the prepared queen-pawn strike.

- Opening themes: ...d5 challenge, e4 tension, French center

### Packet french-black.line-022.ply-06.e6d5

- Move: `exd5` / `e6d5` at ply 6

- CoachCard: **Accept the Exchange French structure** — exd5 recaptures in the Exchange French structure. Black keeps a solid center and shifts the game toward development and piece activity.

- Plain hint: Recapture in the center and settle into a symmetrical but solid pawn structure.

- Opening themes: Exchange French, central recapture, solid structure

### Packet french-black.line-022.ply-08.f8d6

- Move: `Bd6` / `f8d6` at ply 8

- CoachCard: **Place the bishop on an active French diagonal** — Bd6 develops the bishop to an active diagonal in the French structure. It supports castling and can pressure the kingside once the center is stable.

- Plain hint: Use the dark-square bishop to support development and kingside coordination.

- Opening themes: dark-square bishop, king safety, French piece activity

### Packet french-black.line-022.ply-10.c7c6

- Move: `c6` / `c7c6` at ply 10

- CoachCard: **Keep French counterplay aimed at the center** — c6 supports the French plan of ...e6/...d5 central tension and counterplay against White’s center. It stays tied to structure rather than generic development.

- Plain hint: Build the e-pawn and queen-pawn center, then pressure White’s pawn chain.

- Opening themes: French structure, central tension, counterplay

### Packet french-black.line-022.ply-12.g8e7

- Move: `Ne7` / `g8e7` at ply 12

- CoachCard: **Keep French counterplay aimed at the center** — Ne7 supports the French plan of ...e6/...d5 central tension and counterplay against White’s center. It stays tied to structure rather than generic development.

- Plain hint: Build the e-pawn and queen-pawn center, then pressure White’s pawn chain.

- Opening themes: French structure, central tension, counterplay


## french-black-line-023: 1. e4 e6 2. Nf3 d5 3. e5 c5 4. d4 cxd4 5. Nxd4 Nc6 6. Bb5 Bd7

Runtime playKey: `e2e4,e7e6,g1f3,d7d5,e4e5,c7c5,d2d4,c5d4,f3d4,b8c6,f1b5,c8d7`  
Runtime totalGames field at line node: `237644`

### Packet french-black.line-023.ply-02.e7e6

- Move: `e6` / `e7e6` at ply 2

- CoachCard: **Prepare the French central challenge** — e6 is the French Defense foundation: Black prepares ...d5 against White’s e-pawn. The move creates a solid center but can make the light-square bishop harder to activate.

- Plain hint: Prepare a central pawn challenge while accepting a more compact light-square bishop.

- Opening themes: ...e6 foundation, ...d5 preparation, bishop problem

### Packet french-black.line-023.ply-04.d7d5

- Move: `d5` / `d7d5` at ply 4

- CoachCard: **Challenge e4 with the French center** — d5 completes the basic French plan by attacking White’s e-pawn. Black creates central tension that may become an exchange, advance, or locked pawn chain.

- Plain hint: Challenge White’s king pawn with the prepared queen-pawn strike.

- Opening themes: ...d5 challenge, e4 tension, French center

### Packet french-black.line-023.ply-06.c7c5

- Move: `c5` / `c7c5` at ply 6

- CoachCard: **Strike at White’s pawn chain** — c5 is the French counterattack against White’s center, especially when White advances the e-pawn. Black pressures d4 and challenges the pawn chain.

- Plain hint: Attack White’s central chain from the side instead of passively accepting space.

- Opening themes: ...c5 counterplay, pawn-chain pressure, d4 target

### Packet french-black.line-023.ply-08.c5d4

- Move: `cxd4` / `c5d4` at ply 8

- CoachCard: **Keep French counterplay aimed at the center** — cxd4 supports the French plan of ...e6/...d5 central tension and counterplay against White’s center. It stays tied to structure rather than generic development.

- Plain hint: Build the e-pawn and queen-pawn center, then pressure White’s pawn chain.

- Opening themes: French structure, central tension, counterplay

### Packet french-black.line-023.ply-10.b8c6

- Move: `Nc6` / `b8c6` at ply 10

- CoachCard: **Add pressure to the French center** — Nc6 develops into the French central fight and adds pressure on d4/e5 structures. Black supports counterplay rather than defending passively.

- Plain hint: Develop the queenside knight to increase pressure on White’s central pawns.

- Opening themes: central pressure, French development, pawn-chain pressure

### Packet french-black.line-023.ply-12.c8d7

- Move: `Bd7` / `c8d7` at ply 12

- CoachCard: **Develop while supporting the French center** — Bd7 develops the bishop behind the French center and connects queenside coordination. It is useful in Advance-style structures where Black pressures d4.

- Plain hint: Place the bishop where it helps coordination behind the central pawn chain.

- Opening themes: bishop development, Advance French structure, d4 pressure


## french-black-line-024: 1. e4 e6 2. Nf3 d5 3. e5 c5 4. c3 Nc6 5. d4 Bd7 6. Bd3 cxd4

Runtime playKey: `e2e4,e7e6,g1f3,d7d5,e4e5,c7c5,c2c3,b8c6,d2d4,c8d7,f1d3,c5d4`  
Runtime totalGames field at line node: `204980`

### Packet french-black.line-024.ply-02.e7e6

- Move: `e6` / `e7e6` at ply 2

- CoachCard: **Prepare the French central challenge** — e6 is the French Defense foundation: Black prepares ...d5 against White’s e-pawn. The move creates a solid center but can make the light-square bishop harder to activate.

- Plain hint: Prepare a central pawn challenge while accepting a more compact light-square bishop.

- Opening themes: ...e6 foundation, ...d5 preparation, bishop problem

### Packet french-black.line-024.ply-04.d7d5

- Move: `d5` / `d7d5` at ply 4

- CoachCard: **Challenge e4 with the French center** — d5 completes the basic French plan by attacking White’s e-pawn. Black creates central tension that may become an exchange, advance, or locked pawn chain.

- Plain hint: Challenge White’s king pawn with the prepared queen-pawn strike.

- Opening themes: ...d5 challenge, e4 tension, French center

### Packet french-black.line-024.ply-06.c7c5

- Move: `c5` / `c7c5` at ply 6

- CoachCard: **Strike at White’s pawn chain** — c5 is the French counterattack against White’s center, especially when White advances the e-pawn. Black pressures d4 and challenges the pawn chain.

- Plain hint: Attack White’s central chain from the side instead of passively accepting space.

- Opening themes: ...c5 counterplay, pawn-chain pressure, d4 target

### Packet french-black.line-024.ply-08.b8c6

- Move: `Nc6` / `b8c6` at ply 8

- CoachCard: **Add pressure to the French center** — Nc6 develops into the French central fight and adds pressure on d4/e5 structures. Black supports counterplay rather than defending passively.

- Plain hint: Develop the queenside knight to increase pressure on White’s central pawns.

- Opening themes: central pressure, French development, pawn-chain pressure

### Packet french-black.line-024.ply-10.c8d7

- Move: `Bd7` / `c8d7` at ply 10

- CoachCard: **Develop while supporting the French center** — Bd7 develops the bishop behind the French center and connects queenside coordination. It is useful in Advance-style structures where Black pressures d4.

- Plain hint: Place the bishop where it helps coordination behind the central pawn chain.

- Opening themes: bishop development, Advance French structure, d4 pressure

### Packet french-black.line-024.ply-12.c5d4

- Move: `cxd4` / `c5d4` at ply 12

- CoachCard: **Keep French counterplay aimed at the center** — cxd4 supports the French plan of ...e6/...d5 central tension and counterplay against White’s center. It stays tied to structure rather than generic development.

- Plain hint: Build the e-pawn and queen-pawn center, then pressure White’s pawn chain.

- Opening themes: French structure, central tension, counterplay


## french-black-line-025: 1. e4 e6 2. d4 d5 3. Nc3 dxe4 4. Nxe4 Nd7 5. Bd3 Ngf6 6. Nf3 Nxe4

Runtime playKey: `e2e4,e7e6,d2d4,d7d5,b1c3,d5e4,c3e4,b8d7,f1d3,g8f6,g1f3,f6e4`  
Runtime totalGames field at line node: `197401`

### Packet french-black.line-025.ply-02.e7e6

- Move: `e6` / `e7e6` at ply 2

- CoachCard: **Prepare the French central challenge** — e6 is the French Defense foundation: Black prepares ...d5 against White’s e-pawn. The move creates a solid center but can make the light-square bishop harder to activate.

- Plain hint: Prepare a central pawn challenge while accepting a more compact light-square bishop.

- Opening themes: ...e6 foundation, ...d5 preparation, bishop problem

### Packet french-black.line-025.ply-04.d7d5

- Move: `d5` / `d7d5` at ply 4

- CoachCard: **Challenge e4 with the French center** — d5 completes the basic French plan by attacking White’s e-pawn. Black creates central tension that may become an exchange, advance, or locked pawn chain.

- Plain hint: Challenge White’s king pawn with the prepared queen-pawn strike.

- Opening themes: ...d5 challenge, e4 tension, French center

### Packet french-black.line-025.ply-06.d5e4

- Move: `dxe4` / `d5e4` at ply 6

- CoachCard: **Keep French counterplay aimed at the center** — dxe4 supports the French plan of ...e6/...d5 central tension and counterplay against White’s center. It stays tied to structure rather than generic development.

- Plain hint: Build the e-pawn and queen-pawn center, then pressure White’s pawn chain.

- Opening themes: French structure, central tension, counterplay

### Packet french-black.line-025.ply-08.b8d7

- Move: `Nd7` / `b8d7` at ply 8

- CoachCard: **Keep French counterplay aimed at the center** — Nd7 supports the French plan of ...e6/...d5 central tension and counterplay against White’s center. It stays tied to structure rather than generic development.

- Plain hint: Build the e-pawn and queen-pawn center, then pressure White’s pawn chain.

- Opening themes: French structure, central tension, counterplay

### Packet french-black.line-025.ply-10.g8f6

- Move: `Ngf6` / `g8f6` at ply 10

- CoachCard: **Pressure the advanced center** — Ngf6 develops a knight to pressure White’s central structure and brings Black closer to castling. In French lines, piece pressure must support the pawn breaks.

- Plain hint: Bring the kingside knight into the central fight and prepare castling.

- Opening themes: ...Nf6 pressure, king safety, central support

### Packet french-black.line-025.ply-12.f6e4

- Move: `Nxe4` / `f6e4` at ply 12

- CoachCard: **Keep French counterplay aimed at the center** — Nxe4 supports the French plan of ...e6/...d5 central tension and counterplay against White’s center. It stays tied to structure rather than generic development.

- Plain hint: Build the e-pawn and queen-pawn center, then pressure White’s pawn chain.

- Opening themes: French structure, central tension, counterplay
