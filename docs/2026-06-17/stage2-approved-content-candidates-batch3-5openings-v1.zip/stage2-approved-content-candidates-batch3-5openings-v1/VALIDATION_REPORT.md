# Validation Report

## Summary

- Openings attempted: 5
- Openings completed: 5
- Target line count: 20 per opening preferred; 10 per opening minimum
- Actual line count: 125
- Packet count: 625
- Rejected line count: 434
- Rejected packet count: 0

## Results

- Legal sequence validation result: PASS for all selected lines
- Runtime match result: PASS for all emitted packets
- Plain View no-leak result: PASS for all emitted packets
- Generic copy scan result: PASS; forbidden phrases not found in emitted packet copy

## Coverage

- `reti-white`: 10-line minimum=YES; 20-line target=YES; lines=25; packets=125
- `pirc-black`: 10-line minimum=YES; 20-line target=YES; lines=25; packets=125
- `petroff-black`: 10-line minimum=YES; 20-line target=YES; lines=25; packets=125
- `qgd-black`: 10-line minimum=YES; 20-line target=YES; lines=25; packets=125
- `vienna-white`: 10-line minimum=YES; 20-line target=YES; lines=25; packets=125

## Extra round-robin lines

- Extra round-robin lines added: YES
- Extra lines beyond 20/opening: 25

## Activation warning

This package is ready for app-side validation, but it is not final approved app content and must not flip `approvedContentAvailable`.
