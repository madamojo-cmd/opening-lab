# Pirc Defense approved-content candidates — Batch 3

Opening ID: `pirc-black`  
Status: approved candidates only; not app-activated.


## pirc-black-line-001: 1. e4 d6 2. d4 Nf6 3. Nc3 g6 4. Bg5 Bg7 5. e5 dxe5 6. dxe5 Qxd1+

Runtime playKey: `e2e4,d7d6,d2d4,g8f6,b1c3,g7g6,c1g5,f8g7,e4e5,d6e5,d4e5,d8d1`  
Runtime totalGames field at line node: `308338`

### Packet pirc-black.line-001.ply-04.g8f6

- Move: `Nf6` / `g8f6` at ply 4

- CoachCard: **Pressure e4 with the knight** — Nf6 develops the knight and immediately pressures White’s e4 pawn. In the Pirc, that piece pressure is part of the plan against White’s broad center.

- Plain hint: Bring the kingside knight into contact with White’s central pawn.

- Opening themes: ...Nf6 vs e4, piece pressure, Pirc development

### Packet pirc-black.line-001.ply-06.g7g6

- Move: `g6` / `g7g6` at ply 6

- CoachCard: **Build the Pirc fianchetto** — g6 prepares the Pirc bishop on the long diagonal. Black lets White occupy space while preparing pressure from a distance.

- Plain hint: Prepare the kingside fianchetto that pressures the long diagonal.

- Opening themes: ...g6 fianchetto, long diagonal, hypermodern pressure

### Packet pirc-black.line-001.ply-08.f8g7

- Move: `Bg7` / `f8g7` at ply 8

- CoachCard: **Complete the Pirc long diagonal** — Bg7 completes the Pirc fianchetto. The bishop supports central counterplay and contests key dark squares from the long diagonal.

- Plain hint: Place the bishop where it can pressure the center from distance.

- Opening themes: g7 bishop, long diagonal, central counterplay

### Packet pirc-black.line-001.ply-10.d6e5

- Move: `dxe5` / `d6e5` at ply 10

- CoachCard: **Clarify the center after White advances** — dxe5 recaptures in the center after White pushes forward. Black clarifies the position while keeping the Pirc plan tied to White’s central pawns.

- Plain hint: Resolve central tension only when the pawn structure calls for it.

- Opening themes: central clarification, e5 tension, Pirc response

### Packet pirc-black.line-001.ply-12.d8d1

- Move: `Qxd1+` / `d8d1` at ply 12

- CoachCard: **Keep the Pirc setup coherent** — Qxd1+ supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge


## pirc-black-line-002: 1. e4 d6 2. d4 Nf6 3. Nc3 Nbd7 4. Nf3 e5 5. Bc4 Be7 6. dxe5 dxe5

Runtime playKey: `e2e4,d7d6,d2d4,g8f6,b1c3,b8d7,g1f3,e7e5,f1c4,f8e7,d4e5,d6e5`  
Runtime totalGames field at line node: `193207`

### Packet pirc-black.line-002.ply-04.g8f6

- Move: `Nf6` / `g8f6` at ply 4

- CoachCard: **Pressure e4 with the knight** — Nf6 develops the knight and immediately pressures White’s e4 pawn. In the Pirc, that piece pressure is part of the plan against White’s broad center.

- Plain hint: Bring the kingside knight into contact with White’s central pawn.

- Opening themes: ...Nf6 vs e4, piece pressure, Pirc development

### Packet pirc-black.line-002.ply-06.b8d7

- Move: `Nbd7` / `b8d7` at ply 6

- CoachCard: **Support the Pirc center from behind** — Nbd7 develops a knight behind the Pirc pawn structure and supports future central action. It keeps Black compact while preparing counterplay.

- Plain hint: Add a queenside knight defender before choosing the central break.

- Opening themes: ...Nbd7 support, central preparation, compact setup

### Packet pirc-black.line-002.ply-08.e7e5

- Move: `e5` / `e7e5` at ply 8

- CoachCard: **Strike back with the Pirc e-pawn** — e5 is a direct Pirc counterbreak against White’s center. Black uses development and pawn support to challenge White’s space.

- Plain hint: Challenge White’s central pawns only after the setup supports the break.

- Opening themes: ...e5 counterbreak, central challenge, development before break

### Packet pirc-black.line-002.ply-10.f8e7

- Move: `Be7` / `f8e7` at ply 10

- CoachCard: **Keep the Pirc setup coherent** — Be7 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge

### Packet pirc-black.line-002.ply-12.d6e5

- Move: `dxe5` / `d6e5` at ply 12

- CoachCard: **Clarify the center after White advances** — dxe5 recaptures in the center after White pushes forward. Black clarifies the position while keeping the Pirc plan tied to White’s central pawns.

- Plain hint: Resolve central tension only when the pawn structure calls for it.

- Opening themes: central clarification, e5 tension, Pirc response


## pirc-black-line-003: 1. e4 d6 2. d4 Nf6 3. Nc3 Nbd7 4. Nf3 e5 5. dxe5 dxe5 6. Bg5 Be7

Runtime playKey: `e2e4,d7d6,d2d4,g8f6,b1c3,b8d7,g1f3,e7e5,d4e5,d6e5,c1g5,f8e7`  
Runtime totalGames field at line node: `154401`

### Packet pirc-black.line-003.ply-04.g8f6

- Move: `Nf6` / `g8f6` at ply 4

- CoachCard: **Pressure e4 with the knight** — Nf6 develops the knight and immediately pressures White’s e4 pawn. In the Pirc, that piece pressure is part of the plan against White’s broad center.

- Plain hint: Bring the kingside knight into contact with White’s central pawn.

- Opening themes: ...Nf6 vs e4, piece pressure, Pirc development

### Packet pirc-black.line-003.ply-06.b8d7

- Move: `Nbd7` / `b8d7` at ply 6

- CoachCard: **Support the Pirc center from behind** — Nbd7 develops a knight behind the Pirc pawn structure and supports future central action. It keeps Black compact while preparing counterplay.

- Plain hint: Add a queenside knight defender before choosing the central break.

- Opening themes: ...Nbd7 support, central preparation, compact setup

### Packet pirc-black.line-003.ply-08.e7e5

- Move: `e5` / `e7e5` at ply 8

- CoachCard: **Strike back with the Pirc e-pawn** — e5 is a direct Pirc counterbreak against White’s center. Black uses development and pawn support to challenge White’s space.

- Plain hint: Challenge White’s central pawns only after the setup supports the break.

- Opening themes: ...e5 counterbreak, central challenge, development before break

### Packet pirc-black.line-003.ply-10.d6e5

- Move: `dxe5` / `d6e5` at ply 10

- CoachCard: **Clarify the center after White advances** — dxe5 recaptures in the center after White pushes forward. Black clarifies the position while keeping the Pirc plan tied to White’s central pawns.

- Plain hint: Resolve central tension only when the pawn structure calls for it.

- Opening themes: central clarification, e5 tension, Pirc response

### Packet pirc-black.line-003.ply-12.f8e7

- Move: `Be7` / `f8e7` at ply 12

- CoachCard: **Keep the Pirc setup coherent** — Be7 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge


## pirc-black-line-004: 1. e4 d6 2. d4 Nf6 3. Nc3 Nbd7 4. Nf3 e5 5. dxe5 dxe5 6. Bc4 h6

Runtime playKey: `e2e4,d7d6,d2d4,g8f6,b1c3,b8d7,g1f3,e7e5,d4e5,d6e5,f1c4,h7h6`  
Runtime totalGames field at line node: `98115`

### Packet pirc-black.line-004.ply-04.g8f6

- Move: `Nf6` / `g8f6` at ply 4

- CoachCard: **Pressure e4 with the knight** — Nf6 develops the knight and immediately pressures White’s e4 pawn. In the Pirc, that piece pressure is part of the plan against White’s broad center.

- Plain hint: Bring the kingside knight into contact with White’s central pawn.

- Opening themes: ...Nf6 vs e4, piece pressure, Pirc development

### Packet pirc-black.line-004.ply-06.b8d7

- Move: `Nbd7` / `b8d7` at ply 6

- CoachCard: **Support the Pirc center from behind** — Nbd7 develops a knight behind the Pirc pawn structure and supports future central action. It keeps Black compact while preparing counterplay.

- Plain hint: Add a queenside knight defender before choosing the central break.

- Opening themes: ...Nbd7 support, central preparation, compact setup

### Packet pirc-black.line-004.ply-08.e7e5

- Move: `e5` / `e7e5` at ply 8

- CoachCard: **Strike back with the Pirc e-pawn** — e5 is a direct Pirc counterbreak against White’s center. Black uses development and pawn support to challenge White’s space.

- Plain hint: Challenge White’s central pawns only after the setup supports the break.

- Opening themes: ...e5 counterbreak, central challenge, development before break

### Packet pirc-black.line-004.ply-10.d6e5

- Move: `dxe5` / `d6e5` at ply 10

- CoachCard: **Clarify the center after White advances** — dxe5 recaptures in the center after White pushes forward. Black clarifies the position while keeping the Pirc plan tied to White’s central pawns.

- Plain hint: Resolve central tension only when the pawn structure calls for it.

- Opening themes: central clarification, e5 tension, Pirc response

### Packet pirc-black.line-004.ply-12.h7h6

- Move: `h6` / `h7h6` at ply 12

- CoachCard: **Keep the Pirc setup coherent** — h6 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge


## pirc-black-line-005: 1. e4 d6 2. d4 Nf6 3. Nc3 c6 4. Nf3 Qa5 5. Bd2 Qc7 6. Bd3 e5

Runtime playKey: `e2e4,d7d6,d2d4,g8f6,b1c3,c7c6,g1f3,d8a5,c1d2,a5c7,f1d3,e7e5`  
Runtime totalGames field at line node: `82966`

### Packet pirc-black.line-005.ply-04.g8f6

- Move: `Nf6` / `g8f6` at ply 4

- CoachCard: **Pressure e4 with the knight** — Nf6 develops the knight and immediately pressures White’s e4 pawn. In the Pirc, that piece pressure is part of the plan against White’s broad center.

- Plain hint: Bring the kingside knight into contact with White’s central pawn.

- Opening themes: ...Nf6 vs e4, piece pressure, Pirc development

### Packet pirc-black.line-005.ply-06.c7c6

- Move: `c6` / `c7c6` at ply 6

- CoachCard: **Keep the Pirc setup coherent** — c6 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge

### Packet pirc-black.line-005.ply-08.d8a5

- Move: `Qa5` / `d8a5` at ply 8

- CoachCard: **Keep the Pirc setup coherent** — Qa5 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge

### Packet pirc-black.line-005.ply-10.a5c7

- Move: `Qc7` / `a5c7` at ply 10

- CoachCard: **Keep the Pirc setup coherent** — Qc7 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge

### Packet pirc-black.line-005.ply-12.e7e5

- Move: `e5` / `e7e5` at ply 12

- CoachCard: **Strike back with the Pirc e-pawn** — e5 is a direct Pirc counterbreak against White’s center. Black uses development and pawn support to challenge White’s space.

- Plain hint: Challenge White’s central pawns only after the setup supports the break.

- Opening themes: ...e5 counterbreak, central challenge, development before break


## pirc-black-line-006: 1. e4 d6 2. d4 Nf6 3. Nc3 Nbd7 4. f4 e5 5. fxe5 dxe5 6. dxe5 Nxe5

Runtime playKey: `e2e4,d7d6,d2d4,g8f6,b1c3,b8d7,f2f4,e7e5,f4e5,d6e5,d4e5,d7e5`  
Runtime totalGames field at line node: `67404`

### Packet pirc-black.line-006.ply-04.g8f6

- Move: `Nf6` / `g8f6` at ply 4

- CoachCard: **Pressure e4 with the knight** — Nf6 develops the knight and immediately pressures White’s e4 pawn. In the Pirc, that piece pressure is part of the plan against White’s broad center.

- Plain hint: Bring the kingside knight into contact with White’s central pawn.

- Opening themes: ...Nf6 vs e4, piece pressure, Pirc development

### Packet pirc-black.line-006.ply-06.b8d7

- Move: `Nbd7` / `b8d7` at ply 6

- CoachCard: **Support the Pirc center from behind** — Nbd7 develops a knight behind the Pirc pawn structure and supports future central action. It keeps Black compact while preparing counterplay.

- Plain hint: Add a queenside knight defender before choosing the central break.

- Opening themes: ...Nbd7 support, central preparation, compact setup

### Packet pirc-black.line-006.ply-08.e7e5

- Move: `e5` / `e7e5` at ply 8

- CoachCard: **Strike back with the Pirc e-pawn** — e5 is a direct Pirc counterbreak against White’s center. Black uses development and pawn support to challenge White’s space.

- Plain hint: Challenge White’s central pawns only after the setup supports the break.

- Opening themes: ...e5 counterbreak, central challenge, development before break

### Packet pirc-black.line-006.ply-10.d6e5

- Move: `dxe5` / `d6e5` at ply 10

- CoachCard: **Clarify the center after White advances** — dxe5 recaptures in the center after White pushes forward. Black clarifies the position while keeping the Pirc plan tied to White’s central pawns.

- Plain hint: Resolve central tension only when the pawn structure calls for it.

- Opening themes: central clarification, e5 tension, Pirc response

### Packet pirc-black.line-006.ply-12.d7e5

- Move: `Nxe5` / `d7e5` at ply 12

- CoachCard: **Keep the Pirc setup coherent** — Nxe5 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge


## pirc-black-line-007: 1. e4 d6 2. d4 Nf6 3. Nc3 c6 4. Nf3 Qa5 5. Bd3 e5 6. dxe5 dxe5

Runtime playKey: `e2e4,d7d6,d2d4,g8f6,b1c3,c7c6,g1f3,d8a5,f1d3,e7e5,d4e5,d6e5`  
Runtime totalGames field at line node: `66180`

### Packet pirc-black.line-007.ply-04.g8f6

- Move: `Nf6` / `g8f6` at ply 4

- CoachCard: **Pressure e4 with the knight** — Nf6 develops the knight and immediately pressures White’s e4 pawn. In the Pirc, that piece pressure is part of the plan against White’s broad center.

- Plain hint: Bring the kingside knight into contact with White’s central pawn.

- Opening themes: ...Nf6 vs e4, piece pressure, Pirc development

### Packet pirc-black.line-007.ply-06.c7c6

- Move: `c6` / `c7c6` at ply 6

- CoachCard: **Keep the Pirc setup coherent** — c6 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge

### Packet pirc-black.line-007.ply-08.d8a5

- Move: `Qa5` / `d8a5` at ply 8

- CoachCard: **Keep the Pirc setup coherent** — Qa5 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge

### Packet pirc-black.line-007.ply-10.e7e5

- Move: `e5` / `e7e5` at ply 10

- CoachCard: **Strike back with the Pirc e-pawn** — e5 is a direct Pirc counterbreak against White’s center. Black uses development and pawn support to challenge White’s space.

- Plain hint: Challenge White’s central pawns only after the setup supports the break.

- Opening themes: ...e5 counterbreak, central challenge, development before break

### Packet pirc-black.line-007.ply-12.d6e5

- Move: `dxe5` / `d6e5` at ply 12

- CoachCard: **Clarify the center after White advances** — dxe5 recaptures in the center after White pushes forward. Black clarifies the position while keeping the Pirc plan tied to White’s central pawns.

- Plain hint: Resolve central tension only when the pawn structure calls for it.

- Opening themes: central clarification, e5 tension, Pirc response


## pirc-black-line-008: 1. e4 d6 2. d4 Nf6 3. Nc3 Nbd7 4. Nf3 e5 5. Bc4 Be7 6. dxe5 Nxe5

Runtime playKey: `e2e4,d7d6,d2d4,g8f6,b1c3,b8d7,g1f3,e7e5,f1c4,f8e7,d4e5,d7e5`  
Runtime totalGames field at line node: `59822`

### Packet pirc-black.line-008.ply-04.g8f6

- Move: `Nf6` / `g8f6` at ply 4

- CoachCard: **Pressure e4 with the knight** — Nf6 develops the knight and immediately pressures White’s e4 pawn. In the Pirc, that piece pressure is part of the plan against White’s broad center.

- Plain hint: Bring the kingside knight into contact with White’s central pawn.

- Opening themes: ...Nf6 vs e4, piece pressure, Pirc development

### Packet pirc-black.line-008.ply-06.b8d7

- Move: `Nbd7` / `b8d7` at ply 6

- CoachCard: **Support the Pirc center from behind** — Nbd7 develops a knight behind the Pirc pawn structure and supports future central action. It keeps Black compact while preparing counterplay.

- Plain hint: Add a queenside knight defender before choosing the central break.

- Opening themes: ...Nbd7 support, central preparation, compact setup

### Packet pirc-black.line-008.ply-08.e7e5

- Move: `e5` / `e7e5` at ply 8

- CoachCard: **Strike back with the Pirc e-pawn** — e5 is a direct Pirc counterbreak against White’s center. Black uses development and pawn support to challenge White’s space.

- Plain hint: Challenge White’s central pawns only after the setup supports the break.

- Opening themes: ...e5 counterbreak, central challenge, development before break

### Packet pirc-black.line-008.ply-10.f8e7

- Move: `Be7` / `f8e7` at ply 10

- CoachCard: **Keep the Pirc setup coherent** — Be7 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge

### Packet pirc-black.line-008.ply-12.d7e5

- Move: `Nxe5` / `d7e5` at ply 12

- CoachCard: **Keep the Pirc setup coherent** — Nxe5 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge


## pirc-black-line-009: 1. e4 d6 2. d4 Nf6 3. Nc3 g6 4. Bg5 Bg7 5. Nf3 h6 6. Bxf6 Bxf6

Runtime playKey: `e2e4,d7d6,d2d4,g8f6,b1c3,g7g6,c1g5,f8g7,g1f3,h7h6,g5f6,g7f6`  
Runtime totalGames field at line node: `54957`

### Packet pirc-black.line-009.ply-04.g8f6

- Move: `Nf6` / `g8f6` at ply 4

- CoachCard: **Pressure e4 with the knight** — Nf6 develops the knight and immediately pressures White’s e4 pawn. In the Pirc, that piece pressure is part of the plan against White’s broad center.

- Plain hint: Bring the kingside knight into contact with White’s central pawn.

- Opening themes: ...Nf6 vs e4, piece pressure, Pirc development

### Packet pirc-black.line-009.ply-06.g7g6

- Move: `g6` / `g7g6` at ply 6

- CoachCard: **Build the Pirc fianchetto** — g6 prepares the Pirc bishop on the long diagonal. Black lets White occupy space while preparing pressure from a distance.

- Plain hint: Prepare the kingside fianchetto that pressures the long diagonal.

- Opening themes: ...g6 fianchetto, long diagonal, hypermodern pressure

### Packet pirc-black.line-009.ply-08.f8g7

- Move: `Bg7` / `f8g7` at ply 8

- CoachCard: **Complete the Pirc long diagonal** — Bg7 completes the Pirc fianchetto. The bishop supports central counterplay and contests key dark squares from the long diagonal.

- Plain hint: Place the bishop where it can pressure the center from distance.

- Opening themes: g7 bishop, long diagonal, central counterplay

### Packet pirc-black.line-009.ply-10.h7h6

- Move: `h6` / `h7h6` at ply 10

- CoachCard: **Keep the Pirc setup coherent** — h6 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge

### Packet pirc-black.line-009.ply-12.g7f6

- Move: `Bxf6` / `g7f6` at ply 12

- CoachCard: **Keep the Pirc setup coherent** — Bxf6 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge


## pirc-black-line-010: 1. e4 d6 2. d4 Nf6 3. Nc3 g6 4. Bg5 Bg7 5. e5 dxe5 6. dxe5 Nfd7

Runtime playKey: `e2e4,d7d6,d2d4,g8f6,b1c3,g7g6,c1g5,f8g7,e4e5,d6e5,d4e5,f6d7`  
Runtime totalGames field at line node: `48737`

### Packet pirc-black.line-010.ply-04.g8f6

- Move: `Nf6` / `g8f6` at ply 4

- CoachCard: **Pressure e4 with the knight** — Nf6 develops the knight and immediately pressures White’s e4 pawn. In the Pirc, that piece pressure is part of the plan against White’s broad center.

- Plain hint: Bring the kingside knight into contact with White’s central pawn.

- Opening themes: ...Nf6 vs e4, piece pressure, Pirc development

### Packet pirc-black.line-010.ply-06.g7g6

- Move: `g6` / `g7g6` at ply 6

- CoachCard: **Build the Pirc fianchetto** — g6 prepares the Pirc bishop on the long diagonal. Black lets White occupy space while preparing pressure from a distance.

- Plain hint: Prepare the kingside fianchetto that pressures the long diagonal.

- Opening themes: ...g6 fianchetto, long diagonal, hypermodern pressure

### Packet pirc-black.line-010.ply-08.f8g7

- Move: `Bg7` / `f8g7` at ply 8

- CoachCard: **Complete the Pirc long diagonal** — Bg7 completes the Pirc fianchetto. The bishop supports central counterplay and contests key dark squares from the long diagonal.

- Plain hint: Place the bishop where it can pressure the center from distance.

- Opening themes: g7 bishop, long diagonal, central counterplay

### Packet pirc-black.line-010.ply-10.d6e5

- Move: `dxe5` / `d6e5` at ply 10

- CoachCard: **Clarify the center after White advances** — dxe5 recaptures in the center after White pushes forward. Black clarifies the position while keeping the Pirc plan tied to White’s central pawns.

- Plain hint: Resolve central tension only when the pawn structure calls for it.

- Opening themes: central clarification, e5 tension, Pirc response

### Packet pirc-black.line-010.ply-12.f6d7

- Move: `Nfd7` / `f6d7` at ply 12

- CoachCard: **Keep the Pirc setup coherent** — Nfd7 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge


## pirc-black-line-011: 1. e4 d6 2. d4 Nf6 3. Nc3 Nbd7 4. Nf3 e5 5. dxe5 dxe5 6. Bg5 c6

Runtime playKey: `e2e4,d7d6,d2d4,g8f6,b1c3,b8d7,g1f3,e7e5,d4e5,d6e5,c1g5,c7c6`  
Runtime totalGames field at line node: `48064`

### Packet pirc-black.line-011.ply-04.g8f6

- Move: `Nf6` / `g8f6` at ply 4

- CoachCard: **Pressure e4 with the knight** — Nf6 develops the knight and immediately pressures White’s e4 pawn. In the Pirc, that piece pressure is part of the plan against White’s broad center.

- Plain hint: Bring the kingside knight into contact with White’s central pawn.

- Opening themes: ...Nf6 vs e4, piece pressure, Pirc development

### Packet pirc-black.line-011.ply-06.b8d7

- Move: `Nbd7` / `b8d7` at ply 6

- CoachCard: **Support the Pirc center from behind** — Nbd7 develops a knight behind the Pirc pawn structure and supports future central action. It keeps Black compact while preparing counterplay.

- Plain hint: Add a queenside knight defender before choosing the central break.

- Opening themes: ...Nbd7 support, central preparation, compact setup

### Packet pirc-black.line-011.ply-08.e7e5

- Move: `e5` / `e7e5` at ply 8

- CoachCard: **Strike back with the Pirc e-pawn** — e5 is a direct Pirc counterbreak against White’s center. Black uses development and pawn support to challenge White’s space.

- Plain hint: Challenge White’s central pawns only after the setup supports the break.

- Opening themes: ...e5 counterbreak, central challenge, development before break

### Packet pirc-black.line-011.ply-10.d6e5

- Move: `dxe5` / `d6e5` at ply 10

- CoachCard: **Clarify the center after White advances** — dxe5 recaptures in the center after White pushes forward. Black clarifies the position while keeping the Pirc plan tied to White’s central pawns.

- Plain hint: Resolve central tension only when the pawn structure calls for it.

- Opening themes: central clarification, e5 tension, Pirc response

### Packet pirc-black.line-011.ply-12.c7c6

- Move: `c6` / `c7c6` at ply 12

- CoachCard: **Keep the Pirc setup coherent** — c6 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge


## pirc-black-line-012: 1. e4 d6 2. d4 Nf6 3. Nc3 g6 4. Bg5 Bg7 5. e5 Nfd7 6. exd6 cxd6

Runtime playKey: `e2e4,d7d6,d2d4,g8f6,b1c3,g7g6,c1g5,f8g7,e4e5,f6d7,e5d6,c7d6`  
Runtime totalGames field at line node: `42234`

### Packet pirc-black.line-012.ply-04.g8f6

- Move: `Nf6` / `g8f6` at ply 4

- CoachCard: **Pressure e4 with the knight** — Nf6 develops the knight and immediately pressures White’s e4 pawn. In the Pirc, that piece pressure is part of the plan against White’s broad center.

- Plain hint: Bring the kingside knight into contact with White’s central pawn.

- Opening themes: ...Nf6 vs e4, piece pressure, Pirc development

### Packet pirc-black.line-012.ply-06.g7g6

- Move: `g6` / `g7g6` at ply 6

- CoachCard: **Build the Pirc fianchetto** — g6 prepares the Pirc bishop on the long diagonal. Black lets White occupy space while preparing pressure from a distance.

- Plain hint: Prepare the kingside fianchetto that pressures the long diagonal.

- Opening themes: ...g6 fianchetto, long diagonal, hypermodern pressure

### Packet pirc-black.line-012.ply-08.f8g7

- Move: `Bg7` / `f8g7` at ply 8

- CoachCard: **Complete the Pirc long diagonal** — Bg7 completes the Pirc fianchetto. The bishop supports central counterplay and contests key dark squares from the long diagonal.

- Plain hint: Place the bishop where it can pressure the center from distance.

- Opening themes: g7 bishop, long diagonal, central counterplay

### Packet pirc-black.line-012.ply-10.f6d7

- Move: `Nfd7` / `f6d7` at ply 10

- CoachCard: **Keep the Pirc setup coherent** — Nfd7 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge

### Packet pirc-black.line-012.ply-12.c7d6

- Move: `cxd6` / `c7d6` at ply 12

- CoachCard: **Keep the Pirc setup coherent** — cxd6 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge


## pirc-black-line-013: 1. e4 d6 2. d4 Nf6 3. Nc3 g6 4. Bg5 Bg7 5. Nf3 h6 6. Bh4 g5

Runtime playKey: `e2e4,d7d6,d2d4,g8f6,b1c3,g7g6,c1g5,f8g7,g1f3,h7h6,g5h4,g6g5`  
Runtime totalGames field at line node: `38318`

### Packet pirc-black.line-013.ply-04.g8f6

- Move: `Nf6` / `g8f6` at ply 4

- CoachCard: **Pressure e4 with the knight** — Nf6 develops the knight and immediately pressures White’s e4 pawn. In the Pirc, that piece pressure is part of the plan against White’s broad center.

- Plain hint: Bring the kingside knight into contact with White’s central pawn.

- Opening themes: ...Nf6 vs e4, piece pressure, Pirc development

### Packet pirc-black.line-013.ply-06.g7g6

- Move: `g6` / `g7g6` at ply 6

- CoachCard: **Build the Pirc fianchetto** — g6 prepares the Pirc bishop on the long diagonal. Black lets White occupy space while preparing pressure from a distance.

- Plain hint: Prepare the kingside fianchetto that pressures the long diagonal.

- Opening themes: ...g6 fianchetto, long diagonal, hypermodern pressure

### Packet pirc-black.line-013.ply-08.f8g7

- Move: `Bg7` / `f8g7` at ply 8

- CoachCard: **Complete the Pirc long diagonal** — Bg7 completes the Pirc fianchetto. The bishop supports central counterplay and contests key dark squares from the long diagonal.

- Plain hint: Place the bishop where it can pressure the center from distance.

- Opening themes: g7 bishop, long diagonal, central counterplay

### Packet pirc-black.line-013.ply-10.h7h6

- Move: `h6` / `h7h6` at ply 10

- CoachCard: **Keep the Pirc setup coherent** — h6 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge

### Packet pirc-black.line-013.ply-12.g6g5

- Move: `g5` / `g6g5` at ply 12

- CoachCard: **Keep the Pirc setup coherent** — g5 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge


## pirc-black-line-014: 1. e4 d6 2. d4 Nf6 3. Nc3 c6 4. f4 Qa5 5. Bd3 Bg4 6. Nf3 e5

Runtime playKey: `e2e4,d7d6,d2d4,g8f6,b1c3,c7c6,f2f4,d8a5,f1d3,c8g4,g1f3,e7e5`  
Runtime totalGames field at line node: `36730`

### Packet pirc-black.line-014.ply-04.g8f6

- Move: `Nf6` / `g8f6` at ply 4

- CoachCard: **Pressure e4 with the knight** — Nf6 develops the knight and immediately pressures White’s e4 pawn. In the Pirc, that piece pressure is part of the plan against White’s broad center.

- Plain hint: Bring the kingside knight into contact with White’s central pawn.

- Opening themes: ...Nf6 vs e4, piece pressure, Pirc development

### Packet pirc-black.line-014.ply-06.c7c6

- Move: `c6` / `c7c6` at ply 6

- CoachCard: **Keep the Pirc setup coherent** — c6 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge

### Packet pirc-black.line-014.ply-08.d8a5

- Move: `Qa5` / `d8a5` at ply 8

- CoachCard: **Keep the Pirc setup coherent** — Qa5 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge

### Packet pirc-black.line-014.ply-10.c8g4

- Move: `Bg4` / `c8g4` at ply 10

- CoachCard: **Pressure a central defender with the bishop** — Bg4 develops the bishop to pressure a knight or central defender in the Pirc setup. It gives Black activity without claiming premature central space.

- Plain hint: Use the bishop to question a piece that helps White’s center.

- Opening themes: bishop pressure, central defender, Pirc activity

### Packet pirc-black.line-014.ply-12.e7e5

- Move: `e5` / `e7e5` at ply 12

- CoachCard: **Strike back with the Pirc e-pawn** — e5 is a direct Pirc counterbreak against White’s center. Black uses development and pawn support to challenge White’s space.

- Plain hint: Challenge White’s central pawns only after the setup supports the break.

- Opening themes: ...e5 counterbreak, central challenge, development before break


## pirc-black-line-015: 1. e4 d6 2. d4 Nf6 3. Nc3 Nbd7 4. f4 e5 5. Nf3 exd4 6. Qxd4 c6

Runtime playKey: `e2e4,d7d6,d2d4,g8f6,b1c3,b8d7,f2f4,e7e5,g1f3,e5d4,d1d4,c7c6`  
Runtime totalGames field at line node: `33969`

### Packet pirc-black.line-015.ply-04.g8f6

- Move: `Nf6` / `g8f6` at ply 4

- CoachCard: **Pressure e4 with the knight** — Nf6 develops the knight and immediately pressures White’s e4 pawn. In the Pirc, that piece pressure is part of the plan against White’s broad center.

- Plain hint: Bring the kingside knight into contact with White’s central pawn.

- Opening themes: ...Nf6 vs e4, piece pressure, Pirc development

### Packet pirc-black.line-015.ply-06.b8d7

- Move: `Nbd7` / `b8d7` at ply 6

- CoachCard: **Support the Pirc center from behind** — Nbd7 develops a knight behind the Pirc pawn structure and supports future central action. It keeps Black compact while preparing counterplay.

- Plain hint: Add a queenside knight defender before choosing the central break.

- Opening themes: ...Nbd7 support, central preparation, compact setup

### Packet pirc-black.line-015.ply-08.e7e5

- Move: `e5` / `e7e5` at ply 8

- CoachCard: **Strike back with the Pirc e-pawn** — e5 is a direct Pirc counterbreak against White’s center. Black uses development and pawn support to challenge White’s space.

- Plain hint: Challenge White’s central pawns only after the setup supports the break.

- Opening themes: ...e5 counterbreak, central challenge, development before break

### Packet pirc-black.line-015.ply-10.e5d4

- Move: `exd4` / `e5d4` at ply 10

- CoachCard: **Keep the Pirc setup coherent** — exd4 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge

### Packet pirc-black.line-015.ply-12.c7c6

- Move: `c6` / `c7c6` at ply 12

- CoachCard: **Keep the Pirc setup coherent** — c6 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge


## pirc-black-line-016: 1. e4 d6 2. d4 Nf6 3. Nc3 c6 4. Nf3 Bg4 5. Be2 Nbd7 6. h3 Bh5

Runtime playKey: `e2e4,d7d6,d2d4,g8f6,b1c3,c7c6,g1f3,c8g4,f1e2,b8d7,h2h3,g4h5`  
Runtime totalGames field at line node: `32597`

### Packet pirc-black.line-016.ply-04.g8f6

- Move: `Nf6` / `g8f6` at ply 4

- CoachCard: **Pressure e4 with the knight** — Nf6 develops the knight and immediately pressures White’s e4 pawn. In the Pirc, that piece pressure is part of the plan against White’s broad center.

- Plain hint: Bring the kingside knight into contact with White’s central pawn.

- Opening themes: ...Nf6 vs e4, piece pressure, Pirc development

### Packet pirc-black.line-016.ply-06.c7c6

- Move: `c6` / `c7c6` at ply 6

- CoachCard: **Keep the Pirc setup coherent** — c6 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge

### Packet pirc-black.line-016.ply-08.c8g4

- Move: `Bg4` / `c8g4` at ply 8

- CoachCard: **Pressure a central defender with the bishop** — Bg4 develops the bishop to pressure a knight or central defender in the Pirc setup. It gives Black activity without claiming premature central space.

- Plain hint: Use the bishop to question a piece that helps White’s center.

- Opening themes: bishop pressure, central defender, Pirc activity

### Packet pirc-black.line-016.ply-10.b8d7

- Move: `Nbd7` / `b8d7` at ply 10

- CoachCard: **Support the Pirc center from behind** — Nbd7 develops a knight behind the Pirc pawn structure and supports future central action. It keeps Black compact while preparing counterplay.

- Plain hint: Add a queenside knight defender before choosing the central break.

- Opening themes: ...Nbd7 support, central preparation, compact setup

### Packet pirc-black.line-016.ply-12.g4h5

- Move: `Bh5` / `g4h5` at ply 12

- CoachCard: **Keep the Pirc setup coherent** — Bh5 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge


## pirc-black-line-017: 1. e4 d6 2. d4 Nf6 3. Nc3 c6 4. Nf3 Qa5 5. Bd2 Qc7 6. Bd3 Bg4

Runtime playKey: `e2e4,d7d6,d2d4,g8f6,b1c3,c7c6,g1f3,d8a5,c1d2,a5c7,f1d3,c8g4`  
Runtime totalGames field at line node: `32551`

### Packet pirc-black.line-017.ply-04.g8f6

- Move: `Nf6` / `g8f6` at ply 4

- CoachCard: **Pressure e4 with the knight** — Nf6 develops the knight and immediately pressures White’s e4 pawn. In the Pirc, that piece pressure is part of the plan against White’s broad center.

- Plain hint: Bring the kingside knight into contact with White’s central pawn.

- Opening themes: ...Nf6 vs e4, piece pressure, Pirc development

### Packet pirc-black.line-017.ply-06.c7c6

- Move: `c6` / `c7c6` at ply 6

- CoachCard: **Keep the Pirc setup coherent** — c6 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge

### Packet pirc-black.line-017.ply-08.d8a5

- Move: `Qa5` / `d8a5` at ply 8

- CoachCard: **Keep the Pirc setup coherent** — Qa5 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge

### Packet pirc-black.line-017.ply-10.a5c7

- Move: `Qc7` / `a5c7` at ply 10

- CoachCard: **Keep the Pirc setup coherent** — Qc7 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge

### Packet pirc-black.line-017.ply-12.c8g4

- Move: `Bg4` / `c8g4` at ply 12

- CoachCard: **Pressure a central defender with the bishop** — Bg4 develops the bishop to pressure a knight or central defender in the Pirc setup. It gives Black activity without claiming premature central space.

- Plain hint: Use the bishop to question a piece that helps White’s center.

- Opening themes: bishop pressure, central defender, Pirc activity


## pirc-black-line-018: 1. e4 d6 2. d4 Nf6 3. Bd3 e5 4. c3 d5 5. dxe5 Nxe4 6. Bxe4 dxe4

Runtime playKey: `e2e4,d7d6,d2d4,g8f6,f1d3,e7e5,c2c3,d6d5,d4e5,f6e4,d3e4,d5e4`  
Runtime totalGames field at line node: `30893`

### Packet pirc-black.line-018.ply-04.g8f6

- Move: `Nf6` / `g8f6` at ply 4

- CoachCard: **Pressure e4 with the knight** — Nf6 develops the knight and immediately pressures White’s e4 pawn. In the Pirc, that piece pressure is part of the plan against White’s broad center.

- Plain hint: Bring the kingside knight into contact with White’s central pawn.

- Opening themes: ...Nf6 vs e4, piece pressure, Pirc development

### Packet pirc-black.line-018.ply-06.e7e5

- Move: `e5` / `e7e5` at ply 6

- CoachCard: **Strike back with the Pirc e-pawn** — e5 is a direct Pirc counterbreak against White’s center. Black uses development and pawn support to challenge White’s space.

- Plain hint: Challenge White’s central pawns only after the setup supports the break.

- Opening themes: ...e5 counterbreak, central challenge, development before break

### Packet pirc-black.line-018.ply-08.d6d5

- Move: `d5` / `d6d5` at ply 8

- CoachCard: **Keep the Pirc setup coherent** — d5 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge

### Packet pirc-black.line-018.ply-10.f6e4

- Move: `Nxe4` / `f6e4` at ply 10

- CoachCard: **Keep the Pirc setup coherent** — Nxe4 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge

### Packet pirc-black.line-018.ply-12.d5e4

- Move: `dxe4` / `d5e4` at ply 12

- CoachCard: **Keep the Pirc setup coherent** — dxe4 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge


## pirc-black-line-019: 1. e4 d6 2. d4 Nf6 3. Nc3 Nbd7 4. f4 e5 5. Nf3 exd4 6. Nxd4 g6

Runtime playKey: `e2e4,d7d6,d2d4,g8f6,b1c3,b8d7,f2f4,e7e5,g1f3,e5d4,f3d4,g7g6`  
Runtime totalGames field at line node: `30091`

### Packet pirc-black.line-019.ply-04.g8f6

- Move: `Nf6` / `g8f6` at ply 4

- CoachCard: **Pressure e4 with the knight** — Nf6 develops the knight and immediately pressures White’s e4 pawn. In the Pirc, that piece pressure is part of the plan against White’s broad center.

- Plain hint: Bring the kingside knight into contact with White’s central pawn.

- Opening themes: ...Nf6 vs e4, piece pressure, Pirc development

### Packet pirc-black.line-019.ply-06.b8d7

- Move: `Nbd7` / `b8d7` at ply 6

- CoachCard: **Support the Pirc center from behind** — Nbd7 develops a knight behind the Pirc pawn structure and supports future central action. It keeps Black compact while preparing counterplay.

- Plain hint: Add a queenside knight defender before choosing the central break.

- Opening themes: ...Nbd7 support, central preparation, compact setup

### Packet pirc-black.line-019.ply-08.e7e5

- Move: `e5` / `e7e5` at ply 8

- CoachCard: **Strike back with the Pirc e-pawn** — e5 is a direct Pirc counterbreak against White’s center. Black uses development and pawn support to challenge White’s space.

- Plain hint: Challenge White’s central pawns only after the setup supports the break.

- Opening themes: ...e5 counterbreak, central challenge, development before break

### Packet pirc-black.line-019.ply-10.e5d4

- Move: `exd4` / `e5d4` at ply 10

- CoachCard: **Keep the Pirc setup coherent** — exd4 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge

### Packet pirc-black.line-019.ply-12.g7g6

- Move: `g6` / `g7g6` at ply 12

- CoachCard: **Build the Pirc fianchetto** — g6 prepares the Pirc bishop on the long diagonal. Black lets White occupy space while preparing pressure from a distance.

- Plain hint: Prepare the kingside fianchetto that pressures the long diagonal.

- Opening themes: ...g6 fianchetto, long diagonal, hypermodern pressure


## pirc-black-line-020: 1. e4 d6 2. d4 Nf6 3. Nc3 c6 4. Nf3 Qa5 5. Bd2 Qc7 6. Bc4 e5

Runtime playKey: `e2e4,d7d6,d2d4,g8f6,b1c3,c7c6,g1f3,d8a5,c1d2,a5c7,f1c4,e7e5`  
Runtime totalGames field at line node: `30077`

### Packet pirc-black.line-020.ply-04.g8f6

- Move: `Nf6` / `g8f6` at ply 4

- CoachCard: **Pressure e4 with the knight** — Nf6 develops the knight and immediately pressures White’s e4 pawn. In the Pirc, that piece pressure is part of the plan against White’s broad center.

- Plain hint: Bring the kingside knight into contact with White’s central pawn.

- Opening themes: ...Nf6 vs e4, piece pressure, Pirc development

### Packet pirc-black.line-020.ply-06.c7c6

- Move: `c6` / `c7c6` at ply 6

- CoachCard: **Keep the Pirc setup coherent** — c6 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge

### Packet pirc-black.line-020.ply-08.d8a5

- Move: `Qa5` / `d8a5` at ply 8

- CoachCard: **Keep the Pirc setup coherent** — Qa5 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge

### Packet pirc-black.line-020.ply-10.a5c7

- Move: `Qc7` / `a5c7` at ply 10

- CoachCard: **Keep the Pirc setup coherent** — Qc7 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge

### Packet pirc-black.line-020.ply-12.e7e5

- Move: `e5` / `e7e5` at ply 12

- CoachCard: **Strike back with the Pirc e-pawn** — e5 is a direct Pirc counterbreak against White’s center. Black uses development and pawn support to challenge White’s space.

- Plain hint: Challenge White’s central pawns only after the setup supports the break.

- Opening themes: ...e5 counterbreak, central challenge, development before break


## pirc-black-line-021: 1. e4 d6 2. d4 Nf6 3. Nc3 c6 4. Nf3 Bg4 5. h3 Bh5 6. g4 Bg6

Runtime playKey: `e2e4,d7d6,d2d4,g8f6,b1c3,c7c6,g1f3,c8g4,h2h3,g4h5,g2g4,h5g6`  
Runtime totalGames field at line node: `30010`

### Packet pirc-black.line-021.ply-04.g8f6

- Move: `Nf6` / `g8f6` at ply 4

- CoachCard: **Pressure e4 with the knight** — Nf6 develops the knight and immediately pressures White’s e4 pawn. In the Pirc, that piece pressure is part of the plan against White’s broad center.

- Plain hint: Bring the kingside knight into contact with White’s central pawn.

- Opening themes: ...Nf6 vs e4, piece pressure, Pirc development

### Packet pirc-black.line-021.ply-06.c7c6

- Move: `c6` / `c7c6` at ply 6

- CoachCard: **Keep the Pirc setup coherent** — c6 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge

### Packet pirc-black.line-021.ply-08.c8g4

- Move: `Bg4` / `c8g4` at ply 8

- CoachCard: **Pressure a central defender with the bishop** — Bg4 develops the bishop to pressure a knight or central defender in the Pirc setup. It gives Black activity without claiming premature central space.

- Plain hint: Use the bishop to question a piece that helps White’s center.

- Opening themes: bishop pressure, central defender, Pirc activity

### Packet pirc-black.line-021.ply-10.g4h5

- Move: `Bh5` / `g4h5` at ply 10

- CoachCard: **Keep the Pirc setup coherent** — Bh5 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge

### Packet pirc-black.line-021.ply-12.h5g6

- Move: `Bg6` / `h5g6` at ply 12

- CoachCard: **Keep the Pirc setup coherent** — Bg6 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge


## pirc-black-line-022: 1. e4 d6 2. d4 Nf6 3. Nc3 c6 4. Nf3 Bg4 5. h3 Bxf3 6. Qxf3 Nbd7

Runtime playKey: `e2e4,d7d6,d2d4,g8f6,b1c3,c7c6,g1f3,c8g4,h2h3,g4f3,d1f3,b8d7`  
Runtime totalGames field at line node: `26170`

### Packet pirc-black.line-022.ply-04.g8f6

- Move: `Nf6` / `g8f6` at ply 4

- CoachCard: **Pressure e4 with the knight** — Nf6 develops the knight and immediately pressures White’s e4 pawn. In the Pirc, that piece pressure is part of the plan against White’s broad center.

- Plain hint: Bring the kingside knight into contact with White’s central pawn.

- Opening themes: ...Nf6 vs e4, piece pressure, Pirc development

### Packet pirc-black.line-022.ply-06.c7c6

- Move: `c6` / `c7c6` at ply 6

- CoachCard: **Keep the Pirc setup coherent** — c6 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge

### Packet pirc-black.line-022.ply-08.c8g4

- Move: `Bg4` / `c8g4` at ply 8

- CoachCard: **Pressure a central defender with the bishop** — Bg4 develops the bishop to pressure a knight or central defender in the Pirc setup. It gives Black activity without claiming premature central space.

- Plain hint: Use the bishop to question a piece that helps White’s center.

- Opening themes: bishop pressure, central defender, Pirc activity

### Packet pirc-black.line-022.ply-10.g4f3

- Move: `Bxf3` / `g4f3` at ply 10

- CoachCard: **Keep the Pirc setup coherent** — Bxf3 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge

### Packet pirc-black.line-022.ply-12.b8d7

- Move: `Nbd7` / `b8d7` at ply 12

- CoachCard: **Support the Pirc center from behind** — Nbd7 develops a knight behind the Pirc pawn structure and supports future central action. It keeps Black compact while preparing counterplay.

- Plain hint: Add a queenside knight defender before choosing the central break.

- Opening themes: ...Nbd7 support, central preparation, compact setup


## pirc-black-line-023: 1. e4 d6 2. d4 Nf6 3. Nc3 c6 4. Nf3 Bg4 5. Be2 e6 6. h3 Bh5

Runtime playKey: `e2e4,d7d6,d2d4,g8f6,b1c3,c7c6,g1f3,c8g4,f1e2,e7e6,h2h3,g4h5`  
Runtime totalGames field at line node: `25827`

### Packet pirc-black.line-023.ply-04.g8f6

- Move: `Nf6` / `g8f6` at ply 4

- CoachCard: **Pressure e4 with the knight** — Nf6 develops the knight and immediately pressures White’s e4 pawn. In the Pirc, that piece pressure is part of the plan against White’s broad center.

- Plain hint: Bring the kingside knight into contact with White’s central pawn.

- Opening themes: ...Nf6 vs e4, piece pressure, Pirc development

### Packet pirc-black.line-023.ply-06.c7c6

- Move: `c6` / `c7c6` at ply 6

- CoachCard: **Keep the Pirc setup coherent** — c6 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge

### Packet pirc-black.line-023.ply-08.c8g4

- Move: `Bg4` / `c8g4` at ply 8

- CoachCard: **Pressure a central defender with the bishop** — Bg4 develops the bishop to pressure a knight or central defender in the Pirc setup. It gives Black activity without claiming premature central space.

- Plain hint: Use the bishop to question a piece that helps White’s center.

- Opening themes: bishop pressure, central defender, Pirc activity

### Packet pirc-black.line-023.ply-10.e7e6

- Move: `e6` / `e7e6` at ply 10

- CoachCard: **Keep the Pirc setup coherent** — e6 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge

### Packet pirc-black.line-023.ply-12.g4h5

- Move: `Bh5` / `g4h5` at ply 12

- CoachCard: **Keep the Pirc setup coherent** — Bh5 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge


## pirc-black-line-024: 1. e4 d6 2. d4 Nf6 3. Nc3 c6 4. Nf3 Qa5 5. Bd2 Qc7 6. Bc4 Bg4

Runtime playKey: `e2e4,d7d6,d2d4,g8f6,b1c3,c7c6,g1f3,d8a5,c1d2,a5c7,f1c4,c8g4`  
Runtime totalGames field at line node: `25403`

### Packet pirc-black.line-024.ply-04.g8f6

- Move: `Nf6` / `g8f6` at ply 4

- CoachCard: **Pressure e4 with the knight** — Nf6 develops the knight and immediately pressures White’s e4 pawn. In the Pirc, that piece pressure is part of the plan against White’s broad center.

- Plain hint: Bring the kingside knight into contact with White’s central pawn.

- Opening themes: ...Nf6 vs e4, piece pressure, Pirc development

### Packet pirc-black.line-024.ply-06.c7c6

- Move: `c6` / `c7c6` at ply 6

- CoachCard: **Keep the Pirc setup coherent** — c6 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge

### Packet pirc-black.line-024.ply-08.d8a5

- Move: `Qa5` / `d8a5` at ply 8

- CoachCard: **Keep the Pirc setup coherent** — Qa5 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge

### Packet pirc-black.line-024.ply-10.a5c7

- Move: `Qc7` / `a5c7` at ply 10

- CoachCard: **Keep the Pirc setup coherent** — Qc7 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge

### Packet pirc-black.line-024.ply-12.c8g4

- Move: `Bg4` / `c8g4` at ply 12

- CoachCard: **Pressure a central defender with the bishop** — Bg4 develops the bishop to pressure a knight or central defender in the Pirc setup. It gives Black activity without claiming premature central space.

- Plain hint: Use the bishop to question a piece that helps White’s center.

- Opening themes: bishop pressure, central defender, Pirc activity


## pirc-black-line-025: 1. e4 d6 2. d4 Nf6 3. Nc3 g6 4. Bg5 Bg7 5. Nf3 h6 6. Bxf6 exf6

Runtime playKey: `e2e4,d7d6,d2d4,g8f6,b1c3,g7g6,c1g5,f8g7,g1f3,h7h6,g5f6,e7f6`  
Runtime totalGames field at line node: `23258`

### Packet pirc-black.line-025.ply-04.g8f6

- Move: `Nf6` / `g8f6` at ply 4

- CoachCard: **Pressure e4 with the knight** — Nf6 develops the knight and immediately pressures White’s e4 pawn. In the Pirc, that piece pressure is part of the plan against White’s broad center.

- Plain hint: Bring the kingside knight into contact with White’s central pawn.

- Opening themes: ...Nf6 vs e4, piece pressure, Pirc development

### Packet pirc-black.line-025.ply-06.g7g6

- Move: `g6` / `g7g6` at ply 6

- CoachCard: **Build the Pirc fianchetto** — g6 prepares the Pirc bishop on the long diagonal. Black lets White occupy space while preparing pressure from a distance.

- Plain hint: Prepare the kingside fianchetto that pressures the long diagonal.

- Opening themes: ...g6 fianchetto, long diagonal, hypermodern pressure

### Packet pirc-black.line-025.ply-08.f8g7

- Move: `Bg7` / `f8g7` at ply 8

- CoachCard: **Complete the Pirc long diagonal** — Bg7 completes the Pirc fianchetto. The bishop supports central counterplay and contests key dark squares from the long diagonal.

- Plain hint: Place the bishop where it can pressure the center from distance.

- Opening themes: g7 bishop, long diagonal, central counterplay

### Packet pirc-black.line-025.ply-10.h7h6

- Move: `h6` / `h7h6` at ply 10

- CoachCard: **Keep the Pirc setup coherent** — h6 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge

### Packet pirc-black.line-025.ply-12.e7f6

- Move: `exf6` / `e7f6` at ply 12

- CoachCard: **Keep the Pirc setup coherent** — exf6 supports the Pirc plan: compact development, pressure on White’s center, and delayed central counterplay.

- Plain hint: Develop behind the compact setup and prepare to challenge White’s center.

- Opening themes: Pirc setup, hypermodern pressure, center challenge
