# Réti Opening approved-content candidates — Batch 3

Opening ID: `reti-white`  
Status: approved candidates only; not app-activated.


## reti-white-line-001: 1. Nf3 d5 2. c4 c6 3. d4 e6 4. Nc3 Nf6 5. Bg5 Nbd7 6. e3 Be7

Runtime playKey: `g1f3,d7d5,c2c4,c7c6,d2d4,e7e6,b1c3,g8f6,c1g5,b8d7,e2e3,f8e7`  
Runtime totalGames field at line node: `1385042`

### Packet reti-white.line-001.ply-03.c2c4

- Move: `c4` / `c2c4` at ply 3

- CoachCard: **Add flank pressure on d5** — c4 adds the Réti/English-style flank challenge to Black’s d5 square. White still keeps central pawn choices flexible while making Black defend the center.

- Plain hint: Use the flank pawn to pressure Black’s queen-pawn center from the side.

- Opening themes: c4 pressure, d5 target, flank control

### Packet reti-white.line-001.ply-05.d2d4

- Move: `d4` / `d2d4` at ply 5

- CoachCard: **Transpose from Réti pressure into a queen-pawn center** — d4 turns the Réti move order into direct central occupation. White uses earlier knight and c-pawn pressure to support the d-pawn center.

- Plain hint: Commit the queen pawn only after the piece and flank pressure already support the center.

- Opening themes: d4 transposition, central occupation, prepared center

### Packet reti-white.line-001.ply-07.b1c3

- Move: `Nc3` / `b1c3` at ply 7

- CoachCard: **Reinforce the Réti dark-square pressure** — Nc3 adds another piece to the central fight, especially around d5 and e4. In Réti move orders it supports either a queen-pawn transposition or continued flank control.

- Plain hint: Develop the queenside knight to add support behind the flank and central pressure.

- Opening themes: dark-square pressure, piece support, flexible transposition

### Packet reti-white.line-001.ply-09.c1g5

- Move: `Bg5` / `c1g5` at ply 9

- CoachCard: **Pressure a defender from a Réti move order** — Bg5 develops the bishop to pressure a kingside defender in a Réti-to-queen-pawn structure. The move connects piece activity to Black’s central support.

- Plain hint: Use bishop development to pressure a defender of Black’s central setup.

- Opening themes: bishop pressure, defender pressure, queen-pawn transposition

### Packet reti-white.line-001.ply-11.e2e3

- Move: `e3` / `e2e3` at ply 11

- CoachCard: **Support the prepared Réti center** — e3 supports White’s central structure and opens the light-square bishop route. In Réti transpositions, it keeps development safe before further central decisions.

- Plain hint: Support the queen-pawn setup and open a bishop route without forcing the center open.

- Opening themes: central support, safe development, transposition structure


## reti-white-line-002: 1. Nf3 d5 2. c4 e6 3. d4 c5 4. Nc3 Nc6 5. e3 cxd4 6. exd4 Nf6

Runtime playKey: `g1f3,d7d5,c2c4,e7e6,d2d4,c7c5,b1c3,b8c6,e2e3,c5d4,e3d4,g8f6`  
Runtime totalGames field at line node: `794103`

### Packet reti-white.line-002.ply-03.c2c4

- Move: `c4` / `c2c4` at ply 3

- CoachCard: **Add flank pressure on d5** — c4 adds the Réti/English-style flank challenge to Black’s d5 square. White still keeps central pawn choices flexible while making Black defend the center.

- Plain hint: Use the flank pawn to pressure Black’s queen-pawn center from the side.

- Opening themes: c4 pressure, d5 target, flank control

### Packet reti-white.line-002.ply-05.d2d4

- Move: `d4` / `d2d4` at ply 5

- CoachCard: **Transpose from Réti pressure into a queen-pawn center** — d4 turns the Réti move order into direct central occupation. White uses earlier knight and c-pawn pressure to support the d-pawn center.

- Plain hint: Commit the queen pawn only after the piece and flank pressure already support the center.

- Opening themes: d4 transposition, central occupation, prepared center

### Packet reti-white.line-002.ply-07.b1c3

- Move: `Nc3` / `b1c3` at ply 7

- CoachCard: **Reinforce the Réti dark-square pressure** — Nc3 adds another piece to the central fight, especially around d5 and e4. In Réti move orders it supports either a queen-pawn transposition or continued flank control.

- Plain hint: Develop the queenside knight to add support behind the flank and central pressure.

- Opening themes: dark-square pressure, piece support, flexible transposition

### Packet reti-white.line-002.ply-09.e2e3

- Move: `e3` / `e2e3` at ply 9

- CoachCard: **Support the prepared Réti center** — e3 supports White’s central structure and opens the light-square bishop route. In Réti transpositions, it keeps development safe before further central decisions.

- Plain hint: Support the queen-pawn setup and open a bishop route without forcing the center open.

- Opening themes: central support, safe development, transposition structure

### Packet reti-white.line-002.ply-11.e3d4

- Move: `exd4` / `e3d4` at ply 11

- CoachCard: **Keep Réti pressure flexible** — exd4 keeps the line tied to Réti ideas: flexible development, central pressure from distance, and transposition awareness.

- Plain hint: Maintain piece pressure on the center and avoid committing pawns before the structure is clear.

- Opening themes: Réti flexibility, remote central control, development


## reti-white-line-003: 1. Nf3 d5 2. c4 e6 3. cxd5 exd5 4. d4 Nf6 5. Bg5 c6 6. Nc3 Be7

Runtime playKey: `g1f3,d7d5,c2c4,e7e6,c4d5,e6d5,d2d4,g8f6,c1g5,c7c6,b1c3,f8e7`  
Runtime totalGames field at line node: `688605`

### Packet reti-white.line-003.ply-03.c2c4

- Move: `c4` / `c2c4` at ply 3

- CoachCard: **Add flank pressure on d5** — c4 adds the Réti/English-style flank challenge to Black’s d5 square. White still keeps central pawn choices flexible while making Black defend the center.

- Plain hint: Use the flank pawn to pressure Black’s queen-pawn center from the side.

- Opening themes: c4 pressure, d5 target, flank control

### Packet reti-white.line-003.ply-05.c4d5

- Move: `cxd5` / `c4d5` at ply 5

- CoachCard: **Keep Réti pressure flexible** — cxd5 keeps the line tied to Réti ideas: flexible development, central pressure from distance, and transposition awareness.

- Plain hint: Maintain piece pressure on the center and avoid committing pawns before the structure is clear.

- Opening themes: Réti flexibility, remote central control, development

### Packet reti-white.line-003.ply-07.d2d4

- Move: `d4` / `d2d4` at ply 7

- CoachCard: **Transpose from Réti pressure into a queen-pawn center** — d4 turns the Réti move order into direct central occupation. White uses earlier knight and c-pawn pressure to support the d-pawn center.

- Plain hint: Commit the queen pawn only after the piece and flank pressure already support the center.

- Opening themes: d4 transposition, central occupation, prepared center

### Packet reti-white.line-003.ply-09.c1g5

- Move: `Bg5` / `c1g5` at ply 9

- CoachCard: **Pressure a defender from a Réti move order** — Bg5 develops the bishop to pressure a kingside defender in a Réti-to-queen-pawn structure. The move connects piece activity to Black’s central support.

- Plain hint: Use bishop development to pressure a defender of Black’s central setup.

- Opening themes: bishop pressure, defender pressure, queen-pawn transposition

### Packet reti-white.line-003.ply-11.b1c3

- Move: `Nc3` / `b1c3` at ply 11

- CoachCard: **Reinforce the Réti dark-square pressure** — Nc3 adds another piece to the central fight, especially around d5 and e4. In Réti move orders it supports either a queen-pawn transposition or continued flank control.

- Plain hint: Develop the queenside knight to add support behind the flank and central pressure.

- Opening themes: dark-square pressure, piece support, flexible transposition


## reti-white-line-004: 1. Nf3 d5 2. c4 e6 3. d4 c5 4. Nc3 Nc6 5. cxd5 exd5 6. e3 Nf6

Runtime playKey: `g1f3,d7d5,c2c4,e7e6,d2d4,c7c5,b1c3,b8c6,c4d5,e6d5,e2e3,g8f6`  
Runtime totalGames field at line node: `588130`

### Packet reti-white.line-004.ply-03.c2c4

- Move: `c4` / `c2c4` at ply 3

- CoachCard: **Add flank pressure on d5** — c4 adds the Réti/English-style flank challenge to Black’s d5 square. White still keeps central pawn choices flexible while making Black defend the center.

- Plain hint: Use the flank pawn to pressure Black’s queen-pawn center from the side.

- Opening themes: c4 pressure, d5 target, flank control

### Packet reti-white.line-004.ply-05.d2d4

- Move: `d4` / `d2d4` at ply 5

- CoachCard: **Transpose from Réti pressure into a queen-pawn center** — d4 turns the Réti move order into direct central occupation. White uses earlier knight and c-pawn pressure to support the d-pawn center.

- Plain hint: Commit the queen pawn only after the piece and flank pressure already support the center.

- Opening themes: d4 transposition, central occupation, prepared center

### Packet reti-white.line-004.ply-07.b1c3

- Move: `Nc3` / `b1c3` at ply 7

- CoachCard: **Reinforce the Réti dark-square pressure** — Nc3 adds another piece to the central fight, especially around d5 and e4. In Réti move orders it supports either a queen-pawn transposition or continued flank control.

- Plain hint: Develop the queenside knight to add support behind the flank and central pressure.

- Opening themes: dark-square pressure, piece support, flexible transposition

### Packet reti-white.line-004.ply-09.c4d5

- Move: `cxd5` / `c4d5` at ply 9

- CoachCard: **Keep Réti pressure flexible** — cxd5 keeps the line tied to Réti ideas: flexible development, central pressure from distance, and transposition awareness.

- Plain hint: Maintain piece pressure on the center and avoid committing pawns before the structure is clear.

- Opening themes: Réti flexibility, remote central control, development

### Packet reti-white.line-004.ply-11.e2e3

- Move: `e3` / `e2e3` at ply 11

- CoachCard: **Support the prepared Réti center** — e3 supports White’s central structure and opens the light-square bishop route. In Réti transpositions, it keeps development safe before further central decisions.

- Plain hint: Support the queen-pawn setup and open a bishop route without forcing the center open.

- Opening themes: central support, safe development, transposition structure


## reti-white-line-005: 1. Nf3 d5 2. c4 dxc4 3. e3 Nc6 4. Bxc4 Nf6 5. d4 e6 6. Nc3 Bb4

Runtime playKey: `g1f3,d7d5,c2c4,d5c4,e2e3,b8c6,f1c4,g8f6,d2d4,e7e6,b1c3,f8b4`  
Runtime totalGames field at line node: `546969`

### Packet reti-white.line-005.ply-03.c2c4

- Move: `c4` / `c2c4` at ply 3

- CoachCard: **Add flank pressure on d5** — c4 adds the Réti/English-style flank challenge to Black’s d5 square. White still keeps central pawn choices flexible while making Black defend the center.

- Plain hint: Use the flank pawn to pressure Black’s queen-pawn center from the side.

- Opening themes: c4 pressure, d5 target, flank control

### Packet reti-white.line-005.ply-05.e2e3

- Move: `e3` / `e2e3` at ply 5

- CoachCard: **Support the prepared Réti center** — e3 supports White’s central structure and opens the light-square bishop route. In Réti transpositions, it keeps development safe before further central decisions.

- Plain hint: Support the queen-pawn setup and open a bishop route without forcing the center open.

- Opening themes: central support, safe development, transposition structure

### Packet reti-white.line-005.ply-07.f1c4

- Move: `Bxc4` / `f1c4` at ply 7

- CoachCard: **Keep Réti pressure flexible** — Bxc4 keeps the line tied to Réti ideas: flexible development, central pressure from distance, and transposition awareness.

- Plain hint: Maintain piece pressure on the center and avoid committing pawns before the structure is clear.

- Opening themes: Réti flexibility, remote central control, development

### Packet reti-white.line-005.ply-09.d2d4

- Move: `d4` / `d2d4` at ply 9

- CoachCard: **Transpose from Réti pressure into a queen-pawn center** — d4 turns the Réti move order into direct central occupation. White uses earlier knight and c-pawn pressure to support the d-pawn center.

- Plain hint: Commit the queen pawn only after the piece and flank pressure already support the center.

- Opening themes: d4 transposition, central occupation, prepared center

### Packet reti-white.line-005.ply-11.b1c3

- Move: `Nc3` / `b1c3` at ply 11

- CoachCard: **Reinforce the Réti dark-square pressure** — Nc3 adds another piece to the central fight, especially around d5 and e4. In Réti move orders it supports either a queen-pawn transposition or continued flank control.

- Plain hint: Develop the queenside knight to add support behind the flank and central pressure.

- Opening themes: dark-square pressure, piece support, flexible transposition


## reti-white-line-006: 1. Nf3 d5 2. c4 c6 3. d4 e6 4. Nc3 Nf6 5. Bg5 Nbd7 6. e3 Qa5

Runtime playKey: `g1f3,d7d5,c2c4,c7c6,d2d4,e7e6,b1c3,g8f6,c1g5,b8d7,e2e3,d8a5`  
Runtime totalGames field at line node: `544155`

### Packet reti-white.line-006.ply-03.c2c4

- Move: `c4` / `c2c4` at ply 3

- CoachCard: **Add flank pressure on d5** — c4 adds the Réti/English-style flank challenge to Black’s d5 square. White still keeps central pawn choices flexible while making Black defend the center.

- Plain hint: Use the flank pawn to pressure Black’s queen-pawn center from the side.

- Opening themes: c4 pressure, d5 target, flank control

### Packet reti-white.line-006.ply-05.d2d4

- Move: `d4` / `d2d4` at ply 5

- CoachCard: **Transpose from Réti pressure into a queen-pawn center** — d4 turns the Réti move order into direct central occupation. White uses earlier knight and c-pawn pressure to support the d-pawn center.

- Plain hint: Commit the queen pawn only after the piece and flank pressure already support the center.

- Opening themes: d4 transposition, central occupation, prepared center

### Packet reti-white.line-006.ply-07.b1c3

- Move: `Nc3` / `b1c3` at ply 7

- CoachCard: **Reinforce the Réti dark-square pressure** — Nc3 adds another piece to the central fight, especially around d5 and e4. In Réti move orders it supports either a queen-pawn transposition or continued flank control.

- Plain hint: Develop the queenside knight to add support behind the flank and central pressure.

- Opening themes: dark-square pressure, piece support, flexible transposition

### Packet reti-white.line-006.ply-09.c1g5

- Move: `Bg5` / `c1g5` at ply 9

- CoachCard: **Pressure a defender from a Réti move order** — Bg5 develops the bishop to pressure a kingside defender in a Réti-to-queen-pawn structure. The move connects piece activity to Black’s central support.

- Plain hint: Use bishop development to pressure a defender of Black’s central setup.

- Opening themes: bishop pressure, defender pressure, queen-pawn transposition

### Packet reti-white.line-006.ply-11.e2e3

- Move: `e3` / `e2e3` at ply 11

- CoachCard: **Support the prepared Réti center** — e3 supports White’s central structure and opens the light-square bishop route. In Réti transpositions, it keeps development safe before further central decisions.

- Plain hint: Support the queen-pawn setup and open a bishop route without forcing the center open.

- Opening themes: central support, safe development, transposition structure


## reti-white-line-007: 1. Nf3 d5 2. c4 c6 3. d4 Bf5 4. Nc3 e6 5. Bf4 Nf6 6. e3 Bd6

Runtime playKey: `g1f3,d7d5,c2c4,c7c6,d2d4,c8f5,b1c3,e7e6,c1f4,g8f6,e2e3,f8d6`  
Runtime totalGames field at line node: `428078`

### Packet reti-white.line-007.ply-03.c2c4

- Move: `c4` / `c2c4` at ply 3

- CoachCard: **Add flank pressure on d5** — c4 adds the Réti/English-style flank challenge to Black’s d5 square. White still keeps central pawn choices flexible while making Black defend the center.

- Plain hint: Use the flank pawn to pressure Black’s queen-pawn center from the side.

- Opening themes: c4 pressure, d5 target, flank control

### Packet reti-white.line-007.ply-05.d2d4

- Move: `d4` / `d2d4` at ply 5

- CoachCard: **Transpose from Réti pressure into a queen-pawn center** — d4 turns the Réti move order into direct central occupation. White uses earlier knight and c-pawn pressure to support the d-pawn center.

- Plain hint: Commit the queen pawn only after the piece and flank pressure already support the center.

- Opening themes: d4 transposition, central occupation, prepared center

### Packet reti-white.line-007.ply-07.b1c3

- Move: `Nc3` / `b1c3` at ply 7

- CoachCard: **Reinforce the Réti dark-square pressure** — Nc3 adds another piece to the central fight, especially around d5 and e4. In Réti move orders it supports either a queen-pawn transposition or continued flank control.

- Plain hint: Develop the queenside knight to add support behind the flank and central pressure.

- Opening themes: dark-square pressure, piece support, flexible transposition

### Packet reti-white.line-007.ply-09.c1f4

- Move: `Bf4` / `c1f4` at ply 9

- CoachCard: **Keep Réti pressure flexible** — Bf4 keeps the line tied to Réti ideas: flexible development, central pressure from distance, and transposition awareness.

- Plain hint: Maintain piece pressure on the center and avoid committing pawns before the structure is clear.

- Opening themes: Réti flexibility, remote central control, development

### Packet reti-white.line-007.ply-11.e2e3

- Move: `e3` / `e2e3` at ply 11

- CoachCard: **Support the prepared Réti center** — e3 supports White’s central structure and opens the light-square bishop route. In Réti transpositions, it keeps development safe before further central decisions.

- Plain hint: Support the queen-pawn setup and open a bishop route without forcing the center open.

- Opening themes: central support, safe development, transposition structure


## reti-white-line-008: 1. Nf3 d5 2. c4 c6 3. d4 Bf5 4. Nc3 Nf6 5. Bg5 e6 6. e3 Be7

Runtime playKey: `g1f3,d7d5,c2c4,c7c6,d2d4,c8f5,b1c3,g8f6,c1g5,e7e6,e2e3,f8e7`  
Runtime totalGames field at line node: `417046`

### Packet reti-white.line-008.ply-03.c2c4

- Move: `c4` / `c2c4` at ply 3

- CoachCard: **Add flank pressure on d5** — c4 adds the Réti/English-style flank challenge to Black’s d5 square. White still keeps central pawn choices flexible while making Black defend the center.

- Plain hint: Use the flank pawn to pressure Black’s queen-pawn center from the side.

- Opening themes: c4 pressure, d5 target, flank control

### Packet reti-white.line-008.ply-05.d2d4

- Move: `d4` / `d2d4` at ply 5

- CoachCard: **Transpose from Réti pressure into a queen-pawn center** — d4 turns the Réti move order into direct central occupation. White uses earlier knight and c-pawn pressure to support the d-pawn center.

- Plain hint: Commit the queen pawn only after the piece and flank pressure already support the center.

- Opening themes: d4 transposition, central occupation, prepared center

### Packet reti-white.line-008.ply-07.b1c3

- Move: `Nc3` / `b1c3` at ply 7

- CoachCard: **Reinforce the Réti dark-square pressure** — Nc3 adds another piece to the central fight, especially around d5 and e4. In Réti move orders it supports either a queen-pawn transposition or continued flank control.

- Plain hint: Develop the queenside knight to add support behind the flank and central pressure.

- Opening themes: dark-square pressure, piece support, flexible transposition

### Packet reti-white.line-008.ply-09.c1g5

- Move: `Bg5` / `c1g5` at ply 9

- CoachCard: **Pressure a defender from a Réti move order** — Bg5 develops the bishop to pressure a kingside defender in a Réti-to-queen-pawn structure. The move connects piece activity to Black’s central support.

- Plain hint: Use bishop development to pressure a defender of Black’s central setup.

- Opening themes: bishop pressure, defender pressure, queen-pawn transposition

### Packet reti-white.line-008.ply-11.e2e3

- Move: `e3` / `e2e3` at ply 11

- CoachCard: **Support the prepared Réti center** — e3 supports White’s central structure and opens the light-square bishop route. In Réti transpositions, it keeps development safe before further central decisions.

- Plain hint: Support the queen-pawn setup and open a bishop route without forcing the center open.

- Opening themes: central support, safe development, transposition structure


## reti-white-line-009: 1. Nf3 d5 2. c4 c6 3. cxd5 cxd5 4. d4 Nf6 5. Nc3 e6 6. Bg5 Be7

Runtime playKey: `g1f3,d7d5,c2c4,c7c6,c4d5,c6d5,d2d4,g8f6,b1c3,e7e6,c1g5,f8e7`  
Runtime totalGames field at line node: `401137`

### Packet reti-white.line-009.ply-03.c2c4

- Move: `c4` / `c2c4` at ply 3

- CoachCard: **Add flank pressure on d5** — c4 adds the Réti/English-style flank challenge to Black’s d5 square. White still keeps central pawn choices flexible while making Black defend the center.

- Plain hint: Use the flank pawn to pressure Black’s queen-pawn center from the side.

- Opening themes: c4 pressure, d5 target, flank control

### Packet reti-white.line-009.ply-05.c4d5

- Move: `cxd5` / `c4d5` at ply 5

- CoachCard: **Keep Réti pressure flexible** — cxd5 keeps the line tied to Réti ideas: flexible development, central pressure from distance, and transposition awareness.

- Plain hint: Maintain piece pressure on the center and avoid committing pawns before the structure is clear.

- Opening themes: Réti flexibility, remote central control, development

### Packet reti-white.line-009.ply-07.d2d4

- Move: `d4` / `d2d4` at ply 7

- CoachCard: **Transpose from Réti pressure into a queen-pawn center** — d4 turns the Réti move order into direct central occupation. White uses earlier knight and c-pawn pressure to support the d-pawn center.

- Plain hint: Commit the queen pawn only after the piece and flank pressure already support the center.

- Opening themes: d4 transposition, central occupation, prepared center

### Packet reti-white.line-009.ply-09.b1c3

- Move: `Nc3` / `b1c3` at ply 9

- CoachCard: **Reinforce the Réti dark-square pressure** — Nc3 adds another piece to the central fight, especially around d5 and e4. In Réti move orders it supports either a queen-pawn transposition or continued flank control.

- Plain hint: Develop the queenside knight to add support behind the flank and central pressure.

- Opening themes: dark-square pressure, piece support, flexible transposition

### Packet reti-white.line-009.ply-11.c1g5

- Move: `Bg5` / `c1g5` at ply 11

- CoachCard: **Pressure a defender from a Réti move order** — Bg5 develops the bishop to pressure a kingside defender in a Réti-to-queen-pawn structure. The move connects piece activity to Black’s central support.

- Plain hint: Use bishop development to pressure a defender of Black’s central setup.

- Opening themes: bishop pressure, defender pressure, queen-pawn transposition


## reti-white-line-010: 1. Nf3 d5 2. c4 c6 3. cxd5 cxd5 4. d4 Nc6 5. Bf4 Nf6 6. Nc3 a6

Runtime playKey: `g1f3,d7d5,c2c4,c7c6,c4d5,c6d5,d2d4,b8c6,c1f4,g8f6,b1c3,a7a6`  
Runtime totalGames field at line node: `376899`

### Packet reti-white.line-010.ply-03.c2c4

- Move: `c4` / `c2c4` at ply 3

- CoachCard: **Add flank pressure on d5** — c4 adds the Réti/English-style flank challenge to Black’s d5 square. White still keeps central pawn choices flexible while making Black defend the center.

- Plain hint: Use the flank pawn to pressure Black’s queen-pawn center from the side.

- Opening themes: c4 pressure, d5 target, flank control

### Packet reti-white.line-010.ply-05.c4d5

- Move: `cxd5` / `c4d5` at ply 5

- CoachCard: **Keep Réti pressure flexible** — cxd5 keeps the line tied to Réti ideas: flexible development, central pressure from distance, and transposition awareness.

- Plain hint: Maintain piece pressure on the center and avoid committing pawns before the structure is clear.

- Opening themes: Réti flexibility, remote central control, development

### Packet reti-white.line-010.ply-07.d2d4

- Move: `d4` / `d2d4` at ply 7

- CoachCard: **Transpose from Réti pressure into a queen-pawn center** — d4 turns the Réti move order into direct central occupation. White uses earlier knight and c-pawn pressure to support the d-pawn center.

- Plain hint: Commit the queen pawn only after the piece and flank pressure already support the center.

- Opening themes: d4 transposition, central occupation, prepared center

### Packet reti-white.line-010.ply-09.c1f4

- Move: `Bf4` / `c1f4` at ply 9

- CoachCard: **Keep Réti pressure flexible** — Bf4 keeps the line tied to Réti ideas: flexible development, central pressure from distance, and transposition awareness.

- Plain hint: Maintain piece pressure on the center and avoid committing pawns before the structure is clear.

- Opening themes: Réti flexibility, remote central control, development

### Packet reti-white.line-010.ply-11.b1c3

- Move: `Nc3` / `b1c3` at ply 11

- CoachCard: **Reinforce the Réti dark-square pressure** — Nc3 adds another piece to the central fight, especially around d5 and e4. In Réti move orders it supports either a queen-pawn transposition or continued flank control.

- Plain hint: Develop the queenside knight to add support behind the flank and central pressure.

- Opening themes: dark-square pressure, piece support, flexible transposition


## reti-white-line-011: 1. Nf3 d5 2. c4 c6 3. d4 Bf5 4. cxd5 cxd5 5. Nc3 e6 6. e3 Nf6

Runtime playKey: `g1f3,d7d5,c2c4,c7c6,d2d4,c8f5,c4d5,c6d5,b1c3,e7e6,e2e3,g8f6`  
Runtime totalGames field at line node: `294930`

### Packet reti-white.line-011.ply-03.c2c4

- Move: `c4` / `c2c4` at ply 3

- CoachCard: **Add flank pressure on d5** — c4 adds the Réti/English-style flank challenge to Black’s d5 square. White still keeps central pawn choices flexible while making Black defend the center.

- Plain hint: Use the flank pawn to pressure Black’s queen-pawn center from the side.

- Opening themes: c4 pressure, d5 target, flank control

### Packet reti-white.line-011.ply-05.d2d4

- Move: `d4` / `d2d4` at ply 5

- CoachCard: **Transpose from Réti pressure into a queen-pawn center** — d4 turns the Réti move order into direct central occupation. White uses earlier knight and c-pawn pressure to support the d-pawn center.

- Plain hint: Commit the queen pawn only after the piece and flank pressure already support the center.

- Opening themes: d4 transposition, central occupation, prepared center

### Packet reti-white.line-011.ply-07.c4d5

- Move: `cxd5` / `c4d5` at ply 7

- CoachCard: **Keep Réti pressure flexible** — cxd5 keeps the line tied to Réti ideas: flexible development, central pressure from distance, and transposition awareness.

- Plain hint: Maintain piece pressure on the center and avoid committing pawns before the structure is clear.

- Opening themes: Réti flexibility, remote central control, development

### Packet reti-white.line-011.ply-09.b1c3

- Move: `Nc3` / `b1c3` at ply 9

- CoachCard: **Reinforce the Réti dark-square pressure** — Nc3 adds another piece to the central fight, especially around d5 and e4. In Réti move orders it supports either a queen-pawn transposition or continued flank control.

- Plain hint: Develop the queenside knight to add support behind the flank and central pressure.

- Opening themes: dark-square pressure, piece support, flexible transposition

### Packet reti-white.line-011.ply-11.e2e3

- Move: `e3` / `e2e3` at ply 11

- CoachCard: **Support the prepared Réti center** — e3 supports White’s central structure and opens the light-square bishop route. In Réti transpositions, it keeps development safe before further central decisions.

- Plain hint: Support the queen-pawn setup and open a bishop route without forcing the center open.

- Opening themes: central support, safe development, transposition structure


## reti-white-line-012: 1. Nf3 d5 2. c4 c6 3. d4 e6 4. Nc3 f5 5. Bf4 Bd6 6. e3 Nf6

Runtime playKey: `g1f3,d7d5,c2c4,c7c6,d2d4,e7e6,b1c3,f7f5,c1f4,f8d6,e2e3,g8f6`  
Runtime totalGames field at line node: `290932`

### Packet reti-white.line-012.ply-03.c2c4

- Move: `c4` / `c2c4` at ply 3

- CoachCard: **Add flank pressure on d5** — c4 adds the Réti/English-style flank challenge to Black’s d5 square. White still keeps central pawn choices flexible while making Black defend the center.

- Plain hint: Use the flank pawn to pressure Black’s queen-pawn center from the side.

- Opening themes: c4 pressure, d5 target, flank control

### Packet reti-white.line-012.ply-05.d2d4

- Move: `d4` / `d2d4` at ply 5

- CoachCard: **Transpose from Réti pressure into a queen-pawn center** — d4 turns the Réti move order into direct central occupation. White uses earlier knight and c-pawn pressure to support the d-pawn center.

- Plain hint: Commit the queen pawn only after the piece and flank pressure already support the center.

- Opening themes: d4 transposition, central occupation, prepared center

### Packet reti-white.line-012.ply-07.b1c3

- Move: `Nc3` / `b1c3` at ply 7

- CoachCard: **Reinforce the Réti dark-square pressure** — Nc3 adds another piece to the central fight, especially around d5 and e4. In Réti move orders it supports either a queen-pawn transposition or continued flank control.

- Plain hint: Develop the queenside knight to add support behind the flank and central pressure.

- Opening themes: dark-square pressure, piece support, flexible transposition

### Packet reti-white.line-012.ply-09.c1f4

- Move: `Bf4` / `c1f4` at ply 9

- CoachCard: **Keep Réti pressure flexible** — Bf4 keeps the line tied to Réti ideas: flexible development, central pressure from distance, and transposition awareness.

- Plain hint: Maintain piece pressure on the center and avoid committing pawns before the structure is clear.

- Opening themes: Réti flexibility, remote central control, development

### Packet reti-white.line-012.ply-11.e2e3

- Move: `e3` / `e2e3` at ply 11

- CoachCard: **Support the prepared Réti center** — e3 supports White’s central structure and opens the light-square bishop route. In Réti transpositions, it keeps development safe before further central decisions.

- Plain hint: Support the queen-pawn setup and open a bishop route without forcing the center open.

- Opening themes: central support, safe development, transposition structure


## reti-white-line-013: 1. Nf3 d5 2. c4 e6 3. cxd5 Qxd5 4. Nc3 Qd8 5. d4 Bb4 6. e4 Nf6

Runtime playKey: `g1f3,d7d5,c2c4,e7e6,c4d5,d8d5,b1c3,d5d8,d2d4,f8b4,e2e4,g8f6`  
Runtime totalGames field at line node: `274691`

### Packet reti-white.line-013.ply-03.c2c4

- Move: `c4` / `c2c4` at ply 3

- CoachCard: **Add flank pressure on d5** — c4 adds the Réti/English-style flank challenge to Black’s d5 square. White still keeps central pawn choices flexible while making Black defend the center.

- Plain hint: Use the flank pawn to pressure Black’s queen-pawn center from the side.

- Opening themes: c4 pressure, d5 target, flank control

### Packet reti-white.line-013.ply-05.c4d5

- Move: `cxd5` / `c4d5` at ply 5

- CoachCard: **Keep Réti pressure flexible** — cxd5 keeps the line tied to Réti ideas: flexible development, central pressure from distance, and transposition awareness.

- Plain hint: Maintain piece pressure on the center and avoid committing pawns before the structure is clear.

- Opening themes: Réti flexibility, remote central control, development

### Packet reti-white.line-013.ply-07.b1c3

- Move: `Nc3` / `b1c3` at ply 7

- CoachCard: **Reinforce the Réti dark-square pressure** — Nc3 adds another piece to the central fight, especially around d5 and e4. In Réti move orders it supports either a queen-pawn transposition or continued flank control.

- Plain hint: Develop the queenside knight to add support behind the flank and central pressure.

- Opening themes: dark-square pressure, piece support, flexible transposition

### Packet reti-white.line-013.ply-09.d2d4

- Move: `d4` / `d2d4` at ply 9

- CoachCard: **Transpose from Réti pressure into a queen-pawn center** — d4 turns the Réti move order into direct central occupation. White uses earlier knight and c-pawn pressure to support the d-pawn center.

- Plain hint: Commit the queen pawn only after the piece and flank pressure already support the center.

- Opening themes: d4 transposition, central occupation, prepared center

### Packet reti-white.line-013.ply-11.e2e4

- Move: `e4` / `e2e4` at ply 11

- CoachCard: **Keep Réti pressure flexible** — e4 keeps the line tied to Réti ideas: flexible development, central pressure from distance, and transposition awareness.

- Plain hint: Maintain piece pressure on the center and avoid committing pawns before the structure is clear.

- Opening themes: Réti flexibility, remote central control, development


## reti-white-line-014: 1. Nf3 d5 2. c4 c6 3. d4 Bf5 4. Nc3 e6 5. Bf4 Nf6 6. e3 Bb4

Runtime playKey: `g1f3,d7d5,c2c4,c7c6,d2d4,c8f5,b1c3,e7e6,c1f4,g8f6,e2e3,f8b4`  
Runtime totalGames field at line node: `270926`

### Packet reti-white.line-014.ply-03.c2c4

- Move: `c4` / `c2c4` at ply 3

- CoachCard: **Add flank pressure on d5** — c4 adds the Réti/English-style flank challenge to Black’s d5 square. White still keeps central pawn choices flexible while making Black defend the center.

- Plain hint: Use the flank pawn to pressure Black’s queen-pawn center from the side.

- Opening themes: c4 pressure, d5 target, flank control

### Packet reti-white.line-014.ply-05.d2d4

- Move: `d4` / `d2d4` at ply 5

- CoachCard: **Transpose from Réti pressure into a queen-pawn center** — d4 turns the Réti move order into direct central occupation. White uses earlier knight and c-pawn pressure to support the d-pawn center.

- Plain hint: Commit the queen pawn only after the piece and flank pressure already support the center.

- Opening themes: d4 transposition, central occupation, prepared center

### Packet reti-white.line-014.ply-07.b1c3

- Move: `Nc3` / `b1c3` at ply 7

- CoachCard: **Reinforce the Réti dark-square pressure** — Nc3 adds another piece to the central fight, especially around d5 and e4. In Réti move orders it supports either a queen-pawn transposition or continued flank control.

- Plain hint: Develop the queenside knight to add support behind the flank and central pressure.

- Opening themes: dark-square pressure, piece support, flexible transposition

### Packet reti-white.line-014.ply-09.c1f4

- Move: `Bf4` / `c1f4` at ply 9

- CoachCard: **Keep Réti pressure flexible** — Bf4 keeps the line tied to Réti ideas: flexible development, central pressure from distance, and transposition awareness.

- Plain hint: Maintain piece pressure on the center and avoid committing pawns before the structure is clear.

- Opening themes: Réti flexibility, remote central control, development

### Packet reti-white.line-014.ply-11.e2e3

- Move: `e3` / `e2e3` at ply 11

- CoachCard: **Support the prepared Réti center** — e3 supports White’s central structure and opens the light-square bishop route. In Réti transpositions, it keeps development safe before further central decisions.

- Plain hint: Support the queen-pawn setup and open a bishop route without forcing the center open.

- Opening themes: central support, safe development, transposition structure


## reti-white-line-015: 1. Nf3 d5 2. c4 c6 3. d4 e6 4. Nc3 Nf6 5. e3 Nbd7 6. Bd3 dxc4

Runtime playKey: `g1f3,d7d5,c2c4,c7c6,d2d4,e7e6,b1c3,g8f6,e2e3,b8d7,f1d3,d5c4`  
Runtime totalGames field at line node: `264767`

### Packet reti-white.line-015.ply-03.c2c4

- Move: `c4` / `c2c4` at ply 3

- CoachCard: **Add flank pressure on d5** — c4 adds the Réti/English-style flank challenge to Black’s d5 square. White still keeps central pawn choices flexible while making Black defend the center.

- Plain hint: Use the flank pawn to pressure Black’s queen-pawn center from the side.

- Opening themes: c4 pressure, d5 target, flank control

### Packet reti-white.line-015.ply-05.d2d4

- Move: `d4` / `d2d4` at ply 5

- CoachCard: **Transpose from Réti pressure into a queen-pawn center** — d4 turns the Réti move order into direct central occupation. White uses earlier knight and c-pawn pressure to support the d-pawn center.

- Plain hint: Commit the queen pawn only after the piece and flank pressure already support the center.

- Opening themes: d4 transposition, central occupation, prepared center

### Packet reti-white.line-015.ply-07.b1c3

- Move: `Nc3` / `b1c3` at ply 7

- CoachCard: **Reinforce the Réti dark-square pressure** — Nc3 adds another piece to the central fight, especially around d5 and e4. In Réti move orders it supports either a queen-pawn transposition or continued flank control.

- Plain hint: Develop the queenside knight to add support behind the flank and central pressure.

- Opening themes: dark-square pressure, piece support, flexible transposition

### Packet reti-white.line-015.ply-09.e2e3

- Move: `e3` / `e2e3` at ply 9

- CoachCard: **Support the prepared Réti center** — e3 supports White’s central structure and opens the light-square bishop route. In Réti transpositions, it keeps development safe before further central decisions.

- Plain hint: Support the queen-pawn setup and open a bishop route without forcing the center open.

- Opening themes: central support, safe development, transposition structure

### Packet reti-white.line-015.ply-11.f1d3

- Move: `Bd3` / `f1d3` at ply 11

- CoachCard: **Keep Réti pressure flexible** — Bd3 keeps the line tied to Réti ideas: flexible development, central pressure from distance, and transposition awareness.

- Plain hint: Maintain piece pressure on the center and avoid committing pawns before the structure is clear.

- Opening themes: Réti flexibility, remote central control, development


## reti-white-line-016: 1. Nf3 d5 2. c4 e6 3. d4 c5 4. cxd5 exd5 5. g3 Nf6 6. Bg2 Nc6

Runtime playKey: `g1f3,d7d5,c2c4,e7e6,d2d4,c7c5,c4d5,e6d5,g2g3,g8f6,f1g2,b8c6`  
Runtime totalGames field at line node: `262900`

### Packet reti-white.line-016.ply-03.c2c4

- Move: `c4` / `c2c4` at ply 3

- CoachCard: **Add flank pressure on d5** — c4 adds the Réti/English-style flank challenge to Black’s d5 square. White still keeps central pawn choices flexible while making Black defend the center.

- Plain hint: Use the flank pawn to pressure Black’s queen-pawn center from the side.

- Opening themes: c4 pressure, d5 target, flank control

### Packet reti-white.line-016.ply-05.d2d4

- Move: `d4` / `d2d4` at ply 5

- CoachCard: **Transpose from Réti pressure into a queen-pawn center** — d4 turns the Réti move order into direct central occupation. White uses earlier knight and c-pawn pressure to support the d-pawn center.

- Plain hint: Commit the queen pawn only after the piece and flank pressure already support the center.

- Opening themes: d4 transposition, central occupation, prepared center

### Packet reti-white.line-016.ply-07.c4d5

- Move: `cxd5` / `c4d5` at ply 7

- CoachCard: **Keep Réti pressure flexible** — cxd5 keeps the line tied to Réti ideas: flexible development, central pressure from distance, and transposition awareness.

- Plain hint: Maintain piece pressure on the center and avoid committing pawns before the structure is clear.

- Opening themes: Réti flexibility, remote central control, development

### Packet reti-white.line-016.ply-09.g2g3

- Move: `g3` / `g2g3` at ply 9

- CoachCard: **Prepare the Réti kingside fianchetto** — g3 prepares a Réti fianchetto, letting the bishop influence the center from distance. White keeps central pawn decisions flexible.

- Plain hint: Prepare long-diagonal pressure while keeping the center flexible.

- Opening themes: kingside fianchetto, long diagonal, central control from distance

### Packet reti-white.line-016.ply-11.f1g2

- Move: `Bg2` / `f1g2` at ply 11

- CoachCard: **Complete long-diagonal central control** — Bg2 completes the Réti fianchetto. The bishop works with the knight and c-pawn pressure to influence the center without early overextension.

- Plain hint: Place the bishop on the long diagonal so it supports central pressure from distance.

- Opening themes: g2 bishop, long diagonal, remote central pressure


## reti-white-line-017: 1. Nf3 d5 2. c4 c6 3. d4 e6 4. Nc3 Nf6 5. e3 Nbd7 6. Bd3 Bd6

Runtime playKey: `g1f3,d7d5,c2c4,c7c6,d2d4,e7e6,b1c3,g8f6,e2e3,b8d7,f1d3,f8d6`  
Runtime totalGames field at line node: `255426`

### Packet reti-white.line-017.ply-03.c2c4

- Move: `c4` / `c2c4` at ply 3

- CoachCard: **Add flank pressure on d5** — c4 adds the Réti/English-style flank challenge to Black’s d5 square. White still keeps central pawn choices flexible while making Black defend the center.

- Plain hint: Use the flank pawn to pressure Black’s queen-pawn center from the side.

- Opening themes: c4 pressure, d5 target, flank control

### Packet reti-white.line-017.ply-05.d2d4

- Move: `d4` / `d2d4` at ply 5

- CoachCard: **Transpose from Réti pressure into a queen-pawn center** — d4 turns the Réti move order into direct central occupation. White uses earlier knight and c-pawn pressure to support the d-pawn center.

- Plain hint: Commit the queen pawn only after the piece and flank pressure already support the center.

- Opening themes: d4 transposition, central occupation, prepared center

### Packet reti-white.line-017.ply-07.b1c3

- Move: `Nc3` / `b1c3` at ply 7

- CoachCard: **Reinforce the Réti dark-square pressure** — Nc3 adds another piece to the central fight, especially around d5 and e4. In Réti move orders it supports either a queen-pawn transposition or continued flank control.

- Plain hint: Develop the queenside knight to add support behind the flank and central pressure.

- Opening themes: dark-square pressure, piece support, flexible transposition

### Packet reti-white.line-017.ply-09.e2e3

- Move: `e3` / `e2e3` at ply 9

- CoachCard: **Support the prepared Réti center** — e3 supports White’s central structure and opens the light-square bishop route. In Réti transpositions, it keeps development safe before further central decisions.

- Plain hint: Support the queen-pawn setup and open a bishop route without forcing the center open.

- Opening themes: central support, safe development, transposition structure

### Packet reti-white.line-017.ply-11.f1d3

- Move: `Bd3` / `f1d3` at ply 11

- CoachCard: **Keep Réti pressure flexible** — Bd3 keeps the line tied to Réti ideas: flexible development, central pressure from distance, and transposition awareness.

- Plain hint: Maintain piece pressure on the center and avoid committing pawns before the structure is clear.

- Opening themes: Réti flexibility, remote central control, development


## reti-white-line-018: 1. Nf3 d5 2. c4 c6 3. cxd5 cxd5 4. d4 Nc6 5. Bf4 Bf5 6. Nc3 Nf6

Runtime playKey: `g1f3,d7d5,c2c4,c7c6,c4d5,c6d5,d2d4,b8c6,c1f4,c8f5,b1c3,g8f6`  
Runtime totalGames field at line node: `248649`

### Packet reti-white.line-018.ply-03.c2c4

- Move: `c4` / `c2c4` at ply 3

- CoachCard: **Add flank pressure on d5** — c4 adds the Réti/English-style flank challenge to Black’s d5 square. White still keeps central pawn choices flexible while making Black defend the center.

- Plain hint: Use the flank pawn to pressure Black’s queen-pawn center from the side.

- Opening themes: c4 pressure, d5 target, flank control

### Packet reti-white.line-018.ply-05.c4d5

- Move: `cxd5` / `c4d5` at ply 5

- CoachCard: **Keep Réti pressure flexible** — cxd5 keeps the line tied to Réti ideas: flexible development, central pressure from distance, and transposition awareness.

- Plain hint: Maintain piece pressure on the center and avoid committing pawns before the structure is clear.

- Opening themes: Réti flexibility, remote central control, development

### Packet reti-white.line-018.ply-07.d2d4

- Move: `d4` / `d2d4` at ply 7

- CoachCard: **Transpose from Réti pressure into a queen-pawn center** — d4 turns the Réti move order into direct central occupation. White uses earlier knight and c-pawn pressure to support the d-pawn center.

- Plain hint: Commit the queen pawn only after the piece and flank pressure already support the center.

- Opening themes: d4 transposition, central occupation, prepared center

### Packet reti-white.line-018.ply-09.c1f4

- Move: `Bf4` / `c1f4` at ply 9

- CoachCard: **Keep Réti pressure flexible** — Bf4 keeps the line tied to Réti ideas: flexible development, central pressure from distance, and transposition awareness.

- Plain hint: Maintain piece pressure on the center and avoid committing pawns before the structure is clear.

- Opening themes: Réti flexibility, remote central control, development

### Packet reti-white.line-018.ply-11.b1c3

- Move: `Nc3` / `b1c3` at ply 11

- CoachCard: **Reinforce the Réti dark-square pressure** — Nc3 adds another piece to the central fight, especially around d5 and e4. In Réti move orders it supports either a queen-pawn transposition or continued flank control.

- Plain hint: Develop the queenside knight to add support behind the flank and central pressure.

- Opening themes: dark-square pressure, piece support, flexible transposition


## reti-white-line-019: 1. Nf3 d5 2. c4 e6 3. d4 Nf6 4. Nc3 Bb4 5. Bg5 h6 6. Bxf6 Qxf6

Runtime playKey: `g1f3,d7d5,c2c4,e7e6,d2d4,g8f6,b1c3,f8b4,c1g5,h7h6,g5f6,d8f6`  
Runtime totalGames field at line node: `239045`

### Packet reti-white.line-019.ply-03.c2c4

- Move: `c4` / `c2c4` at ply 3

- CoachCard: **Add flank pressure on d5** — c4 adds the Réti/English-style flank challenge to Black’s d5 square. White still keeps central pawn choices flexible while making Black defend the center.

- Plain hint: Use the flank pawn to pressure Black’s queen-pawn center from the side.

- Opening themes: c4 pressure, d5 target, flank control

### Packet reti-white.line-019.ply-05.d2d4

- Move: `d4` / `d2d4` at ply 5

- CoachCard: **Transpose from Réti pressure into a queen-pawn center** — d4 turns the Réti move order into direct central occupation. White uses earlier knight and c-pawn pressure to support the d-pawn center.

- Plain hint: Commit the queen pawn only after the piece and flank pressure already support the center.

- Opening themes: d4 transposition, central occupation, prepared center

### Packet reti-white.line-019.ply-07.b1c3

- Move: `Nc3` / `b1c3` at ply 7

- CoachCard: **Reinforce the Réti dark-square pressure** — Nc3 adds another piece to the central fight, especially around d5 and e4. In Réti move orders it supports either a queen-pawn transposition or continued flank control.

- Plain hint: Develop the queenside knight to add support behind the flank and central pressure.

- Opening themes: dark-square pressure, piece support, flexible transposition

### Packet reti-white.line-019.ply-09.c1g5

- Move: `Bg5` / `c1g5` at ply 9

- CoachCard: **Pressure a defender from a Réti move order** — Bg5 develops the bishop to pressure a kingside defender in a Réti-to-queen-pawn structure. The move connects piece activity to Black’s central support.

- Plain hint: Use bishop development to pressure a defender of Black’s central setup.

- Opening themes: bishop pressure, defender pressure, queen-pawn transposition

### Packet reti-white.line-019.ply-11.g5f6

- Move: `Bxf6` / `g5f6` at ply 11

- CoachCard: **Keep Réti pressure flexible** — Bxf6 keeps the line tied to Réti ideas: flexible development, central pressure from distance, and transposition awareness.

- Plain hint: Maintain piece pressure on the center and avoid committing pawns before the structure is clear.

- Opening themes: Réti flexibility, remote central control, development


## reti-white-line-020: 1. Nf3 d5 2. c4 e6 3. cxd5 exd5 4. d4 Nf6 5. Bg5 c6 6. Nc3 Bd6

Runtime playKey: `g1f3,d7d5,c2c4,e7e6,c4d5,e6d5,d2d4,g8f6,c1g5,c7c6,b1c3,f8d6`  
Runtime totalGames field at line node: `234321`

### Packet reti-white.line-020.ply-03.c2c4

- Move: `c4` / `c2c4` at ply 3

- CoachCard: **Add flank pressure on d5** — c4 adds the Réti/English-style flank challenge to Black’s d5 square. White still keeps central pawn choices flexible while making Black defend the center.

- Plain hint: Use the flank pawn to pressure Black’s queen-pawn center from the side.

- Opening themes: c4 pressure, d5 target, flank control

### Packet reti-white.line-020.ply-05.c4d5

- Move: `cxd5` / `c4d5` at ply 5

- CoachCard: **Keep Réti pressure flexible** — cxd5 keeps the line tied to Réti ideas: flexible development, central pressure from distance, and transposition awareness.

- Plain hint: Maintain piece pressure on the center and avoid committing pawns before the structure is clear.

- Opening themes: Réti flexibility, remote central control, development

### Packet reti-white.line-020.ply-07.d2d4

- Move: `d4` / `d2d4` at ply 7

- CoachCard: **Transpose from Réti pressure into a queen-pawn center** — d4 turns the Réti move order into direct central occupation. White uses earlier knight and c-pawn pressure to support the d-pawn center.

- Plain hint: Commit the queen pawn only after the piece and flank pressure already support the center.

- Opening themes: d4 transposition, central occupation, prepared center

### Packet reti-white.line-020.ply-09.c1g5

- Move: `Bg5` / `c1g5` at ply 9

- CoachCard: **Pressure a defender from a Réti move order** — Bg5 develops the bishop to pressure a kingside defender in a Réti-to-queen-pawn structure. The move connects piece activity to Black’s central support.

- Plain hint: Use bishop development to pressure a defender of Black’s central setup.

- Opening themes: bishop pressure, defender pressure, queen-pawn transposition

### Packet reti-white.line-020.ply-11.b1c3

- Move: `Nc3` / `b1c3` at ply 11

- CoachCard: **Reinforce the Réti dark-square pressure** — Nc3 adds another piece to the central fight, especially around d5 and e4. In Réti move orders it supports either a queen-pawn transposition or continued flank control.

- Plain hint: Develop the queenside knight to add support behind the flank and central pressure.

- Opening themes: dark-square pressure, piece support, flexible transposition


## reti-white-line-021: 1. Nf3 d5 2. c4 e6 3. d4 c5 4. cxd5 exd5 5. Nc3 Nf6 6. g3 Nc6

Runtime playKey: `g1f3,d7d5,c2c4,e7e6,d2d4,c7c5,c4d5,e6d5,b1c3,g8f6,g2g3,b8c6`  
Runtime totalGames field at line node: `226670`

### Packet reti-white.line-021.ply-03.c2c4

- Move: `c4` / `c2c4` at ply 3

- CoachCard: **Add flank pressure on d5** — c4 adds the Réti/English-style flank challenge to Black’s d5 square. White still keeps central pawn choices flexible while making Black defend the center.

- Plain hint: Use the flank pawn to pressure Black’s queen-pawn center from the side.

- Opening themes: c4 pressure, d5 target, flank control

### Packet reti-white.line-021.ply-05.d2d4

- Move: `d4` / `d2d4` at ply 5

- CoachCard: **Transpose from Réti pressure into a queen-pawn center** — d4 turns the Réti move order into direct central occupation. White uses earlier knight and c-pawn pressure to support the d-pawn center.

- Plain hint: Commit the queen pawn only after the piece and flank pressure already support the center.

- Opening themes: d4 transposition, central occupation, prepared center

### Packet reti-white.line-021.ply-07.c4d5

- Move: `cxd5` / `c4d5` at ply 7

- CoachCard: **Keep Réti pressure flexible** — cxd5 keeps the line tied to Réti ideas: flexible development, central pressure from distance, and transposition awareness.

- Plain hint: Maintain piece pressure on the center and avoid committing pawns before the structure is clear.

- Opening themes: Réti flexibility, remote central control, development

### Packet reti-white.line-021.ply-09.b1c3

- Move: `Nc3` / `b1c3` at ply 9

- CoachCard: **Reinforce the Réti dark-square pressure** — Nc3 adds another piece to the central fight, especially around d5 and e4. In Réti move orders it supports either a queen-pawn transposition or continued flank control.

- Plain hint: Develop the queenside knight to add support behind the flank and central pressure.

- Opening themes: dark-square pressure, piece support, flexible transposition

### Packet reti-white.line-021.ply-11.g2g3

- Move: `g3` / `g2g3` at ply 11

- CoachCard: **Prepare the Réti kingside fianchetto** — g3 prepares a Réti fianchetto, letting the bishop influence the center from distance. White keeps central pawn decisions flexible.

- Plain hint: Prepare long-diagonal pressure while keeping the center flexible.

- Opening themes: kingside fianchetto, long diagonal, central control from distance


## reti-white-line-022: 1. Nf3 d5 2. c4 c6 3. d4 Bf5 4. Nc3 Nf6 5. e3 e6 6. Bd3 Bxd3

Runtime playKey: `g1f3,d7d5,c2c4,c7c6,d2d4,c8f5,b1c3,g8f6,e2e3,e7e6,f1d3,f5d3`  
Runtime totalGames field at line node: `223390`

### Packet reti-white.line-022.ply-03.c2c4

- Move: `c4` / `c2c4` at ply 3

- CoachCard: **Add flank pressure on d5** — c4 adds the Réti/English-style flank challenge to Black’s d5 square. White still keeps central pawn choices flexible while making Black defend the center.

- Plain hint: Use the flank pawn to pressure Black’s queen-pawn center from the side.

- Opening themes: c4 pressure, d5 target, flank control

### Packet reti-white.line-022.ply-05.d2d4

- Move: `d4` / `d2d4` at ply 5

- CoachCard: **Transpose from Réti pressure into a queen-pawn center** — d4 turns the Réti move order into direct central occupation. White uses earlier knight and c-pawn pressure to support the d-pawn center.

- Plain hint: Commit the queen pawn only after the piece and flank pressure already support the center.

- Opening themes: d4 transposition, central occupation, prepared center

### Packet reti-white.line-022.ply-07.b1c3

- Move: `Nc3` / `b1c3` at ply 7

- CoachCard: **Reinforce the Réti dark-square pressure** — Nc3 adds another piece to the central fight, especially around d5 and e4. In Réti move orders it supports either a queen-pawn transposition or continued flank control.

- Plain hint: Develop the queenside knight to add support behind the flank and central pressure.

- Opening themes: dark-square pressure, piece support, flexible transposition

### Packet reti-white.line-022.ply-09.e2e3

- Move: `e3` / `e2e3` at ply 9

- CoachCard: **Support the prepared Réti center** — e3 supports White’s central structure and opens the light-square bishop route. In Réti transpositions, it keeps development safe before further central decisions.

- Plain hint: Support the queen-pawn setup and open a bishop route without forcing the center open.

- Opening themes: central support, safe development, transposition structure

### Packet reti-white.line-022.ply-11.f1d3

- Move: `Bd3` / `f1d3` at ply 11

- CoachCard: **Keep Réti pressure flexible** — Bd3 keeps the line tied to Réti ideas: flexible development, central pressure from distance, and transposition awareness.

- Plain hint: Maintain piece pressure on the center and avoid committing pawns before the structure is clear.

- Opening themes: Réti flexibility, remote central control, development


## reti-white-line-023: 1. Nf3 d5 2. c4 c6 3. d4 Bf5 4. Nc3 Nf6 5. Bg5 Nbd7 6. e3 e6

Runtime playKey: `g1f3,d7d5,c2c4,c7c6,d2d4,c8f5,b1c3,g8f6,c1g5,b8d7,e2e3,e7e6`  
Runtime totalGames field at line node: `191675`

### Packet reti-white.line-023.ply-03.c2c4

- Move: `c4` / `c2c4` at ply 3

- CoachCard: **Add flank pressure on d5** — c4 adds the Réti/English-style flank challenge to Black’s d5 square. White still keeps central pawn choices flexible while making Black defend the center.

- Plain hint: Use the flank pawn to pressure Black’s queen-pawn center from the side.

- Opening themes: c4 pressure, d5 target, flank control

### Packet reti-white.line-023.ply-05.d2d4

- Move: `d4` / `d2d4` at ply 5

- CoachCard: **Transpose from Réti pressure into a queen-pawn center** — d4 turns the Réti move order into direct central occupation. White uses earlier knight and c-pawn pressure to support the d-pawn center.

- Plain hint: Commit the queen pawn only after the piece and flank pressure already support the center.

- Opening themes: d4 transposition, central occupation, prepared center

### Packet reti-white.line-023.ply-07.b1c3

- Move: `Nc3` / `b1c3` at ply 7

- CoachCard: **Reinforce the Réti dark-square pressure** — Nc3 adds another piece to the central fight, especially around d5 and e4. In Réti move orders it supports either a queen-pawn transposition or continued flank control.

- Plain hint: Develop the queenside knight to add support behind the flank and central pressure.

- Opening themes: dark-square pressure, piece support, flexible transposition

### Packet reti-white.line-023.ply-09.c1g5

- Move: `Bg5` / `c1g5` at ply 9

- CoachCard: **Pressure a defender from a Réti move order** — Bg5 develops the bishop to pressure a kingside defender in a Réti-to-queen-pawn structure. The move connects piece activity to Black’s central support.

- Plain hint: Use bishop development to pressure a defender of Black’s central setup.

- Opening themes: bishop pressure, defender pressure, queen-pawn transposition

### Packet reti-white.line-023.ply-11.e2e3

- Move: `e3` / `e2e3` at ply 11

- CoachCard: **Support the prepared Réti center** — e3 supports White’s central structure and opens the light-square bishop route. In Réti transpositions, it keeps development safe before further central decisions.

- Plain hint: Support the queen-pawn setup and open a bishop route without forcing the center open.

- Opening themes: central support, safe development, transposition structure


## reti-white-line-024: 1. Nf3 d5 2. c4 c6 3. cxd5 cxd5 4. d4 Nf6 5. Bf4 e6 6. Nc3 Nc6

Runtime playKey: `g1f3,d7d5,c2c4,c7c6,c4d5,c6d5,d2d4,g8f6,c1f4,e7e6,b1c3,b8c6`  
Runtime totalGames field at line node: `190963`

### Packet reti-white.line-024.ply-03.c2c4

- Move: `c4` / `c2c4` at ply 3

- CoachCard: **Add flank pressure on d5** — c4 adds the Réti/English-style flank challenge to Black’s d5 square. White still keeps central pawn choices flexible while making Black defend the center.

- Plain hint: Use the flank pawn to pressure Black’s queen-pawn center from the side.

- Opening themes: c4 pressure, d5 target, flank control

### Packet reti-white.line-024.ply-05.c4d5

- Move: `cxd5` / `c4d5` at ply 5

- CoachCard: **Keep Réti pressure flexible** — cxd5 keeps the line tied to Réti ideas: flexible development, central pressure from distance, and transposition awareness.

- Plain hint: Maintain piece pressure on the center and avoid committing pawns before the structure is clear.

- Opening themes: Réti flexibility, remote central control, development

### Packet reti-white.line-024.ply-07.d2d4

- Move: `d4` / `d2d4` at ply 7

- CoachCard: **Transpose from Réti pressure into a queen-pawn center** — d4 turns the Réti move order into direct central occupation. White uses earlier knight and c-pawn pressure to support the d-pawn center.

- Plain hint: Commit the queen pawn only after the piece and flank pressure already support the center.

- Opening themes: d4 transposition, central occupation, prepared center

### Packet reti-white.line-024.ply-09.c1f4

- Move: `Bf4` / `c1f4` at ply 9

- CoachCard: **Keep Réti pressure flexible** — Bf4 keeps the line tied to Réti ideas: flexible development, central pressure from distance, and transposition awareness.

- Plain hint: Maintain piece pressure on the center and avoid committing pawns before the structure is clear.

- Opening themes: Réti flexibility, remote central control, development

### Packet reti-white.line-024.ply-11.b1c3

- Move: `Nc3` / `b1c3` at ply 11

- CoachCard: **Reinforce the Réti dark-square pressure** — Nc3 adds another piece to the central fight, especially around d5 and e4. In Réti move orders it supports either a queen-pawn transposition or continued flank control.

- Plain hint: Develop the queenside knight to add support behind the flank and central pressure.

- Opening themes: dark-square pressure, piece support, flexible transposition


## reti-white-line-025: 1. Nf3 d5 2. c4 c6 3. cxd5 cxd5 4. d4 Nc6 5. Nc3 Nf6 6. Bg5 e6

Runtime playKey: `g1f3,d7d5,c2c4,c7c6,c4d5,c6d5,d2d4,b8c6,b1c3,g8f6,c1g5,e7e6`  
Runtime totalGames field at line node: `186616`

### Packet reti-white.line-025.ply-03.c2c4

- Move: `c4` / `c2c4` at ply 3

- CoachCard: **Add flank pressure on d5** — c4 adds the Réti/English-style flank challenge to Black’s d5 square. White still keeps central pawn choices flexible while making Black defend the center.

- Plain hint: Use the flank pawn to pressure Black’s queen-pawn center from the side.

- Opening themes: c4 pressure, d5 target, flank control

### Packet reti-white.line-025.ply-05.c4d5

- Move: `cxd5` / `c4d5` at ply 5

- CoachCard: **Keep Réti pressure flexible** — cxd5 keeps the line tied to Réti ideas: flexible development, central pressure from distance, and transposition awareness.

- Plain hint: Maintain piece pressure on the center and avoid committing pawns before the structure is clear.

- Opening themes: Réti flexibility, remote central control, development

### Packet reti-white.line-025.ply-07.d2d4

- Move: `d4` / `d2d4` at ply 7

- CoachCard: **Transpose from Réti pressure into a queen-pawn center** — d4 turns the Réti move order into direct central occupation. White uses earlier knight and c-pawn pressure to support the d-pawn center.

- Plain hint: Commit the queen pawn only after the piece and flank pressure already support the center.

- Opening themes: d4 transposition, central occupation, prepared center

### Packet reti-white.line-025.ply-09.b1c3

- Move: `Nc3` / `b1c3` at ply 9

- CoachCard: **Reinforce the Réti dark-square pressure** — Nc3 adds another piece to the central fight, especially around d5 and e4. In Réti move orders it supports either a queen-pawn transposition or continued flank control.

- Plain hint: Develop the queenside knight to add support behind the flank and central pressure.

- Opening themes: dark-square pressure, piece support, flexible transposition

### Packet reti-white.line-025.ply-11.c1g5

- Move: `Bg5` / `c1g5` at ply 11

- CoachCard: **Pressure a defender from a Réti move order** — Bg5 develops the bishop to pressure a kingside defender in a Réti-to-queen-pawn structure. The move connects piece activity to Black’s central support.

- Plain hint: Use bishop development to pressure a defender of Black’s central setup.

- Opening themes: bishop pressure, defender pressure, queen-pawn transposition
