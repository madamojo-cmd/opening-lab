# Vienna Game approved-content candidates — Batch 3

Opening ID: `vienna-white`  
Status: approved candidates only; not app-activated.


## vienna-white-line-001: 1. e4 e5 2. Nc3 Nc6 3. Bc4 Bc5 4. d3 d6 5. Nf3 h6 6. h3 Nf6

Runtime playKey: `e2e4,e7e5,b1c3,b8c6,f1c4,f8c5,d2d3,d7d6,g1f3,h7h6,h2h3,g8f6`  
Runtime totalGames field at line node: `1887143`

### Packet vienna-white.line-001.ply-03.b1c3

- Move: `Nc3` / `b1c3` at ply 3

- CoachCard: **Support e4 with the Vienna knight** — Nc3 is the Vienna’s defining move: the knight supports e4 and keeps options for Bc4, g3, f4, or Nf3 depending on Black.

- Plain hint: Bring the queenside knight out to support the king-pawn center and keep kingside choices flexible.

- Opening themes: Nc3 supports e4, flexible kingside play, Vienna identity

### Packet vienna-white.line-001.ply-05.f1c4

- Move: `Bc4` / `f1c4` at ply 5

- CoachCard: **Aim the Vienna bishop at f7** — Bc4 develops the bishop toward f7, a natural Vienna attacking diagonal. The move supports rapid development without needing a premature queen sortie.

- Plain hint: Use the light-square bishop to pressure Black’s kingside before committing to tactics.

- Opening themes: Bc4 diagonal, f7 pressure, rapid development

### Packet vienna-white.line-001.ply-07.d2d3

- Move: `d3` / `d2d3` at ply 7

- CoachCard: **Build a quiet Vienna support base** — d3 supports e4 and gives White a stable Vienna structure. It prepares castling before any central or kingside expansion.

- Plain hint: Support the king pawn and keep the bishop diagonal open for safe development.

- Opening themes: d3 support, quiet Vienna, king safety

### Packet vienna-white.line-001.ply-09.g1f3

- Move: `Nf3` / `g1f3` at ply 9

- CoachCard: **Add kingside development to the Vienna center** — Nf3 develops the kingside knight and prepares castling while keeping the e-pawn defended. It fits quieter Vienna lines with steady development.

- Plain hint: Bring the kingside knight out once the Vienna center is supported.

- Opening themes: Nf3 development, king safety, e4 support

### Packet vienna-white.line-001.ply-11.h2h3

- Move: `h3` / `h2h3` at ply 11

- CoachCard: **Keep Vienna development purposeful** — h3 supports the Vienna plan of e4 plus Nc3, rapid development, and king safety before tactics.

- Plain hint: Support the center, develop quickly, and avoid premature queen attacks.

- Opening themes: Vienna development, central support, king safety


## vienna-white-line-002: 1. e4 e5 2. Nc3 Nc6 3. Bc4 Nf6 4. Nf3 Nxe4 5. Nxe4 d5 6. Bxd5 Qxd5

Runtime playKey: `e2e4,e7e5,b1c3,b8c6,f1c4,g8f6,g1f3,f6e4,c3e4,d7d5,c4d5,d8d5`  
Runtime totalGames field at line node: `1264706`

### Packet vienna-white.line-002.ply-03.b1c3

- Move: `Nc3` / `b1c3` at ply 3

- CoachCard: **Support e4 with the Vienna knight** — Nc3 is the Vienna’s defining move: the knight supports e4 and keeps options for Bc4, g3, f4, or Nf3 depending on Black.

- Plain hint: Bring the queenside knight out to support the king-pawn center and keep kingside choices flexible.

- Opening themes: Nc3 supports e4, flexible kingside play, Vienna identity

### Packet vienna-white.line-002.ply-05.f1c4

- Move: `Bc4` / `f1c4` at ply 5

- CoachCard: **Aim the Vienna bishop at f7** — Bc4 develops the bishop toward f7, a natural Vienna attacking diagonal. The move supports rapid development without needing a premature queen sortie.

- Plain hint: Use the light-square bishop to pressure Black’s kingside before committing to tactics.

- Opening themes: Bc4 diagonal, f7 pressure, rapid development

### Packet vienna-white.line-002.ply-07.g1f3

- Move: `Nf3` / `g1f3` at ply 7

- CoachCard: **Add kingside development to the Vienna center** — Nf3 develops the kingside knight and prepares castling while keeping the e-pawn defended. It fits quieter Vienna lines with steady development.

- Plain hint: Bring the kingside knight out once the Vienna center is supported.

- Opening themes: Nf3 development, king safety, e4 support

### Packet vienna-white.line-002.ply-09.c3e4

- Move: `Nxe4` / `c3e4` at ply 9

- CoachCard: **Keep Vienna development purposeful** — Nxe4 supports the Vienna plan of e4 plus Nc3, rapid development, and king safety before tactics.

- Plain hint: Support the center, develop quickly, and avoid premature queen attacks.

- Opening themes: Vienna development, central support, king safety

### Packet vienna-white.line-002.ply-11.c4d5

- Move: `Bxd5` / `c4d5` at ply 11

- CoachCard: **Keep Vienna development purposeful** — Bxd5 supports the Vienna plan of e4 plus Nc3, rapid development, and king safety before tactics.

- Plain hint: Support the center, develop quickly, and avoid premature queen attacks.

- Opening themes: Vienna development, central support, king safety


## vienna-white-line-003: 1. e4 e5 2. Nc3 Nc6 3. Bc4 Bc5 4. d3 Nf6 5. Bg5 d6 6. Nf3 h6

Runtime playKey: `e2e4,e7e5,b1c3,b8c6,f1c4,f8c5,d2d3,g8f6,c1g5,d7d6,g1f3,h7h6`  
Runtime totalGames field at line node: `826383`

### Packet vienna-white.line-003.ply-03.b1c3

- Move: `Nc3` / `b1c3` at ply 3

- CoachCard: **Support e4 with the Vienna knight** — Nc3 is the Vienna’s defining move: the knight supports e4 and keeps options for Bc4, g3, f4, or Nf3 depending on Black.

- Plain hint: Bring the queenside knight out to support the king-pawn center and keep kingside choices flexible.

- Opening themes: Nc3 supports e4, flexible kingside play, Vienna identity

### Packet vienna-white.line-003.ply-05.f1c4

- Move: `Bc4` / `f1c4` at ply 5

- CoachCard: **Aim the Vienna bishop at f7** — Bc4 develops the bishop toward f7, a natural Vienna attacking diagonal. The move supports rapid development without needing a premature queen sortie.

- Plain hint: Use the light-square bishop to pressure Black’s kingside before committing to tactics.

- Opening themes: Bc4 diagonal, f7 pressure, rapid development

### Packet vienna-white.line-003.ply-07.d2d3

- Move: `d3` / `d2d3` at ply 7

- CoachCard: **Build a quiet Vienna support base** — d3 supports e4 and gives White a stable Vienna structure. It prepares castling before any central or kingside expansion.

- Plain hint: Support the king pawn and keep the bishop diagonal open for safe development.

- Opening themes: d3 support, quiet Vienna, king safety

### Packet vienna-white.line-003.ply-09.c1g5

- Move: `Bg5` / `c1g5` at ply 9

- CoachCard: **Keep Vienna development purposeful** — Bg5 supports the Vienna plan of e4 plus Nc3, rapid development, and king safety before tactics.

- Plain hint: Support the center, develop quickly, and avoid premature queen attacks.

- Opening themes: Vienna development, central support, king safety

### Packet vienna-white.line-003.ply-11.g1f3

- Move: `Nf3` / `g1f3` at ply 11

- CoachCard: **Add kingside development to the Vienna center** — Nf3 develops the kingside knight and prepares castling while keeping the e-pawn defended. It fits quieter Vienna lines with steady development.

- Plain hint: Bring the kingside knight out once the Vienna center is supported.

- Opening themes: Nf3 development, king safety, e4 support


## vienna-white-line-004: 1. e4 e5 2. Nc3 Nc6 3. Bc4 Nf6 4. Nf3 Nxe4 5. Bxf7+ Kxf7 6. Nxe4 d5

Runtime playKey: `e2e4,e7e5,b1c3,b8c6,f1c4,g8f6,g1f3,f6e4,c4f7,e8f7,c3e4,d7d5`  
Runtime totalGames field at line node: `785278`

### Packet vienna-white.line-004.ply-03.b1c3

- Move: `Nc3` / `b1c3` at ply 3

- CoachCard: **Support e4 with the Vienna knight** — Nc3 is the Vienna’s defining move: the knight supports e4 and keeps options for Bc4, g3, f4, or Nf3 depending on Black.

- Plain hint: Bring the queenside knight out to support the king-pawn center and keep kingside choices flexible.

- Opening themes: Nc3 supports e4, flexible kingside play, Vienna identity

### Packet vienna-white.line-004.ply-05.f1c4

- Move: `Bc4` / `f1c4` at ply 5

- CoachCard: **Aim the Vienna bishop at f7** — Bc4 develops the bishop toward f7, a natural Vienna attacking diagonal. The move supports rapid development without needing a premature queen sortie.

- Plain hint: Use the light-square bishop to pressure Black’s kingside before committing to tactics.

- Opening themes: Bc4 diagonal, f7 pressure, rapid development

### Packet vienna-white.line-004.ply-07.g1f3

- Move: `Nf3` / `g1f3` at ply 7

- CoachCard: **Add kingside development to the Vienna center** — Nf3 develops the kingside knight and prepares castling while keeping the e-pawn defended. It fits quieter Vienna lines with steady development.

- Plain hint: Bring the kingside knight out once the Vienna center is supported.

- Opening themes: Nf3 development, king safety, e4 support

### Packet vienna-white.line-004.ply-09.c4f7

- Move: `Bxf7+` / `c4f7` at ply 9

- CoachCard: **Keep Vienna development purposeful** — Bxf7+ supports the Vienna plan of e4 plus Nc3, rapid development, and king safety before tactics.

- Plain hint: Support the center, develop quickly, and avoid premature queen attacks.

- Opening themes: Vienna development, central support, king safety

### Packet vienna-white.line-004.ply-11.c3e4

- Move: `Nxe4` / `c3e4` at ply 11

- CoachCard: **Keep Vienna development purposeful** — Nxe4 supports the Vienna plan of e4 plus Nc3, rapid development, and king safety before tactics.

- Plain hint: Support the center, develop quickly, and avoid premature queen attacks.

- Opening themes: Vienna development, central support, king safety


## vienna-white-line-005: 1. e4 e5 2. Nc3 Nc6 3. Nf3 Nf6 4. Bb5 d6 5. d4 exd4 6. Nxd4 Bd7

Runtime playKey: `e2e4,e7e5,b1c3,b8c6,g1f3,g8f6,f1b5,d7d6,d2d4,e5d4,f3d4,c8d7`  
Runtime totalGames field at line node: `762961`

### Packet vienna-white.line-005.ply-03.b1c3

- Move: `Nc3` / `b1c3` at ply 3

- CoachCard: **Support e4 with the Vienna knight** — Nc3 is the Vienna’s defining move: the knight supports e4 and keeps options for Bc4, g3, f4, or Nf3 depending on Black.

- Plain hint: Bring the queenside knight out to support the king-pawn center and keep kingside choices flexible.

- Opening themes: Nc3 supports e4, flexible kingside play, Vienna identity

### Packet vienna-white.line-005.ply-05.g1f3

- Move: `Nf3` / `g1f3` at ply 5

- CoachCard: **Add kingside development to the Vienna center** — Nf3 develops the kingside knight and prepares castling while keeping the e-pawn defended. It fits quieter Vienna lines with steady development.

- Plain hint: Bring the kingside knight out once the Vienna center is supported.

- Opening themes: Nf3 development, king safety, e4 support

### Packet vienna-white.line-005.ply-07.f1b5

- Move: `Bb5` / `f1b5` at ply 7

- CoachCard: **Keep Vienna development purposeful** — Bb5 supports the Vienna plan of e4 plus Nc3, rapid development, and king safety before tactics.

- Plain hint: Support the center, develop quickly, and avoid premature queen attacks.

- Opening themes: Vienna development, central support, king safety

### Packet vienna-white.line-005.ply-09.d2d4

- Move: `d4` / `d2d4` at ply 9

- CoachCard: **Use the supported Vienna central break** — d4 expands in the center from a Vienna setup. White uses Nc3 and development to make the central break credible.

- Plain hint: Break in the center only after the pieces and pawn base support it.

- Opening themes: d4 break, central expansion, piece support

### Packet vienna-white.line-005.ply-11.f3d4

- Move: `Nxd4` / `f3d4` at ply 11

- CoachCard: **Keep Vienna development purposeful** — Nxd4 supports the Vienna plan of e4 plus Nc3, rapid development, and king safety before tactics.

- Plain hint: Support the center, develop quickly, and avoid premature queen attacks.

- Opening themes: Vienna development, central support, king safety


## vienna-white-line-006: 1. e4 e5 2. Nc3 Nc6 3. Bc4 Bc5 4. d3 d6 5. Nf3 Bg4 6. h3 Bh5

Runtime playKey: `e2e4,e7e5,b1c3,b8c6,f1c4,f8c5,d2d3,d7d6,g1f3,c8g4,h2h3,g4h5`  
Runtime totalGames field at line node: `472294`

### Packet vienna-white.line-006.ply-03.b1c3

- Move: `Nc3` / `b1c3` at ply 3

- CoachCard: **Support e4 with the Vienna knight** — Nc3 is the Vienna’s defining move: the knight supports e4 and keeps options for Bc4, g3, f4, or Nf3 depending on Black.

- Plain hint: Bring the queenside knight out to support the king-pawn center and keep kingside choices flexible.

- Opening themes: Nc3 supports e4, flexible kingside play, Vienna identity

### Packet vienna-white.line-006.ply-05.f1c4

- Move: `Bc4` / `f1c4` at ply 5

- CoachCard: **Aim the Vienna bishop at f7** — Bc4 develops the bishop toward f7, a natural Vienna attacking diagonal. The move supports rapid development without needing a premature queen sortie.

- Plain hint: Use the light-square bishop to pressure Black’s kingside before committing to tactics.

- Opening themes: Bc4 diagonal, f7 pressure, rapid development

### Packet vienna-white.line-006.ply-07.d2d3

- Move: `d3` / `d2d3` at ply 7

- CoachCard: **Build a quiet Vienna support base** — d3 supports e4 and gives White a stable Vienna structure. It prepares castling before any central or kingside expansion.

- Plain hint: Support the king pawn and keep the bishop diagonal open for safe development.

- Opening themes: d3 support, quiet Vienna, king safety

### Packet vienna-white.line-006.ply-09.g1f3

- Move: `Nf3` / `g1f3` at ply 9

- CoachCard: **Add kingside development to the Vienna center** — Nf3 develops the kingside knight and prepares castling while keeping the e-pawn defended. It fits quieter Vienna lines with steady development.

- Plain hint: Bring the kingside knight out once the Vienna center is supported.

- Opening themes: Nf3 development, king safety, e4 support

### Packet vienna-white.line-006.ply-11.h2h3

- Move: `h3` / `h2h3` at ply 11

- CoachCard: **Keep Vienna development purposeful** — h3 supports the Vienna plan of e4 plus Nc3, rapid development, and king safety before tactics.

- Plain hint: Support the center, develop quickly, and avoid premature queen attacks.

- Opening themes: Vienna development, central support, king safety


## vienna-white-line-007: 1. e4 e5 2. Nc3 Nf6 3. Nf3 Bc5 4. Nxe5 Nc6 5. Nxc6 dxc6 6. Bc4 Ng4

Runtime playKey: `e2e4,e7e5,b1c3,g8f6,g1f3,f8c5,f3e5,b8c6,e5c6,d7c6,f1c4,f6g4`  
Runtime totalGames field at line node: `446381`

### Packet vienna-white.line-007.ply-03.b1c3

- Move: `Nc3` / `b1c3` at ply 3

- CoachCard: **Support e4 with the Vienna knight** — Nc3 is the Vienna’s defining move: the knight supports e4 and keeps options for Bc4, g3, f4, or Nf3 depending on Black.

- Plain hint: Bring the queenside knight out to support the king-pawn center and keep kingside choices flexible.

- Opening themes: Nc3 supports e4, flexible kingside play, Vienna identity

### Packet vienna-white.line-007.ply-05.g1f3

- Move: `Nf3` / `g1f3` at ply 5

- CoachCard: **Add kingside development to the Vienna center** — Nf3 develops the kingside knight and prepares castling while keeping the e-pawn defended. It fits quieter Vienna lines with steady development.

- Plain hint: Bring the kingside knight out once the Vienna center is supported.

- Opening themes: Nf3 development, king safety, e4 support

### Packet vienna-white.line-007.ply-07.f3e5

- Move: `Nxe5` / `f3e5` at ply 7

- CoachCard: **Keep Vienna development purposeful** — Nxe5 supports the Vienna plan of e4 plus Nc3, rapid development, and king safety before tactics.

- Plain hint: Support the center, develop quickly, and avoid premature queen attacks.

- Opening themes: Vienna development, central support, king safety

### Packet vienna-white.line-007.ply-09.e5c6

- Move: `Nxc6` / `e5c6` at ply 9

- CoachCard: **Keep Vienna development purposeful** — Nxc6 supports the Vienna plan of e4 plus Nc3, rapid development, and king safety before tactics.

- Plain hint: Support the center, develop quickly, and avoid premature queen attacks.

- Opening themes: Vienna development, central support, king safety

### Packet vienna-white.line-007.ply-11.f1c4

- Move: `Bc4` / `f1c4` at ply 11

- CoachCard: **Aim the Vienna bishop at f7** — Bc4 develops the bishop toward f7, a natural Vienna attacking diagonal. The move supports rapid development without needing a premature queen sortie.

- Plain hint: Use the light-square bishop to pressure Black’s kingside before committing to tactics.

- Opening themes: Bc4 diagonal, f7 pressure, rapid development


## vienna-white-line-008: 1. e4 e5 2. Nc3 Nc6 3. Bc4 Nf6 4. Nf3 Nxe4 5. Nxe4 d5 6. Bd3 dxe4

Runtime playKey: `e2e4,e7e5,b1c3,b8c6,f1c4,g8f6,g1f3,f6e4,c3e4,d7d5,c4d3,d5e4`  
Runtime totalGames field at line node: `428542`

### Packet vienna-white.line-008.ply-03.b1c3

- Move: `Nc3` / `b1c3` at ply 3

- CoachCard: **Support e4 with the Vienna knight** — Nc3 is the Vienna’s defining move: the knight supports e4 and keeps options for Bc4, g3, f4, or Nf3 depending on Black.

- Plain hint: Bring the queenside knight out to support the king-pawn center and keep kingside choices flexible.

- Opening themes: Nc3 supports e4, flexible kingside play, Vienna identity

### Packet vienna-white.line-008.ply-05.f1c4

- Move: `Bc4` / `f1c4` at ply 5

- CoachCard: **Aim the Vienna bishop at f7** — Bc4 develops the bishop toward f7, a natural Vienna attacking diagonal. The move supports rapid development without needing a premature queen sortie.

- Plain hint: Use the light-square bishop to pressure Black’s kingside before committing to tactics.

- Opening themes: Bc4 diagonal, f7 pressure, rapid development

### Packet vienna-white.line-008.ply-07.g1f3

- Move: `Nf3` / `g1f3` at ply 7

- CoachCard: **Add kingside development to the Vienna center** — Nf3 develops the kingside knight and prepares castling while keeping the e-pawn defended. It fits quieter Vienna lines with steady development.

- Plain hint: Bring the kingside knight out once the Vienna center is supported.

- Opening themes: Nf3 development, king safety, e4 support

### Packet vienna-white.line-008.ply-09.c3e4

- Move: `Nxe4` / `c3e4` at ply 9

- CoachCard: **Keep Vienna development purposeful** — Nxe4 supports the Vienna plan of e4 plus Nc3, rapid development, and king safety before tactics.

- Plain hint: Support the center, develop quickly, and avoid premature queen attacks.

- Opening themes: Vienna development, central support, king safety

### Packet vienna-white.line-008.ply-11.c4d3

- Move: `Bd3` / `c4d3` at ply 11

- CoachCard: **Keep Vienna development purposeful** — Bd3 supports the Vienna plan of e4 plus Nc3, rapid development, and king safety before tactics.

- Plain hint: Support the center, develop quickly, and avoid premature queen attacks.

- Opening themes: Vienna development, central support, king safety


## vienna-white-line-009: 1. e4 e5 2. Nc3 Nc6 3. Bc4 Bc5 4. d3 Nf6 5. Bg5 d6 6. Nf3 Bg4

Runtime playKey: `e2e4,e7e5,b1c3,b8c6,f1c4,f8c5,d2d3,g8f6,c1g5,d7d6,g1f3,c8g4`  
Runtime totalGames field at line node: `420585`

### Packet vienna-white.line-009.ply-03.b1c3

- Move: `Nc3` / `b1c3` at ply 3

- CoachCard: **Support e4 with the Vienna knight** — Nc3 is the Vienna’s defining move: the knight supports e4 and keeps options for Bc4, g3, f4, or Nf3 depending on Black.

- Plain hint: Bring the queenside knight out to support the king-pawn center and keep kingside choices flexible.

- Opening themes: Nc3 supports e4, flexible kingside play, Vienna identity

### Packet vienna-white.line-009.ply-05.f1c4

- Move: `Bc4` / `f1c4` at ply 5

- CoachCard: **Aim the Vienna bishop at f7** — Bc4 develops the bishop toward f7, a natural Vienna attacking diagonal. The move supports rapid development without needing a premature queen sortie.

- Plain hint: Use the light-square bishop to pressure Black’s kingside before committing to tactics.

- Opening themes: Bc4 diagonal, f7 pressure, rapid development

### Packet vienna-white.line-009.ply-07.d2d3

- Move: `d3` / `d2d3` at ply 7

- CoachCard: **Build a quiet Vienna support base** — d3 supports e4 and gives White a stable Vienna structure. It prepares castling before any central or kingside expansion.

- Plain hint: Support the king pawn and keep the bishop diagonal open for safe development.

- Opening themes: d3 support, quiet Vienna, king safety

### Packet vienna-white.line-009.ply-09.c1g5

- Move: `Bg5` / `c1g5` at ply 9

- CoachCard: **Keep Vienna development purposeful** — Bg5 supports the Vienna plan of e4 plus Nc3, rapid development, and king safety before tactics.

- Plain hint: Support the center, develop quickly, and avoid premature queen attacks.

- Opening themes: Vienna development, central support, king safety

### Packet vienna-white.line-009.ply-11.g1f3

- Move: `Nf3` / `g1f3` at ply 11

- CoachCard: **Add kingside development to the Vienna center** — Nf3 develops the kingside knight and prepares castling while keeping the e-pawn defended. It fits quieter Vienna lines with steady development.

- Plain hint: Bring the kingside knight out once the Vienna center is supported.

- Opening themes: Nf3 development, king safety, e4 support


## vienna-white-line-010: 1. e4 e5 2. Nc3 Nc6 3. Bc4 Bc5 4. d3 d6 5. h3 Nf6 6. Nf3 Be6

Runtime playKey: `e2e4,e7e5,b1c3,b8c6,f1c4,f8c5,d2d3,d7d6,h2h3,g8f6,g1f3,c8e6`  
Runtime totalGames field at line node: `419138`

### Packet vienna-white.line-010.ply-03.b1c3

- Move: `Nc3` / `b1c3` at ply 3

- CoachCard: **Support e4 with the Vienna knight** — Nc3 is the Vienna’s defining move: the knight supports e4 and keeps options for Bc4, g3, f4, or Nf3 depending on Black.

- Plain hint: Bring the queenside knight out to support the king-pawn center and keep kingside choices flexible.

- Opening themes: Nc3 supports e4, flexible kingside play, Vienna identity

### Packet vienna-white.line-010.ply-05.f1c4

- Move: `Bc4` / `f1c4` at ply 5

- CoachCard: **Aim the Vienna bishop at f7** — Bc4 develops the bishop toward f7, a natural Vienna attacking diagonal. The move supports rapid development without needing a premature queen sortie.

- Plain hint: Use the light-square bishop to pressure Black’s kingside before committing to tactics.

- Opening themes: Bc4 diagonal, f7 pressure, rapid development

### Packet vienna-white.line-010.ply-07.d2d3

- Move: `d3` / `d2d3` at ply 7

- CoachCard: **Build a quiet Vienna support base** — d3 supports e4 and gives White a stable Vienna structure. It prepares castling before any central or kingside expansion.

- Plain hint: Support the king pawn and keep the bishop diagonal open for safe development.

- Opening themes: d3 support, quiet Vienna, king safety

### Packet vienna-white.line-010.ply-09.h2h3

- Move: `h3` / `h2h3` at ply 9

- CoachCard: **Keep Vienna development purposeful** — h3 supports the Vienna plan of e4 plus Nc3, rapid development, and king safety before tactics.

- Plain hint: Support the center, develop quickly, and avoid premature queen attacks.

- Opening themes: Vienna development, central support, king safety

### Packet vienna-white.line-010.ply-11.g1f3

- Move: `Nf3` / `g1f3` at ply 11

- CoachCard: **Add kingside development to the Vienna center** — Nf3 develops the kingside knight and prepares castling while keeping the e-pawn defended. It fits quieter Vienna lines with steady development.

- Plain hint: Bring the kingside knight out once the Vienna center is supported.

- Opening themes: Nf3 development, king safety, e4 support


## vienna-white-line-011: 1. e4 e5 2. Nc3 Nc6 3. Nf3 Nf6 4. Bb5 d6 5. Bxc6+ bxc6 6. d4 exd4

Runtime playKey: `e2e4,e7e5,b1c3,b8c6,g1f3,g8f6,f1b5,d7d6,b5c6,b7c6,d2d4,e5d4`  
Runtime totalGames field at line node: `247036`

### Packet vienna-white.line-011.ply-03.b1c3

- Move: `Nc3` / `b1c3` at ply 3

- CoachCard: **Support e4 with the Vienna knight** — Nc3 is the Vienna’s defining move: the knight supports e4 and keeps options for Bc4, g3, f4, or Nf3 depending on Black.

- Plain hint: Bring the queenside knight out to support the king-pawn center and keep kingside choices flexible.

- Opening themes: Nc3 supports e4, flexible kingside play, Vienna identity

### Packet vienna-white.line-011.ply-05.g1f3

- Move: `Nf3` / `g1f3` at ply 5

- CoachCard: **Add kingside development to the Vienna center** — Nf3 develops the kingside knight and prepares castling while keeping the e-pawn defended. It fits quieter Vienna lines with steady development.

- Plain hint: Bring the kingside knight out once the Vienna center is supported.

- Opening themes: Nf3 development, king safety, e4 support

### Packet vienna-white.line-011.ply-07.f1b5

- Move: `Bb5` / `f1b5` at ply 7

- CoachCard: **Keep Vienna development purposeful** — Bb5 supports the Vienna plan of e4 plus Nc3, rapid development, and king safety before tactics.

- Plain hint: Support the center, develop quickly, and avoid premature queen attacks.

- Opening themes: Vienna development, central support, king safety

### Packet vienna-white.line-011.ply-09.b5c6

- Move: `Bxc6+` / `b5c6` at ply 9

- CoachCard: **Keep Vienna development purposeful** — Bxc6+ supports the Vienna plan of e4 plus Nc3, rapid development, and king safety before tactics.

- Plain hint: Support the center, develop quickly, and avoid premature queen attacks.

- Opening themes: Vienna development, central support, king safety

### Packet vienna-white.line-011.ply-11.d2d4

- Move: `d4` / `d2d4` at ply 11

- CoachCard: **Use the supported Vienna central break** — d4 expands in the center from a Vienna setup. White uses Nc3 and development to make the central break credible.

- Plain hint: Break in the center only after the pieces and pawn base support it.

- Opening themes: d4 break, central expansion, piece support


## vienna-white-line-012: 1. e4 e5 2. Nc3 Nc6 3. Nf3 Bc5 4. Bb5 Nf6 5. Bxc6 dxc6 6. Nxe5 Qd4

Runtime playKey: `e2e4,e7e5,b1c3,b8c6,g1f3,f8c5,f1b5,g8f6,b5c6,d7c6,f3e5,d8d4`  
Runtime totalGames field at line node: `235148`

### Packet vienna-white.line-012.ply-03.b1c3

- Move: `Nc3` / `b1c3` at ply 3

- CoachCard: **Support e4 with the Vienna knight** — Nc3 is the Vienna’s defining move: the knight supports e4 and keeps options for Bc4, g3, f4, or Nf3 depending on Black.

- Plain hint: Bring the queenside knight out to support the king-pawn center and keep kingside choices flexible.

- Opening themes: Nc3 supports e4, flexible kingside play, Vienna identity

### Packet vienna-white.line-012.ply-05.g1f3

- Move: `Nf3` / `g1f3` at ply 5

- CoachCard: **Add kingside development to the Vienna center** — Nf3 develops the kingside knight and prepares castling while keeping the e-pawn defended. It fits quieter Vienna lines with steady development.

- Plain hint: Bring the kingside knight out once the Vienna center is supported.

- Opening themes: Nf3 development, king safety, e4 support

### Packet vienna-white.line-012.ply-07.f1b5

- Move: `Bb5` / `f1b5` at ply 7

- CoachCard: **Keep Vienna development purposeful** — Bb5 supports the Vienna plan of e4 plus Nc3, rapid development, and king safety before tactics.

- Plain hint: Support the center, develop quickly, and avoid premature queen attacks.

- Opening themes: Vienna development, central support, king safety

### Packet vienna-white.line-012.ply-09.b5c6

- Move: `Bxc6` / `b5c6` at ply 9

- CoachCard: **Keep Vienna development purposeful** — Bxc6 supports the Vienna plan of e4 plus Nc3, rapid development, and king safety before tactics.

- Plain hint: Support the center, develop quickly, and avoid premature queen attacks.

- Opening themes: Vienna development, central support, king safety

### Packet vienna-white.line-012.ply-11.f3e5

- Move: `Nxe5` / `f3e5` at ply 11

- CoachCard: **Keep Vienna development purposeful** — Nxe5 supports the Vienna plan of e4 plus Nc3, rapid development, and king safety before tactics.

- Plain hint: Support the center, develop quickly, and avoid premature queen attacks.

- Opening themes: Vienna development, central support, king safety


## vienna-white-line-013: 1. e4 e5 2. Nc3 Nf6 3. f4 exf4 4. e5 Ng8 5. d4 d6 6. Nf3 dxe5

Runtime playKey: `e2e4,e7e5,b1c3,g8f6,f2f4,e5f4,e4e5,f6g8,d2d4,d7d6,g1f3,d6e5`  
Runtime totalGames field at line node: `224201`

### Packet vienna-white.line-013.ply-03.b1c3

- Move: `Nc3` / `b1c3` at ply 3

- CoachCard: **Support e4 with the Vienna knight** — Nc3 is the Vienna’s defining move: the knight supports e4 and keeps options for Bc4, g3, f4, or Nf3 depending on Black.

- Plain hint: Bring the queenside knight out to support the king-pawn center and keep kingside choices flexible.

- Opening themes: Nc3 supports e4, flexible kingside play, Vienna identity

### Packet vienna-white.line-013.ply-05.f2f4

- Move: `f4` / `f2f4` at ply 5

- CoachCard: **Use the Vienna f-pawn only when supported** — f4 is the Vienna f-pawn idea, adding kingside pressure while challenging Black’s center. It should be supported by White’s development, not played as a loose pawn rush.

- Plain hint: Expand on the kingside only when the center and pieces already support it.

- Opening themes: f4 idea, kingside pressure, central support

### Packet vienna-white.line-013.ply-07.e4e5

- Move: `e5` / `e4e5` at ply 7

- CoachCard: **Keep Vienna development purposeful** — e5 supports the Vienna plan of e4 plus Nc3, rapid development, and king safety before tactics.

- Plain hint: Support the center, develop quickly, and avoid premature queen attacks.

- Opening themes: Vienna development, central support, king safety

### Packet vienna-white.line-013.ply-09.d2d4

- Move: `d4` / `d2d4` at ply 9

- CoachCard: **Use the supported Vienna central break** — d4 expands in the center from a Vienna setup. White uses Nc3 and development to make the central break credible.

- Plain hint: Break in the center only after the pieces and pawn base support it.

- Opening themes: d4 break, central expansion, piece support

### Packet vienna-white.line-013.ply-11.g1f3

- Move: `Nf3` / `g1f3` at ply 11

- CoachCard: **Add kingside development to the Vienna center** — Nf3 develops the kingside knight and prepares castling while keeping the e-pawn defended. It fits quieter Vienna lines with steady development.

- Plain hint: Bring the kingside knight out once the Vienna center is supported.

- Opening themes: Nf3 development, king safety, e4 support


## vienna-white-line-014: 1. e4 e5 2. Nc3 Nf6 3. Nf3 Bc5 4. Nxe5 Nc6 5. Nxc6 dxc6 6. h3 h5

Runtime playKey: `e2e4,e7e5,b1c3,g8f6,g1f3,f8c5,f3e5,b8c6,e5c6,d7c6,h2h3,h7h5`  
Runtime totalGames field at line node: `215202`

### Packet vienna-white.line-014.ply-03.b1c3

- Move: `Nc3` / `b1c3` at ply 3

- CoachCard: **Support e4 with the Vienna knight** — Nc3 is the Vienna’s defining move: the knight supports e4 and keeps options for Bc4, g3, f4, or Nf3 depending on Black.

- Plain hint: Bring the queenside knight out to support the king-pawn center and keep kingside choices flexible.

- Opening themes: Nc3 supports e4, flexible kingside play, Vienna identity

### Packet vienna-white.line-014.ply-05.g1f3

- Move: `Nf3` / `g1f3` at ply 5

- CoachCard: **Add kingside development to the Vienna center** — Nf3 develops the kingside knight and prepares castling while keeping the e-pawn defended. It fits quieter Vienna lines with steady development.

- Plain hint: Bring the kingside knight out once the Vienna center is supported.

- Opening themes: Nf3 development, king safety, e4 support

### Packet vienna-white.line-014.ply-07.f3e5

- Move: `Nxe5` / `f3e5` at ply 7

- CoachCard: **Keep Vienna development purposeful** — Nxe5 supports the Vienna plan of e4 plus Nc3, rapid development, and king safety before tactics.

- Plain hint: Support the center, develop quickly, and avoid premature queen attacks.

- Opening themes: Vienna development, central support, king safety

### Packet vienna-white.line-014.ply-09.e5c6

- Move: `Nxc6` / `e5c6` at ply 9

- CoachCard: **Keep Vienna development purposeful** — Nxc6 supports the Vienna plan of e4 plus Nc3, rapid development, and king safety before tactics.

- Plain hint: Support the center, develop quickly, and avoid premature queen attacks.

- Opening themes: Vienna development, central support, king safety

### Packet vienna-white.line-014.ply-11.h2h3

- Move: `h3` / `h2h3` at ply 11

- CoachCard: **Keep Vienna development purposeful** — h3 supports the Vienna plan of e4 plus Nc3, rapid development, and king safety before tactics.

- Plain hint: Support the center, develop quickly, and avoid premature queen attacks.

- Opening themes: Vienna development, central support, king safety


## vienna-white-line-015: 1. e4 e5 2. Nc3 Nf6 3. Nf3 Bc5 4. Nxe5 Nc6 5. Nxc6 dxc6 6. h3 Qd4

Runtime playKey: `e2e4,e7e5,b1c3,g8f6,g1f3,f8c5,f3e5,b8c6,e5c6,d7c6,h2h3,d8d4`  
Runtime totalGames field at line node: `193986`

### Packet vienna-white.line-015.ply-03.b1c3

- Move: `Nc3` / `b1c3` at ply 3

- CoachCard: **Support e4 with the Vienna knight** — Nc3 is the Vienna’s defining move: the knight supports e4 and keeps options for Bc4, g3, f4, or Nf3 depending on Black.

- Plain hint: Bring the queenside knight out to support the king-pawn center and keep kingside choices flexible.

- Opening themes: Nc3 supports e4, flexible kingside play, Vienna identity

### Packet vienna-white.line-015.ply-05.g1f3

- Move: `Nf3` / `g1f3` at ply 5

- CoachCard: **Add kingside development to the Vienna center** — Nf3 develops the kingside knight and prepares castling while keeping the e-pawn defended. It fits quieter Vienna lines with steady development.

- Plain hint: Bring the kingside knight out once the Vienna center is supported.

- Opening themes: Nf3 development, king safety, e4 support

### Packet vienna-white.line-015.ply-07.f3e5

- Move: `Nxe5` / `f3e5` at ply 7

- CoachCard: **Keep Vienna development purposeful** — Nxe5 supports the Vienna plan of e4 plus Nc3, rapid development, and king safety before tactics.

- Plain hint: Support the center, develop quickly, and avoid premature queen attacks.

- Opening themes: Vienna development, central support, king safety

### Packet vienna-white.line-015.ply-09.e5c6

- Move: `Nxc6` / `e5c6` at ply 9

- CoachCard: **Keep Vienna development purposeful** — Nxc6 supports the Vienna plan of e4 plus Nc3, rapid development, and king safety before tactics.

- Plain hint: Support the center, develop quickly, and avoid premature queen attacks.

- Opening themes: Vienna development, central support, king safety

### Packet vienna-white.line-015.ply-11.h2h3

- Move: `h3` / `h2h3` at ply 11

- CoachCard: **Keep Vienna development purposeful** — h3 supports the Vienna plan of e4 plus Nc3, rapid development, and king safety before tactics.

- Plain hint: Support the center, develop quickly, and avoid premature queen attacks.

- Opening themes: Vienna development, central support, king safety


## vienna-white-line-016: 1. e4 e5 2. Nc3 Nc6 3. Bc4 Bc5 4. d3 Nf6 5. f4 d6 6. Nf3 Bg4

Runtime playKey: `e2e4,e7e5,b1c3,b8c6,f1c4,f8c5,d2d3,g8f6,f2f4,d7d6,g1f3,c8g4`  
Runtime totalGames field at line node: `192887`

### Packet vienna-white.line-016.ply-03.b1c3

- Move: `Nc3` / `b1c3` at ply 3

- CoachCard: **Support e4 with the Vienna knight** — Nc3 is the Vienna’s defining move: the knight supports e4 and keeps options for Bc4, g3, f4, or Nf3 depending on Black.

- Plain hint: Bring the queenside knight out to support the king-pawn center and keep kingside choices flexible.

- Opening themes: Nc3 supports e4, flexible kingside play, Vienna identity

### Packet vienna-white.line-016.ply-05.f1c4

- Move: `Bc4` / `f1c4` at ply 5

- CoachCard: **Aim the Vienna bishop at f7** — Bc4 develops the bishop toward f7, a natural Vienna attacking diagonal. The move supports rapid development without needing a premature queen sortie.

- Plain hint: Use the light-square bishop to pressure Black’s kingside before committing to tactics.

- Opening themes: Bc4 diagonal, f7 pressure, rapid development

### Packet vienna-white.line-016.ply-07.d2d3

- Move: `d3` / `d2d3` at ply 7

- CoachCard: **Build a quiet Vienna support base** — d3 supports e4 and gives White a stable Vienna structure. It prepares castling before any central or kingside expansion.

- Plain hint: Support the king pawn and keep the bishop diagonal open for safe development.

- Opening themes: d3 support, quiet Vienna, king safety

### Packet vienna-white.line-016.ply-09.f2f4

- Move: `f4` / `f2f4` at ply 9

- CoachCard: **Use the Vienna f-pawn only when supported** — f4 is the Vienna f-pawn idea, adding kingside pressure while challenging Black’s center. It should be supported by White’s development, not played as a loose pawn rush.

- Plain hint: Expand on the kingside only when the center and pieces already support it.

- Opening themes: f4 idea, kingside pressure, central support

### Packet vienna-white.line-016.ply-11.g1f3

- Move: `Nf3` / `g1f3` at ply 11

- CoachCard: **Add kingside development to the Vienna center** — Nf3 develops the kingside knight and prepares castling while keeping the e-pawn defended. It fits quieter Vienna lines with steady development.

- Plain hint: Bring the kingside knight out once the Vienna center is supported.

- Opening themes: Nf3 development, king safety, e4 support


## vienna-white-line-017: 1. e4 e5 2. Nc3 Nc6 3. Nf3 Bc5 4. Bb5 d6 5. Bxc6+ bxc6 6. d4 exd4

Runtime playKey: `e2e4,e7e5,b1c3,b8c6,g1f3,f8c5,f1b5,d7d6,b5c6,b7c6,d2d4,e5d4`  
Runtime totalGames field at line node: `178434`

### Packet vienna-white.line-017.ply-03.b1c3

- Move: `Nc3` / `b1c3` at ply 3

- CoachCard: **Support e4 with the Vienna knight** — Nc3 is the Vienna’s defining move: the knight supports e4 and keeps options for Bc4, g3, f4, or Nf3 depending on Black.

- Plain hint: Bring the queenside knight out to support the king-pawn center and keep kingside choices flexible.

- Opening themes: Nc3 supports e4, flexible kingside play, Vienna identity

### Packet vienna-white.line-017.ply-05.g1f3

- Move: `Nf3` / `g1f3` at ply 5

- CoachCard: **Add kingside development to the Vienna center** — Nf3 develops the kingside knight and prepares castling while keeping the e-pawn defended. It fits quieter Vienna lines with steady development.

- Plain hint: Bring the kingside knight out once the Vienna center is supported.

- Opening themes: Nf3 development, king safety, e4 support

### Packet vienna-white.line-017.ply-07.f1b5

- Move: `Bb5` / `f1b5` at ply 7

- CoachCard: **Keep Vienna development purposeful** — Bb5 supports the Vienna plan of e4 plus Nc3, rapid development, and king safety before tactics.

- Plain hint: Support the center, develop quickly, and avoid premature queen attacks.

- Opening themes: Vienna development, central support, king safety

### Packet vienna-white.line-017.ply-09.b5c6

- Move: `Bxc6+` / `b5c6` at ply 9

- CoachCard: **Keep Vienna development purposeful** — Bxc6+ supports the Vienna plan of e4 plus Nc3, rapid development, and king safety before tactics.

- Plain hint: Support the center, develop quickly, and avoid premature queen attacks.

- Opening themes: Vienna development, central support, king safety

### Packet vienna-white.line-017.ply-11.d2d4

- Move: `d4` / `d2d4` at ply 11

- CoachCard: **Use the supported Vienna central break** — d4 expands in the center from a Vienna setup. White uses Nc3 and development to make the central break credible.

- Plain hint: Break in the center only after the pieces and pawn base support it.

- Opening themes: d4 break, central expansion, piece support


## vienna-white-line-018: 1. e4 e5 2. Nc3 Nc6 3. f4 exf4 4. Nf3 d6 5. d4 Bg4 6. Bxf4 Nf6

Runtime playKey: `e2e4,e7e5,b1c3,b8c6,f2f4,e5f4,g1f3,d7d6,d2d4,c8g4,c1f4,g8f6`  
Runtime totalGames field at line node: `178323`

### Packet vienna-white.line-018.ply-03.b1c3

- Move: `Nc3` / `b1c3` at ply 3

- CoachCard: **Support e4 with the Vienna knight** — Nc3 is the Vienna’s defining move: the knight supports e4 and keeps options for Bc4, g3, f4, or Nf3 depending on Black.

- Plain hint: Bring the queenside knight out to support the king-pawn center and keep kingside choices flexible.

- Opening themes: Nc3 supports e4, flexible kingside play, Vienna identity

### Packet vienna-white.line-018.ply-05.f2f4

- Move: `f4` / `f2f4` at ply 5

- CoachCard: **Use the Vienna f-pawn only when supported** — f4 is the Vienna f-pawn idea, adding kingside pressure while challenging Black’s center. It should be supported by White’s development, not played as a loose pawn rush.

- Plain hint: Expand on the kingside only when the center and pieces already support it.

- Opening themes: f4 idea, kingside pressure, central support

### Packet vienna-white.line-018.ply-07.g1f3

- Move: `Nf3` / `g1f3` at ply 7

- CoachCard: **Add kingside development to the Vienna center** — Nf3 develops the kingside knight and prepares castling while keeping the e-pawn defended. It fits quieter Vienna lines with steady development.

- Plain hint: Bring the kingside knight out once the Vienna center is supported.

- Opening themes: Nf3 development, king safety, e4 support

### Packet vienna-white.line-018.ply-09.d2d4

- Move: `d4` / `d2d4` at ply 9

- CoachCard: **Use the supported Vienna central break** — d4 expands in the center from a Vienna setup. White uses Nc3 and development to make the central break credible.

- Plain hint: Break in the center only after the pieces and pawn base support it.

- Opening themes: d4 break, central expansion, piece support

### Packet vienna-white.line-018.ply-11.c1f4

- Move: `Bxf4` / `c1f4` at ply 11

- CoachCard: **Keep Vienna development purposeful** — Bxf4 supports the Vienna plan of e4 plus Nc3, rapid development, and king safety before tactics.

- Plain hint: Support the center, develop quickly, and avoid premature queen attacks.

- Opening themes: Vienna development, central support, king safety


## vienna-white-line-019: 1. e4 e5 2. Nc3 Nc6 3. Nf3 Nf6 4. Bb5 d6 5. Bxc6+ bxc6 6. d3 Be7

Runtime playKey: `e2e4,e7e5,b1c3,b8c6,g1f3,g8f6,f1b5,d7d6,b5c6,b7c6,d2d3,f8e7`  
Runtime totalGames field at line node: `142284`

### Packet vienna-white.line-019.ply-03.b1c3

- Move: `Nc3` / `b1c3` at ply 3

- CoachCard: **Support e4 with the Vienna knight** — Nc3 is the Vienna’s defining move: the knight supports e4 and keeps options for Bc4, g3, f4, or Nf3 depending on Black.

- Plain hint: Bring the queenside knight out to support the king-pawn center and keep kingside choices flexible.

- Opening themes: Nc3 supports e4, flexible kingside play, Vienna identity

### Packet vienna-white.line-019.ply-05.g1f3

- Move: `Nf3` / `g1f3` at ply 5

- CoachCard: **Add kingside development to the Vienna center** — Nf3 develops the kingside knight and prepares castling while keeping the e-pawn defended. It fits quieter Vienna lines with steady development.

- Plain hint: Bring the kingside knight out once the Vienna center is supported.

- Opening themes: Nf3 development, king safety, e4 support

### Packet vienna-white.line-019.ply-07.f1b5

- Move: `Bb5` / `f1b5` at ply 7

- CoachCard: **Keep Vienna development purposeful** — Bb5 supports the Vienna plan of e4 plus Nc3, rapid development, and king safety before tactics.

- Plain hint: Support the center, develop quickly, and avoid premature queen attacks.

- Opening themes: Vienna development, central support, king safety

### Packet vienna-white.line-019.ply-09.b5c6

- Move: `Bxc6+` / `b5c6` at ply 9

- CoachCard: **Keep Vienna development purposeful** — Bxc6+ supports the Vienna plan of e4 plus Nc3, rapid development, and king safety before tactics.

- Plain hint: Support the center, develop quickly, and avoid premature queen attacks.

- Opening themes: Vienna development, central support, king safety

### Packet vienna-white.line-019.ply-11.d2d3

- Move: `d3` / `d2d3` at ply 11

- CoachCard: **Build a quiet Vienna support base** — d3 supports e4 and gives White a stable Vienna structure. It prepares castling before any central or kingside expansion.

- Plain hint: Support the king pawn and keep the bishop diagonal open for safe development.

- Opening themes: d3 support, quiet Vienna, king safety


## vienna-white-line-020: 1. e4 e5 2. Nc3 Nc6 3. Bc4 Bc5 4. d3 d6 5. Nf3 h6 6. h3 a6

Runtime playKey: `e2e4,e7e5,b1c3,b8c6,f1c4,f8c5,d2d3,d7d6,g1f3,h7h6,h2h3,a7a6`  
Runtime totalGames field at line node: `137783`

### Packet vienna-white.line-020.ply-03.b1c3

- Move: `Nc3` / `b1c3` at ply 3

- CoachCard: **Support e4 with the Vienna knight** — Nc3 is the Vienna’s defining move: the knight supports e4 and keeps options for Bc4, g3, f4, or Nf3 depending on Black.

- Plain hint: Bring the queenside knight out to support the king-pawn center and keep kingside choices flexible.

- Opening themes: Nc3 supports e4, flexible kingside play, Vienna identity

### Packet vienna-white.line-020.ply-05.f1c4

- Move: `Bc4` / `f1c4` at ply 5

- CoachCard: **Aim the Vienna bishop at f7** — Bc4 develops the bishop toward f7, a natural Vienna attacking diagonal. The move supports rapid development without needing a premature queen sortie.

- Plain hint: Use the light-square bishop to pressure Black’s kingside before committing to tactics.

- Opening themes: Bc4 diagonal, f7 pressure, rapid development

### Packet vienna-white.line-020.ply-07.d2d3

- Move: `d3` / `d2d3` at ply 7

- CoachCard: **Build a quiet Vienna support base** — d3 supports e4 and gives White a stable Vienna structure. It prepares castling before any central or kingside expansion.

- Plain hint: Support the king pawn and keep the bishop diagonal open for safe development.

- Opening themes: d3 support, quiet Vienna, king safety

### Packet vienna-white.line-020.ply-09.g1f3

- Move: `Nf3` / `g1f3` at ply 9

- CoachCard: **Add kingside development to the Vienna center** — Nf3 develops the kingside knight and prepares castling while keeping the e-pawn defended. It fits quieter Vienna lines with steady development.

- Plain hint: Bring the kingside knight out once the Vienna center is supported.

- Opening themes: Nf3 development, king safety, e4 support

### Packet vienna-white.line-020.ply-11.h2h3

- Move: `h3` / `h2h3` at ply 11

- CoachCard: **Keep Vienna development purposeful** — h3 supports the Vienna plan of e4 plus Nc3, rapid development, and king safety before tactics.

- Plain hint: Support the center, develop quickly, and avoid premature queen attacks.

- Opening themes: Vienna development, central support, king safety


## vienna-white-line-021: 1. e4 e5 2. Nc3 Nc6 3. f4 exf4 4. Nf3 d6 5. d4 Nf6 6. Bxf4 Be7

Runtime playKey: `e2e4,e7e5,b1c3,b8c6,f2f4,e5f4,g1f3,d7d6,d2d4,g8f6,c1f4,f8e7`  
Runtime totalGames field at line node: `134492`

### Packet vienna-white.line-021.ply-03.b1c3

- Move: `Nc3` / `b1c3` at ply 3

- CoachCard: **Support e4 with the Vienna knight** — Nc3 is the Vienna’s defining move: the knight supports e4 and keeps options for Bc4, g3, f4, or Nf3 depending on Black.

- Plain hint: Bring the queenside knight out to support the king-pawn center and keep kingside choices flexible.

- Opening themes: Nc3 supports e4, flexible kingside play, Vienna identity

### Packet vienna-white.line-021.ply-05.f2f4

- Move: `f4` / `f2f4` at ply 5

- CoachCard: **Use the Vienna f-pawn only when supported** — f4 is the Vienna f-pawn idea, adding kingside pressure while challenging Black’s center. It should be supported by White’s development, not played as a loose pawn rush.

- Plain hint: Expand on the kingside only when the center and pieces already support it.

- Opening themes: f4 idea, kingside pressure, central support

### Packet vienna-white.line-021.ply-07.g1f3

- Move: `Nf3` / `g1f3` at ply 7

- CoachCard: **Add kingside development to the Vienna center** — Nf3 develops the kingside knight and prepares castling while keeping the e-pawn defended. It fits quieter Vienna lines with steady development.

- Plain hint: Bring the kingside knight out once the Vienna center is supported.

- Opening themes: Nf3 development, king safety, e4 support

### Packet vienna-white.line-021.ply-09.d2d4

- Move: `d4` / `d2d4` at ply 9

- CoachCard: **Use the supported Vienna central break** — d4 expands in the center from a Vienna setup. White uses Nc3 and development to make the central break credible.

- Plain hint: Break in the center only after the pieces and pawn base support it.

- Opening themes: d4 break, central expansion, piece support

### Packet vienna-white.line-021.ply-11.c1f4

- Move: `Bxf4` / `c1f4` at ply 11

- CoachCard: **Keep Vienna development purposeful** — Bxf4 supports the Vienna plan of e4 plus Nc3, rapid development, and king safety before tactics.

- Plain hint: Support the center, develop quickly, and avoid premature queen attacks.

- Opening themes: Vienna development, central support, king safety


## vienna-white-line-022: 1. e4 e5 2. Nc3 Nf6 3. Nf3 Bc5 4. Nxe5 Nc6 5. Nxc6 dxc6 6. Bc4 Qd4

Runtime playKey: `e2e4,e7e5,b1c3,g8f6,g1f3,f8c5,f3e5,b8c6,e5c6,d7c6,f1c4,d8d4`  
Runtime totalGames field at line node: `133248`

### Packet vienna-white.line-022.ply-03.b1c3

- Move: `Nc3` / `b1c3` at ply 3

- CoachCard: **Support e4 with the Vienna knight** — Nc3 is the Vienna’s defining move: the knight supports e4 and keeps options for Bc4, g3, f4, or Nf3 depending on Black.

- Plain hint: Bring the queenside knight out to support the king-pawn center and keep kingside choices flexible.

- Opening themes: Nc3 supports e4, flexible kingside play, Vienna identity

### Packet vienna-white.line-022.ply-05.g1f3

- Move: `Nf3` / `g1f3` at ply 5

- CoachCard: **Add kingside development to the Vienna center** — Nf3 develops the kingside knight and prepares castling while keeping the e-pawn defended. It fits quieter Vienna lines with steady development.

- Plain hint: Bring the kingside knight out once the Vienna center is supported.

- Opening themes: Nf3 development, king safety, e4 support

### Packet vienna-white.line-022.ply-07.f3e5

- Move: `Nxe5` / `f3e5` at ply 7

- CoachCard: **Keep Vienna development purposeful** — Nxe5 supports the Vienna plan of e4 plus Nc3, rapid development, and king safety before tactics.

- Plain hint: Support the center, develop quickly, and avoid premature queen attacks.

- Opening themes: Vienna development, central support, king safety

### Packet vienna-white.line-022.ply-09.e5c6

- Move: `Nxc6` / `e5c6` at ply 9

- CoachCard: **Keep Vienna development purposeful** — Nxc6 supports the Vienna plan of e4 plus Nc3, rapid development, and king safety before tactics.

- Plain hint: Support the center, develop quickly, and avoid premature queen attacks.

- Opening themes: Vienna development, central support, king safety

### Packet vienna-white.line-022.ply-11.f1c4

- Move: `Bc4` / `f1c4` at ply 11

- CoachCard: **Aim the Vienna bishop at f7** — Bc4 develops the bishop toward f7, a natural Vienna attacking diagonal. The move supports rapid development without needing a premature queen sortie.

- Plain hint: Use the light-square bishop to pressure Black’s kingside before committing to tactics.

- Opening themes: Bc4 diagonal, f7 pressure, rapid development


## vienna-white-line-023: 1. e4 e5 2. Nc3 Nc6 3. Bc4 Bc5 4. d3 d6 5. Nf3 h6 6. Be3 Bb6

Runtime playKey: `e2e4,e7e5,b1c3,b8c6,f1c4,f8c5,d2d3,d7d6,g1f3,h7h6,c1e3,c5b6`  
Runtime totalGames field at line node: `129768`

### Packet vienna-white.line-023.ply-03.b1c3

- Move: `Nc3` / `b1c3` at ply 3

- CoachCard: **Support e4 with the Vienna knight** — Nc3 is the Vienna’s defining move: the knight supports e4 and keeps options for Bc4, g3, f4, or Nf3 depending on Black.

- Plain hint: Bring the queenside knight out to support the king-pawn center and keep kingside choices flexible.

- Opening themes: Nc3 supports e4, flexible kingside play, Vienna identity

### Packet vienna-white.line-023.ply-05.f1c4

- Move: `Bc4` / `f1c4` at ply 5

- CoachCard: **Aim the Vienna bishop at f7** — Bc4 develops the bishop toward f7, a natural Vienna attacking diagonal. The move supports rapid development without needing a premature queen sortie.

- Plain hint: Use the light-square bishop to pressure Black’s kingside before committing to tactics.

- Opening themes: Bc4 diagonal, f7 pressure, rapid development

### Packet vienna-white.line-023.ply-07.d2d3

- Move: `d3` / `d2d3` at ply 7

- CoachCard: **Build a quiet Vienna support base** — d3 supports e4 and gives White a stable Vienna structure. It prepares castling before any central or kingside expansion.

- Plain hint: Support the king pawn and keep the bishop diagonal open for safe development.

- Opening themes: d3 support, quiet Vienna, king safety

### Packet vienna-white.line-023.ply-09.g1f3

- Move: `Nf3` / `g1f3` at ply 9

- CoachCard: **Add kingside development to the Vienna center** — Nf3 develops the kingside knight and prepares castling while keeping the e-pawn defended. It fits quieter Vienna lines with steady development.

- Plain hint: Bring the kingside knight out once the Vienna center is supported.

- Opening themes: Nf3 development, king safety, e4 support

### Packet vienna-white.line-023.ply-11.c1e3

- Move: `Be3` / `c1e3` at ply 11

- CoachCard: **Keep Vienna development purposeful** — Be3 supports the Vienna plan of e4 plus Nc3, rapid development, and king safety before tactics.

- Plain hint: Support the center, develop quickly, and avoid premature queen attacks.

- Opening themes: Vienna development, central support, king safety


## vienna-white-line-024: 1. e4 e5 2. Nc3 Nc6 3. Nf3 Nf6 4. Bb5 d6 5. d4 exd4 6. Qxd4 Bd7

Runtime playKey: `e2e4,e7e5,b1c3,b8c6,g1f3,g8f6,f1b5,d7d6,d2d4,e5d4,d1d4,c8d7`  
Runtime totalGames field at line node: `114283`

### Packet vienna-white.line-024.ply-03.b1c3

- Move: `Nc3` / `b1c3` at ply 3

- CoachCard: **Support e4 with the Vienna knight** — Nc3 is the Vienna’s defining move: the knight supports e4 and keeps options for Bc4, g3, f4, or Nf3 depending on Black.

- Plain hint: Bring the queenside knight out to support the king-pawn center and keep kingside choices flexible.

- Opening themes: Nc3 supports e4, flexible kingside play, Vienna identity

### Packet vienna-white.line-024.ply-05.g1f3

- Move: `Nf3` / `g1f3` at ply 5

- CoachCard: **Add kingside development to the Vienna center** — Nf3 develops the kingside knight and prepares castling while keeping the e-pawn defended. It fits quieter Vienna lines with steady development.

- Plain hint: Bring the kingside knight out once the Vienna center is supported.

- Opening themes: Nf3 development, king safety, e4 support

### Packet vienna-white.line-024.ply-07.f1b5

- Move: `Bb5` / `f1b5` at ply 7

- CoachCard: **Keep Vienna development purposeful** — Bb5 supports the Vienna plan of e4 plus Nc3, rapid development, and king safety before tactics.

- Plain hint: Support the center, develop quickly, and avoid premature queen attacks.

- Opening themes: Vienna development, central support, king safety

### Packet vienna-white.line-024.ply-09.d2d4

- Move: `d4` / `d2d4` at ply 9

- CoachCard: **Use the supported Vienna central break** — d4 expands in the center from a Vienna setup. White uses Nc3 and development to make the central break credible.

- Plain hint: Break in the center only after the pieces and pawn base support it.

- Opening themes: d4 break, central expansion, piece support

### Packet vienna-white.line-024.ply-11.d1d4

- Move: `Qxd4` / `d1d4` at ply 11

- CoachCard: **Keep Vienna development purposeful** — Qxd4 supports the Vienna plan of e4 plus Nc3, rapid development, and king safety before tactics.

- Plain hint: Support the center, develop quickly, and avoid premature queen attacks.

- Opening themes: Vienna development, central support, king safety


## vienna-white-line-025: 1. e4 e5 2. Nc3 Nc6 3. Bc4 Bc5 4. d3 d6 5. Nf3 Bg4 6. h3 Bxf3

Runtime playKey: `e2e4,e7e5,b1c3,b8c6,f1c4,f8c5,d2d3,d7d6,g1f3,c8g4,h2h3,g4f3`  
Runtime totalGames field at line node: `109930`

### Packet vienna-white.line-025.ply-03.b1c3

- Move: `Nc3` / `b1c3` at ply 3

- CoachCard: **Support e4 with the Vienna knight** — Nc3 is the Vienna’s defining move: the knight supports e4 and keeps options for Bc4, g3, f4, or Nf3 depending on Black.

- Plain hint: Bring the queenside knight out to support the king-pawn center and keep kingside choices flexible.

- Opening themes: Nc3 supports e4, flexible kingside play, Vienna identity

### Packet vienna-white.line-025.ply-05.f1c4

- Move: `Bc4` / `f1c4` at ply 5

- CoachCard: **Aim the Vienna bishop at f7** — Bc4 develops the bishop toward f7, a natural Vienna attacking diagonal. The move supports rapid development without needing a premature queen sortie.

- Plain hint: Use the light-square bishop to pressure Black’s kingside before committing to tactics.

- Opening themes: Bc4 diagonal, f7 pressure, rapid development

### Packet vienna-white.line-025.ply-07.d2d3

- Move: `d3` / `d2d3` at ply 7

- CoachCard: **Build a quiet Vienna support base** — d3 supports e4 and gives White a stable Vienna structure. It prepares castling before any central or kingside expansion.

- Plain hint: Support the king pawn and keep the bishop diagonal open for safe development.

- Opening themes: d3 support, quiet Vienna, king safety

### Packet vienna-white.line-025.ply-09.g1f3

- Move: `Nf3` / `g1f3` at ply 9

- CoachCard: **Add kingside development to the Vienna center** — Nf3 develops the kingside knight and prepares castling while keeping the e-pawn defended. It fits quieter Vienna lines with steady development.

- Plain hint: Bring the kingside knight out once the Vienna center is supported.

- Opening themes: Nf3 development, king safety, e4 support

### Packet vienna-white.line-025.ply-11.h2h3

- Move: `h3` / `h2h3` at ply 11

- CoachCard: **Keep Vienna development purposeful** — h3 supports the Vienna plan of e4 plus Nc3, rapid development, and king safety before tactics.

- Plain hint: Support the center, develop quickly, and avoid premature queen attacks.

- Opening themes: Vienna development, central support, king safety
