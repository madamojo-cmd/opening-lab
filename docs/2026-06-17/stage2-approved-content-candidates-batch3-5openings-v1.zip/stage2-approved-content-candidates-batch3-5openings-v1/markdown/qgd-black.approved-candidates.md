# Queen’s Gambit Declined approved-content candidates — Batch 3

Opening ID: `qgd-black`  
Status: approved candidates only; not app-activated.


## qgd-black-line-001: 1. d4 d5 2. c4 e6 3. Nf3 c6 4. Nc3 Nf6 5. Bg5 Nbd7 6. e3 Be7

Runtime playKey: `d2d4,d7d5,c2c4,e7e6,g1f3,c7c6,b1c3,g8f6,c1g5,b8d7,e2e3,f8e7`  
Runtime totalGames field at line node: `1385201`

### Packet qgd-black.line-001.ply-04.e7e6

- Move: `e6` / `e7e6` at ply 4

- CoachCard: **Decline the gambit with solid d5 support** — e6 is the Queen’s Gambit Declined answer: Black supports d5 and declines immediate overextension on c4. The center stays solid.

- Plain hint: Support the queen-pawn center instead of taking the side pawn too early.

- Opening themes: ...e6 supports d5, declined c-pawn tension, solid center

### Packet qgd-black.line-001.ply-06.c7c6

- Move: `c6` / `c7c6` at ply 6

- CoachCard: **Add a solid queenside support pawn** — c6 reinforces d5 and builds a Slav/Semi-Slav style support structure inside the QGD family. Black keeps the center compact.

- Plain hint: Support d5 and build a compact structure against White’s c-pawn pressure.

- Opening themes: ...c6 support, d5 reinforcement, compact center

### Packet qgd-black.line-001.ply-08.g8f6

- Move: `Nf6` / `g8f6` at ply 8

- CoachCard: **Develop behind the QGD center** — Nf6 develops behind the QGD d5/e6 structure. Black increases central control without resolving the c4/d5 tension too early.

- Plain hint: Bring the kingside knight into the central fight while d5 remains supported.

- Opening themes: ...Nf6 development, d5 support, castling preparation

### Packet qgd-black.line-001.ply-10.b8d7

- Move: `Nbd7` / `b8d7` at ply 10

- CoachCard: **Reinforce the QGD center** — Nbd7 develops the knight to support e5/c5 ideas and reinforce the QGD center. It keeps Black flexible behind the d5/e6 shell.

- Plain hint: Add the queenside knight behind the supported d-pawn center.

- Opening themes: Nbd7 support, central reinforcement, QGD flexibility

### Packet qgd-black.line-001.ply-12.f8e7

- Move: `Be7` / `f8e7` at ply 12

- CoachCard: **Prepare safe QGD castling** — Be7 develops the bishop and prepares castling in the QGD. Black accepts some light-square bishop restraint in exchange for a stable center.

- Plain hint: Place the bishop where it supports king safety behind the solid center.

- Opening themes: ...Be7 development, king safety, bishop constraint


## qgd-black-line-002: 1. d4 d5 2. c4 e6 3. Nf3 c5 4. Nc3 Nc6 5. e3 cxd4 6. exd4 Nf6

Runtime playKey: `d2d4,d7d5,c2c4,e7e6,g1f3,c7c5,b1c3,b8c6,e2e3,c5d4,e3d4,g8f6`  
Runtime totalGames field at line node: `792190`

### Packet qgd-black.line-002.ply-04.e7e6

- Move: `e6` / `e7e6` at ply 4

- CoachCard: **Decline the gambit with solid d5 support** — e6 is the Queen’s Gambit Declined answer: Black supports d5 and declines immediate overextension on c4. The center stays solid.

- Plain hint: Support the queen-pawn center instead of taking the side pawn too early.

- Opening themes: ...e6 supports d5, declined c-pawn tension, solid center

### Packet qgd-black.line-002.ply-06.c7c5

- Move: `c5` / `c7c5` at ply 6

- CoachCard: **Counterstrike at the QGD center** — c5 is a central counterstrike against White’s d4/c4 structure. In QGD positions it must be supported, not rushed.

- Plain hint: Challenge White’s center only after d5 has enough support.

- Opening themes: ...c5 break, central counterplay, d4 pressure

### Packet qgd-black.line-002.ply-08.b8c6

- Move: `Nc6` / `b8c6` at ply 8

- CoachCard: **Keep the QGD center solid** — Nc6 supports the Queen’s Gambit Declined plan: solid d5 support, measured development, and careful handling of c4 tension.

- Plain hint: Support the queen-pawn center and develop before resolving the c-pawn tension.

- Opening themes: QGD structure, d5 support, c-pawn tension

### Packet qgd-black.line-002.ply-10.c5d4

- Move: `cxd4` / `c5d4` at ply 10

- CoachCard: **Resolve c-pawn tension with structure in mind** — cxd4 resolves central tension by exchanging into White’s d-pawn structure. Black should use the opened lines for development, not pawn hunting.

- Plain hint: Exchange only when it clarifies the center without weakening Black’s setup.

- Opening themes: central exchange, c4/d5 tension, structure decision

### Packet qgd-black.line-002.ply-12.g8f6

- Move: `Nf6` / `g8f6` at ply 12

- CoachCard: **Develop behind the QGD center** — Nf6 develops behind the QGD d5/e6 structure. Black increases central control without resolving the c4/d5 tension too early.

- Plain hint: Bring the kingside knight into the central fight while d5 remains supported.

- Opening themes: ...Nf6 development, d5 support, castling preparation


## qgd-black-line-003: 1. d4 d5 2. c4 e6 3. Nf3 c5 4. Nc3 Nc6 5. cxd5 exd5 6. e3 Nf6

Runtime playKey: `d2d4,d7d5,c2c4,e7e6,g1f3,c7c5,b1c3,b8c6,c4d5,e6d5,e2e3,g8f6`  
Runtime totalGames field at line node: `586805`

### Packet qgd-black.line-003.ply-04.e7e6

- Move: `e6` / `e7e6` at ply 4

- CoachCard: **Decline the gambit with solid d5 support** — e6 is the Queen’s Gambit Declined answer: Black supports d5 and declines immediate overextension on c4. The center stays solid.

- Plain hint: Support the queen-pawn center instead of taking the side pawn too early.

- Opening themes: ...e6 supports d5, declined c-pawn tension, solid center

### Packet qgd-black.line-003.ply-06.c7c5

- Move: `c5` / `c7c5` at ply 6

- CoachCard: **Counterstrike at the QGD center** — c5 is a central counterstrike against White’s d4/c4 structure. In QGD positions it must be supported, not rushed.

- Plain hint: Challenge White’s center only after d5 has enough support.

- Opening themes: ...c5 break, central counterplay, d4 pressure

### Packet qgd-black.line-003.ply-08.b8c6

- Move: `Nc6` / `b8c6` at ply 8

- CoachCard: **Keep the QGD center solid** — Nc6 supports the Queen’s Gambit Declined plan: solid d5 support, measured development, and careful handling of c4 tension.

- Plain hint: Support the queen-pawn center and develop before resolving the c-pawn tension.

- Opening themes: QGD structure, d5 support, c-pawn tension

### Packet qgd-black.line-003.ply-10.e6d5

- Move: `exd5` / `e6d5` at ply 10

- CoachCard: **Keep the QGD center solid** — exd5 supports the Queen’s Gambit Declined plan: solid d5 support, measured development, and careful handling of c4 tension.

- Plain hint: Support the queen-pawn center and develop before resolving the c-pawn tension.

- Opening themes: QGD structure, d5 support, c-pawn tension

### Packet qgd-black.line-003.ply-12.g8f6

- Move: `Nf6` / `g8f6` at ply 12

- CoachCard: **Develop behind the QGD center** — Nf6 develops behind the QGD d5/e6 structure. Black increases central control without resolving the c4/d5 tension too early.

- Plain hint: Bring the kingside knight into the central fight while d5 remains supported.

- Opening themes: ...Nf6 development, d5 support, castling preparation


## qgd-black-line-004: 1. d4 d5 2. c4 e6 3. Nf3 c6 4. Nc3 Nf6 5. Bg5 Nbd7 6. e3 Qa5

Runtime playKey: `d2d4,d7d5,c2c4,e7e6,g1f3,c7c6,b1c3,g8f6,c1g5,b8d7,e2e3,d8a5`  
Runtime totalGames field at line node: `544225`

### Packet qgd-black.line-004.ply-04.e7e6

- Move: `e6` / `e7e6` at ply 4

- CoachCard: **Decline the gambit with solid d5 support** — e6 is the Queen’s Gambit Declined answer: Black supports d5 and declines immediate overextension on c4. The center stays solid.

- Plain hint: Support the queen-pawn center instead of taking the side pawn too early.

- Opening themes: ...e6 supports d5, declined c-pawn tension, solid center

### Packet qgd-black.line-004.ply-06.c7c6

- Move: `c6` / `c7c6` at ply 6

- CoachCard: **Add a solid queenside support pawn** — c6 reinforces d5 and builds a Slav/Semi-Slav style support structure inside the QGD family. Black keeps the center compact.

- Plain hint: Support d5 and build a compact structure against White’s c-pawn pressure.

- Opening themes: ...c6 support, d5 reinforcement, compact center

### Packet qgd-black.line-004.ply-08.g8f6

- Move: `Nf6` / `g8f6` at ply 8

- CoachCard: **Develop behind the QGD center** — Nf6 develops behind the QGD d5/e6 structure. Black increases central control without resolving the c4/d5 tension too early.

- Plain hint: Bring the kingside knight into the central fight while d5 remains supported.

- Opening themes: ...Nf6 development, d5 support, castling preparation

### Packet qgd-black.line-004.ply-10.b8d7

- Move: `Nbd7` / `b8d7` at ply 10

- CoachCard: **Reinforce the QGD center** — Nbd7 develops the knight to support e5/c5 ideas and reinforce the QGD center. It keeps Black flexible behind the d5/e6 shell.

- Plain hint: Add the queenside knight behind the supported d-pawn center.

- Opening themes: Nbd7 support, central reinforcement, QGD flexibility

### Packet qgd-black.line-004.ply-12.d8a5

- Move: `Qa5` / `d8a5` at ply 12

- CoachCard: **Keep the QGD center solid** — Qa5 supports the Queen’s Gambit Declined plan: solid d5 support, measured development, and careful handling of c4 tension.

- Plain hint: Support the queen-pawn center and develop before resolving the c-pawn tension.

- Opening themes: QGD structure, d5 support, c-pawn tension


## qgd-black-line-005: 1. d4 d5 2. c4 e6 3. Nf3 c6 4. Nc3 f5 5. Bf4 Bd6 6. e3 Nf6

Runtime playKey: `d2d4,d7d5,c2c4,e7e6,g1f3,c7c6,b1c3,f7f5,c1f4,f8d6,e2e3,g8f6`  
Runtime totalGames field at line node: `290255`

### Packet qgd-black.line-005.ply-04.e7e6

- Move: `e6` / `e7e6` at ply 4

- CoachCard: **Decline the gambit with solid d5 support** — e6 is the Queen’s Gambit Declined answer: Black supports d5 and declines immediate overextension on c4. The center stays solid.

- Plain hint: Support the queen-pawn center instead of taking the side pawn too early.

- Opening themes: ...e6 supports d5, declined c-pawn tension, solid center

### Packet qgd-black.line-005.ply-06.c7c6

- Move: `c6` / `c7c6` at ply 6

- CoachCard: **Add a solid queenside support pawn** — c6 reinforces d5 and builds a Slav/Semi-Slav style support structure inside the QGD family. Black keeps the center compact.

- Plain hint: Support d5 and build a compact structure against White’s c-pawn pressure.

- Opening themes: ...c6 support, d5 reinforcement, compact center

### Packet qgd-black.line-005.ply-08.f7f5

- Move: `f5` / `f7f5` at ply 8

- CoachCard: **Keep the QGD center solid** — f5 supports the Queen’s Gambit Declined plan: solid d5 support, measured development, and careful handling of c4 tension.

- Plain hint: Support the queen-pawn center and develop before resolving the c-pawn tension.

- Opening themes: QGD structure, d5 support, c-pawn tension

### Packet qgd-black.line-005.ply-10.f8d6

- Move: `Bd6` / `f8d6` at ply 10

- CoachCard: **Keep the QGD center solid** — Bd6 supports the Queen’s Gambit Declined plan: solid d5 support, measured development, and careful handling of c4 tension.

- Plain hint: Support the queen-pawn center and develop before resolving the c-pawn tension.

- Opening themes: QGD structure, d5 support, c-pawn tension

### Packet qgd-black.line-005.ply-12.g8f6

- Move: `Nf6` / `g8f6` at ply 12

- CoachCard: **Develop behind the QGD center** — Nf6 develops behind the QGD d5/e6 structure. Black increases central control without resolving the c4/d5 tension too early.

- Plain hint: Bring the kingside knight into the central fight while d5 remains supported.

- Opening themes: ...Nf6 development, d5 support, castling preparation


## qgd-black-line-006: 1. d4 d5 2. c4 e6 3. Nf3 c6 4. Nc3 Nf6 5. e3 Nbd7 6. Bd3 dxc4

Runtime playKey: `d2d4,d7d5,c2c4,e7e6,g1f3,c7c6,b1c3,g8f6,e2e3,b8d7,f1d3,d5c4`  
Runtime totalGames field at line node: `264259`

### Packet qgd-black.line-006.ply-04.e7e6

- Move: `e6` / `e7e6` at ply 4

- CoachCard: **Decline the gambit with solid d5 support** — e6 is the Queen’s Gambit Declined answer: Black supports d5 and declines immediate overextension on c4. The center stays solid.

- Plain hint: Support the queen-pawn center instead of taking the side pawn too early.

- Opening themes: ...e6 supports d5, declined c-pawn tension, solid center

### Packet qgd-black.line-006.ply-06.c7c6

- Move: `c6` / `c7c6` at ply 6

- CoachCard: **Add a solid queenside support pawn** — c6 reinforces d5 and builds a Slav/Semi-Slav style support structure inside the QGD family. Black keeps the center compact.

- Plain hint: Support d5 and build a compact structure against White’s c-pawn pressure.

- Opening themes: ...c6 support, d5 reinforcement, compact center

### Packet qgd-black.line-006.ply-08.g8f6

- Move: `Nf6` / `g8f6` at ply 8

- CoachCard: **Develop behind the QGD center** — Nf6 develops behind the QGD d5/e6 structure. Black increases central control without resolving the c4/d5 tension too early.

- Plain hint: Bring the kingside knight into the central fight while d5 remains supported.

- Opening themes: ...Nf6 development, d5 support, castling preparation

### Packet qgd-black.line-006.ply-10.b8d7

- Move: `Nbd7` / `b8d7` at ply 10

- CoachCard: **Reinforce the QGD center** — Nbd7 develops the knight to support e5/c5 ideas and reinforce the QGD center. It keeps Black flexible behind the d5/e6 shell.

- Plain hint: Add the queenside knight behind the supported d-pawn center.

- Opening themes: Nbd7 support, central reinforcement, QGD flexibility

### Packet qgd-black.line-006.ply-12.d5c4

- Move: `dxc4` / `d5c4` at ply 12

- CoachCard: **Keep the QGD center solid** — dxc4 supports the Queen’s Gambit Declined plan: solid d5 support, measured development, and careful handling of c4 tension.

- Plain hint: Support the queen-pawn center and develop before resolving the c-pawn tension.

- Opening themes: QGD structure, d5 support, c-pawn tension


## qgd-black-line-007: 1. d4 d5 2. c4 e6 3. Nf3 c5 4. cxd5 exd5 5. g3 Nc6 6. Bg2 Nf6

Runtime playKey: `d2d4,d7d5,c2c4,e7e6,g1f3,c7c5,c4d5,e6d5,g2g3,b8c6,f1g2,g8f6`  
Runtime totalGames field at line node: `262946`

### Packet qgd-black.line-007.ply-04.e7e6

- Move: `e6` / `e7e6` at ply 4

- CoachCard: **Decline the gambit with solid d5 support** — e6 is the Queen’s Gambit Declined answer: Black supports d5 and declines immediate overextension on c4. The center stays solid.

- Plain hint: Support the queen-pawn center instead of taking the side pawn too early.

- Opening themes: ...e6 supports d5, declined c-pawn tension, solid center

### Packet qgd-black.line-007.ply-06.c7c5

- Move: `c5` / `c7c5` at ply 6

- CoachCard: **Counterstrike at the QGD center** — c5 is a central counterstrike against White’s d4/c4 structure. In QGD positions it must be supported, not rushed.

- Plain hint: Challenge White’s center only after d5 has enough support.

- Opening themes: ...c5 break, central counterplay, d4 pressure

### Packet qgd-black.line-007.ply-08.e6d5

- Move: `exd5` / `e6d5` at ply 8

- CoachCard: **Keep the QGD center solid** — exd5 supports the Queen’s Gambit Declined plan: solid d5 support, measured development, and careful handling of c4 tension.

- Plain hint: Support the queen-pawn center and develop before resolving the c-pawn tension.

- Opening themes: QGD structure, d5 support, c-pawn tension

### Packet qgd-black.line-007.ply-10.b8c6

- Move: `Nc6` / `b8c6` at ply 10

- CoachCard: **Keep the QGD center solid** — Nc6 supports the Queen’s Gambit Declined plan: solid d5 support, measured development, and careful handling of c4 tension.

- Plain hint: Support the queen-pawn center and develop before resolving the c-pawn tension.

- Opening themes: QGD structure, d5 support, c-pawn tension

### Packet qgd-black.line-007.ply-12.g8f6

- Move: `Nf6` / `g8f6` at ply 12

- CoachCard: **Develop behind the QGD center** — Nf6 develops behind the QGD d5/e6 structure. Black increases central control without resolving the c4/d5 tension too early.

- Plain hint: Bring the kingside knight into the central fight while d5 remains supported.

- Opening themes: ...Nf6 development, d5 support, castling preparation


## qgd-black-line-008: 1. d4 d5 2. c4 e6 3. Nc3 c6 4. Bf4 Nf6 5. e3 Be7 6. Nf3 Nbd7

Runtime playKey: `d2d4,d7d5,c2c4,e7e6,b1c3,c7c6,c1f4,g8f6,e2e3,f8e7,g1f3,b8d7`  
Runtime totalGames field at line node: `259577`

### Packet qgd-black.line-008.ply-04.e7e6

- Move: `e6` / `e7e6` at ply 4

- CoachCard: **Decline the gambit with solid d5 support** — e6 is the Queen’s Gambit Declined answer: Black supports d5 and declines immediate overextension on c4. The center stays solid.

- Plain hint: Support the queen-pawn center instead of taking the side pawn too early.

- Opening themes: ...e6 supports d5, declined c-pawn tension, solid center

### Packet qgd-black.line-008.ply-06.c7c6

- Move: `c6` / `c7c6` at ply 6

- CoachCard: **Add a solid queenside support pawn** — c6 reinforces d5 and builds a Slav/Semi-Slav style support structure inside the QGD family. Black keeps the center compact.

- Plain hint: Support d5 and build a compact structure against White’s c-pawn pressure.

- Opening themes: ...c6 support, d5 reinforcement, compact center

### Packet qgd-black.line-008.ply-08.g8f6

- Move: `Nf6` / `g8f6` at ply 8

- CoachCard: **Develop behind the QGD center** — Nf6 develops behind the QGD d5/e6 structure. Black increases central control without resolving the c4/d5 tension too early.

- Plain hint: Bring the kingside knight into the central fight while d5 remains supported.

- Opening themes: ...Nf6 development, d5 support, castling preparation

### Packet qgd-black.line-008.ply-10.f8e7

- Move: `Be7` / `f8e7` at ply 10

- CoachCard: **Prepare safe QGD castling** — Be7 develops the bishop and prepares castling in the QGD. Black accepts some light-square bishop restraint in exchange for a stable center.

- Plain hint: Place the bishop where it supports king safety behind the solid center.

- Opening themes: ...Be7 development, king safety, bishop constraint

### Packet qgd-black.line-008.ply-12.b8d7

- Move: `Nbd7` / `b8d7` at ply 12

- CoachCard: **Reinforce the QGD center** — Nbd7 develops the knight to support e5/c5 ideas and reinforce the QGD center. It keeps Black flexible behind the d5/e6 shell.

- Plain hint: Add the queenside knight behind the supported d-pawn center.

- Opening themes: Nbd7 support, central reinforcement, QGD flexibility


## qgd-black-line-009: 1. d4 d5 2. c4 e6 3. Nf3 c6 4. Nc3 Nf6 5. e3 Nbd7 6. Bd3 Bd6

Runtime playKey: `d2d4,d7d5,c2c4,e7e6,g1f3,c7c6,b1c3,g8f6,e2e3,b8d7,f1d3,f8d6`  
Runtime totalGames field at line node: `254880`

### Packet qgd-black.line-009.ply-04.e7e6

- Move: `e6` / `e7e6` at ply 4

- CoachCard: **Decline the gambit with solid d5 support** — e6 is the Queen’s Gambit Declined answer: Black supports d5 and declines immediate overextension on c4. The center stays solid.

- Plain hint: Support the queen-pawn center instead of taking the side pawn too early.

- Opening themes: ...e6 supports d5, declined c-pawn tension, solid center

### Packet qgd-black.line-009.ply-06.c7c6

- Move: `c6` / `c7c6` at ply 6

- CoachCard: **Add a solid queenside support pawn** — c6 reinforces d5 and builds a Slav/Semi-Slav style support structure inside the QGD family. Black keeps the center compact.

- Plain hint: Support d5 and build a compact structure against White’s c-pawn pressure.

- Opening themes: ...c6 support, d5 reinforcement, compact center

### Packet qgd-black.line-009.ply-08.g8f6

- Move: `Nf6` / `g8f6` at ply 8

- CoachCard: **Develop behind the QGD center** — Nf6 develops behind the QGD d5/e6 structure. Black increases central control without resolving the c4/d5 tension too early.

- Plain hint: Bring the kingside knight into the central fight while d5 remains supported.

- Opening themes: ...Nf6 development, d5 support, castling preparation

### Packet qgd-black.line-009.ply-10.b8d7

- Move: `Nbd7` / `b8d7` at ply 10

- CoachCard: **Reinforce the QGD center** — Nbd7 develops the knight to support e5/c5 ideas and reinforce the QGD center. It keeps Black flexible behind the d5/e6 shell.

- Plain hint: Add the queenside knight behind the supported d-pawn center.

- Opening themes: Nbd7 support, central reinforcement, QGD flexibility

### Packet qgd-black.line-009.ply-12.f8d6

- Move: `Bd6` / `f8d6` at ply 12

- CoachCard: **Keep the QGD center solid** — Bd6 supports the Queen’s Gambit Declined plan: solid d5 support, measured development, and careful handling of c4 tension.

- Plain hint: Support the queen-pawn center and develop before resolving the c-pawn tension.

- Opening themes: QGD structure, d5 support, c-pawn tension


## qgd-black-line-010: 1. d4 d5 2. c4 e6 3. Nf3 Nf6 4. Nc3 Bb4 5. Bg5 h6 6. Bxf6 Qxf6

Runtime playKey: `d2d4,d7d5,c2c4,e7e6,g1f3,g8f6,b1c3,f8b4,c1g5,h7h6,g5f6,d8f6`  
Runtime totalGames field at line node: `239398`

### Packet qgd-black.line-010.ply-04.e7e6

- Move: `e6` / `e7e6` at ply 4

- CoachCard: **Decline the gambit with solid d5 support** — e6 is the Queen’s Gambit Declined answer: Black supports d5 and declines immediate overextension on c4. The center stays solid.

- Plain hint: Support the queen-pawn center instead of taking the side pawn too early.

- Opening themes: ...e6 supports d5, declined c-pawn tension, solid center

### Packet qgd-black.line-010.ply-06.g8f6

- Move: `Nf6` / `g8f6` at ply 6

- CoachCard: **Develop behind the QGD center** — Nf6 develops behind the QGD d5/e6 structure. Black increases central control without resolving the c4/d5 tension too early.

- Plain hint: Bring the kingside knight into the central fight while d5 remains supported.

- Opening themes: ...Nf6 development, d5 support, castling preparation

### Packet qgd-black.line-010.ply-08.f8b4

- Move: `Bb4` / `f8b4` at ply 8

- CoachCard: **Keep the QGD center solid** — Bb4 supports the Queen’s Gambit Declined plan: solid d5 support, measured development, and careful handling of c4 tension.

- Plain hint: Support the queen-pawn center and develop before resolving the c-pawn tension.

- Opening themes: QGD structure, d5 support, c-pawn tension

### Packet qgd-black.line-010.ply-10.h7h6

- Move: `h6` / `h7h6` at ply 10

- CoachCard: **Question the bishop without losing the center** — h6 questions White’s bishop and reduces pressure on Black’s kingside defender. It is relevant only because the QGD center is already stable.

- Plain hint: Ask the bishop to decide while preserving the supported queen-pawn structure.

- Opening themes: bishop question, king-side luft, d5 stability

### Packet qgd-black.line-010.ply-12.d8f6

- Move: `Qxf6` / `d8f6` at ply 12

- CoachCard: **Keep the QGD center solid** — Qxf6 supports the Queen’s Gambit Declined plan: solid d5 support, measured development, and careful handling of c4 tension.

- Plain hint: Support the queen-pawn center and develop before resolving the c-pawn tension.

- Opening themes: QGD structure, d5 support, c-pawn tension


## qgd-black-line-011: 1. d4 d5 2. c4 e6 3. Nf3 c5 4. Nc3 Nc6 5. cxd5 exd5 6. g3 Nf6

Runtime playKey: `d2d4,d7d5,c2c4,e7e6,g1f3,c7c5,b1c3,b8c6,c4d5,e6d5,g2g3,g8f6`  
Runtime totalGames field at line node: `226104`

### Packet qgd-black.line-011.ply-04.e7e6

- Move: `e6` / `e7e6` at ply 4

- CoachCard: **Decline the gambit with solid d5 support** — e6 is the Queen’s Gambit Declined answer: Black supports d5 and declines immediate overextension on c4. The center stays solid.

- Plain hint: Support the queen-pawn center instead of taking the side pawn too early.

- Opening themes: ...e6 supports d5, declined c-pawn tension, solid center

### Packet qgd-black.line-011.ply-06.c7c5

- Move: `c5` / `c7c5` at ply 6

- CoachCard: **Counterstrike at the QGD center** — c5 is a central counterstrike against White’s d4/c4 structure. In QGD positions it must be supported, not rushed.

- Plain hint: Challenge White’s center only after d5 has enough support.

- Opening themes: ...c5 break, central counterplay, d4 pressure

### Packet qgd-black.line-011.ply-08.b8c6

- Move: `Nc6` / `b8c6` at ply 8

- CoachCard: **Keep the QGD center solid** — Nc6 supports the Queen’s Gambit Declined plan: solid d5 support, measured development, and careful handling of c4 tension.

- Plain hint: Support the queen-pawn center and develop before resolving the c-pawn tension.

- Opening themes: QGD structure, d5 support, c-pawn tension

### Packet qgd-black.line-011.ply-10.e6d5

- Move: `exd5` / `e6d5` at ply 10

- CoachCard: **Keep the QGD center solid** — exd5 supports the Queen’s Gambit Declined plan: solid d5 support, measured development, and careful handling of c4 tension.

- Plain hint: Support the queen-pawn center and develop before resolving the c-pawn tension.

- Opening themes: QGD structure, d5 support, c-pawn tension

### Packet qgd-black.line-011.ply-12.g8f6

- Move: `Nf6` / `g8f6` at ply 12

- CoachCard: **Develop behind the QGD center** — Nf6 develops behind the QGD d5/e6 structure. Black increases central control without resolving the c4/d5 tension too early.

- Plain hint: Bring the kingside knight into the central fight while d5 remains supported.

- Opening themes: ...Nf6 development, d5 support, castling preparation


## qgd-black-line-012: 1. d4 d5 2. c4 e6 3. Nf3 c5 4. Nc3 Nc6 5. e3 Nf6 6. cxd5 Nxd5

Runtime playKey: `d2d4,d7d5,c2c4,e7e6,g1f3,c7c5,b1c3,b8c6,e2e3,g8f6,c4d5,f6d5`  
Runtime totalGames field at line node: `185246`

### Packet qgd-black.line-012.ply-04.e7e6

- Move: `e6` / `e7e6` at ply 4

- CoachCard: **Decline the gambit with solid d5 support** — e6 is the Queen’s Gambit Declined answer: Black supports d5 and declines immediate overextension on c4. The center stays solid.

- Plain hint: Support the queen-pawn center instead of taking the side pawn too early.

- Opening themes: ...e6 supports d5, declined c-pawn tension, solid center

### Packet qgd-black.line-012.ply-06.c7c5

- Move: `c5` / `c7c5` at ply 6

- CoachCard: **Counterstrike at the QGD center** — c5 is a central counterstrike against White’s d4/c4 structure. In QGD positions it must be supported, not rushed.

- Plain hint: Challenge White’s center only after d5 has enough support.

- Opening themes: ...c5 break, central counterplay, d4 pressure

### Packet qgd-black.line-012.ply-08.b8c6

- Move: `Nc6` / `b8c6` at ply 8

- CoachCard: **Keep the QGD center solid** — Nc6 supports the Queen’s Gambit Declined plan: solid d5 support, measured development, and careful handling of c4 tension.

- Plain hint: Support the queen-pawn center and develop before resolving the c-pawn tension.

- Opening themes: QGD structure, d5 support, c-pawn tension

### Packet qgd-black.line-012.ply-10.g8f6

- Move: `Nf6` / `g8f6` at ply 10

- CoachCard: **Develop behind the QGD center** — Nf6 develops behind the QGD d5/e6 structure. Black increases central control without resolving the c4/d5 tension too early.

- Plain hint: Bring the kingside knight into the central fight while d5 remains supported.

- Opening themes: ...Nf6 development, d5 support, castling preparation

### Packet qgd-black.line-012.ply-12.f6d5

- Move: `Nxd5` / `f6d5` at ply 12

- CoachCard: **Keep the QGD center solid** — Nxd5 supports the Queen’s Gambit Declined plan: solid d5 support, measured development, and careful handling of c4 tension.

- Plain hint: Support the queen-pawn center and develop before resolving the c-pawn tension.

- Opening themes: QGD structure, d5 support, c-pawn tension


## qgd-black-line-013: 1. d4 d5 2. c4 e6 3. Nf3 c6 4. Nc3 Nf6 5. e3 Be7 6. Bd3 Nbd7

Runtime playKey: `d2d4,d7d5,c2c4,e7e6,g1f3,c7c6,b1c3,g8f6,e2e3,f8e7,f1d3,b8d7`  
Runtime totalGames field at line node: `165363`

### Packet qgd-black.line-013.ply-04.e7e6

- Move: `e6` / `e7e6` at ply 4

- CoachCard: **Decline the gambit with solid d5 support** — e6 is the Queen’s Gambit Declined answer: Black supports d5 and declines immediate overextension on c4. The center stays solid.

- Plain hint: Support the queen-pawn center instead of taking the side pawn too early.

- Opening themes: ...e6 supports d5, declined c-pawn tension, solid center

### Packet qgd-black.line-013.ply-06.c7c6

- Move: `c6` / `c7c6` at ply 6

- CoachCard: **Add a solid queenside support pawn** — c6 reinforces d5 and builds a Slav/Semi-Slav style support structure inside the QGD family. Black keeps the center compact.

- Plain hint: Support d5 and build a compact structure against White’s c-pawn pressure.

- Opening themes: ...c6 support, d5 reinforcement, compact center

### Packet qgd-black.line-013.ply-08.g8f6

- Move: `Nf6` / `g8f6` at ply 8

- CoachCard: **Develop behind the QGD center** — Nf6 develops behind the QGD d5/e6 structure. Black increases central control without resolving the c4/d5 tension too early.

- Plain hint: Bring the kingside knight into the central fight while d5 remains supported.

- Opening themes: ...Nf6 development, d5 support, castling preparation

### Packet qgd-black.line-013.ply-10.f8e7

- Move: `Be7` / `f8e7` at ply 10

- CoachCard: **Prepare safe QGD castling** — Be7 develops the bishop and prepares castling in the QGD. Black accepts some light-square bishop restraint in exchange for a stable center.

- Plain hint: Place the bishop where it supports king safety behind the solid center.

- Opening themes: ...Be7 development, king safety, bishop constraint

### Packet qgd-black.line-013.ply-12.b8d7

- Move: `Nbd7` / `b8d7` at ply 12

- CoachCard: **Reinforce the QGD center** — Nbd7 develops the knight to support e5/c5 ideas and reinforce the QGD center. It keeps Black flexible behind the d5/e6 shell.

- Plain hint: Add the queenside knight behind the supported d-pawn center.

- Opening themes: Nbd7 support, central reinforcement, QGD flexibility


## qgd-black-line-014: 1. d4 d5 2. c4 e6 3. Nc3 c6 4. Nf3 Nf6 5. e3 Nbd7 6. Qc2 Bd6

Runtime playKey: `d2d4,d7d5,c2c4,e7e6,b1c3,c7c6,g1f3,g8f6,e2e3,b8d7,d1c2,f8d6`  
Runtime totalGames field at line node: `163881`

### Packet qgd-black.line-014.ply-04.e7e6

- Move: `e6` / `e7e6` at ply 4

- CoachCard: **Decline the gambit with solid d5 support** — e6 is the Queen’s Gambit Declined answer: Black supports d5 and declines immediate overextension on c4. The center stays solid.

- Plain hint: Support the queen-pawn center instead of taking the side pawn too early.

- Opening themes: ...e6 supports d5, declined c-pawn tension, solid center

### Packet qgd-black.line-014.ply-06.c7c6

- Move: `c6` / `c7c6` at ply 6

- CoachCard: **Add a solid queenside support pawn** — c6 reinforces d5 and builds a Slav/Semi-Slav style support structure inside the QGD family. Black keeps the center compact.

- Plain hint: Support d5 and build a compact structure against White’s c-pawn pressure.

- Opening themes: ...c6 support, d5 reinforcement, compact center

### Packet qgd-black.line-014.ply-08.g8f6

- Move: `Nf6` / `g8f6` at ply 8

- CoachCard: **Develop behind the QGD center** — Nf6 develops behind the QGD d5/e6 structure. Black increases central control without resolving the c4/d5 tension too early.

- Plain hint: Bring the kingside knight into the central fight while d5 remains supported.

- Opening themes: ...Nf6 development, d5 support, castling preparation

### Packet qgd-black.line-014.ply-10.b8d7

- Move: `Nbd7` / `b8d7` at ply 10

- CoachCard: **Reinforce the QGD center** — Nbd7 develops the knight to support e5/c5 ideas and reinforce the QGD center. It keeps Black flexible behind the d5/e6 shell.

- Plain hint: Add the queenside knight behind the supported d-pawn center.

- Opening themes: Nbd7 support, central reinforcement, QGD flexibility

### Packet qgd-black.line-014.ply-12.f8d6

- Move: `Bd6` / `f8d6` at ply 12

- CoachCard: **Keep the QGD center solid** — Bd6 supports the Queen’s Gambit Declined plan: solid d5 support, measured development, and careful handling of c4 tension.

- Plain hint: Support the queen-pawn center and develop before resolving the c-pawn tension.

- Opening themes: QGD structure, d5 support, c-pawn tension


## qgd-black-line-015: 1. d4 d5 2. c4 e6 3. Nc3 c6 4. Nf3 f5 5. Bg5 Nf6 6. e3 Be7

Runtime playKey: `d2d4,d7d5,c2c4,e7e6,b1c3,c7c6,g1f3,f7f5,c1g5,g8f6,e2e3,f8e7`  
Runtime totalGames field at line node: `161987`

### Packet qgd-black.line-015.ply-04.e7e6

- Move: `e6` / `e7e6` at ply 4

- CoachCard: **Decline the gambit with solid d5 support** — e6 is the Queen’s Gambit Declined answer: Black supports d5 and declines immediate overextension on c4. The center stays solid.

- Plain hint: Support the queen-pawn center instead of taking the side pawn too early.

- Opening themes: ...e6 supports d5, declined c-pawn tension, solid center

### Packet qgd-black.line-015.ply-06.c7c6

- Move: `c6` / `c7c6` at ply 6

- CoachCard: **Add a solid queenside support pawn** — c6 reinforces d5 and builds a Slav/Semi-Slav style support structure inside the QGD family. Black keeps the center compact.

- Plain hint: Support d5 and build a compact structure against White’s c-pawn pressure.

- Opening themes: ...c6 support, d5 reinforcement, compact center

### Packet qgd-black.line-015.ply-08.f7f5

- Move: `f5` / `f7f5` at ply 8

- CoachCard: **Keep the QGD center solid** — f5 supports the Queen’s Gambit Declined plan: solid d5 support, measured development, and careful handling of c4 tension.

- Plain hint: Support the queen-pawn center and develop before resolving the c-pawn tension.

- Opening themes: QGD structure, d5 support, c-pawn tension

### Packet qgd-black.line-015.ply-10.g8f6

- Move: `Nf6` / `g8f6` at ply 10

- CoachCard: **Develop behind the QGD center** — Nf6 develops behind the QGD d5/e6 structure. Black increases central control without resolving the c4/d5 tension too early.

- Plain hint: Bring the kingside knight into the central fight while d5 remains supported.

- Opening themes: ...Nf6 development, d5 support, castling preparation

### Packet qgd-black.line-015.ply-12.f8e7

- Move: `Be7` / `f8e7` at ply 12

- CoachCard: **Prepare safe QGD castling** — Be7 develops the bishop and prepares castling in the QGD. Black accepts some light-square bishop restraint in exchange for a stable center.

- Plain hint: Place the bishop where it supports king safety behind the solid center.

- Opening themes: ...Be7 development, king safety, bishop constraint


## qgd-black-line-016: 1. d4 d5 2. c4 e6 3. Nc3 Nf6 4. Nf3 Bb4 5. Bg5 h6 6. Bh4 g5

Runtime playKey: `d2d4,d7d5,c2c4,e7e6,b1c3,g8f6,g1f3,f8b4,c1g5,h7h6,g5h4,g7g5`  
Runtime totalGames field at line node: `159100`

### Packet qgd-black.line-016.ply-04.e7e6

- Move: `e6` / `e7e6` at ply 4

- CoachCard: **Decline the gambit with solid d5 support** — e6 is the Queen’s Gambit Declined answer: Black supports d5 and declines immediate overextension on c4. The center stays solid.

- Plain hint: Support the queen-pawn center instead of taking the side pawn too early.

- Opening themes: ...e6 supports d5, declined c-pawn tension, solid center

### Packet qgd-black.line-016.ply-06.g8f6

- Move: `Nf6` / `g8f6` at ply 6

- CoachCard: **Develop behind the QGD center** — Nf6 develops behind the QGD d5/e6 structure. Black increases central control without resolving the c4/d5 tension too early.

- Plain hint: Bring the kingside knight into the central fight while d5 remains supported.

- Opening themes: ...Nf6 development, d5 support, castling preparation

### Packet qgd-black.line-016.ply-08.f8b4

- Move: `Bb4` / `f8b4` at ply 8

- CoachCard: **Keep the QGD center solid** — Bb4 supports the Queen’s Gambit Declined plan: solid d5 support, measured development, and careful handling of c4 tension.

- Plain hint: Support the queen-pawn center and develop before resolving the c-pawn tension.

- Opening themes: QGD structure, d5 support, c-pawn tension

### Packet qgd-black.line-016.ply-10.h7h6

- Move: `h6` / `h7h6` at ply 10

- CoachCard: **Question the bishop without losing the center** — h6 questions White’s bishop and reduces pressure on Black’s kingside defender. It is relevant only because the QGD center is already stable.

- Plain hint: Ask the bishop to decide while preserving the supported queen-pawn structure.

- Opening themes: bishop question, king-side luft, d5 stability

### Packet qgd-black.line-016.ply-12.g7g5

- Move: `g5` / `g7g5` at ply 12

- CoachCard: **Keep the QGD center solid** — g5 supports the Queen’s Gambit Declined plan: solid d5 support, measured development, and careful handling of c4 tension.

- Plain hint: Support the queen-pawn center and develop before resolving the c-pawn tension.

- Opening themes: QGD structure, d5 support, c-pawn tension


## qgd-black-line-017: 1. d4 d5 2. c4 e6 3. Nc3 Nf6 4. Nf3 Be7 5. Bg5 h6 6. Bxf6 Bxf6

Runtime playKey: `d2d4,d7d5,c2c4,e7e6,b1c3,g8f6,g1f3,f8e7,c1g5,h7h6,g5f6,e7f6`  
Runtime totalGames field at line node: `156711`

### Packet qgd-black.line-017.ply-04.e7e6

- Move: `e6` / `e7e6` at ply 4

- CoachCard: **Decline the gambit with solid d5 support** — e6 is the Queen’s Gambit Declined answer: Black supports d5 and declines immediate overextension on c4. The center stays solid.

- Plain hint: Support the queen-pawn center instead of taking the side pawn too early.

- Opening themes: ...e6 supports d5, declined c-pawn tension, solid center

### Packet qgd-black.line-017.ply-06.g8f6

- Move: `Nf6` / `g8f6` at ply 6

- CoachCard: **Develop behind the QGD center** — Nf6 develops behind the QGD d5/e6 structure. Black increases central control without resolving the c4/d5 tension too early.

- Plain hint: Bring the kingside knight into the central fight while d5 remains supported.

- Opening themes: ...Nf6 development, d5 support, castling preparation

### Packet qgd-black.line-017.ply-08.f8e7

- Move: `Be7` / `f8e7` at ply 8

- CoachCard: **Prepare safe QGD castling** — Be7 develops the bishop and prepares castling in the QGD. Black accepts some light-square bishop restraint in exchange for a stable center.

- Plain hint: Place the bishop where it supports king safety behind the solid center.

- Opening themes: ...Be7 development, king safety, bishop constraint

### Packet qgd-black.line-017.ply-10.h7h6

- Move: `h6` / `h7h6` at ply 10

- CoachCard: **Question the bishop without losing the center** — h6 questions White’s bishop and reduces pressure on Black’s kingside defender. It is relevant only because the QGD center is already stable.

- Plain hint: Ask the bishop to decide while preserving the supported queen-pawn structure.

- Opening themes: bishop question, king-side luft, d5 stability

### Packet qgd-black.line-017.ply-12.e7f6

- Move: `Bxf6` / `e7f6` at ply 12

- CoachCard: **Keep the QGD center solid** — Bxf6 supports the Queen’s Gambit Declined plan: solid d5 support, measured development, and careful handling of c4 tension.

- Plain hint: Support the queen-pawn center and develop before resolving the c-pawn tension.

- Opening themes: QGD structure, d5 support, c-pawn tension


## qgd-black-line-018: 1. d4 d5 2. c4 e6 3. Nc3 c6 4. Bf4 Nf6 5. Nf3 Bd6 6. Bxd6 Qxd6

Runtime playKey: `d2d4,d7d5,c2c4,e7e6,b1c3,c7c6,c1f4,g8f6,g1f3,f8d6,f4d6,d8d6`  
Runtime totalGames field at line node: `147378`

### Packet qgd-black.line-018.ply-04.e7e6

- Move: `e6` / `e7e6` at ply 4

- CoachCard: **Decline the gambit with solid d5 support** — e6 is the Queen’s Gambit Declined answer: Black supports d5 and declines immediate overextension on c4. The center stays solid.

- Plain hint: Support the queen-pawn center instead of taking the side pawn too early.

- Opening themes: ...e6 supports d5, declined c-pawn tension, solid center

### Packet qgd-black.line-018.ply-06.c7c6

- Move: `c6` / `c7c6` at ply 6

- CoachCard: **Add a solid queenside support pawn** — c6 reinforces d5 and builds a Slav/Semi-Slav style support structure inside the QGD family. Black keeps the center compact.

- Plain hint: Support d5 and build a compact structure against White’s c-pawn pressure.

- Opening themes: ...c6 support, d5 reinforcement, compact center

### Packet qgd-black.line-018.ply-08.g8f6

- Move: `Nf6` / `g8f6` at ply 8

- CoachCard: **Develop behind the QGD center** — Nf6 develops behind the QGD d5/e6 structure. Black increases central control without resolving the c4/d5 tension too early.

- Plain hint: Bring the kingside knight into the central fight while d5 remains supported.

- Opening themes: ...Nf6 development, d5 support, castling preparation

### Packet qgd-black.line-018.ply-10.f8d6

- Move: `Bd6` / `f8d6` at ply 10

- CoachCard: **Keep the QGD center solid** — Bd6 supports the Queen’s Gambit Declined plan: solid d5 support, measured development, and careful handling of c4 tension.

- Plain hint: Support the queen-pawn center and develop before resolving the c-pawn tension.

- Opening themes: QGD structure, d5 support, c-pawn tension

### Packet qgd-black.line-018.ply-12.d8d6

- Move: `Qxd6` / `d8d6` at ply 12

- CoachCard: **Keep the QGD center solid** — Qxd6 supports the Queen’s Gambit Declined plan: solid d5 support, measured development, and careful handling of c4 tension.

- Plain hint: Support the queen-pawn center and develop before resolving the c-pawn tension.

- Opening themes: QGD structure, d5 support, c-pawn tension


## qgd-black-line-019: 1. d4 d5 2. c4 e6 3. Nf3 c6 4. Nc3 f5 5. Bf4 Nf6 6. e3 Be7

Runtime playKey: `d2d4,d7d5,c2c4,e7e6,g1f3,c7c6,b1c3,f7f5,c1f4,g8f6,e2e3,f8e7`  
Runtime totalGames field at line node: `141867`

### Packet qgd-black.line-019.ply-04.e7e6

- Move: `e6` / `e7e6` at ply 4

- CoachCard: **Decline the gambit with solid d5 support** — e6 is the Queen’s Gambit Declined answer: Black supports d5 and declines immediate overextension on c4. The center stays solid.

- Plain hint: Support the queen-pawn center instead of taking the side pawn too early.

- Opening themes: ...e6 supports d5, declined c-pawn tension, solid center

### Packet qgd-black.line-019.ply-06.c7c6

- Move: `c6` / `c7c6` at ply 6

- CoachCard: **Add a solid queenside support pawn** — c6 reinforces d5 and builds a Slav/Semi-Slav style support structure inside the QGD family. Black keeps the center compact.

- Plain hint: Support d5 and build a compact structure against White’s c-pawn pressure.

- Opening themes: ...c6 support, d5 reinforcement, compact center

### Packet qgd-black.line-019.ply-08.f7f5

- Move: `f5` / `f7f5` at ply 8

- CoachCard: **Keep the QGD center solid** — f5 supports the Queen’s Gambit Declined plan: solid d5 support, measured development, and careful handling of c4 tension.

- Plain hint: Support the queen-pawn center and develop before resolving the c-pawn tension.

- Opening themes: QGD structure, d5 support, c-pawn tension

### Packet qgd-black.line-019.ply-10.g8f6

- Move: `Nf6` / `g8f6` at ply 10

- CoachCard: **Develop behind the QGD center** — Nf6 develops behind the QGD d5/e6 structure. Black increases central control without resolving the c4/d5 tension too early.

- Plain hint: Bring the kingside knight into the central fight while d5 remains supported.

- Opening themes: ...Nf6 development, d5 support, castling preparation

### Packet qgd-black.line-019.ply-12.f8e7

- Move: `Be7` / `f8e7` at ply 12

- CoachCard: **Prepare safe QGD castling** — Be7 develops the bishop and prepares castling in the QGD. Black accepts some light-square bishop restraint in exchange for a stable center.

- Plain hint: Place the bishop where it supports king safety behind the solid center.

- Opening themes: ...Be7 development, king safety, bishop constraint


## qgd-black-line-020: 1. d4 d5 2. c4 e6 3. Nf3 c6 4. Nc3 f5 5. Bg5 Nf6 6. e3 Bd6

Runtime playKey: `d2d4,d7d5,c2c4,e7e6,g1f3,c7c6,b1c3,f7f5,c1g5,g8f6,e2e3,f8d6`  
Runtime totalGames field at line node: `134846`

### Packet qgd-black.line-020.ply-04.e7e6

- Move: `e6` / `e7e6` at ply 4

- CoachCard: **Decline the gambit with solid d5 support** — e6 is the Queen’s Gambit Declined answer: Black supports d5 and declines immediate overextension on c4. The center stays solid.

- Plain hint: Support the queen-pawn center instead of taking the side pawn too early.

- Opening themes: ...e6 supports d5, declined c-pawn tension, solid center

### Packet qgd-black.line-020.ply-06.c7c6

- Move: `c6` / `c7c6` at ply 6

- CoachCard: **Add a solid queenside support pawn** — c6 reinforces d5 and builds a Slav/Semi-Slav style support structure inside the QGD family. Black keeps the center compact.

- Plain hint: Support d5 and build a compact structure against White’s c-pawn pressure.

- Opening themes: ...c6 support, d5 reinforcement, compact center

### Packet qgd-black.line-020.ply-08.f7f5

- Move: `f5` / `f7f5` at ply 8

- CoachCard: **Keep the QGD center solid** — f5 supports the Queen’s Gambit Declined plan: solid d5 support, measured development, and careful handling of c4 tension.

- Plain hint: Support the queen-pawn center and develop before resolving the c-pawn tension.

- Opening themes: QGD structure, d5 support, c-pawn tension

### Packet qgd-black.line-020.ply-10.g8f6

- Move: `Nf6` / `g8f6` at ply 10

- CoachCard: **Develop behind the QGD center** — Nf6 develops behind the QGD d5/e6 structure. Black increases central control without resolving the c4/d5 tension too early.

- Plain hint: Bring the kingside knight into the central fight while d5 remains supported.

- Opening themes: ...Nf6 development, d5 support, castling preparation

### Packet qgd-black.line-020.ply-12.f8d6

- Move: `Bd6` / `f8d6` at ply 12

- CoachCard: **Keep the QGD center solid** — Bd6 supports the Queen’s Gambit Declined plan: solid d5 support, measured development, and careful handling of c4 tension.

- Plain hint: Support the queen-pawn center and develop before resolving the c-pawn tension.

- Opening themes: QGD structure, d5 support, c-pawn tension


## qgd-black-line-021: 1. d4 d5 2. c4 e6 3. Nc3 c6 4. Bf4 Bd6 5. Bxd6 Qxd6 6. e3 Nf6

Runtime playKey: `d2d4,d7d5,c2c4,e7e6,b1c3,c7c6,c1f4,f8d6,f4d6,d8d6,e2e3,g8f6`  
Runtime totalGames field at line node: `134463`

### Packet qgd-black.line-021.ply-04.e7e6

- Move: `e6` / `e7e6` at ply 4

- CoachCard: **Decline the gambit with solid d5 support** — e6 is the Queen’s Gambit Declined answer: Black supports d5 and declines immediate overextension on c4. The center stays solid.

- Plain hint: Support the queen-pawn center instead of taking the side pawn too early.

- Opening themes: ...e6 supports d5, declined c-pawn tension, solid center

### Packet qgd-black.line-021.ply-06.c7c6

- Move: `c6` / `c7c6` at ply 6

- CoachCard: **Add a solid queenside support pawn** — c6 reinforces d5 and builds a Slav/Semi-Slav style support structure inside the QGD family. Black keeps the center compact.

- Plain hint: Support d5 and build a compact structure against White’s c-pawn pressure.

- Opening themes: ...c6 support, d5 reinforcement, compact center

### Packet qgd-black.line-021.ply-08.f8d6

- Move: `Bd6` / `f8d6` at ply 8

- CoachCard: **Keep the QGD center solid** — Bd6 supports the Queen’s Gambit Declined plan: solid d5 support, measured development, and careful handling of c4 tension.

- Plain hint: Support the queen-pawn center and develop before resolving the c-pawn tension.

- Opening themes: QGD structure, d5 support, c-pawn tension

### Packet qgd-black.line-021.ply-10.d8d6

- Move: `Qxd6` / `d8d6` at ply 10

- CoachCard: **Keep the QGD center solid** — Qxd6 supports the Queen’s Gambit Declined plan: solid d5 support, measured development, and careful handling of c4 tension.

- Plain hint: Support the queen-pawn center and develop before resolving the c-pawn tension.

- Opening themes: QGD structure, d5 support, c-pawn tension

### Packet qgd-black.line-021.ply-12.g8f6

- Move: `Nf6` / `g8f6` at ply 12

- CoachCard: **Develop behind the QGD center** — Nf6 develops behind the QGD d5/e6 structure. Black increases central control without resolving the c4/d5 tension too early.

- Plain hint: Bring the kingside knight into the central fight while d5 remains supported.

- Opening themes: ...Nf6 development, d5 support, castling preparation


## qgd-black-line-022: 1. d4 d5 2. c4 e6 3. Nc3 c6 4. Nf3 f5 5. Bg5 Nf6 6. cxd5 exd5

Runtime playKey: `d2d4,d7d5,c2c4,e7e6,b1c3,c7c6,g1f3,f7f5,c1g5,g8f6,c4d5,e6d5`  
Runtime totalGames field at line node: `120757`

### Packet qgd-black.line-022.ply-04.e7e6

- Move: `e6` / `e7e6` at ply 4

- CoachCard: **Decline the gambit with solid d5 support** — e6 is the Queen’s Gambit Declined answer: Black supports d5 and declines immediate overextension on c4. The center stays solid.

- Plain hint: Support the queen-pawn center instead of taking the side pawn too early.

- Opening themes: ...e6 supports d5, declined c-pawn tension, solid center

### Packet qgd-black.line-022.ply-06.c7c6

- Move: `c6` / `c7c6` at ply 6

- CoachCard: **Add a solid queenside support pawn** — c6 reinforces d5 and builds a Slav/Semi-Slav style support structure inside the QGD family. Black keeps the center compact.

- Plain hint: Support d5 and build a compact structure against White’s c-pawn pressure.

- Opening themes: ...c6 support, d5 reinforcement, compact center

### Packet qgd-black.line-022.ply-08.f7f5

- Move: `f5` / `f7f5` at ply 8

- CoachCard: **Keep the QGD center solid** — f5 supports the Queen’s Gambit Declined plan: solid d5 support, measured development, and careful handling of c4 tension.

- Plain hint: Support the queen-pawn center and develop before resolving the c-pawn tension.

- Opening themes: QGD structure, d5 support, c-pawn tension

### Packet qgd-black.line-022.ply-10.g8f6

- Move: `Nf6` / `g8f6` at ply 10

- CoachCard: **Develop behind the QGD center** — Nf6 develops behind the QGD d5/e6 structure. Black increases central control without resolving the c4/d5 tension too early.

- Plain hint: Bring the kingside knight into the central fight while d5 remains supported.

- Opening themes: ...Nf6 development, d5 support, castling preparation

### Packet qgd-black.line-022.ply-12.e6d5

- Move: `exd5` / `e6d5` at ply 12

- CoachCard: **Keep the QGD center solid** — exd5 supports the Queen’s Gambit Declined plan: solid d5 support, measured development, and careful handling of c4 tension.

- Plain hint: Support the queen-pawn center and develop before resolving the c-pawn tension.

- Opening themes: QGD structure, d5 support, c-pawn tension


## qgd-black-line-023: 1. d4 d5 2. c4 e6 3. Nf3 c5 4. Nc3 Nc6 5. e3 cxd4 6. Nxd4 Nf6

Runtime playKey: `d2d4,d7d5,c2c4,e7e6,g1f3,c7c5,b1c3,b8c6,e2e3,c5d4,f3d4,g8f6`  
Runtime totalGames field at line node: `119123`

### Packet qgd-black.line-023.ply-04.e7e6

- Move: `e6` / `e7e6` at ply 4

- CoachCard: **Decline the gambit with solid d5 support** — e6 is the Queen’s Gambit Declined answer: Black supports d5 and declines immediate overextension on c4. The center stays solid.

- Plain hint: Support the queen-pawn center instead of taking the side pawn too early.

- Opening themes: ...e6 supports d5, declined c-pawn tension, solid center

### Packet qgd-black.line-023.ply-06.c7c5

- Move: `c5` / `c7c5` at ply 6

- CoachCard: **Counterstrike at the QGD center** — c5 is a central counterstrike against White’s d4/c4 structure. In QGD positions it must be supported, not rushed.

- Plain hint: Challenge White’s center only after d5 has enough support.

- Opening themes: ...c5 break, central counterplay, d4 pressure

### Packet qgd-black.line-023.ply-08.b8c6

- Move: `Nc6` / `b8c6` at ply 8

- CoachCard: **Keep the QGD center solid** — Nc6 supports the Queen’s Gambit Declined plan: solid d5 support, measured development, and careful handling of c4 tension.

- Plain hint: Support the queen-pawn center and develop before resolving the c-pawn tension.

- Opening themes: QGD structure, d5 support, c-pawn tension

### Packet qgd-black.line-023.ply-10.c5d4

- Move: `cxd4` / `c5d4` at ply 10

- CoachCard: **Resolve c-pawn tension with structure in mind** — cxd4 resolves central tension by exchanging into White’s d-pawn structure. Black should use the opened lines for development, not pawn hunting.

- Plain hint: Exchange only when it clarifies the center without weakening Black’s setup.

- Opening themes: central exchange, c4/d5 tension, structure decision

### Packet qgd-black.line-023.ply-12.g8f6

- Move: `Nf6` / `g8f6` at ply 12

- CoachCard: **Develop behind the QGD center** — Nf6 develops behind the QGD d5/e6 structure. Black increases central control without resolving the c4/d5 tension too early.

- Plain hint: Bring the kingside knight into the central fight while d5 remains supported.

- Opening themes: ...Nf6 development, d5 support, castling preparation


## qgd-black-line-024: 1. d4 d5 2. c4 e6 3. Nf3 c5 4. cxd5 exd5 5. Nc3 Nf6 6. Bg5 Be7

Runtime playKey: `d2d4,d7d5,c2c4,e7e6,g1f3,c7c5,c4d5,e6d5,b1c3,g8f6,c1g5,f8e7`  
Runtime totalGames field at line node: `117204`

### Packet qgd-black.line-024.ply-04.e7e6

- Move: `e6` / `e7e6` at ply 4

- CoachCard: **Decline the gambit with solid d5 support** — e6 is the Queen’s Gambit Declined answer: Black supports d5 and declines immediate overextension on c4. The center stays solid.

- Plain hint: Support the queen-pawn center instead of taking the side pawn too early.

- Opening themes: ...e6 supports d5, declined c-pawn tension, solid center

### Packet qgd-black.line-024.ply-06.c7c5

- Move: `c5` / `c7c5` at ply 6

- CoachCard: **Counterstrike at the QGD center** — c5 is a central counterstrike against White’s d4/c4 structure. In QGD positions it must be supported, not rushed.

- Plain hint: Challenge White’s center only after d5 has enough support.

- Opening themes: ...c5 break, central counterplay, d4 pressure

### Packet qgd-black.line-024.ply-08.e6d5

- Move: `exd5` / `e6d5` at ply 8

- CoachCard: **Keep the QGD center solid** — exd5 supports the Queen’s Gambit Declined plan: solid d5 support, measured development, and careful handling of c4 tension.

- Plain hint: Support the queen-pawn center and develop before resolving the c-pawn tension.

- Opening themes: QGD structure, d5 support, c-pawn tension

### Packet qgd-black.line-024.ply-10.g8f6

- Move: `Nf6` / `g8f6` at ply 10

- CoachCard: **Develop behind the QGD center** — Nf6 develops behind the QGD d5/e6 structure. Black increases central control without resolving the c4/d5 tension too early.

- Plain hint: Bring the kingside knight into the central fight while d5 remains supported.

- Opening themes: ...Nf6 development, d5 support, castling preparation

### Packet qgd-black.line-024.ply-12.f8e7

- Move: `Be7` / `f8e7` at ply 12

- CoachCard: **Prepare safe QGD castling** — Be7 develops the bishop and prepares castling in the QGD. Black accepts some light-square bishop restraint in exchange for a stable center.

- Plain hint: Place the bishop where it supports king safety behind the solid center.

- Opening themes: ...Be7 development, king safety, bishop constraint


## qgd-black-line-025: 1. d4 d5 2. c4 e6 3. Nf3 c5 4. Nc3 Nc6 5. e3 Nf6 6. Be2 Be7

Runtime playKey: `d2d4,d7d5,c2c4,e7e6,g1f3,c7c5,b1c3,b8c6,e2e3,g8f6,f1e2,f8e7`  
Runtime totalGames field at line node: `95049`

### Packet qgd-black.line-025.ply-04.e7e6

- Move: `e6` / `e7e6` at ply 4

- CoachCard: **Decline the gambit with solid d5 support** — e6 is the Queen’s Gambit Declined answer: Black supports d5 and declines immediate overextension on c4. The center stays solid.

- Plain hint: Support the queen-pawn center instead of taking the side pawn too early.

- Opening themes: ...e6 supports d5, declined c-pawn tension, solid center

### Packet qgd-black.line-025.ply-06.c7c5

- Move: `c5` / `c7c5` at ply 6

- CoachCard: **Counterstrike at the QGD center** — c5 is a central counterstrike against White’s d4/c4 structure. In QGD positions it must be supported, not rushed.

- Plain hint: Challenge White’s center only after d5 has enough support.

- Opening themes: ...c5 break, central counterplay, d4 pressure

### Packet qgd-black.line-025.ply-08.b8c6

- Move: `Nc6` / `b8c6` at ply 8

- CoachCard: **Keep the QGD center solid** — Nc6 supports the Queen’s Gambit Declined plan: solid d5 support, measured development, and careful handling of c4 tension.

- Plain hint: Support the queen-pawn center and develop before resolving the c-pawn tension.

- Opening themes: QGD structure, d5 support, c-pawn tension

### Packet qgd-black.line-025.ply-10.g8f6

- Move: `Nf6` / `g8f6` at ply 10

- CoachCard: **Develop behind the QGD center** — Nf6 develops behind the QGD d5/e6 structure. Black increases central control without resolving the c4/d5 tension too early.

- Plain hint: Bring the kingside knight into the central fight while d5 remains supported.

- Opening themes: ...Nf6 development, d5 support, castling preparation

### Packet qgd-black.line-025.ply-12.f8e7

- Move: `Be7` / `f8e7` at ply 12

- CoachCard: **Prepare safe QGD castling** — Be7 develops the bishop and prepares castling in the QGD. Black accepts some light-square bishop restraint in exchange for a stable center.

- Plain hint: Place the bishop where it supports king safety behind the solid center.

- Opening themes: ...Be7 development, king safety, bishop constraint
