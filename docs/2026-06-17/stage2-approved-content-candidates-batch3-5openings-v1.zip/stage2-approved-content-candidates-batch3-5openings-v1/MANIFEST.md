# Manifest

## Source runtime package

`stage2-21opening-crawled-filtered5to2-runtime-source-v1.zip`

## Selected openings

- `reti-white` (Réti Opening): 25 lines, 125 packets
- `pirc-black` (Pirc Defense): 25 lines, 125 packets
- `petroff-black` (Petroff Defense): 25 lines, 125 packets
- `qgd-black` (Queen’s Gambit Declined): 25 lines, 125 packets
- `vienna-white` (Vienna Game): 25 lines, 125 packets

## Totals

- Total line count: 125
- Total packet count: 625
- 10-line minimum met for every opening: YES
- 20-line target met for every opening: YES
- Extra round-robin lines added: YES (25 extra beyond 20/opening)

## Validation status

PASS

## Known limitations

- Candidate content only; not app-activated.
- Runtime `totalGames` fields are preserved for traceability, but packet copy does not claim popularity or engine evaluation.
- Some early learner moves are not packetized when the opening-specific runtime node begins after the move; emitted packets preserve `runtimeMatched: true`.
- Petroff selection was filtered toward lines with Petroff central themes such as White Ne5 or Black ...Nxe4 when available, avoiding unrelated Italian-style continuations where possible.

## Next step for app validation

Run app-side validation/activation through the Stage 2 resolver before any approved-content availability flag or app-approved status is changed.
