"use client";

import dynamic from "next/dynamic";
import { useEffect, useMemo, useState } from "react";
import { Chess } from "chess.js";
import {
  BarChart3,
  Beaker,
  BookOpen,
  CheckCircle2,
  ChevronRight,
  Flame,
  Home,
  Plus,
  RotateCcw,
  Search,
  Settings,
  Target,
  Trophy,
  XCircle,
} from "lucide-react";

const Chessboard = dynamic(
  () => import("react-chessboard").then((mod) => mod.Chessboard),
  { ssr: false }
);

type RepertoireColor = "white" | "black";

type Repertoire = {
  id: string;
  name: string;
  color: RepertoireColor;
  lines: string[][];
  description: string;
};

type Continuation = {
  san: string;
  uci: string;
  color: "w" | "b";
  resultingFen: string;
};

type Mistake = {
  fen: string;
  expectedMove: string;
  playedMove: string;
  count: number;
  opening: string;
};

type Progress = {
  attempts: number;
  correct: number;
  incorrect: number;
  streak: number;
  trainedPositions: Record<string, boolean>;
  mistakes: Record<string, Mistake>;
};

const DEFAULT_PROGRESS: Progress = {
  attempts: 0,
  correct: 0,
  incorrect: 0,
  streak: 0,
  trainedPositions: {},
  mistakes: {},
};

const REPERTOIRES: Repertoire[] = [
  {
    id: "italian-white",
    name: "Italian Game Starter",
    color: "white",
    description: "A simple 1.e4 repertoire focused on fast development.",
    lines: [
      ["e4", "e5", "Nf3", "Nc6", "Bc4"],
      ["e4", "e5", "Nf3", "Nf6", "Nxe5"],
      ["e4", "c5", "Nf3", "d6", "d4"],
      ["e4", "e6", "d4", "d5", "Nc3"],
      ["e4", "c6", "d4", "d5", "Nc3"],
    ],
  },
  {
    id: "queens-gambit-white",
    name: "Queen's Gambit",
    color: "white",
    description: "A sturdy 1.d4 starter repertoire.",
    lines: [
      ["d4", "d5", "c4"],
      ["d4", "d5", "c4", "e6", "Nc3"],
      ["d4", "d5", "c4", "c6", "Nf3"],
      ["d4", "Nf6", "c4", "e6", "Nc3"],
      ["d4", "Nf6", "c4", "g6", "Nc3"],
    ],
  },
  {
    id: "caro-black",
    name: "Caro-Kann as Black",
    color: "black",
    description: "A clean black repertoire against 1.e4.",
    lines: [
      ["e4", "c6", "d4", "d5", "Nc3", "dxe4"],
      ["e4", "c6", "d4", "d5", "e5", "Bf5"],
      ["e4", "c6", "Nf3", "d5", "exd5", "cxd5"],
      ["e4", "c6", "d4", "d5", "exd5", "cxd5"],
      ["e4", "c6", "d4", "d5", "f3", "dxe4"],
    ],
  },
  {
    id: "sicilian-black",
    name: "Sicilian Defense",
    color: "black",
    description: "A direct Sicilian starter against 1.e4.",
    lines: [
      ["e4", "c5", "Nf3", "d6", "d4", "cxd4"],
      ["e4", "c5", "Nf3", "Nc6", "d4", "cxd4"],
      ["e4", "c5", "c3", "Nf6"],
      ["e4", "c5", "Nc3", "Nc6"],
      ["e4", "c5", "f4", "d5"],
    ],
  },
];

function normalizeFen(fen: string) {
  return fen.split(" ").slice(0, 4).join(" ");
}

function moveToUci(move: { from: string; to: string; promotion?: string }) {
  return `${move.from}${move.to}${move.promotion ?? ""}`;
}

function buildTree(repertoire: Repertoire) {
  const tree: Record<string, Continuation[]> = {};

  for (const line of repertoire.lines) {
    const game = new Chess();

    for (const san of line) {
      const key = normalizeFen(game.fen());
      const move = game.move(san);

      if (!move) break;

      const continuation: Continuation = {
        san: move.san,
        uci: moveToUci(move),
        color: move.color,
        resultingFen: game.fen(),
      };

      const existing = tree[key] ?? [];
      const isDuplicate = existing.some((item) => item.uci === continuation.uci);
      tree[key] = isDuplicate ? existing : [...existing, continuation];
    }
  }

  return tree;
}

function getAccuracy(progress: Progress) {
  if (!progress.attempts) return 0;
  return Math.round((progress.correct / progress.attempts) * 100);
}

function randomItem<T>(items: T[]) {
  return items[Math.floor(Math.random() * items.length)];
}

function classNames(...classes: Array<string | false | null | undefined>) {
  return classes.filter(Boolean).join(" ");
}

export default function OpeningLabApp() {
  const [activeTab, setActiveTab] = useState<"home" | "train" | "review" | "progress" | "repertoire">("home");
  const [selectedRepertoireId, setSelectedRepertoireId] = useState(REPERTOIRES[0].id);
  const [fen, setFen] = useState(new Chess().fen());
  const [feedback, setFeedback] = useState("Choose a repertoire and begin training.");
  const [lastMove, setLastMove] = useState<string | null>(null);
  const [progress, setProgress] = useState<Progress>(DEFAULT_PROGRESS);
  const [boardWidth, setBoardWidth] = useState(340);

  const repertoire = REPERTOIRES.find((item) => item.id === selectedRepertoireId) ?? REPERTOIRES[0];
  const tree = useMemo(() => buildTree(repertoire), [repertoire]);
  const game = useMemo(() => new Chess(fen), [fen]);
  const userColor = repertoire.color === "white" ? "w" : "b";
  const isUserTurn = game.turn() === userColor;
  const key = normalizeFen(fen);
  const options = tree[key] ?? [];
  const expectedUserOptions = options.filter((move) => move.color === userColor);
  const mistakeList = Object.values(progress.mistakes).sort((a, b) => b.count - a.count);
  const accuracy = getAccuracy(progress);
  const positionsTrained = Object.keys(progress.trainedPositions).length;

  useEffect(() => {
    const raw = localStorage.getItem("opening-lab-progress");
    if (raw) {
      try {
        setProgress(JSON.parse(raw));
      } catch {
        setProgress(DEFAULT_PROGRESS);
      }
    }
  }, []);

  useEffect(() => {
    localStorage.setItem("opening-lab-progress", JSON.stringify(progress));
  }, [progress]);

  useEffect(() => {
    function resize() {
      const width = Math.min(window.innerWidth - 32, 430);
      setBoardWidth(Math.max(width, 280));
    }

    resize();
    window.addEventListener("resize", resize);
    return () => window.removeEventListener("resize", resize);
  }, []);

  useEffect(() => {
    if (activeTab !== "train") return;
    if (game.isGameOver()) {
      setFeedback("Game over. Restart this repertoire to train again.");
      return;
    }

    if (!isUserTurn) {
      const timer = window.setTimeout(() => {
        playOpponentMove();
      }, 550);

      return () => window.clearTimeout(timer);
    }
  }, [activeTab, fen, selectedRepertoireId]);

  function selectRepertoire(id: string) {
    setSelectedRepertoireId(id);
    setFen(new Chess().fen());
    setFeedback("Repertoire loaded. Start training.");
    setLastMove(null);
    setActiveTab("train");
  }

  function resetBoard() {
    setFen(new Chess().fen());
    setFeedback("Restarted. Find the first move.");
    setLastMove(null);
    setActiveTab("train");
  }

  function playOpponentMove() {
    const current = new Chess(fen);
    const currentKey = normalizeFen(current.fen());
    const candidates = tree[currentKey] ?? [];

    if (!candidates.length) {
      setFeedback("Line complete. Restart or choose another repertoire.");
      return;
    }

    const move = randomItem(candidates);
    setFen(move.resultingFen);
    setLastMove(move.uci);
    setFeedback(`Opponent played ${move.san}. Your move.`);
  }

  function onPieceDrop(sourceSquare: string, targetSquare: string) {
    if (!isUserTurn) return false;

    const current = new Chess(fen);
    const currentKey = normalizeFen(current.fen());
    const legalMove = current.move({
      from: sourceSquare,
      to: targetSquare,
      promotion: "q",
    });

    if (!legalMove) return false;

    const playedUci = moveToUci(legalMove);
    const expected = expectedUserOptions[0];
    const correct = expectedUserOptions.some((move) => move.uci === playedUci);

    if (correct) {
      setFen(current.fen());
      setLastMove(playedUci);
      setFeedback(`Correct: ${legalMove.san}.`);
      setProgress((prev) => ({
        ...prev,
        attempts: prev.attempts + 1,
        correct: prev.correct + 1,
        streak: prev.streak + 1,
        trainedPositions: {
          ...prev.trainedPositions,
          [currentKey]: true,
        },
      }));
      return true;
    }

    setFeedback(`Not quite. Best move: ${expected?.san ?? "no move saved"}.`);
    setProgress((prev) => {
      const old = prev.mistakes[currentKey];
      const nextMistake: Mistake = {
        fen,
        expectedMove: expected?.san ?? "Unknown",
        playedMove: legalMove.san,
        count: old ? old.count + 1 : 1,
        opening: repertoire.name,
      };

      return {
        ...prev,
        attempts: prev.attempts + 1,
        incorrect: prev.incorrect + 1,
        streak: 0,
        mistakes: {
          ...prev.mistakes,
          [currentKey]: nextMistake,
        },
      };
    });

    return false;
  }

  function practiceMistake(mistake: Mistake) {
    setFen(mistake.fen);
    setFeedback(`Review this position. Best move to find: ${mistake.expectedMove}.`);
    setActiveTab("train");
  }

  function clearProgress() {
    setProgress(DEFAULT_PROGRESS);
    setFeedback("Progress reset.");
    setFen(new Chess().fen());
    setLastMove(null);
  }

  const customSquareStyles: Record<string, React.CSSProperties> = {};
  if (lastMove && lastMove.length >= 4) {
    customSquareStyles[lastMove.slice(0, 2)] = { backgroundColor: "rgba(234, 179, 8, 0.45)" };
    customSquareStyles[lastMove.slice(2, 4)] = { backgroundColor: "rgba(234, 179, 8, 0.45)" };
  }

  return (
    <main className="min-h-screen bg-[#f7f7f4] text-stone-950">
      <div className="mx-auto flex min-h-screen max-w-md flex-col px-4 pb-24 pt-5">
        {activeTab === "home" && (
          <section className="space-y-6">
            <header className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-green-700 text-white shadow-sm">
                  <Beaker size={20} />
                </div>
                <div>
                  <h1 className="text-2xl font-bold tracking-tight">Opening Lab</h1>
                  <p className="text-sm text-stone-500">Train until the right move is automatic.</p>
                </div>
              </div>
              <Settings className="text-stone-500" size={22} />
            </header>

            <div className="grid grid-cols-2 gap-3">
              <MetricCard label="Today's Goal" value="20" sub="positions" icon={<Target size={19} />} />
              <MetricCard label="Accuracy" value={`${accuracy}%`} sub="all time" icon={<Trophy size={19} />} />
              <MetricCard label="Current Streak" value={String(progress.streak)} sub="correct" icon={<Flame size={19} />} />
              <MetricCard label="Mistakes Due" value={String(mistakeList.length)} sub="review now" icon={<XCircle size={19} />} warning />
            </div>

            <div>
              <div className="mb-3 flex items-center justify-between">
                <h2 className="text-lg font-bold">Continue Training</h2>
                <button onClick={() => setActiveTab("repertoire")} className="text-sm font-semibold text-green-700">
                  View all
                </button>
              </div>

              <div className="space-y-3">
                {REPERTOIRES.slice(0, 3).map((item, index) => (
                  <button
                    key={item.id}
                    onClick={() => selectRepertoire(item.id)}
                    className="flex w-full items-center gap-3 rounded-3xl border border-stone-200 bg-white p-3 text-left shadow-sm"
                  >
                    <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-stone-100 text-3xl">
                      {item.color === "white" ? "♙" : "♟"}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="font-bold">{item.name}</div>
                      <div className="text-sm text-stone-500">
                        {index + 3} moves • {item.lines.length} lines
                      </div>
                      <div className="mt-2 h-1.5 rounded-full bg-stone-200">
                        <div className="h-1.5 rounded-full bg-green-700" style={{ width: `${80 - index * 8}%` }} />
                      </div>
                    </div>
                    <ChevronRight className="text-stone-400" size={20} />
                  </button>
                ))}
              </div>
            </div>
          </section>
        )}

        {activeTab === "repertoire" && (
          <section className="space-y-5">
            <header>
              <h1 className="text-2xl font-bold tracking-tight">Repertoires</h1>
              <p className="text-sm text-stone-500">Choose the lines you want to drill.</p>
            </header>

            <div className="grid grid-cols-2 rounded-2xl bg-stone-200 p-1 text-sm font-semibold">
              <button className="rounded-xl bg-white py-2 text-green-700 shadow-sm">White</button>
              <button className="rounded-xl py-2 text-stone-500">Black</button>
            </div>

            <div className="flex items-center gap-2 rounded-2xl bg-white px-4 py-3 shadow-sm">
              <Search size={18} className="text-stone-400" />
              <span className="text-sm text-stone-400">Search repertoires</span>
            </div>

            <div className="space-y-3">
              {REPERTOIRES.map((item) => (
                <button
                  key={item.id}
                  onClick={() => selectRepertoire(item.id)}
                  className={classNames(
                    "flex w-full items-center gap-3 rounded-3xl border bg-white p-3 text-left shadow-sm",
                    item.id === selectedRepertoireId ? "border-green-700" : "border-stone-200"
                  )}
                >
                  <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-stone-100 text-3xl">
                    {item.color === "white" ? "♙" : "♟"}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="font-bold">{item.name}</div>
                    <div className="text-sm text-stone-500">
                      {item.lines.length} lines • {item.color}
                    </div>
                    <p className="mt-1 line-clamp-2 text-xs text-stone-400">{item.description}</p>
                  </div>
                  <ChevronRight className="text-stone-400" size={20} />
                </button>
              ))}
            </div>

            <button className="fixed bottom-24 right-5 flex h-14 items-center gap-2 rounded-full bg-green-700 px-5 font-bold text-white shadow-lg">
              <Plus size={19} /> Add
            </button>
          </section>
        )}

        {activeTab === "train" && (
          <section className="space-y-4">
            <header className="flex items-start justify-between">
              <div>
                <h1 className="text-xl font-bold tracking-tight">{repertoire.name}</h1>
                <p className="text-sm font-semibold text-green-700">
                  Training as {repertoire.color === "white" ? "White" : "Black"}
                </p>
              </div>
              <button onClick={resetBoard} className="rounded-2xl bg-white p-3 shadow-sm">
                <RotateCcw size={20} />
              </button>
            </header>

            <div className="grid grid-cols-3 gap-2">
              <SmallStat label="Turn" value={isUserTurn ? "You" : "Bot"} />
              <SmallStat label="Accuracy" value={`${accuracy}%`} />
              <SmallStat label="Streak" value={String(progress.streak)} />
            </div>

            <div className="overflow-hidden rounded-3xl bg-white p-2 shadow-sm">
              <Chessboard
                id="OpeningLabBoard"
                boardWidth={boardWidth}
                position={fen}
                onPieceDrop={onPieceDrop}
                boardOrientation={repertoire.color}
                customBoardStyle={{
                  borderRadius: "18px",
                  overflow: "hidden",
                }}
                customDarkSquareStyle={{ backgroundColor: "#759656" }}
                customLightSquareStyle={{ backgroundColor: "#eeeed2" }}
                customSquareStyles={customSquareStyles}
              />
            </div>

            <div className="rounded-3xl border border-stone-200 bg-white p-4 shadow-sm">
              <div className="flex items-start gap-3">
                {feedback.toLowerCase().includes("correct") ? (
                  <CheckCircle2 className="mt-0.5 text-green-700" size={24} />
                ) : feedback.toLowerCase().includes("not quite") ? (
                  <XCircle className="mt-0.5 text-red-600" size={24} />
                ) : (
                  <Target className="mt-0.5 text-green-700" size={24} />
                )}
                <div>
                  <div className="font-bold">
                    {isUserTurn ? "Your move" : "Opponent thinking"}
                  </div>
                  <p className="text-sm leading-6 text-stone-600">{feedback}</p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={playOpponentMove}
                disabled={isUserTurn}
                className="rounded-2xl bg-green-700 px-4 py-4 font-bold text-white shadow-sm disabled:opacity-40"
              >
                Force Opponent
              </button>
              <button
                onClick={resetBoard}
                className="rounded-2xl border border-stone-200 bg-white px-4 py-4 font-bold shadow-sm"
              >
                Restart
              </button>
            </div>

            <div className="rounded-3xl bg-stone-900 p-4 text-white">
              <div className="text-sm text-stone-300">Expected move options</div>
              <div className="mt-2 text-lg font-bold">
                {expectedUserOptions.length
                  ? expectedUserOptions.map((move) => move.san).join(" / ")
                  : isUserTurn
                  ? "Line complete"
                  : "Waiting for opponent"}
              </div>
            </div>
          </section>
        )}

        {activeTab === "review" && (
          <section className="space-y-5">
            <header>
              <h1 className="text-2xl font-bold tracking-tight">Review Mistakes</h1>
              <p className="text-sm text-stone-500">Drill the positions you missed most.</p>
            </header>

            {mistakeList.length === 0 ? (
              <div className="rounded-3xl bg-white p-6 text-center shadow-sm">
                <CheckCircle2 className="mx-auto mb-3 text-green-700" size={40} />
                <h2 className="text-lg font-bold">No mistakes due</h2>
                <p className="mt-2 text-sm text-stone-500">Train a repertoire and your missed positions will appear here.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {mistakeList.map((mistake) => (
                  <button
                    key={mistake.fen}
                    onClick={() => practiceMistake(mistake)}
                    className="w-full rounded-3xl border border-stone-200 bg-white p-4 text-left shadow-sm"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <div className="font-bold">{mistake.opening}</div>
                        <div className="mt-1 text-sm text-stone-500">
                          Best move: <span className="font-bold text-green-700">{mistake.expectedMove}</span>
                        </div>
                        <div className="text-sm text-stone-500">You played: {mistake.playedMove}</div>
                      </div>
                      <span className="rounded-full bg-red-50 px-3 py-1 text-xs font-bold text-red-700">
                        Missed {mistake.count}x
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </section>
        )}

        {activeTab === "progress" && (
          <section className="space-y-5">
            <header className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold tracking-tight">Progress</h1>
                <p className="text-sm text-stone-500">Your training snapshot.</p>
              </div>
              <button onClick={clearProgress} className="rounded-2xl bg-white px-3 py-2 text-sm font-bold shadow-sm">
                Reset
              </button>
            </header>

            <div className="grid grid-cols-3 gap-2">
              <MetricCard compact label="Accuracy" value={`${accuracy}%`} sub="overall" icon={<Target size={18} />} />
              <MetricCard compact label="Trained" value={String(positionsTrained)} sub="positions" icon={<BookOpen size={18} />} />
              <MetricCard compact label="Queue" value={String(mistakeList.length)} sub="due" icon={<XCircle size={18} />} warning />
            </div>

            <div className="rounded-3xl bg-white p-4 shadow-sm">
              <div className="mb-4 flex items-center justify-between">
                <h2 className="font-bold">Accuracy by Opening</h2>
                <span className="text-sm font-semibold text-green-700">View all</span>
              </div>
              <div className="space-y-3">
                {REPERTOIRES.map((item, index) => {
                  const fake = Math.max(48, accuracy - index * 5 + 12);
                  return (
                    <div key={item.id}>
                      <div className="mb-1 flex justify-between text-sm">
                        <span>{item.name}</span>
                        <span className="font-bold">{fake}%</span>
                      </div>
                      <div className="h-2 rounded-full bg-stone-200">
                        <div className="h-2 rounded-full bg-green-700" style={{ width: `${fake}%` }} />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="rounded-3xl bg-white p-4 shadow-sm">
              <h2 className="mb-3 font-bold">Weekly Training Sessions</h2>
              <div className="flex h-36 items-end gap-3">
                {[45, 35, 30, 80, 50, 25, 38].map((height, index) => (
                  <div key={index} className="flex flex-1 flex-col items-center gap-2">
                    <div className="w-full rounded-t-lg bg-green-700" style={{ height: `${height}%` }} />
                    <span className="text-xs text-stone-500">{["M", "T", "W", "T", "F", "S", "S"][index]}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="rounded-3xl bg-white p-4 shadow-sm">
              <h2 className="mb-3 font-bold">Most Missed Positions</h2>
              {mistakeList.length ? (
                <div className="space-y-3">
                  {mistakeList.slice(0, 3).map((mistake, index) => (
                    <div key={mistake.fen} className="flex items-center justify-between rounded-2xl bg-stone-50 p-3">
                      <span className="text-sm">
                        {index + 1}. {mistake.opening}
                      </span>
                      <span className="text-sm font-bold text-red-700">Missed {mistake.count}x</span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-stone-500">No missed positions yet.</p>
              )}
            </div>
          </section>
        )}
      </div>

      <BottomNav activeTab={activeTab} setActiveTab={setActiveTab} />
    </main>
  );
}

function MetricCard({
  label,
  value,
  sub,
  icon,
  warning = false,
  compact = false,
}: {
  label: string;
  value: string;
  sub: string;
  icon: React.ReactNode;
  warning?: boolean;
  compact?: boolean;
}) {
  return (
    <div className={classNames("rounded-3xl bg-white shadow-sm", compact ? "p-3" : "p-4")}>
      <div className={classNames("mb-2", warning ? "text-orange-600" : "text-green-700")}>{icon}</div>
      <div className="text-xs text-stone-500">{label}</div>
      <div className={classNames("font-black tracking-tight", compact ? "text-xl" : "text-3xl")}>{value}</div>
      <div className="text-xs text-stone-400">{sub}</div>
    </div>
  );
}

function SmallStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl bg-white p-3 text-center shadow-sm">
      <div className="text-xs text-stone-500">{label}</div>
      <div className="font-black">{value}</div>
    </div>
  );
}

function BottomNav({
  activeTab,
  setActiveTab,
}: {
  activeTab: string;
  setActiveTab: (tab: "home" | "train" | "review" | "progress" | "repertoire") => void;
}) {
  const tabs = [
    { id: "home", label: "Home", icon: Home },
    { id: "train", label: "Train", icon: Target },
    { id: "review", label: "Review", icon: CheckCircle2 },
    { id: "progress", label: "Progress", icon: BarChart3 },
    { id: "repertoire", label: "Repertoire", icon: BookOpen },
  ] as const;

  return (
    <nav className="fixed inset-x-0 bottom-0 z-50 border-t border-stone-200 bg-white/95 px-2 pb-4 pt-2 backdrop-blur">
      <div className="mx-auto grid max-w-md grid-cols-5 gap-1">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const active = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={classNames(
                "flex flex-col items-center gap-1 rounded-2xl px-2 py-2 text-xs font-semibold",
                active ? "bg-green-50 text-green-700" : "text-stone-500"
              )}
            >
              <Icon size={19} />
              {tab.label}
            </button>
          );
        })}
      </div>
    </nav>
  );
}
